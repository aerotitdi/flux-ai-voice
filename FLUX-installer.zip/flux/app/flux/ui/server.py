"""HTTP-сервер консоли на стандартной библиотеке (без тяжёлых зависимостей).

SSE-поток /api/events отдаёт события состояния, транскрипт и журнал инструментов
в реальном времени. Настройки пишутся в config.json (тот же файл читает меню
Flux.exe), поэтому изменения из консоли и из меню согласованы.
"""
from __future__ import annotations

import json
import queue
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Optional
from urllib.parse import parse_qs, urlparse

from .. import config, logger
from ..audio import devices as devmod
from ..tools import registry

log = logger.get_logger("flux.ui")

STATIC = Path(__file__).resolve().parent / "static"


def _another_flux_here(host: str, port: int) -> bool:
    """Проверяет, не сидит ли на порту уже работающий FLUX (второй экземпляр)."""
    import json as _json
    import socket

    try:
        with socket.create_connection((host or "127.0.0.1", port), timeout=1.5) as s:
            s.sendall(f"GET /api/state HTTP/1.0\r\nHost: {host}\r\n\r\n".encode())
            data = b""
            while len(data) < 65536:
                chunk = s.recv(4096)
                if not chunk:
                    break
                data += chunk
    except OSError:
        return False
    body = data.split(b"\r\n\r\n", 1)[-1]
    try:
        state = _json.loads(body.decode("utf-8", "replace"))
    except Exception:
        return False
    return isinstance(state, dict) and ("state" in state or "app" in state
                                        or "flux" in str(state)[:400].lower())


class UiServer:
    def __init__(self, app: Any) -> None:
        self.app = app
        self._srv: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self.subscribers: list[queue.Queue] = []
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ sse
    def broadcast(self, event: str, **data: Any) -> None:
        payload = {"event": event, **data}
        with self._lock:
            subs = list(self.subscribers)
        for q in subs:
            try:
                q.put_nowait(payload)
            except queue.Full:
                pass

    def _subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=500)
        with self._lock:
            self.subscribers.append(q)
        return q

    def _unsubscribe(self, q: queue.Queue) -> None:
        with self._lock:
            if q in self.subscribers:
                self.subscribers.remove(q)

    # ----------------------------------------------------------------- server
    def start(self) -> bool:
        if not config.get("ui.enabled", True):
            return False
        host = str(config.get("ui.host", "127.0.0.1"))
        port = int(config.get("ui.port", 8790))
        handler = _make_handler(self)
        try:
            self._srv = ThreadingHTTPServer((host, port), handler)
        except OSError as e:
            if _another_flux_here(host, port):
                log.error(
                    "порт %s уже занят ДРУГИМ запущенным FLUX: второй экземпляр "
                    "будет драться за микрофон и ключи. Закрой первый "
                    "(меню -> «Выход» или Диспетчер задач -> python.exe) "
                    "и запусти заново. Ошибка: %s", port, e)
            else:
                log.error("консоль не стартовала на %s:%s: %s", host, port, e)
            return False
        self._srv.daemon_threads = True
        self._thread = threading.Thread(target=self._srv.serve_forever,
                                        name="flux-ui", daemon=True)
        self._thread.start()
        log.info("консоль FLUX: http://%s:%s/", host, port)
        return True

    def stop(self) -> None:
        if self._srv is not None:
            self._srv.shutdown()
            self._srv.server_close()
            self._srv = None


def _make_handler(ui: UiServer):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "FluxConsole/1.0"

        # ------------------------------------------------------------ helpers
        def _json(self, obj: Any, code: int = 200) -> None:
            data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _text(self, body: bytes, ctype: str, code: int = 200) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _body(self) -> dict:
            length = int(self.headers.get("Content-Length", 0) or 0)
            raw = self.rfile.read(length) if length else b"{}"
            try:
                obj = json.loads(raw.decode("utf-8"))
                return obj if isinstance(obj, dict) else {}
            except Exception:
                return {}

        def log_message(self, fmt, *args):  # не спамим в консоль
            pass

        # ---------------------------------------------------------------- GET
        def do_GET(self):
            parsed = urlparse(self.path)
            path = parsed.path.rstrip("/") or "/"
            if path == "/":
                html = (STATIC / "index.html").read_bytes()
                return self._text(html, "text/html; charset=utf-8")
            if path == "/api/state":
                return self._json(ui.app.public_state())
            if path == "/api/config":
                return self._json(config.as_dict())
            if path == "/api/models":
                # выбор моделей в настройках консоли: понимание речи (STT)
                # и ИИ для ответа (LLM) — только то, что реально доступно
                try:
                    from .. import models as models_mod
                    return self._json(models_mod.catalog())
                except Exception as e:
                    return self._json({"error": str(e),
                                       "stt": {"models": [], "current": ""},
                                       "llm": {"models": [], "current": ""}})
            if path == "/api/voices":
                try:
                    from ..tts.engine import list_voices
                    voices = [{"short": v.short_name, "label": v.label,
                               "locale": v.locale, "gender": v.gender}
                              for v in list_voices()]
                except Exception as e:
                    voices = []
                    return self._json({"error": str(e), "voices": []})
                return self._json({"voices": voices})
            if path == "/api/devices":
                try:
                    devs = [{"index": d.index, "name": d.name,
                             "channels": d.channels, "host": d.host_api,
                             "default": d.is_default_input,
                             "loopback": d.is_loopback}
                            for d in devmod.list_input_devices()]
                except Exception as e:
                    devs = []
                    return self._json({"error": str(e), "devices": []})
                return self._json({"devices": devs})
            if path == "/api/last":
                return self._json(ui.app.last_snapshot())
            if path == "/api/history":
                qs = parse_qs(parsed.query)
                limit = int(qs.get("limit", ["40"])[0])
                return self._json({"history": ui.app.recent_history(limit)})
            if path == "/api/tools":
                return self._json({"tools": [
                    {"name": s["function"]["name"],
                     "description": s["function"]["description"]}
                    for s in registry.schemas()]})
            if path == "/api/events":
                return self._sse()
            return self._json({"error": "not found"}, 404)

        # ---------------------------------------------------------------- SSE
        def _sse(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            q = ui._subscribe()
            try:
                self.wfile.write(b": connected\n\n")
                self.wfile.flush()
                while True:
                    try:
                        payload = q.get(timeout=20)
                    except queue.Empty:
                        self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
                        continue
                    data = json.dumps(payload, ensure_ascii=False)
                    self.wfile.write(f"data: {data}\n\n".encode("utf-8"))
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                ui._unsubscribe(q)

        # --------------------------------------------------------------- POST
        def do_POST(self):
            parsed = urlparse(self.path)
            path = parsed.path.rstrip("/")
            body = self._body()
            if path == "/api/config":
                try:
                    for dotted, value in (body.get("set") or {}).items():
                        config.set_value(dotted, value, save=False)
                    config.save_config()
                    ui.app.on_config_changed()
                    return self._json({"ok": True})
                except Exception as e:
                    return self._json({"ok": False, "error": str(e)}, 400)
            if path == "/api/action":
                action = body.get("action")
                try:
                    result = ui.app.console_action(action, body)
                    return self._json({"ok": True, "result": result})
                except Exception as e:
                    return self._json({"ok": False, "error": str(e)}, 400)
            if path == "/api/chat":
                text = str(body.get("text", ""))
                speak = bool(body.get("speak", False))
                browser_speak = bool(body.get("browser_speak", False))
                # пилюли в стиле DeepSeek: «Глубокое мышление» и «Умный поиск»
                think = bool(body.get("think", False))
                web = bool(body.get("web", False))
                try:
                    res = ui.app.console_chat(text, speak=speak,
                                              browser_speak=browser_speak,
                                              think=think, web=web)
                    return self._json(res if res.get("ok") else res,
                                      200 if res.get("ok") else 409)
                except Exception as e:
                    return self._json({"ok": False, "error": str(e)}, 500)
            if path == "/api/confirm":
                cid = body.get("confirm_id")
                answer = bool(body.get("answer"))
                ok = ui.app.resolve_confirmation(cid, answer)
                return self._json({"ok": ok})
            return self._json({"error": "not found"}, 404)

    return Handler
