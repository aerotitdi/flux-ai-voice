"""FLUX — оркестратор голосового агента (словесная архитектура).

Поток данных (без порогов громкости и акустической тишины — в комнате тишины
не бывает, решает ТОЛЬКО whisper):

  микрофон (сырой звук БЕЗ обработки: AGC/шумодава нет, в whisper как есть)
    -> кольцо звука (~70 c) -> курсор: каждый кусок прослушивается ОДИН раз
    -> кусок НАПРЯМУЮ уходит в whisper (локальный faster-whisper, либо
       whisper-эндпоинт из настроек) и возвращает СЛОВА С МЕТКАМИ ВРЕМЕНИ
    -> voice.utterance.UtteranceAssembler: копилка слов; конец фразы решает
       САМ whisper — когда после последнего слова прошло stream.word_idle_sec
       (5 c) прослушанного звука (шкала времени whisper, не громкость)
    -> voice.stream.WordStream отдаёт ОДНО ЦЕЛОЕ сообщение (Utterance):
         IDLE : ищем «флюкс» в целом сообщении;
                «флюкс + команда» -> команда модели сразу;
                только «флюкс»    -> AWAKE («Слушаю»);
         AWAKE: сообщение копится ЦЕЛИКОМ; whisper замолчал -> ОДНА отправка
                всего текста модели, сессия в IDLE (никаких отрывков)

Отдельно: flux.whisper_server поднимает локальный эндпоинт
POST /v1/audio/transcriptions, чтобы ВНЕШНИЙ whisper мог сам ОТПРАВИТЬ
звук/текст Флюксу (whisper — библиотека и сам ничего никуда не шлёт).
    -> агент (Ollama + 61 инструмент), стриминг ответа
    -> парсер *-...-* -> озвучка кусками (ключевые TTS -> edge -> SAPI5)
    -> на время озвучки кольцо не читается (анти-эхо); barge-in опционально

Push-to-talk: зажал Numpad 9 -> кольцо помечается; отпустил -> весь кусок
напрямую в whisper -> команда модели (без слова-активации).
"""
from __future__ import annotations

import argparse
import os
import sys
import threading
import time
import uuid
from typing import Optional

import numpy as np

from . import config, logger, paths, prompts
from .audio.capture import MicCapture
from .audio.devices import (assert_is_microphone, configured_spec,
                          resolve_input_device)
from .audio.player import Player
from .hotkey import HotkeyListener
from .llm.agent import Agent, Chunk
from .llm.ollama_client import OllamaClient
from .memory.store import MemoryStore
from .stt.router import STTRouter
from .tray import TrayIcon, open_console
from .tts.engine import TTSRouter
from .ui.server import UiServer
from .voice.stream import WordStream
from .voice.utterance import Utterance
from .txt_bridge import TxtBridge
from .whisper_server import WhisperServer
from .wakeword import WakeDetector

log = logger.get_logger("flux.main")

IDLE, AWAKE, THINKING, SPEAKING, CONFIRM, PTT = (
    "idle", "awake", "thinking", "speaking", "confirm", "ptt")

_STATE_RU = {IDLE: "слушаю (микрофон → whisper)", AWAKE: "слушаю команду", THINKING: "думаю",
             SPEAKING: "говорю", CONFIRM: "жду подтверждения", PTT: "зажата клавиша"}


def _beep(freq: float = 880.0, ms: int = 90, sr: int = 24000,
          volume: float = 0.25) -> np.ndarray:
    n = int(sr * ms / 1000)
    t = np.arange(n) / sr
    env = np.linspace(1.0, 0.0, n) ** 2
    return (np.sin(2 * np.pi * freq * t) * env * volume).astype(np.float32)


class FluxApp:
    def __init__(self, enable_ui: bool = True, enable_tray: bool = True,
                 greet: bool = True) -> None:
        paths.ensure_dirs()
        config.load()
        self.state = IDLE
        self.state_lock = threading.Lock()
        self.level = 0.0
        self.last_transcript = ""
        self.last_answer = ""
        self.last_whisper_words = ""

        self.store = MemoryStore()
        self.conv_id = self.store.new_conversation(
            time.strftime("Диалог %d.%m %H:%M"))
        self.client = OllamaClient()
        self.agent = Agent(client=self.client, store=self.store)
        self.agent.ctx.confirm = self._confirm_request
        self.agent.ctx.emit = lambda *a, **kw: self.ui.broadcast("tool", **kw)

        self.tts = TTSRouter()
        self.player = Player(volume=float(config.get("tts.volume", 1.0)),
                             on_speech_start=self._on_speech_start,
                             on_speech_end=self._on_speech_end)
        self.tts_queue: list[Chunk] = []
        self._tts_cv = threading.Condition()
        self._stop = threading.Event()

        self.cmd_stt = STTRouter()          # local faster-whisper -> ollama -> api
        self.wake_det = self._build_wake_detector()
        self.stream = self._build_word_stream()
        # курсор звука: сколько секунд микрофона уже прослушал whisper.
        # Каждый кусок обрабатывается РОВНО ОДИН раз (без повторов и дыр).
        self._cursor_ts = 0.0
        self._last_external_at = 0.0
        self.last_utterance: Optional[Utterance] = None
        # «как whisper отправляет Флюксу»: локальный HTTP-приёмник звука/текста
        self.whisper_srv = WhisperServer(
            transcribe=lambda audio, sr: self.cmd_stt.transcribe(audio, sr),
            on_words=self.on_external_words,
            models_provider=lambda: [str(config.get("stt.local.model", "")),
                                     str(config.get("stt.ollama.model", ""))])

        # «whisper сохранил .txt»: наблюдатель папки data\inbox — третий
        # способ передать Флюксу готовый текст (после библиотеки и HTTP)
        self.txt_bridge = TxtBridge(self.on_external_message)

        self.capture: Optional[MicCapture] = None
        self.hotkey = HotkeyListener(self._ptt_start, self._ptt_release,
                                     self._cancel)
        self.ui = UiServer(self)
        self.tray: Optional[TrayIcon] = None
        self._enable_ui = enable_ui
        self._enable_tray = enable_tray
        self._greet = greet

        self._ptt_mark = 0.0
        self._barge_frames = 0
        self._last_beep_at = 0.0
        self._last_spoken_text = ""
        self._last_tts_end = 0.0
        self._last_tool_log: list = []

        self._confirm_lock = threading.Lock()
        self._confirm_event = threading.Event()
        self._confirm_answer: Optional[bool] = None
        self._confirm_id: Optional[str] = None

    # ------------------------------------------------------------- build/help
    def _build_word_stream(self) -> WordStream:
        """Поток слов: таймер конца фразы и порог быстрого «Слушаю» из конфига."""
        return WordStream(
            self.wake_det if hasattr(self, "wake_det") else self._build_wake_detector(),
            word_idle_sec=float(config.get("stream.word_idle_sec", 5.0)),
            keep_sec=float(config.get("stream.keep_sec", 8.0)),
            wake_idle_sec=float(config.get("audio.wake_silence_sec", 1.2)),
            max_message_sec=float(config.get("stream.max_message_sec", 60.0)),
            awake_timeout_sec=float(config.get("wake.awake_timeout_sec", 15.0)),
            on_state=self._on_stream_state)

    def _build_wake_detector(self) -> WakeDetector:
        return WakeDetector(
            words=tuple(config.get("wake.words", ["флюкс"]) or ["флюкс"]),
            sensitivity=int(config.get("wake.sensitivity", 0)),
            require_at_start=bool(config.get("wake.require_at_start", True)),
            max_leading_fillers=int(config.get("wake.max_leading_fillers", 1)),
        )

    def _set_state(self, name: str) -> None:
        with self.state_lock:
            self.state = name
        self.ui.broadcast("state", state=name, label=_STATE_RU.get(name, name))
        if self.tray is not None:
            try:
                self.tray.set_state(_STATE_RU.get(name, name))
            except Exception:
                pass

    def _on_stream_state(self, st: str) -> None:
        self._set_state(AWAKE if st == AWAKE else IDLE)

    def _feedback(self, freq: float, cooldown: float = 2.0) -> None:
        """Короткий сигнал только на осмысленные события, не чаще 1 раза в 2 c."""
        now = time.monotonic()
        if now - self._last_beep_at < cooldown:
            return
        self._last_beep_at = now
        if config.get("audio.feedback_sounds", True):
            self.player.enqueue_pcm(_beep(freq), 24000)

    # ----------------------------------------------------------------- preflight
    def _preflight_keys(self) -> None:
        """Ключи из конфига: валидны ли (один быстрый запрос на провайдера).

        Не блокируем старт: при недоступном ключе FLUX продолжает работать
        локальными движками, а в лог и консоль пишется ПРИЧИНА (код + что делать).
        """
        from . import keys as keymod
        have = {n: str(config.get(f"keys.{n}", "") or "")
                for n in keymod.PROBES}
        if not any(have.values()):
            log.info("API-ключи не заданы: STT = локальный faster-whisper, "
                     "TTS = edge-tts/SAPI5 (всё офлайн)")
            return

        def worker():
            try:
                results = keymod.check_all(lambda n: have.get(n, ""))
            except Exception as e:  # pragma: no cover - сеть может всё сломать
                log.warning("проверка ключей не удалась: %s", e)
                return
            for name, r in results.items():
                if r.get("ok"):
                    log.info("ключ %s (%s): %s", name, r.get("masked", ""),
                             r.get("detail", "валиден"))
                else:
                    log.warning("ключ %s НЕ РАБОТАЕТ -> %s", name,
                                r.get("detail", ""))
            try:
                self.ui.broadcast("keys_status", **{
                    n: keymod.short(r) for n, r in results.items()})
            except Exception:  # pragma: no cover
                pass

        threading.Thread(target=worker, name="flux-keys-preflight",
                         daemon=True).start()

    # ------------------------------------------------------------------ start
    def start(self) -> None:
        log.info("FLUX стартует (дом: %s)", paths.HOME)
        try:
            (paths.DATA_DIR / "flux.pid").write_text(str(os.getpid()),
                                                     encoding="utf-8")
        except OSError:
            pass
        self.player.start()
        threading.Thread(target=self._tts_worker, name="flux-tts-worker",
                         daemon=True).start()
        threading.Thread(target=self._timer_worker, name="flux-timers",
                         daemon=True).start()
        threading.Thread(target=self._stream_worker, name="flux-whisper-stream",
                         daemon=True).start()

        self._preflight_keys()
        dev = resolve_input_device(configured_spec())
        if dev is None:
            log.error("МИКРОФОН НЕ НАЙДЕН: голосовой ввод недоступен")
        else:
            try:
                assert_is_microphone(dev)
                self.capture = MicCapture(
                    dev.index,
                    sample_rate=int(config.get("audio.sample_rate", 16000)),
                    block_ms=int(config.get("audio.block_ms", 30)),
                    on_frame=self._on_frame, name=dev.name)
                self.capture.start()
                log.info("микрофон: %s (индекс %s)", dev.name, dev.index)
            except ValueError as e:
                log.error("%s", e)
        log.info("горячая клавиша: Numpad 9 (backend=%s)", self.hotkey.start())

        if self._enable_ui:
            self.ui.start()
        try:
            self.whisper_srv.start()
        except Exception as e:                  # pragma: no cover
            log.warning("whisper-сервер не поднялся: %s", e)
        try:
            if self.txt_bridge.start():
                log.info("txt-мост: папка %s (положи .txt — уйдёт ИИ целиком)",
                         self.txt_bridge.directory)
        except Exception as e:                  # pragma: no cover
            log.warning("txt-мост не поднялся: %s", e)
        if self._enable_tray:
            self.tray = TrayIcon(open_console, self.listen_now,
                                 self.stop_speaking, self.shutdown)
            self.tray.start()
        if self._greet:
            greeting = str(config.get("assistant.greeting", "") or "")
            if greeting:
                threading.Thread(target=self.say, args=(greeting,),
                                 daemon=True).start()

    def run_forever(self) -> None:
        try:
            while not self._stop.is_set():
                time.sleep(0.5)
        except KeyboardInterrupt:
            log.info("Ctrl+C - остановка")
        finally:
            self.shutdown()

    def shutdown(self) -> None:
        if self._stop.is_set():
            return
        self._stop.set()
        log.info("FLUX останавливается")
        try:
            if self.capture:
                self.capture.stop()
            self.hotkey.stop()
            self.player.stop()
            self.ui.stop()
            self.whisper_srv.stop()
            if self.tray:
                self.tray.stop()
            self.store.close()
            (paths.DATA_DIR / "flux.pid").unlink(missing_ok=True)
        except Exception:
            log.exception("ошибка при остановке")

    # ------------------------------------------------------------- mic frames
    def _on_frame(self, data: np.ndarray, rms: float) -> None:
        """Только уровень + barge-in. Никаких порогов для распознавания."""
        self.level = rms
        if (self.player.speaking
                and bool(config.get("audio.barge_in", False))
                and not self._in_tail_window()):
            thr = float(config.get("audio.barge_rms", 0.10))
            if rms > thr:
                self._barge_frames += 1
                if self._barge_frames >= 8:      # ~0.25 c устойчивой речи
                    self._barge_frames = 0
                    log.info("barge-in: пользователь перебил, останавливаю речь")
                    self.player.interrupt()
                    self.ui.broadcast("barge_in")
            else:
                self._barge_frames = 0

    def _in_tail_window(self) -> bool:
        if not self._last_tts_end:
            return False
        return (time.monotonic() - self._last_tts_end
                < float(config.get("audio.tail_guard_sec", 0.5)))

    # ------------------------------------------------------- whisper streaming
    def _consume_chunk(self) -> None:
        """Один шаг потока: НОВЫЙ кусок звука -> whisper -> слова -> сообщение.

        Звук берётся СТРОГО после курсора (каждый участок прослушивается один
        раз) и уходит в whisper СЫРЫМ. Дальше решает whisper: вернул слова —
        копим; слов нет — идёт отсчёт тишины ПО ШКАЛЕ WHISPER; как только
        после последнего слова прошло stream.word_idle_sec — сообщение
        считается ЗАКОНЧЕННЫМ и уходит модели ЦЕЛИКОМ, одним текстом.
        """
        cap = self.capture
        if cap is None:
            return
        with self.state_lock:
            st = self.state
        if st in (THINKING, CONFIRM, PTT, SPEAKING) or self.player.speaking:
            return                            # анти-эхо: себя не слушаем
        if self._in_tail_window():
            self._cursor_ts = time.monotonic()   # хвост озвучки не слушаем
            return
        sr = int(config.get("audio.sample_rate", 16000))
        now = time.monotonic()
        span = float(getattr(cap, "_ring_span", 70.0) or 70.0)
        max_win = min(float(config.get("stream.max_window_sec", 30.0)), span)
        if not self._cursor_ts or now - self._cursor_ts > max_win:
            # FLUX долго не слушал (говорил/думал) или кольцо уже затёрло
            # старьё: начинаем слушать с свежего звука, без дыр в шкале
            self._cursor_ts = now - min(max_win, span * 0.5)
            cap.clear_ring()
        t0 = self._cursor_ts
        audio = cap.get_window_since(t0)
        max_chunk = float(config.get("stream.max_chunk_sec", 10.0))
        if audio.size > int(sr * max_chunk):
            # whisper не успевает: берём самый свежий кусок, старьё пропускаем
            audio = audio[-int(sr * max_chunk):]
            t0 = now - audio.size / float(sr)
        have = audio.size / float(sr)
        if have < 0.3:
            return                            # ещё не накопилось — ждём
        t1 = t0 + have
        try:
            tr = self.cmd_stt.transcribe(audio, sr)
        except Exception as e:
            log.warning("whisper-поток: сбой транскрипции: %s", e)
            self._cursor_ts = time.monotonic()   # кусок пропущен, не зацикливаемся
            return
        self._cursor_ts = t1
        # курсор слегка откатываем, если whisper вернул меньше звука, чем дали
        win = float(getattr(tr, "window_sec", 0.0) or 0.0) or have
        if win < have - 0.05:
            self._cursor_ts = max(t0, t1 - (have - win) - 0.05)
        text = (tr.text or "").strip()
        self.last_whisper_words = text or self.stream.partial
        self.ui.broadcast("whisper_words", text=self.last_whisper_words,
                          engine=tr.engine, model=getattr(tr, "model", ""),
                          partial=self.stream.partial,
                          silence_left=round(self.stream.silence_left, 2))
        if text:
            log.info("whisper[%s/%s]: %r", tr.engine,
                     getattr(tr, "model", ""), text)
        for ev in self.stream.feed(text=text, tr=tr, end_sec=t1, sec=have):
            self._handle_stream_event(ev)

    def on_external_words(self, text: str) -> None:
        """Текст ПРИСЛАЛ внешний whisper (POST на whisper-сервер FLUX).

        Это и есть ответ на «как whisper отправит Флюксу»: он шлёт звук или
        готовый текст на http://127.0.0.1:<порт>/v1/audio/transcriptions,
        а FLUX кладёт его в ту же копилку сообщения. Пустая строка = «whisper
        замолчал»: она тоже важна — по ней идёт отсчёт конца фразы.
        """
        text = (text or "").strip()
        now = time.monotonic()
        prev = self._last_external_at or now
        self._last_external_at = now
        pos = max(self.stream.asm.now, prev, now)
        if text:
            log.info("внешний whisper прислал: %r", text)
            self.last_whisper_words = text
            self.ui.broadcast("whisper_words", text=text, engine="external")
        for ev in self.stream.feed(text=text, end_sec=pos):
            self._handle_stream_event(ev)

    def on_external_message(self, text: str, source: str = "txt-bridge") -> bool:
        """ГОТОВОЕ сообщение извне (.txt из data\\inbox): сразу целиком ИИ.

        В отличие от on_external_words (поток слов внешнего whisper с таймером
        тишины), файл .txt — это УЖЕ законченное сообщение: таймер не нужен,
        слово «флюкс» (если его написали) убираем, остальное отправляем как
        одно целое Utterance — тем же путём, что голосовое сообщение.
        """
        from .stt.filter import is_filler_only, strip_hallucination_tail
        from .voice.utterance import utterance_from_text

        raw = strip_hallucination_tail(" ".join((text or "").split()))
        if not raw or is_filler_only(raw):
            log.info("txt-мост: %r отброшено фильтром (галлюцинация/пустышка)",
                     raw[:80])
            return False
        command = raw
        try:
            m = self.wake_det.match(raw)
            if m is not None and m.matched and m.command.strip():
                command = m.command.strip()
        except Exception:                        # pragma: no cover
            pass
        utt = utterance_from_text(command, engine=source)
        self.last_utterance = utt
        self.last_whisper_words = command
        log.info("txt-мост: СООБЩЕНИЕ ЦЕЛИКОМ (%d слов): %r", utt.word_count,
                 utt.text)
        self.ui.broadcast("utterance", text=utt.text, words=utt.word_count,
                          silence=0.0, engine=source, model="txt")
        self._feedback(1560)
        self._process_command(command)
        return True

    def _handle_stream_event(self, ev) -> None:
        if ev.kind == "wake_only":
            self._feedback(1560)
            self.say("Слушаю.")
        elif ev.kind == "send" and ev.text.strip():
            utt = getattr(ev, "utterance", None)
            if utt is not None:
                self.last_utterance = utt
                log.info("СООБЩЕНИЕ ЦЕЛИКОМ (%d записей, тишина %.1f c, "
                         "движок %s/%s): %r", utt.word_count, utt.silence_sec,
                         utt.engine or "?", utt.model or "?", utt.text)
                self.ui.broadcast("utterance", text=utt.text,
                                  words=utt.word_count,
                                  silence=utt.silence_sec,
                                  engine=utt.engine, model=utt.model)
            self._feedback(1560)
            self._process_command(ev.text)

    def _stream_worker(self) -> None:
        """ЗВУКИ -> whisper -> СЛОВА -> ОДНО целое сообщение. Без порогов.

        Пока пользователь молчит, прослушиваем новый звук раз в chunk_sec (3 c);
        как только сообщение начало собираться — проверяем чаще (1 c), чтобы
        не добавить лишней задержки к правилу «5 секунд молчания».
        """
        while not self._stop.is_set():
            busy = bool(self.stream.partial)
            time.sleep(1.0 if busy
                       else float(config.get("stream.chunk_sec", 3.0)))
            try:
                if self.stream.tick():
                    log.info("«Слушаю» без продолжения %.0f c — закрываю сессию",
                             float(config.get("wake.awake_timeout_sec", 15.0)))
                    self.ui.broadcast("awake_timeout")
                self._consume_chunk()
            except Exception:
                log.exception("whisper-поток: сбой шага, продолжаю")

    # -------------------------------------------------------------------- PTT
    def _ptt_start(self) -> None:
        with self.state_lock:
            self.state = PTT
        self._ptt_mark = time.monotonic()
        if self.capture:
            self.capture.clear_ring()
        self.ui.broadcast("state", state=PTT, label=_STATE_RU[PTT])
        self._feedback(1180, cooldown=0.0)

    def _ptt_release(self) -> None:
        cap = self.capture
        mark, self._ptt_mark = self._ptt_mark, 0.0
        with self.state_lock:
            if self.state == PTT:
                self.state = IDLE
        if cap is None or not mark:
            return
        audio = cap.get_window_since(mark)
        if audio.size == 0:
            return

        def work() -> None:
            sr = int(config.get("audio.sample_rate", 16000))
            tr = self.cmd_stt.transcribe(audio, sr)
            text = (tr.text or "").strip()
            self.last_whisper_words = text
            self.ui.broadcast("whisper_words", text=text, engine=tr.engine)
            if text:
                self.ui.broadcast("transcript", text=text)
                self.last_transcript = text
                self._process_command(text)

        threading.Thread(target=work, daemon=True).start()

    def _cancel(self) -> None:
        self.stream.reset()
        self.player.interrupt()
        self._set_state(IDLE)
        self._feedback(420)

    # --------------------------------------------------------------- pipeline
    def _process_command(self, command: str) -> None:
        with self.state_lock:
            self.state = THINKING
        self.ui.broadcast("state", state=THINKING, label=_STATE_RU[THINKING])
        self.ui.broadcast("transcript", text=command)
        self.last_transcript = command
        threading.Thread(target=self._run_agent, args=(command,),
                         daemon=True).start()

    def _run_agent(self, command: str) -> None:
        def on_token(piece: str) -> None:
            self.ui.broadcast("answer_token", token=piece)

        def on_speak(chunk: Chunk) -> None:
            with self._tts_cv:
                self.tts_queue.append(chunk)
                self._tts_cv.notify()

        result = self.agent.run(command, conv_id=self.conv_id,
                                on_token=on_token, on_speak_chunk=on_speak)
        self._last_tool_log = list(result.tool_log)
        self.last_answer = result.text or result.error
        if result.spoken:
            self._last_spoken_text = result.spoken
        self.ui.broadcast("answer_done",
                          text=result.text or f"ошибка: {result.error}")
        if result.error and not result.text:
            self.say(f"Не получилось: {result.error[:120]}")
        with self.state_lock:
            self.state = IDLE
        self.ui.broadcast("state", state=IDLE, label=_STATE_RU[IDLE])

    # -------------------------------------------------------------------- tts
    def _tts_worker(self) -> None:
        while not self._stop.is_set():
            chunk: Optional[Chunk] = None
            with self._tts_cv:
                while not self.tts_queue and not self._stop.is_set():
                    self._tts_cv.wait(0.2)
                if self.tts_queue:
                    chunk = self.tts_queue.pop(0)
            if chunk is None:
                continue
            try:
                path, engine = self.tts.synthesize(chunk.text)
                if path:
                    try:
                        self.player.enqueue_file(path)
                    except Exception as e:
                        log.warning("плеер не принял файл (%s)", e)
                    try:
                        os.remove(path)
                    except OSError:
                        pass
                else:
                    log.warning("озвучка не удалась (движок %s): %r",
                                engine, chunk.text)
            except Exception:
                log.exception("tts worker: сбой на куске, продолжаю")

    def say(self, text: str) -> None:
        if not text.strip():
            return
        self._last_spoken_text = text
        try:
            path, engine = self.tts.synthesize(text)
            if path:
                try:
                    self.player.enqueue_file(path)
                except Exception as e:
                    log.warning("say: плеер не принял файл: %s", e)
                try:
                    os.remove(path)
                except OSError:
                    pass
            else:
                log.warning("say: озвучка не удалась (%s)", engine)
        except Exception:
            log.exception("say: сбой озвучки, продолжаю без речи")

    def _on_speech_start(self) -> None:
        with self.state_lock:
            if self.state not in (PTT, CONFIRM):
                self.state = SPEAKING
        if self.capture and not config.get("audio.barge_in", False):
            self.capture.pause()            # анти-эхо: не слушаем себя
            self.capture.clear_ring()       # и не читаем собственный хвост потом
        self._cursor_ts = time.monotonic()  # звук во время речи не считаем
        self.ui.broadcast("state", state=SPEAKING, label=_STATE_RU[SPEAKING])

    def _on_speech_end(self) -> None:
        if self.player.queue_size() == 0 and not self.player.speaking:
            self._last_tts_end = time.monotonic()
            if self.capture:
                self.capture.resume()
                self.capture.clear_ring()
            self._cursor_ts = time.monotonic()
            with self.state_lock:
                if self.state == SPEAKING:
                    self.state = IDLE
            self.ui.broadcast("state", state=IDLE, label=_STATE_RU[IDLE])

    # ---------------------------------------------------------------- confirm
    def _confirm_request(self, name: str, args: dict) -> bool:
        if not config.get("security.confirm_destructive", True):
            return True
        cid = uuid.uuid4().hex[:8]
        with self._confirm_lock:
            self._confirm_id = cid
            self._confirm_answer = None
            self._confirm_event.clear()
        self.ui.broadcast("confirm", confirm_id=cid, name=name, args=args)
        with self.state_lock:
            self.state = CONFIRM
        threading.Thread(target=self.say,
                         args=(prompts.VOICE_CONFIRM_QUESTION.format(tool=name),),
                         daemon=True).start()
        ok = self._confirm_event.wait(timeout=20.0)
        with self._confirm_lock:
            answer = self._confirm_answer
        with self.state_lock:
            self.state = IDLE
        if not ok or answer is None:
            return False
        return bool(answer)

    def resolve_confirmation(self, confirm_id: Optional[str], answer: bool) -> bool:
        with self._confirm_lock:
            if self._confirm_id and confirm_id and confirm_id != self._confirm_id:
                return False
            self._confirm_answer = bool(answer)
            self._confirm_event.set()
        return True

    # ----------------------------------------------------------------- timers
    def _timer_worker(self) -> None:
        while not self._stop.is_set():
            try:
                for t in self.store.timers_due():
                    self.store.timer_done(t["id"])
                    kind = "Напоминание" if t["kind"] == "reminder" else "Таймер"
                    self.say(f"{kind}: {t['message']}")
                    self.ui.broadcast("timer", message=t["message"])
            except Exception:
                log.exception("timer worker error")
            time.sleep(0.5)

    # ------------------------------------------------------------------- chat
    def console_chat(self, text: str, speak: bool = False,
                     browser_speak: bool = False, think: bool = False,
                     web: bool = False) -> dict:
        text = (text or "").strip()
        if not text:
            return {"ok": False, "error": "пустой текст"}
        with self.state_lock:
            busy = self.state == THINKING
            if not busy:
                self.state = THINKING
        if busy:
            return {"ok": False, "error": "Флюкс уже думает, секунду"}

        def work() -> None:
            def on_token(piece: str) -> None:
                self.ui.broadcast("answer_token", token=piece)

            def on_speak(chunk: Chunk) -> None:
                if speak and not browser_speak:
                    with self._tts_cv:
                        self.tts_queue.append(chunk)
                        self._tts_cv.notify()

            def on_think(piece: str) -> None:
                # пилюля «Глубокое мышление»: токены рассуждения модели
                # (DeepSeek рисует их блоком «Размышление» — у нас так же)
                self.ui.broadcast("think_token", token=piece)

            try:
                self.ui.broadcast("transcript", text=text)
                result = self.agent.run(text, conv_id=self.conv_id,
                                        on_token=on_token, on_speak_chunk=on_speak,
                                        think=think, web=web,
                                        on_thinking=on_think if think else None)
                self._last_tool_log = list(result.tool_log)
                self.last_answer = result.text or result.error
                if result.spoken:
                    self._last_spoken_text = result.spoken
                self.ui.broadcast("answer_done",
                                  text=result.text or f"ошибка: {result.error}",
                                  browser_speak=bool(browser_speak),
                                  thinking=result.thinking or "")
            finally:
                with self.state_lock:
                    self.state = IDLE
                self.ui.broadcast("state", state=IDLE, label=_STATE_RU[IDLE])

        threading.Thread(target=work, name="flux-chat", daemon=True).start()
        return {"ok": True}

    # ------------------------------------------------------------- console api
    def public_state(self) -> dict:
        dev = None
        try:
            d = resolve_input_device(configured_spec())
            dev = d.name if d else None
        except Exception:
            pass
        return {
            "state": self.state,
            "level": round(self.level, 4),
            "silence_left": round(self.stream.silence_left, 2),
            "partial_message": self.stream.partial,
            "speaking": self.player.speaking,
            "queue": self.player.queue_size(),
            "model": config.get("llm.model"),
            "stt_model": str(config.get("stt.local.model", "")),
            "stt_engine": str(config.get("stt.engine", "auto")),
            "word_idle_sec": float(config.get("stream.word_idle_sec", 5.0)),
            "whisper_server": self.whisper_srv.info() if self.whisper_srv else {},
            "voice": config.get("tts.edge.voice"),
            "tts_engine": self.tts.last_engine or config.get("tts.engine"),
            "mic": dev,
            "wake_words": config.get("wake.words"),
            "hotkey": config.get("hotkey.push_to_talk"),
            "hotkey_backend": self.hotkey.backend,
            "searxng": config.get("search.searxng_url"),
            "whisper_words": self.last_whisper_words,
            "version": __import__("flux").__version__,
        }

    def last_snapshot(self) -> dict:
        utt = self.last_utterance
        return {
            "transcript": self.last_transcript,
            "answer": self.last_answer,
            "whisper_words": self.last_whisper_words,
            "partial_message": self.stream.partial,
            "silence_left": round(self.stream.silence_left, 2),
            "message": ({"text": utt.text, "words": utt.word_count,
                         "silence": utt.silence_sec, "engine": utt.engine,
                         "model": utt.model} if utt else None),
            "state": self.state,
            "tool_log": [{"name": t.name, "ok": t.ok, "preview": t.preview[:120],
                          "elapsed": t.elapsed} for t in self._last_tool_log],
        }

    def recent_history(self, limit: int = 40) -> list[dict]:
        if self.conv_id is None:
            return []
        return self.store.history(self.conv_id, limit)

    def console_action(self, action: str, body: dict) -> dict:
        if action == "listen_now":
            self.listen_now()
            return {"state": self.state}
        if action == "stop_speaking":
            self.stop_speaking()
            return {"stopped": True}
        if action == "cancel":
            self._cancel()
            return {"cancelled": True}
        if action == "chain_test":
            # ПОЭТАПНАЯ диагностика цепи: микрофон (сырой) -> whisper -> слово
            # -> команда. Звук МЕЖДУ микрофоном и whisper НЕ изменяется
            # (ни AGC, ни шумодава, ни нормализации) — как в Buzz.
            import numpy as _np
            from .audio.devices import record_seconds
            secs = float(body.get("seconds", 6.0))
            audio, info = record_seconds(
                secs, device_spec=configured_spec())
            if not info.get("ok") or audio.size == 0:
                return {"ok": False, "error": info.get("error", "нет данных")}
            raw_peak = float(_np.max(_np.abs(audio.astype(_np.float32)))) / 32768.0
            tr = self.cmd_stt.transcribe(audio,
                                         int(config.get("audio.sample_rate", 16000)))
            m = self.wake_det.check(tr.text or "")
            import math as _math
            return {
                "ok": True,
                "device": info.get("device"),
                "raw_peak": round(raw_peak, 5),
                "raw_dbfs": round(20 * _math.log10(raw_peak + 1e-9), 1),
                "modified": False,      # в whisper ушёл ровно этот сырой сигнал
                "engine": tr.engine,
                "text": tr.text,
                "wake": bool(m.matched),
                "command": m.command,
            }
        if action == "whisper_test":
            # ШТУКА ДЛЯ ПРОВЕРКИ ЛОКАЛЬНОГО WHISPER: запись -> модель -> текст
            # + цифры (устройство, compute, время, RTF). Просил пользователь.
            from .stt import whisper_check
            secs = float(body.get("seconds", 6.0))
            return {"ok": True, "result": whisper_check.check(seconds=secs)}
        if action == "mic_transcribe":
            from .audio.devices import record_seconds
            secs = float(body.get("seconds", 4.0))
            audio, info = record_seconds(
                secs, device_spec=configured_spec())
            if not info.get("ok") or audio.size == 0:
                return {"ok": False, "error": info.get("error", "микрофон молчит")}
            tr = self.cmd_stt.transcribe(audio,
                                         int(config.get("audio.sample_rate", 16000)))
            m = self.wake_det.check(tr.text)
            return {"ok": True, "device": info.get("device"), "engine": tr.engine,
                    "text": tr.text, "wake": bool(m.matched), "command": m.command,
                    "seconds": secs}
        if action == "check_keys":
            # расшифровка кодов и маскирование ключа - в общем модуле flux.keys
            from . import keys as keymod
            results = keymod.check_all(lambda n: config.get(f"keys.{n}", ""))
            out = {}
            for name in ("groq", "openai", "elevenlabs"):
                r = results.get(name)
                out[name] = "нет ключа" if r is None else keymod.short(r)
            if not results:
                out["_note"] = ("ключи не заданы: работают локальные движки "
                                "(faster-whisper + SAPI5/edge-tts)")
            self.ui.broadcast("keys_status", **out)
            log.info("проверка ключей:\n%s", keymod.summary(results))
            return out
        if action == "test_tts":
            text = body.get("text", "Проверка озвучки Флюкс.")
            from .tts.engine import EdgeTTSEngine
            eng = EdgeTTSEngine(voice=body.get("voice") or
                                str(config.get("tts.edge.voice")),
                                rate=int(body.get("rate", 0)),
                                pitch=int(body.get("pitch", 0)))
            path = eng.synthesize(text)
            if path:
                self.player.enqueue_file(path)
                return {"played": True, "engine": "edge"}
            return {"played": False}
        if action == "message_test":
            # ДОКАЗАТЕЛЬСТВО «whisper отдаёт сообщение целиком»: пишем N секунд,
            # режем на куски как в боевом потоке, каждый кусок -> whisper ->
            # копилка. Печатаем всё, что было, и ОДНО итоговое сообщение.
            from .audio.devices import record_seconds
            secs = float(body.get("seconds", 8.0))
            audio, info = record_seconds(
                secs, device_spec=configured_spec())
            if not info.get("ok") or audio.size == 0:
                return {"ok": False, "error": info.get("error", "нет звука")}
            sr = int(config.get("audio.sample_rate", 16000))
            from .voice.stream import WordStream
            st = WordStream(self.wake_det,
                            word_idle_sec=float(config.get(
                                "stream.word_idle_sec", 5.0)),
                            wake_idle_sec=float(config.get(
                                "audio.wake_silence_sec", 1.2)),
                            max_message_sec=float(config.get(
                                "stream.max_message_sec", 60.0)))
            chunk = float(config.get("stream.chunk_sec", 3.0))
            step = max(1, int(sr * chunk))
            steps, sends, pos = [], [], 0.0
            for i in range(0, audio.size, step):
                piece = audio[i:i + step]
                if piece.size < int(sr * 0.3):
                    break
                pos += piece.size / float(sr)
                tr = self.cmd_stt.transcribe(piece, sr)
                steps.append({"t": round(pos, 2),
                              "heard": (tr.text or "").strip(),
                              "engine": tr.engine, "model": getattr(tr, "model", ""),
                              "words": len(getattr(tr, "words", None) or [])})
                for ev in st.feed(text=(tr.text or "").strip(), tr=tr,
                                  end_sec=pos, sec=piece.size / float(sr)):
                    if ev.kind == "send":
                        sends.append(ev.text)
            utt = st.last_message
            return {"ok": True, "device": info.get("device"), "seconds": secs,
                    "steps": steps, "sent_messages": sends,
                    "message": (utt.text if utt else ""),
                    "message_words": (utt.word_count if utt else 0),
                    "message_silence_sec": (utt.silence_sec if utt else 0.0),
                    "note": ("сообщение ушло ЦЕЛИКОМ, одна отправка"
                             if len(sends) == 1 else
                             "отправок: %d (0 = whisper не услышал слов)"
                             % len(sends))}
        if action == "whisper_status":
            # ЧЕСТНО: какой движок/модель работают, что скачано, куда слать звук
            from . import models as models_mod
            from .stt import local as local_stt
            from .stt.ollama_asr import OllamaWhisperSTT

            oll = OllamaWhisperSTT()
            base = oll.probe()
            return {
                "local": local_stt.status(),
                "ollama": {"base": base or "", "model": oll.model,
                           "works": bool(base) and oll.model_present(),
                           "note": ("работает" if (base and oll.model_present())
                                    else "сток-Ollama не умеет "
                                         "/audio/transcriptions — нужен "
                                         "whisper-сервер или xOllama")},
                "server": self.whisper_srv.info(),
                "bridge": self.txt_bridge.info(),
                "current": models_mod._current_stt(),
                "llm_model": str(config.get("llm.model", "")),
            }
        if action == "list_models":
            from . import models as models_mod
            return models_mod.catalog()
        if action == "external_text":
            # то же самое, что делает внешний whisper через POST /text
            self.on_external_words(str(body.get("text", "")))
            return {"injected": True, "partial": self.stream.partial}
        if action == "test_mic":
            from .audio.devices import mic_self_test
            return mic_self_test()
        if action == "mic_db":
            # «штука теста громкости микро по дб» (просил пользователь):
            # 5 секунд сырой записи -> пик/RMS в dBFS, посекундная шкала,
            # вердикт. Запись СОХРАНЯЕТСЯ в data/speech.wav, чтобы команда
            # curl.exe -F "file=@..." для проверки whisper-сервера работала
            # из любой папки (раньше curl падал с (26) file not found).
            import wave
            from . import paths
            from .audio import meter
            from .audio.devices import record_seconds
            secs = float(body.get("seconds", 5.0))
            audio, info = record_seconds(secs, device_spec=configured_spec())
            if not info.get("ok") or audio.size == 0:
                return {"ok": False, "error": info.get("error", "нет данных")}
            stats = meter.db_stats(audio, int(config.get(
                "audio.sample_rate", 16000)))
            wav_path = ""
            try:
                paths.ensure_dirs()
                wav_path = str(paths.DATA_DIR / "speech.wav")
                with wave.open(wav_path, "wb") as w:
                    w.setnchannels(1)
                    w.setsampwidth(2)
                    w.setframerate(int(config.get("audio.sample_rate", 16000)))
                    w.writeframes(audio.tobytes())
            except Exception as e:  # pragma: no cover - диск/права
                log.warning("не удалось сохранить speech.wav: %s", e)
                wav_path = ""
            out = {"ok": True, "device": info.get("device"),
                   "fallback_from": info.get("fallback_from", ""),
                   "signal_ranked": bool(info.get("signal_ranked"))}
            out.update(stats)
            if wav_path:
                out["wav"] = wav_path
                out["curl"] = (f'curl.exe -F "file=@{wav_path}" '
                               f'http://{config.get("whisper_server.host", "127.0.0.1")}'
                               f':{config.get("whisper_server.port", 8793)}'
                               f'/v1/audio/transcriptions')
            return out
        raise ValueError(f"неизвестное действие {action}")

    def listen_now(self) -> None:
        """Кнопка/трей: сеанс прослушивания без слова (как AWAKE)."""
        self.stream.reset()
        self._set_state(AWAKE)
        self.say("Слушаю.")

    def stop_speaking(self) -> None:
        self.player.interrupt()
        if self.capture:
            self.capture.resume()
        with self.state_lock:
            self.state = IDLE

    def on_config_changed(self) -> None:
        config.load(force=True)
        self.tts.reload()
        self.wake_det = self._build_wake_detector()
        self.stream.det = self.wake_det
        self.stream.word_idle_sec = float(config.get("stream.word_idle_sec", 5.0))
        self.stream.wake_idle_sec = float(config.get("audio.wake_silence_sec", 1.2))
        self.stream.asm.max_sec = float(config.get("stream.max_message_sec", 60.0))
        self.cmd_stt = STTRouter()
        try:                                    # сменили порт/флаг — перезапустим
            self.whisper_srv.stop()
            self.whisper_srv.start()
        except Exception:                       # pragma: no cover
            pass
        try:
            self.txt_bridge.reload()
        except Exception:                       # pragma: no cover
            pass
        self.player.volume = float(config.get("tts.volume", 1.0))
        dev = resolve_input_device(configured_spec())
        if self.capture is not None and dev is not None \
                and dev.index != self.capture.device_index:
            log.info("смена микрофона на %s", dev.name)
            self.capture.stop()
            self.capture = MicCapture(dev.index, on_frame=self._on_frame,
                                      name=dev.name)
            self.capture.start()
        self._apply_autostart()

    # ---------------------------------------------------------------- autostart
    def _apply_autostart(self) -> None:
        if os.name != "nt":
            return
        try:
            import winreg  # type: ignore
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                 r"Software\Microsoft\Windows\CurrentVersion\Run",
                                 0, winreg.KEY_SET_VALUE)
            name = "FluxAssistant"
            if config.get("autostart.enabled", False):
                winreg.SetValueEx(key, name, 0, winreg.REG_SZ,
                                  f'"{paths.HOME / "Flux.exe"}" --autostart')
            else:
                try:
                    winreg.DeleteValue(key, name)
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
        except Exception as e:
            log.warning("автозагрузку не удалось применить: %s", e)


def acquire_single_instance() -> bool:
    if os.name != "nt":
        lock = paths.DATA_DIR / "flux.lock"
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
            import atexit
            atexit.register(lambda: os.path.exists(lock) and os.remove(lock))
            return True
        except FileExistsError:
            try:
                pid = int(lock.read_text().strip() or 0)
                os.kill(pid, 0)
                return False
            except (OSError, ValueError):
                os.remove(lock)
                return acquire_single_instance()
    import ctypes
    mutex = ctypes.windll.kernel32.CreateMutexW(None, False, "Global\\FluxAssistant")
    if ctypes.windll.kernel32.GetLastError() == 183:
        return False
    globals()["_mutex_handle"] = mutex
    return True


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="flux", description="FLUX voice agent")
    parser.add_argument("--no-ui", action="store_true")
    parser.add_argument("--no-tray", action="store_true")
    parser.add_argument("--no-greet", action="store_true")
    parser.add_argument("--autostart", action="store_true")
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args(argv)

    if args.selftest:
        from .selftest import run_selftest
        report = run_selftest(quick=False)
        print(report.as_text())
        return 0 if report.ok else 1

    if not acquire_single_instance():
        print("FLUX уже запущен - второй экземпляр не стартует.")
        return 0

    app = FluxApp(enable_ui=not args.no_ui, enable_tray=not args.no_tray,
                  greet=not (args.no_greet or args.autostart))
    app.start()
    app.run_forever()
    return 0


if __name__ == "__main__":
    sys.exit(main())
