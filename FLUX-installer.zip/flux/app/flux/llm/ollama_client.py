"""Клиент Ollama /api/chat со стримингом и function calling.

Маршрутизация моделей:
  * обычные модели        -> локальный сервер http://localhost:11434;
  * модели вида *:cloud   -> локальный сервер (если в приложении Ollama выполнен
    вход), иначе напрямую https://ollama.com с заголовком
    Authorization: Bearer <OLLAMA_API_KEY> (ключ из настроек меню);
  * при сбое основной модели перебирается список fallback_models.

Стриминг: NDJSON, накапливаем content и tool_calls из финального чанка.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Callable, Iterator, Optional

import requests

from .. import config, logger

log = logger.get_logger("flux.llm")

DEFAULT_LOCAL = "http://localhost:11434"
DEFAULT_CLOUD = "https://ollama.com"


@dataclass
class ToolCall:
    name: str
    arguments: dict = field(default_factory=dict)
    id: str = ""


@dataclass
class LLMResponse:
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    model: str = ""
    done: bool = True
    error: str = ""
    endpoint: str = ""
    elapsed: float = 0.0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    thinking: str = ""


class OllamaError(RuntimeError):
    pass


# У стокового Ollama есть нативный параметр think (модели с reasoning).
# OpenAI-совместимые подключения (openrouter/xkiro/vLLM) параметра think не
# имеют — там просим рассуждать системной инструкцией (как DeepThink).
THINK_INSTRUCTION = (
    "Режим глубокого мышления (как DeepThink в DeepSeek): прежде чем "
    "отвечать, рассуждай пошагово — разложи задачу на шаги, проверь "
    "варианты, затем дай итоговый ответ пользователю.")


def is_cloud_model(model: str) -> bool:
    return ":cloud" in (model or "") or (model or "").endswith("-cloud")


class OllamaClient:
    def __init__(self, endpoint: Optional[str] = None, model: Optional[str] = None,
                 api_key: Optional[str] = None, timeout: Optional[float] = None):
        self.endpoint = (endpoint or str(config.get("llm.endpoint", DEFAULT_LOCAL))).rstrip("/")
        self.cloud_endpoint = str(config.get("llm.cloud_endpoint", DEFAULT_CLOUD)).rstrip("/")
        self.model = model or str(config.get("llm.model", "gemma4:31b-cloud"))
        self.api_key = api_key if api_key is not None else str(config.get("llm.api_key", ""))
        self.timeout = float(timeout or config.get("llm.timeout_sec", 240))
        self.last_endpoint = ""
        self.last_error = ""

    # ------------------------------------------------------------------ utils
    def _headers(self, use_cloud: bool) -> dict:
        h = {"Content-Type": "application/json"}
        if use_cloud and self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def _url(self, use_cloud: bool) -> str:
        return f"{self.cloud_endpoint if use_cloud else self.endpoint}/api/chat"

    def models(self) -> list[str]:
        """Список доступных моделей (локально + облако, если есть ключ)."""
        out: list[str] = []
        try:
            r = requests.get(f"{self.endpoint}/api/tags", timeout=8)
            if r.ok:
                out += [m.get("name", "") for m in r.json().get("models", [])]
        except Exception:
            pass
        if self.api_key:
            try:
                r = requests.get(f"{self.cloud_endpoint}/api/tags",
                                 headers=self._headers(True), timeout=8)
                if r.ok:
                    out += [m.get("name", "") for m in r.json().get("models", [])]
            except Exception:
                pass
        return [m for m in out if m]

    def ping(self) -> dict:
        """Проверка доступности: локальный сервер, модель, облако."""
        res = {"local": False, "cloud": False, "model_ok": False, "detail": ""}
        try:
            r = requests.get(f"{self.endpoint}/api/version", timeout=6)
            res["local"] = r.ok
            if r.ok:
                res["detail"] = f"ollama {r.json().get('version')}"
        except Exception as e:
            res["detail"] = f"локальный сервер недоступен: {e}"
        if self.api_key:
            try:
                r = requests.get(f"{self.cloud_endpoint}/api/version",
                                 headers=self._headers(True), timeout=8)
                res["cloud"] = r.ok
            except Exception:
                pass
        try:
            r = requests.post(self._url(False),
                              json={"model": self.model,
                                    "messages": [{"role": "user", "content": "ping"}],
                                    "stream": False, "options": {"num_predict": 4}},
                              timeout=30)
            res["model_ok"] = r.ok
            if not r.ok:
                res["detail"] = f"модель {self.model}: {r.status_code} {r.text[:200]}"
        except Exception as e:
            res["detail"] = res["detail"] or str(e)
        return res

    # ------------------------------------------------------------------- chat
    def chat(self, messages: list[dict], tools: Optional[list[dict]] = None,
             on_token: Optional[Callable[[str], None]] = None,
             model: Optional[str] = None, stream: Optional[bool] = None,
             temperature: Optional[float] = None,
             think: Optional[bool] = None,
             on_thinking: Optional[Callable[[str], None]] = None) -> LLMResponse:
        """Один запрос с авто-фолбэком моделей и эндпоинтов.

        think=True — режим «Глубокое мышление» (пилюля в консоли, как
        DeepThink в DeepSeek): нативный параметр think у Ollama, у
        OpenAI-совместимых подключений — системная инструкция.
        on_thinking — колбэк токенов рассуждения (модель с reasoning)."""
        models_to_try = [model or self.model]
        models_to_try += [m for m in (config.get("llm.fallback_models", []) or [])
                          if m not in models_to_try]
        use_stream = bool(config.get("llm.stream", True)) if stream is None else stream
        last_exc: Exception | None = None
        for m in models_to_try:
            for use_cloud in self._endpoint_order(m):
                payload = self._build_payload(m, messages, tools, use_stream,
                                               temperature, think=think)
                try:
                    resp = self._request(payload, use_cloud, on_token,
                                         use_stream, on_thinking)
                    resp.model = m
                    resp.endpoint = self._url(use_cloud)
                    self.last_endpoint = resp.endpoint
                    return resp
                except Exception as e:
                    last_exc = e
                    self.last_error = str(e)
                    log.warning("chat failed (%s, cloud=%s): %s", m, use_cloud, e)
            # фолбэк: OpenAI-совместимые подключения (Open WebUI style)
            for conn in self.connections():
                try:
                    resp = self._chat_openai(conn, m, messages, tools, temperature)
                    self.last_endpoint = conn["base_url"]
                    return resp
                except Exception as e:
                    last_exc = e
                    self.last_error = f"{conn['name']}: {e}"
                    log.warning("chat failed via connection %s: %s",
                                conn["name"], e)
        raise OllamaError(f"все варианты запроса не удались: {last_exc}")

    @staticmethod
    def _openai_messages(messages: list[dict]) -> list[dict]:
        """Конвертация внутренних сообщений в OpenAI-формат:
        assistant.tool_calls (id/type/function), tool.tool_call_id,
        изображения как content-parts с data-URL."""
        out: list[dict] = []
        for m in messages:
            role = m.get("role")
            if role == "assistant" and m.get("_openai_tool_calls"):
                calls = []
                for i, tc in enumerate(m["_openai_tool_calls"]):
                    calls.append({
                        "id": tc.id or f"call_{i}",
                        "type": "function",
                        "function": {"name": tc.name,
                                     "arguments": json.dumps(tc.arguments or {},
                                                             ensure_ascii=False)},
                    })
                out.append({"role": "assistant",
                            "content": m.get("content") or None,
                            "tool_calls": calls})
            elif role == "tool":
                out.append({"role": "tool",
                            "tool_call_id": m.get("tool_call_id") or "call_0",
                            "content": m.get("content", "")})
            elif m.get("images"):
                parts = [{"type": "text", "text": m.get("content", "")}]
                for b64 in m["images"]:
                    parts.append({"type": "image_url",
                                  "image_url": {"url": f"data:image/png;base64,{b64}"}})
                out.append({"role": "user", "content": parts})
            else:
                item = {"role": role, "content": m.get("content", "")}
                out.append(item)
        return out

    def _chat_openai(self, conn: dict, model: str, messages: list[dict],
                     tools: Optional[list[dict]],
                     temperature: Optional[float],
                     think: Optional[bool] = None,
                     on_thinking: Optional[Callable[[str], None]] = None
                     ) -> LLMResponse:
        """OpenAI-совместимый /chat/completions (openrouter, xkiro, vLLM...)."""
        t0 = time.time()
        msgs = list(messages)
        if think:
            msgs = [{"role": "system", "content": THINK_INSTRUCTION}] + msgs
        payload: dict = {
            "model": conn.get("model") or model,
            "messages": self._openai_messages(msgs),
            "stream": False,
            "temperature": float(temperature if temperature is not None
                                 else config.get("llm.temperature", 0.4)),
        }
        if tools:
            payload["tools"] = tools
        headers = {"Content-Type": "application/json"}
        if conn.get("api_key"):
            headers["Authorization"] = f"Bearer {conn['api_key']}"
        r = requests.post(conn["base_url"] + "/chat/completions", json=payload,
                          headers=headers, timeout=self.timeout)
        if r.status_code == 404:
            raise OllamaError(f"{conn['name']}: /chat/completions не найден")
        r.raise_for_status()
        obj = r.json()
        choice = (obj.get("choices") or [{}])[0]
        msg = choice.get("message") or {}
        calls: list[ToolCall] = []
        for tc in msg.get("tool_calls") or []:
            fn = tc.get("function") or {}
            args = fn.get("arguments")
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            calls.append(ToolCall(name=fn.get("name", ""), arguments=args or {},
                                  id=str(tc.get("id", ""))))
        return LLMResponse(content=msg.get("content") or "", tool_calls=calls,
                           model=obj.get("model", payload["model"]),
                           endpoint=conn["base_url"], elapsed=time.time() - t0,
                           prompt_tokens=int((obj.get("usage") or {})
                                             .get("prompt_tokens", 0) or 0),
                           completion_tokens=int((obj.get("usage") or {})
                                                 .get("completion_tokens", 0) or 0))

    def connections(self) -> list[dict]:
        """OpenAI-совместимые подключения (как вкладка «Подключения» в Open WebUI)."""
        out = []
        for c in (config.get("llm.connections", []) or []):
            if isinstance(c, dict) and c.get("base_url"):
                out.append({
                    "name": str(c.get("name") or c["base_url"]),
                    "base_url": str(c["base_url"]).rstrip("/"),
                    "api_key": str(c.get("api_key") or ""),
                    "model": str(c.get("model") or ""),
                })
        return out

    def _endpoint_order(self, model: str) -> list[bool]:
        if is_cloud_model(model):
            prefer_cloud = bool(config.get("llm.prefer_cloud_endpoint", False))
            return [prefer_cloud, not prefer_cloud]
        return [False]

    @staticmethod
    def _native_messages(messages: list[dict]) -> list[dict]:
        """Чистый native-формат Ollama: без приватных полей (_openai_tool_calls)
        и без service-полей OpenAI (tool_call_id)."""
        out = []
        for m in messages:
            item = {k: v for k, v in m.items()
                    if not k.startswith("_") and k != "tool_call_id"}
            if not item.get("images"):
                item.pop("images", None)
            out.append(item)
        return out

    def _build_payload(self, model: str, messages: list[dict],
                       tools: Optional[list[dict]], stream: bool,
                       temperature: Optional[float],
                       think: Optional[bool] = None) -> dict:
        payload: dict = {
            "model": model,
            "messages": self._native_messages(messages),
            "stream": stream,
            "keep_alive": str(config.get("llm.keep_alive", "15m")),
            "options": {
                "temperature": float(temperature if temperature is not None
                                     else config.get("llm.temperature", 0.4)),
                "top_p": float(config.get("llm.top_p", 0.95)),
                "num_ctx": int(config.get("llm.num_ctx", 16384)),
                "num_predict": int(config.get("llm.num_predict", 2048)),
            },
        }
        if tools:
            payload["tools"] = tools
        if think:
            payload["think"] = True      # нативный think Ollama (reasoning)
        return payload

    def _request(self, payload: dict, use_cloud: bool,
                 on_token: Optional[Callable[[str], None]],
                 stream: bool,
                 on_thinking: Optional[Callable[[str], None]] = None
                 ) -> LLMResponse:
        t0 = time.time()
        url = self._url(use_cloud)
        r = requests.post(url, json=payload, headers=self._headers(use_cloud),
                          timeout=self.timeout, stream=stream)
        if r.status_code in (401, 403):
            raise OllamaError(
                f"{r.status_code}: нужен вход/ключ Ollama для облачной модели "
                f"(укажите OLLAMA_API_KEY в настройках меню). {r.text[:200]}")
        if r.status_code == 404 and "cloud" in str(payload.get("model")):
            raise OllamaError(f"404: модель {payload.get('model')} недоступна "
                              f"на этом эндпоинте ({r.text[:200]})")
        r.raise_for_status()

        content_parts: list[str] = []
        thinking_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        meta: dict = {}
        if stream:
            for line in r.iter_lines():
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                msg = obj.get("message") or {}
                think_piece = msg.get("thinking") or ""
                if think_piece:
                    thinking_parts.append(think_piece)
                    if on_thinking:
                        on_thinking(think_piece)
                piece = msg.get("content") or ""
                if piece:
                    content_parts.append(piece)
                    if on_token:
                        on_token(piece)
                for tc in msg.get("tool_calls") or []:
                    fn = tc.get("function") or {}
                    args = fn.get("arguments") or {}
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except json.JSONDecodeError:
                            args = {"raw": args}
                    tool_calls.append(ToolCall(name=fn.get("name", ""),
                                               arguments=args,
                                               id=str(tc.get("id", ""))))
                if obj.get("done"):
                    meta = obj
        else:
            obj = r.json()
            msg = obj.get("message") or {}
            if msg.get("thinking"):
                thinking_parts.append(msg["thinking"])
                if on_thinking:
                    on_thinking(msg["thinking"])
            content_parts.append(msg.get("content") or "")
            for tc in msg.get("tool_calls") or []:
                fn = tc.get("function") or {}
                args = fn.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {"raw": args}
                tool_calls.append(ToolCall(name=fn.get("name", ""), arguments=args))
            if on_token and content_parts[0]:
                on_token(content_parts[0])
            meta = obj
        return LLMResponse(
            content="".join(content_parts),
            thinking="".join(thinking_parts),
            tool_calls=tool_calls,
            done=True,
            elapsed=time.time() - t0,
            prompt_tokens=int(meta.get("prompt_eval_count", 0) or 0),
            completion_tokens=int(meta.get("eval_count", 0) or 0),
        )


def iter_stream(client: OllamaClient, messages: list[dict],
                tools: Optional[list[dict]] = None) -> Iterator[str]:
    """Удобный генератор токенов (для веб-консоли)."""
    buf: list[str] = []

    def cb(piece: str) -> None:
        buf.append(piece)

    client.chat(messages, tools=tools, on_token=cb)
    yield from buf
