"""Системные инструменты: громкость, медиа-клавиши, яркость, питание,
буфер обмена, уведомления, сведения о системе, время."""
from __future__ import annotations

import datetime
import os
import platform
import subprocess
import time

from .. import logger
from .registry import ToolResult, tool

log = logger.get_logger("flux.tools.system")


def _ps(script: str, timeout: int = 20) -> tuple[int, str, str]:
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", script],
                           capture_output=True, text=True, timeout=timeout,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return r.returncode, r.stdout or "", r.stderr or ""
    except Exception as e:
        return 1, "", str(e)


# ------------------------------------------------------------------ volume
def _get_volume_windows() -> int | None:
    try:
        from ctypes import POINTER, cast
        from comtypes import CLSCTX_ALL  # type: ignore
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume  # type: ignore

        devices = AudioUtilities.GetSpeakers()
        interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        volume = cast(interface, POINTER(IAudioEndpointVolume))
        return int(round(volume.GetMasterVolumeLevelScalar() * 100))
    except Exception:
        code, out, _ = _ps(
            "(Get-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Multimedia\\SoundMapper' "
            "-ErrorAction SilentlyContinue).Volume")
        return None


def _set_volume_windows(level: int) -> bool:
    try:
        from ctypes import POINTER, cast
        from comtypes import CLSCTX_ALL  # type: ignore
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume  # type: ignore

        devices = AudioUtilities.GetSpeakers()
        interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        volume = cast(interface, POINTER(IAudioEndpointVolume))
        volume.SetMasterVolumeLevelScalar(max(0.0, min(1.0, level / 100.0)), None)
        return True
    except Exception as e:
        log.debug("pycaw failed: %s", e)
        return False


@tool("get_volume", "Текущая громкость системы в процентах.",
      {"type": "object", "properties": {}},
      category="system")
def t_get_volume(ctx=None) -> ToolResult:
    if os.name == "nt":
        v = _get_volume_windows()
        if v is not None:
            return ToolResult(True, f"громкость: {v}%")
        code, out, _ = _ps(
            "$v = (New-Object -ComObject WScript.Shell); "
            "# fallback через реестр недоступен; используем nircmd-альтернативу")
        return ToolResult(False, "не удалось прочитать громкость")
    code, out, _ = _run_sh("amixer get Master | tail -2")
    return ToolResult(code == 0, out.strip() or "громкость недоступна")


def _run_sh(cmd: str) -> tuple[int, str, str]:
    try:
        r = subprocess.run(["bash", "-c", cmd], capture_output=True, text=True,
                           timeout=10)
        return r.returncode, r.stdout or "", r.stderr or ""
    except Exception as e:
        return 1, "", str(e)


@tool("set_volume", "Устанавливает громкость системы (0-100) и снимает mute.",
      {"type": "object",
       "properties": {"level": {"type": "integer", "description": "0-100"}},
       "required": ["level"]},
      category="system")
def t_set_volume(ctx=None, level: int = 50) -> ToolResult:
    level = max(0, min(100, int(level)))
    if os.name == "nt":
        if _set_volume_windows(level):
            return ToolResult(True, f"громкость установлена: {level}%")
        # фолбэк: клавиши громкости через SendInput слишком сложны; честно сообщаем
        return ToolResult(False, "не удалось изменить громкость (нужны pycaw/comtypes)")
    code, out, err = _run_sh(f"amixer -q sset Master {level}% unmute")
    return ToolResult(code == 0, f"громкость {level}%" if code == 0 else err)


@tool("mute_toggle", "Включает/выключает звук (mute/unmute).",
      {"type": "object",
       "properties": {"muted": {"type": "boolean",
                                "description": "True = выключить звук"}}},
      category="system")
def t_mute_toggle(ctx=None, muted: bool = True) -> ToolResult:
    if os.name == "nt":
        try:
            from ctypes import POINTER, cast
            from comtypes import CLSCTX_ALL  # type: ignore
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume  # type: ignore
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            vol = cast(interface, POINTER(IAudioEndpointVolume))
            vol.SetMute(1 if muted else 0, None)
            return ToolResult(True, "звук выключен" if muted else "звук включен")
        except Exception as e:
            return ToolResult(False, f"mute не удался: {e}")
    code, out, err = _run_sh("amixer -q sset Master toggle")
    return ToolResult(code == 0, "переключено" if code == 0 else err)


@tool("media_key", "Медиа-клавиши: play, pause, next, prev, stop, play_pause.",
      {"type": "object",
       "properties": {"action": {"type": "string",
                                 "enum": ["play", "pause", "play_pause", "next",
                                          "prev", "stop"]}},
       "required": ["action"]},
      category="system")
def t_media_key(ctx=None, action: str = "play_pause") -> ToolResult:
    try:
        import pyautogui  # type: ignore
        mapping = {"play": "play", "pause": "pause", "play_pause": "playpause",
                   "next": "nexttrack", "prev": "prevtrack", "stop": "stop"}
        pyautogui.press(mapping.get(action, "playpause"))
        return ToolResult(True, f"медиа-команда: {action}")
    except Exception as e:
        return ToolResult(False, f"медиа-клавиша не сработала: {e}")


@tool("set_brightness", "Яркость экрана (0-100), Windows.",
      {"type": "object",
       "properties": {"level": {"type": "integer"}},
       "required": ["level"]},
      category="system")
def t_set_brightness(ctx=None, level: int = 70) -> ToolResult:
    if os.name != "nt":
        return ToolResult(False, "яркость регулируется только на Windows")
    level = max(0, min(100, int(level)))
    code, out, err = _ps(
        "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods) | "
        f"ForEach-Object {{ $_.WmiSetBrightness(1, {level}) }}")
    if code != 0:
        return ToolResult(False, f"яркость не изменилась: {err.strip()[:200]}")
    return ToolResult(True, f"яркость: {level}%")


@tool("system_power",
      "Действия с питанием: lock (заблокировать), sleep (сон), logout, "
      "restart, shutdown, hibernate. ОПАСНО: обязательно подтверждение.",
      {"type": "object",
       "properties": {
           "action": {"type": "string",
                      "enum": ["lock", "sleep", "logout", "restart", "shutdown",
                               "hibernate"]},
           "delay_sec": {"type": "integer", "description": "задержка перед действием"},
       },
       "required": ["action"]},
      dangerous=True, category="power")
def t_system_power(ctx=None, action: str = "lock", delay_sec: int = 0) -> ToolResult:
    delay = max(0, min(600, int(delay_sec or 0)))
    if os.name == "nt":
        cmds = {
            "lock": "rundll32.exe user32.dll,LockWorkStation",
            "logout": "shutdown /l",
            "restart": f"shutdown /r /t {delay}",
            "shutdown": f"shutdown /s /t {delay}",
            "hibernate": "shutdown /h",
            "sleep": ("powershell -Command \"(Add-Type '[DllImport(\\\"user32\\\")]public static extern int SetSuspendState(int a,int b,int c);' -Name U -Namespace W) -f W::SetSuspendState(0,0,0)\""),
        }
        try:
            subprocess.Popen(cmds[action].split(),
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            return ToolResult(True, f"выполнено: {action}"
                                    + (f" через {delay} c" if delay else ""))
        except Exception as e:
            return ToolResult(False, f"команда питания не удалась: {e}")
    cmds = {"lock": "loginctl lock-session", "sleep": "systemctl suspend",
            "logout": "loginctl terminate-session $(loginctl session-status | head -1 | cut -d' ' -f1)",
            "restart": f"shutdown -r +{max(0, delay // 60)}",
            "shutdown": f"shutdown -h +{max(0, delay // 60)}",
            "hibernate": "systemctl hibernate"}
    code, out, err = _run_sh(cmds[action])
    return ToolResult(code == 0, f"{action}: ok" if code == 0 else err)


@tool("clipboard_get", "Читает текст из буфера обмена.",
      {"type": "object", "properties": {}},
      category="system")
def t_clipboard_get(ctx=None) -> ToolResult:
    text = _clipboard(get=True)
    if text is None:
        return ToolResult(False, "буфер обмена недоступен")
    return ToolResult(True, f"БУФЕР ({len(text)} симв.):\n{text[:4000]}")


@tool("clipboard_set", "Кладёт текст в буфер обмена.",
      {"type": "object",
       "properties": {"text": {"type": "string"}},
       "required": ["text"]},
      category="system")
def t_clipboard_set(ctx=None, text: str = "") -> ToolResult:
    ok = _clipboard(get=False, text=text)
    return ToolResult(ok, "скопировано в буфер" if ok else "буфер недоступен")


def _clipboard(get: bool, text: str = "") -> str | None | bool:
    if os.name == "nt":
        if get:
            code, out, _ = _ps("Get-Clipboard -Raw")
            return out if code == 0 else None
        code, out, err = _ps(
            "Set-Clipboard -Value ([Console]::In.ReadToEnd())")
        return code == 0
    if get:
        for c in (["xclip", "-selection", "clipboard", "-o"],
                  ["xsel", "--clipboard", "--output"]):
            try:
                r = subprocess.run(c, capture_output=True, text=True, timeout=5)
                if r.returncode == 0:
                    return r.stdout
            except Exception:
                continue
        return None
    for c in (["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"]):
        try:
            r = subprocess.run(c, input=text.encode(), timeout=5)
            if r.returncode == 0:
                return True
        except Exception:
            continue
    return False


@tool("notify", "Показывает системное уведомление (toast) с текстом.",
      {"type": "object",
       "properties": {"title": {"type": "string"}, "text": {"type": "string"}},
       "required": ["text"]},
      category="system")
def t_notify(ctx=None, title: str = "FLUX", text: str = "") -> ToolResult:
    title = title or "FLUX"
    if os.name == "nt":
        script = (
            "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, "
            "ContentType = WindowsRuntime] | Out-Null; "
            "$t = [Windows.UI.Notifications.ToastNotificationManager]::"
            "CreateToastNotifier('FLUX'); "
            "$xml = [Windows.UI.Notifications.ToastNotificationManager]::"
            "GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02); "
            "$xml.GetElementsByTagName('text')[0].AppendChild($xml.CreateTextNode("
            f"'{title}')) | Out-Null; "
            "$xml.GetElementsByTagName('text')[1].AppendChild($xml.CreateTextNode("
            f"'{text.replace(chr(39), chr(96))}')) | Out-Null; "
            "$t.Show([Windows.UI.Notifications.ToastNotification]::new($xml))")
        code, out, err = _ps(script)
        if code == 0:
            return ToolResult(True, f"уведомление показано: {text}")
        # простой фолбэк: msgbox не нужен, пишем в лог
        log.info("notify fallback: %s / %s", title, text)
        return ToolResult(True, f"уведомление (лог): {title}: {text}")
    code, out, err = _run_sh(
        f"notify-send '{title}' '{text}' 2>/dev/null || echo ok")
    return ToolResult(True, f"уведомление: {text}")


@tool("system_info",
      "Сведения о системе: ОС, CPU, RAM, диски, батарея, аптайм, IP-адрес.",
      {"type": "object", "properties": {}},
      category="system")
def t_system_info(ctx=None) -> ToolResult:
    import psutil

    boot = datetime.datetime.fromtimestamp(psutil.boot_time())
    up = datetime.datetime.now() - boot
    lines = [
        f"ОС: {platform.system()} {platform.release()} ({platform.machine()})",
        f"Python: {platform.python_version()}",
        f"CPU: {psutil.cpu_count()} ядер, загрузка {psutil.cpu_percent(interval=0.3)}%",
        f"RAM: {psutil.virtual_memory().used // 2**20} МБ из "
        f"{psutil.virtual_memory().total // 2**20} МБ "
        f"({psutil.virtual_memory().percent}%)",
        f"Аптайм: {up.days} дн. {up.seconds // 3600} ч.",
    ]
    for part in psutil.disk_partitions(all=False):
        try:
            u = psutil.disk_usage(part.mountpoint)
            lines.append(f"Диск {part.mountpoint}: {u.used // 2**30} ГБ из "
                         f"{u.total // 2**30} ГБ ({u.percent}%)")
        except OSError:
            pass
    bat = psutil.sensors_battery()
    if bat:
        lines.append(f"Батарея: {int(bat.percent)}% "
                     f"({'зарядка' if bat.power_plugged else 'от батареи'})")
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        lines.append(f"Локальный IP: {s.getsockname()[0]}")
        s.close()
    except OSError:
        pass
    return ToolResult(True, "\n".join(lines))


@tool("current_time", "Текущие дата и время (с днём недели) и часовой пояс.",
      {"type": "object", "properties": {}},
      category="system")
def t_current_time(ctx=None) -> ToolResult:
    now = datetime.datetime.now()
    tz = time.tzname[time.daylight]
    return ToolResult(True, f"{now:%A, %d %B %Y, %H:%M:%S} (часовой пояс {tz})")
