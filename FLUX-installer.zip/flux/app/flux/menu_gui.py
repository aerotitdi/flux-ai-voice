"""Скромное меню FLUX (Tkinter) - ярлык на рабочем столе открывает именно его.

МИНИМУМ настроек (остальное живёт в config.json со здравыми значениями):
слово активации, голос, скорость речи, модель распознавания речи (whisper),
модель ИИ для ответа, таймер тишины whisper, автозагрузка.
Кнопки: Запустить ИИ / Остановить / Консоль / Диагностика / Папка / Выход.
"""
from __future__ import annotations

import os
import subprocess
import sys
import webbrowser
from pathlib import Path

from . import __version__, config, logger, paths

log = logger.get_logger("flux.menu")

RU_VOICES = ["ru-RU-DmitryNeural", "ru-RU-SvetlanaNeural", "ru-RU-DariyaNeural"]


def _pythonw() -> str:
    base = Path(sys.executable)
    cand = base.with_name("pythonw.exe")
    return str(cand if cand.exists() else base)


def _run_hidden(args: list[str]) -> None:
    kwargs: dict = {}
    if os.name == "nt":
        kwargs["creationflags"] = (getattr(subprocess, "CREATE_NO_WINDOW", 0)
                                   | getattr(subprocess, "DETACHED_PROCESS", 0))
    subprocess.Popen(args, cwd=str(paths.APP_DIR), **kwargs)


def read_pid() -> int:
    try:
        return int((paths.DATA_DIR / "flux.pid").read_text().strip() or 0)
    except Exception:
        return 0


def is_running() -> bool:
    pid = read_pid()
    if not pid:
        return False
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:
        return False


def _num(v) -> float:
    try:
        if isinstance(v, str):
            return float(v.strip().rstrip("%"))
        return float(v)
    except Exception:
        return 0.0


class MenuApp:
    def __init__(self) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        cfg = config.load()
        self.root = tk.Tk()
        self.root.title(f"FLUX {__version__}")
        self.root.geometry("430x430")
        self.root.minsize(400, 400)
        try:
            self.root.iconbitmap(str(paths.APP_DIR / "flux" / "ui" / "flux.ico"))
        except Exception:
            pass
        try:
            ttk.Style().theme_use("clam")
        except Exception:
            pass

        ttk.Label(self.root, text="FLUX — голосовой ассистент",
                  font=("Segoe UI", 13, "bold")).pack(pady=(12, 0))
        self.status = ttk.Label(self.root, text="", foreground="#666")
        self.status.pack(pady=(0, 8))

        btns = ttk.Frame(self.root)
        btns.pack(fill="x", padx=14)
        for text, cmd in (
            ("▶  Запустить ИИ", self.launch),
            ("⏹  Остановить", self.stop),
            ("🌐  Консоль и доп. настройки", self.open_console),
            ("🪽  Проверить whisper", self.whisper_test),
            ("🩺  Диагностика", self.diagnose),
            ("📁  Папка установки", self.open_folder),
            ("✕  Выход", self.quit),
        ):
            ttk.Button(btns, text=text, command=cmd).pack(fill="x", pady=2)

        ttk.Separator(self.root, orient="horizontal").pack(fill="x", padx=14,
                                                           pady=10)
        ttk.Label(self.root, text="Настройки",
                  font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=16)

        form = ttk.Frame(self.root)
        form.pack(fill="x", padx=16, pady=(6, 0))
        form.columnconfigure(1, weight=1)

        def row(r, label, factory):
            ttk.Label(form, text=label).grid(row=r, column=0, sticky="w", pady=3)
            w = factory()
            w.grid(row=r, column=1, sticky="we", pady=3, padx=(8, 0))
            return w

        self.wake = row(0, "Слово активации", lambda: ttk.Entry(form))
        self.wake.insert(0, ", ".join(cfg.get("wake.words", ["флюкс"])))
        self.voice = row(1, "Голос", lambda: ttk.Combobox(form, values=RU_VOICES,
                                                          width=24))
        self.voice.set(cfg.get("tts.edge.voice", "ru-RU-DmitryNeural"))
        self.rate = row(2, "Скорость речи, %", lambda: ttk.Scale(
            form, from_=-50, to=50, orient="horizontal"))
        self.rate.set(_num(cfg.get("tts.edge.rate", 0)))
        self.rate_lbl = ttk.Label(form, text="", width=7)
        self.rate_lbl.grid(row=2, column=2, padx=(6, 0))
        self.rate.configure(command=lambda v: self.rate_lbl.configure(
            text=f"{int(float(v)):+d}%"))
        self.rate_lbl.configure(text=f"{int(self.rate.get()):+d}%")
        self.stt_model = row(3, "Понимание речи (whisper)",
                             lambda: ttk.Combobox(form, width=24,
                                                  values=self._stt_choices()))
        self.stt_model.set(cfg.get("stt.local.model", "large-v3-turbo"))
        self.model = row(4, "Модель ИИ", lambda: ttk.Entry(form))
        self.model.insert(0, cfg.get("llm.model", "gemma4:31b-cloud"))
        self.idle = row(5, "Таймер тишины whisper, сек", lambda: ttk.Spinbox(
            form, from_=1.0, to=30.0, increment=0.5, width=6))
        self.idle.set(float(cfg.get("stream.word_idle_sec", 5.0)))

        self.autostart = tk.BooleanVar(value=bool(cfg.get("autostart.enabled", False)))
        ttk.Checkbutton(self.root, text="Запускать вместе с Windows",
                        variable=self.autostart,
                        command=self._toggle_autostart).pack(anchor="w", padx=18,
                                                             pady=(8, 0))
        ttk.Button(self.root, text="💾  Сохранить настройки",
                   command=self.save_settings).pack(fill="x", padx=16, pady=(10, 14))
        ttk.Label(self.root,
                  text="Тон, микрофон, whisper-эндпоинт, SearXNG и прочее —\n"
                       "в консоли (⚙) или в config\\config.json",
                  foreground="#888", font=("Segoe UI", 8)).pack(pady=(0, 8))

        self._refresh_status()
        self.root.protocol("WM_DELETE_WINDOW", self.quit)

    @staticmethod
    def _stt_choices() -> list:
        """Модели распознавания: уже скачанные первыми, потом известные."""
        try:
            from .stt import local as local_stt
            cached = local_stt.cached_models()
            known = list(local_stt.FALLBACK_CHAIN)
        except Exception:
            cached, known = [], ["large-v3-turbo", "small", "base"]
        out = []
        for m in cached + known:
            if m not in out:
                out.append(m)
        return out

    def _refresh_status(self) -> None:
        self.status.config(text=f"v{__version__} · "
                                + ("работает" if is_running() else "остановлен"))

    def _toggle_autostart(self) -> None:
        from .autostart import set_autostart
        try:
            set_autostart(bool(self.autostart.get()))
        except Exception as e:
            log.warning("autostart: %s", e)

    def launch(self) -> None:
        if is_running():
            self.status.config(text=f"v{__version__} · уже работает")
            return
        _run_hidden([_pythonw(), "-m", "flux.main"])
        self.root.after(1500, self._refresh_status)

    def stop(self) -> None:
        pid = read_pid()
        if pid:
            try:
                import psutil
                psutil.Process(pid).terminate()
            except Exception:
                pass
        self.root.after(800, self._refresh_status)

    def open_console(self) -> None:
        webbrowser.open(f"http://{config.get('ui.host', '127.0.0.1')}:"
                        f"{config.get('ui.port', 8790)}/")

    def whisper_test(self) -> None:
        """Запись 6 секунд -> локальный whisper -> отчёт в окошке."""
        import threading
        from tkinter import messagebox

        self.status.config(text="whisper-тест: говори в микрофон…")

        def run() -> None:
            try:
                from .stt import whisper_check
                rep = whisper_check.report(whisper_check.check(seconds=6.0))
            except Exception as e:
                rep = f"whisper-тест не удался: {e}"
            def show() -> None:
                self.status.config(text=f"v{__version__} · whisper-тест готов")
                messagebox.showinfo("FLUX: локальный whisper", rep)
            self.root.after(0, show)

        threading.Thread(target=run, daemon=True).start()

    def diagnose(self) -> None:
        subprocess.Popen([sys.executable, "-m", "flux.selftest"],
                         cwd=str(paths.APP_DIR))

    def open_folder(self) -> None:
        try:
            if os.name == "nt":
                os.startfile(str(paths.HOME))  # type: ignore[attr-defined]
            else:
                subprocess.Popen(["xdg-open", str(paths.HOME)])
        except Exception:
            pass

    def save_settings(self) -> None:
        words = [w.strip() for w in self.wake.get().split(",") if w.strip()]
        setv = config.set_value
        setv("wake.words", words or ["флюкс"], save=False)
        setv("tts.edge.voice", self.voice.get() or "ru-RU-DmitryNeural", save=False)
        setv("tts.edge.rate", f"{int(self.rate.get()):+d}%", save=False)
        setv("llm.model", self.model.get().strip() or "gemma4:31b-cloud", save=False)
        stt_choice = str(self.stt_model.get().strip() or "")
        if stt_choice:
            # в меню только локальные модели faster-whisper (приватно, офлайн)
            setv("stt.local.model", stt_choice, save=False)
            setv("stt.engine", "local", save=False)
        try:
            setv("stream.word_idle_sec", float(self.idle.get()), save=False)
        except Exception:
            pass
        setv("autostart.enabled", bool(self.autostart.get()), save=False)
        config.save_config()
        self.status.config(text=f"v{__version__} · настройки сохранены")

    def quit(self) -> None:
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    MenuApp().run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
