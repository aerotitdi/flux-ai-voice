"""Распознавание через ВНЕШНИЙ whisper-сервер с OpenAI-эндпоинтом.

Модель по умолчанию: mannix/whisper:large-v3-turbo (whisper.cpp large-v3 turbo,
99 языков). Она отдаёт текст через OpenAI-совместимый эндпоинт
``POST {base}/audio/transcriptions`` (multipart file) с ответом ``{"text": …}``.

ВАЖНО (проверено 08.10.2026): **сток-Ollama так не умеет** — в официальном
API Ollama нет эндпоинта транскрипции (docs.ollama.com/api: generate/chat/
embed/tags/ps/pull/push/version/usage/balance), ollama/ollama#1168 закрыт
как «We'd love to support this at some point», OllamaSharp#381 (26.03.2026):
«you can load in whisper models … but you can't use them». Поэтому модель в
Ollama скачивается и видна в списке, но не запускается, а 404 на
``/audio/transcriptions`` мы считаем «эндпоинт не умеет» и кэшируем базу как
негодную. Эндпоинт пригодится, если у тебя поднят отдельный whisper-сервер
(faster-whisper-server, speaches, whisper.cpp server или форк Ollama с
поддержкой ASR, напр. xOllama на порту 22434) — впиши его адрес в
``stt.ollama.base_url``. Основной движок FLUX — локальный faster-whisper.
"""
from __future__ import annotations

import time
from typing import Optional

import requests

from .. import config, logger
from .api import transcribe_wav_openai_compat
from .base import Transcript, audio_to_wav_bytes

log = logger.get_logger("flux.stt.ollama")

DEFAULT_MODEL = "mannix/whisper:large-v3-turbo"
DEFAULT_BASES = ("http://localhost:22434/v1", "http://localhost:11434/v1")


class OllamaWhisperSTT:
    name = "ollama-whisper"

    def __init__(self, model: Optional[str] = None,
                 base_url: Optional[str] = None,
                 language: Optional[str] = None,
                 timeout: Optional[float] = None) -> None:
        o = config.get("stt.ollama", {}) or {}
        self.model = model or str(o.get("model", DEFAULT_MODEL))
        self.base_url = (base_url or str(o.get("base_url", DEFAULT_BASES[0]))).rstrip("/")
        self.fallback_bases = [u.rstrip("/") for u in
                               (o.get("fallback_base_urls", list(DEFAULT_BASES[1:]))
                                or [])]
        self.language = language or str(o.get("language",
                                              config.get("stt.language", "ru")))
        self.timeout = float(timeout or o.get("timeout_sec", 30))
        self.enabled_flag = bool(o.get("enabled", True))
        self._alive_base: Optional[str] = None
        self._alive_checked_at = 0.0
        self._models_cache: list[str] = []
        self._bad_bases: dict[str, float] = {}

    # ------------------------------------------------------------------ config
    def enabled(self) -> bool:
        return self.enabled_flag

    def bases(self) -> list[str]:
        out = [self.base_url] + [b for b in self.fallback_bases if b != self.base_url]
        return out

    def probe(self, ttl: float = 20.0) -> Optional[str]:
        """Живой ли эндпоинт (только HTTP 200 на /models; кэш на ttl секунд).

        404 НЕ считаем живостью: сток-Ollama отвечает на /v1/* частично и
        раньше маскировался под рабочий эндпоинт whisper.
        """
        now = time.time()
        if self._alive_base and now - self._alive_checked_at < ttl:
            return self._alive_base
        self._alive_checked_at = now
        for base in self.bases():
            try:
                r = requests.get(base.rstrip("/") + "/models", timeout=2.5)
                if r.status_code == 200:
                    self._alive_base = base
                    self._models_cache = self._parse_models(r)
                    return base
            except Exception:
                continue
        self._alive_base = None
        self._models_cache = []
        return None

    @staticmethod
    def _parse_models(r) -> list[str]:
        try:
            data = r.json()
            items = data.get("data") or data.get("models") or []
            out = []
            for m in items:
                if isinstance(m, dict):
                    out.append(str(m.get("id") or m.get("name") or ""))
                else:
                    out.append(str(m))
            return [x for x in out if x]
        except Exception:
            return []

    def model_present(self) -> bool:
        """Есть ли на эндпоинте whisper-модель (сток-Ollama её не запускает)."""
        if self.probe() is None:
            return False
        needle = self.model.split(":")[0].lower()
        return any(("whisper" in m.lower()) or (needle and needle in m.lower())
                   for m in (self._models_cache or []))

    def available(self) -> bool:
        return self.enabled() and self.probe() is not None and self.model_present()

    # ------------------------------------------------------------------- stt
    def transcribe_wav(self, wav: bytes) -> Transcript:
        bases = [self._alive_base] if self._alive_base else self.bases()
        bases += [b for b in self.bases() if b not in bases]
        last: Exception | None = None
        now = time.time()
        for base in bases:
            if base in self._bad_bases and now - self._bad_bases[base] < 300:
                continue  # уже знаем, что эндпоинт транскрипцию не умеет
            try:
                tr = transcribe_wav_openai_compat(
                    base, self.model, wav, language=self.language,
                    timeout=self.timeout)
                tr.engine = self.name
                self._alive_base = base
                if tr.text:
                    return tr
                last = RuntimeError("пустой текст от whisper-эндпоинта")
            except Exception as e:
                last = e
                status = getattr(getattr(e, "response", None), "status_code", None)
                if status == 404:
                    # сток-Ollama модель перечисляет, но транскрипцию не умеет
                    self._bad_bases[base] = now
                    log.info("%s: /audio/transcriptions = 404 — этот сервер "
                             "не умеет транскрипцию (в сток-Ollama её нет)", base)
                else:
                    self._alive_base = None
                log.debug("ollama whisper %s failed: %s", base, e)
        if last is not None:
            raise last
        return Transcript(text="", engine=self.name, model=self.model)

    def transcribe_audio(self, audio, sample_rate: int = 16000) -> Transcript:
        wav = audio_to_wav_bytes(audio, sample_rate)
        return self.transcribe_wav(wav)

    def transcribe_file(self, path: str) -> Transcript:
        with open(path, "rb") as f:
            data = f.read()
        if path.lower().endswith(".wav"):
            return self.transcribe_wav(data)
        # mp3/m4a whisper-эндпоинт читает как есть
        tr = transcribe_wav_openai_compat(
            self._alive_base or self.base_url, self.model, data,
            language=self.language, timeout=self.timeout,
            filename=path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1])
        tr.engine = self.name
        return tr
