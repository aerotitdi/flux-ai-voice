"""Локальное распознавание faster-whisper (офлайн, бесплатно, приватно).

Основной движок FLUX (цепочка пользователя: микрофон -> whisper -> FLUX):
  * model (по умолчанию large-v3-turbo) — основная модель: на GPU уровня
    RTX 5060 Ti работает в разы быстрее реального времени (видео RixAI
    про Buzz: «Turbo — та же умная large, но в 4-8 раз быстрее»);
  * wake_model (base) — лёгкая, если слово-активацию проверяют отдельно.
Модели кэшируются в D:\\flux\\models и переиспользуются между вызовами.

Звук в модель передаётся СЫРЫМ (без AGC/нормализации): whisper работает
с log-mel спектрограммами, а тишину/шум вырезает Silero VAD ВНУТРИ
транскрипции (vad_filter) — это buzz-овский «Extract speech», а не
обработка микрофона.
"""
from __future__ import annotations

import os
import threading
import time

import numpy as np
from typing import Optional

from .. import config, logger, paths
from .base import Transcript

log = logger.get_logger("flux.stt")

_models: dict[str, object] = {}
_lock = threading.Lock()

# Если основная модель не скачалась/не загрузилась (нет доступа к huggingface,
# мало места, нет CUDA-рантайма) — пробуем более лёгкие, чтобы распознавание
# РАБОТАЛО, а не молча падало. Порядок ровно такой: сначала то, что выбрал
# пользователь в консоли, потом запасные.
FALLBACK_CHAIN = ("large-v3-turbo", "large-v3", "medium", "small", "base", "tiny")
_last_error: dict = {"model": "", "error": "", "fallback": ""}
# ЧТО реально загрузилось в последний раз (модель/устройство/compute). Запрошено
# может быть «cuda», а по факту (нет cublas64_12.dll) модель живёт на cpu —
# статус обязан показывать ПРОВЕРЕННОЕ устройство, а не желаемое.
_last_load: dict = {"model": "", "device": "", "compute": ""}


def model_chain(size: str) -> list[str]:
    """Список моделей для загрузки: выбранная + запасные (без повторов)."""
    out = [size] if size else []
    for m in FALLBACK_CHAIN:
        if m not in out:
            out.append(m)
    return out


def last_error() -> dict:
    """Почему основная модель не завелась и на что упали (для консоли)."""
    return dict(_last_error)


def last_load() -> dict:
    """Проверенный факт последней загрузки: модель, устройство, compute."""
    return dict(_last_load)


def _resolve_device(pref: str) -> str:
    if pref in ("cpu", "cuda"):
        return pref
    try:
        import ctranslate2  # type: ignore
        return "cuda" if ctranslate2.get_cuda_device_count() > 0 else "cpu"
    except Exception:
        return "cpu"


def _resolve_compute(pref: str, device: str) -> str:
    """compute_type: 'auto' -> float16 на GPU (быстрее и точнее), int8 на CPU."""
    if pref and pref != "auto":
        return pref
    return "float16" if device == "cuda" else "int8"


def get_model(size: str = "base", device: Optional[str] = None,
              compute_type: str = "auto", download_root: Optional[str] = None,
              cpu_threads: int = 0):
    """Ленивая загрузка модели с кэшем в словаре и на диске.

    Возвращает (model, effective_size): если выбранная модель не завелась
    (не скачалась / нет CUDA-рантайма), пробуем запасные по FALLBACK_CHAIN —
    распознавание должно РАБОТАТЬ, а не молча молчать.
    """
    device = device or _resolve_device(str(config.get("stt.local.device", "auto")))
    compute_type = _resolve_compute(compute_type, device)
    root = download_root or str(config.get("stt.local.download_root", "") or paths.MODELS_DIR)
    allow_fallback = bool(config.get("stt.local.model_fallback", True))
    chain = model_chain(size) if allow_fallback else [size]
    tried: list[str] = []
    first_error = ""
    for cand in chain:
        key = f"{cand}|{device}|{compute_type}"
        with _lock:
            if key in _models:
                _last_load.update({"model": cand, "device": device,
                                   "compute": compute_type})
                return _models[key], cand
        tried.append(cand)
        fits, why = fits_in_ram(cand, device)
        if not fits:
            first_error = first_error or f"{cand}: {why}"
            log.warning("модель %s не подходит этой машине (%s) — беру легче",
                        cand, why)
            continue
        size_on_disk = model_bytes_on_disk(cand, root)
        if 0 < size_on_disk < 40 * 1024 * 1024:
            first_error = first_error or (
                f"{cand}: скачано только {size_on_disk // (1024 * 1024)} МБ — "
                f"загрузка оборвалась")
            log.warning("модель %s скачана не целиком (%d МБ) — удаляю огрызок "
                        "и беру запасную; перекачай: python -m "
                        "flux.stt.whisper_check 3 %s",
                        cand, size_on_disk // (1024 * 1024), cand)
            _remove_broken_model(cand, root)
            continue
        try:
            model, dev, comp = _load_one(cand, device, compute_type, root,
                                         cpu_threads)
        except Exception as e:
            first_error = first_error or f"{cand}: {e}"
            log.warning("whisper-модель %s не завелась (%s)", cand, e)
            continue
        if cand != size:
            _last_error.update({"model": size, "error": first_error,
                                "fallback": cand})
            log.warning("ВНИМАНИЕ: модель %s недоступна (%s) — работаю на %s. "
                        "Выбери модель в консоли (Настройки → Понимание речи) "
                        "или скачай её: python -m flux.stt.whisper_check 3 %s",
                        size, first_error, cand, size)
        else:
            _last_error.update({"model": size, "error": "", "fallback": ""})
        with _lock:
            _models[f"{cand}|{dev}|{comp}"] = model
        _last_load.update({"model": cand, "device": dev, "compute": comp})
        return model, cand
    _last_error.update({"model": size, "error": first_error, "fallback": ""})
    raise RuntimeError(
        f"ни одна whisper-модель не загрузилась ({', '.join(tried)}): "
        f"{first_error}")


def _remove_broken_model(size: str, root: str) -> None:
    """Удаляет недокачанную модель, чтобы следующая попытка начала заново."""
    import shutil

    for prefix in ("models--Systran--faster-whisper-",
                   "models--mobiuslabsgmbh--faster-whisper-"):
        d = os.path.join(root, prefix + size)
        try:
            if os.path.isdir(d):
                shutil.rmtree(d, ignore_errors=True)
        except OSError:
            pass


def _load_one(size: str, device: str, compute_type: str, root: str,
              cpu_threads: int):
    """Одна попытка загрузки: device -> cpu (напр. нет cublas64_12.dll)."""
    from faster_whisper import WhisperModel  # type: ignore

    kwargs = {"device": device, "compute_type": compute_type,
              "download_root": root}
    if cpu_threads:
        kwargs["cpu_threads"] = cpu_threads
    log.info("загрузка whisper-модели %s (%s/%s)...", size, device, compute_type)
    t0 = time.time()
    try:
        model = WhisperModel(size, **kwargs)
    except Exception as e:
        if device == "cpu":
            raise
        log.warning("загрузка %s на %s не удалась (%s) - повторяю на cpu",
                    size, device, e)
        kwargs["device"] = "cpu"
        model = WhisperModel(size, **kwargs)
        device = "cpu"
    log.info("модель %s загружена за %.1f c (%s)", size, time.time() - t0, device)
    return model, device, str(kwargs["compute_type"])


# Сколько оперативной памяти примерно нужно модели на CPU (int8). На GPU
# модель живёт в видеопамяти, поэтому проверка делается только для device=cpu.
RAM_NEED_MB = {"tiny": 300, "base": 450, "small": 900, "medium": 2200,
               "large-v3": 3800, "large-v3-turbo": 2200}


def available_ram_mb() -> float:
    """Свободная оперативная память в МБ (Windows/Linux/macOS, без падений)."""
    try:
        import psutil  # type: ignore

        return float(psutil.virtual_memory().available) / (1024 * 1024)
    except Exception:
        pass
    try:
        if os.name == "nt":
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong),
                            ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong),
                            ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong),
                            ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

            stat = MEMORYSTATUSEX()
            stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
            return float(stat.ullAvailPhys) / (1024 * 1024)
        with open("/proc/meminfo", encoding="utf-8") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return float(line.split()[1]) / 1024.0
    except Exception:
        pass
    return 0.0


def fits_in_ram(size: str, device: str) -> tuple[bool, str]:
    """Влезет ли модель в оперативную память (для CPU-запуска).

    Возвращает (влезет, причина). Нужно, чтобы на слабой машине FLUX не
    пытался загрузить large-v3-turbo и не вешал систему (OOM-killer),
    а честно брал модель поменьше и говорил почему.
    """
    if device != "cpu":
        return True, ""
    need = RAM_NEED_MB.get(size, 0)
    if not need:
        return True, ""
    free = available_ram_mb()
    if not free:
        return True, ""                          # не смогли измерить — не мешаем
    if free < need * 1.2:
        return False, (f"{size} нужно ~{need} МБ свободной памяти, "
                       f"а свободно {int(free)} МБ")
    return True, ""


def model_bytes_on_disk(size: str, root: Optional[str] = None) -> int:
    """Сколько байт модели УЖЕ лежит на диске (0 = не скачана).

    Нужно, чтобы отличить «модель не скачана» от «скачалась наполовину и
    оборвалась» (типично при обрыве связи с huggingface.co): во втором случае
    загрузка виснет/падает, и честнее сразу сказать пользователю, что делать.
    """
    import os

    root = root or str(config.get("stt.local.download_root", "") or paths.MODELS_DIR)
    for prefix in ("models--Systran--faster-whisper-",
                   "models--mobiuslabsgmbh--faster-whisper-"):
        snap = os.path.join(root, prefix + size, "snapshots")
        try:
            for name in os.listdir(snap):
                candidate = os.path.join(snap, name, "model.bin")
                if os.path.exists(candidate):
                    return int(os.path.getsize(os.path.realpath(candidate)))
        except OSError:
            continue
    return 0


def cached_models(root: Optional[str] = None,
                  min_bytes: int = 20 * 1024 * 1024) -> list[str]:
    """Какие модели УЖЕ скачаны на диск (для списка выбора в консоли).

    Недокачанные огрызки (< min_bytes) не показываем: они всё равно не
    загрузятся, а пользователя введут в заблуждение.
    """
    root = root or str(config.get("stt.local.download_root", "") or paths.MODELS_DIR)
    out: list[str] = []
    try:
        for name in os.listdir(root):
            if "--faster-whisper-" not in name:
                continue          # кэш huggingface от других моделей
            size = name.split("--faster-whisper-", 1)[1]
            if size and model_bytes_on_disk(size, root) >= min_bytes:
                out.append(size)
    except OSError:
        return out
    order = {m: i for i, m in enumerate(FALLBACK_CHAIN)}
    return sorted(set(out), key=lambda m: order.get(m, 99))


def unload_models() -> None:
    with _lock:
        _models.clear()


class LocalWhisperSTT:
    name = "local"

    def __init__(self, size: str | None = None, language: str | None = None,
                 beam_size: int | None = None) -> None:
        self.size = size or str(config.get("stt.local.model", "base"))
        self.language = language or str(config.get("stt.language", "ru"))
        self.beam_size = int(config.get("stt.local.beam_size", 1)
                             if beam_size is None else beam_size)

    def available(self) -> bool:
        try:
            import faster_whisper  # noqa: F401
            return True
        except Exception:
            return False

    def transcribe_audio(self, audio, sample_rate: int = 16000) -> Transcript:
        """audio: numpy int16 mono или bytes int16. Передаётся в модель СЫРЫМ."""
        import numpy as np

        arr16 = np.asarray(audio)
        if arr16.dtype != np.int16:
            arr16 = (np.asarray(audio, dtype=np.float32) * 32767.0).astype(np.int16)
        arr = arr16.astype(np.float32) / 32768.0     # без нормализации и AGC
        if sample_rate != 16000:
            # быстрое линейное прореживание/интерполяция через numpy
            factor = 16000 / float(sample_rate)
            n = int(len(arr) * factor)
            idx = np.linspace(0, len(arr) - 1, num=max(1, n)).astype(int)
            arr = arr[idx]
        model, eff_size = get_model(
            self.size,
            compute_type=str(config.get("stt.local.compute_type", "auto")),
            cpu_threads=int(config.get("stt.local.cpu_threads", 0) or 0),
        )
        # Практики wyoming-faster-whisper (STT-движок Home Assistant):
        #  * vad_filter=True - Silero VAD вырезает тишину/шум ВНУТРИ транскрипции
        #    (убирает галлюцинации на тишине лучше любых текстовых фильтров);
        #  * condition_on_previous_text=False - не тянет галлюцинации по кругу;
        #  * initial_prompt - смещение словаря в сторону наших слов («Флюкс»);
        #  * language зафиксирован - не guessing на коротких фразах.
        kwargs: dict = {
            "language": self.language or None,
            "beam_size": self.beam_size,
            "condition_on_previous_text": bool(
                config.get("stt.local.condition_on_previous_text", False)),
            "temperature": float(config.get("stt.local.temperature", 0.0)),
            # МЕТКИ ВРЕМЕНИ СЛОВ: именно по ним FLUX понимает, когда whisper
            # замолчал, и отдаёт сообщение ЦЕЛИКОМ (voice/utterance.py)
            "word_timestamps": bool(config.get("stt.local.word_timestamps", True)),
        }
        prompt = str(config.get("stt.local.initial_prompt", "") or "").strip()
        if prompt:
            kwargs["initial_prompt"] = prompt
        use_vad = bool(config.get("stt.local.vad_filter", True))
        t0 = time.time()

        def _collect(model_obj, vad_on: bool):
            """transcribe возвращает ГЕНЕРАТОР: вывод (и cublas) взрываются
            именно при итерации, поэтому собираем сегменты внутри try."""
            gen, info = model_obj.transcribe(arr, vad_filter=vad_on, **kwargs)
            segs = list(gen)
            return segs, info

        try:
            segments, info = _collect(model, use_vad)
        except Exception as e:
            msg = str(e).lower()
            if "cublas" in msg or "cuda" in msg or "cudnn" in msg:
                log.warning("CUDA-вывод не удался (%s) - переход на cpu", e)
                unload_models()
                model, eff_size = get_model(self.size, device="cpu",
                                            compute_type=str(config.get(
                                                "stt.local.compute_type", "auto")))
                segments, info = _collect(model, use_vad)
            elif use_vad and ("onnx" in msg or "silero" in msg or "vad" in msg):
                log.warning("Silero VAD недоступен (%s) - без vad_filter", e)
                segments, info = _collect(model, False)
            else:
                raise
        texts, confs = [], []
        seg_list, word_list = [], []
        for s in segments:
            texts.append(s.text)
            if getattr(s, "avg_logprob", None) is not None:
                import math
                confs.append(math.exp(max(-10.0, min(0.0, s.avg_logprob))))
            seg_list.append({"start": s.start, "end": s.end, "text": s.text})
            for w in (getattr(s, "words", None) or []):
                word_list.append({"word": str(getattr(w, "word", "")).strip(),
                                  "start": float(getattr(w, "start", 0.0) or 0.0),
                                  "end": float(getattr(w, "end", 0.0) or 0.0),
                                  "prob": float(getattr(w, "probability", 0.0) or 0.0)})
        text = " ".join(t.strip() for t in texts if t.strip()).strip()
        conf = sum(confs) / len(confs) if confs else 0.0
        return Transcript(text=text, language=getattr(info, "language", self.language),
                          confidence=round(conf, 3), duration=time.time() - t0,
                          engine=self.name, model=eff_size, segments=seg_list,
                          words=[w for w in word_list if w["word"]],
                          window_sec=round(len(arr) / 16000.0, 3))

    def transcribe_file(self, path: str) -> Transcript:
        """Декодируем своим декодером: faster_whisper.audio.decode_audio
        несовместим с PyAV>=16 (open() без metadata_errors)."""
        from ..audio.player import decode_audio_file

        data, sr = decode_audio_file(path, target_sr=16000)
        arr = (data * 32767.0).astype(np.int16) if data.dtype != np.int16 else data
        return self.transcribe_audio(arr, 16000)


def status() -> dict:
    """Состояние локального whisper — для консоли («Понимание речи»).

    Показывает ЧЕСТНО: какая модель выбрана, какая реально работает,
    какие модели уже скачаны, есть ли GPU и почему случился фолбэк.
    """
    ok = False
    version = ""
    try:
        import faster_whisper  # type: ignore

        ok = True
        version = str(getattr(faster_whisper, "__version__", ""))
    except Exception:
        pass
    device = _resolve_device(str(config.get("stt.local.device", "auto")))
    compute = _resolve_compute(str(config.get("stt.local.compute_type", "auto")),
                                device)
    loaded = sorted({k.split("|")[0] for k in _models})
    err = last_error()
    fact = last_load()
    device_note = ""
    if fact.get("device") and fact["device"] != device:
        device_note = (f"запрошено {device}, но модель фактически загружена на "
                       f"{fact['device']} ({fact.get('compute')}) — CUDA-рантайм "
                       f"ctranslate2 недоступен (cublas64_12.dll)")
    return {
        "engine": "faster-whisper (локально)",
        "installed": ok,
        "version": version,
        "configured_model": str(config.get("stt.local.model", "large-v3-turbo")),
        "effective_model": (err.get("fallback") or loaded[0]
                            if (err.get("fallback") or loaded) else ""),
        "loaded_models": loaded,
        "cached_models": cached_models(),
        "models_dir": str(config.get("stt.local.download_root", "")
                          or paths.MODELS_DIR),
        "device": fact.get("device") or device,
        "device_requested": device,
        "device_note": device_note,
        "verified_load": fact,
        "compute_type": fact.get("compute") or compute,
        "ram_free_mb": int(available_ram_mb()),
        "ram_need_mb": RAM_NEED_MB.get(
            str(config.get("stt.local.model", "large-v3-turbo")), 0),
        "fallback": err,
    }
