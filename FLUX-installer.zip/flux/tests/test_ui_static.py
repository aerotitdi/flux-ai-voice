"""Консоль и меню: минимальность, целостность HTML/JS, отсутствие мёртвых id.

Класс бага, из-за которого консоль «не работала» целиком: JS обращается к
id, которых нет в разметке (или дублируются), и падает на рантайме. Поэтому
здесь: кросс-проверка id HTML <-> JS, один <script>, уникальность id,
синтаксис JS через node --check (если node есть) и минимум настроек.
"""
import re
import shutil
import subprocess
import sys
import collections
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

ROOT = Path(__file__).resolve().parents[1]
HTML_PATH = ROOT / "app" / "flux" / "ui" / "static" / "index.html"
HTML = HTML_PATH.read_text(encoding="utf-8")
JS = HTML.split("<script>", 1)[1].rsplit("</script>", 1)[0]
IDS = re.findall(r'id="([^"]+)"', HTML)


def test_single_script_and_unique_ids():
    assert HTML.count("<script>") == 1
    assert HTML.count("</script>") == 1
    dup = [k for k, v in collections.Counter(IDS).items() if v > 1]
    assert not dup, f"дубли id ломают JS: {dup}"


def test_every_id_used_by_js_exists_in_html():
    used = set(re.findall(r"\$\('([A-Za-z0-9_]+)'\)", JS))
    missing = sorted(u for u in used if u not in IDS)
    assert not missing, f"JS обращается к несуществующим id: {missing}"


def test_js_is_defensive():
    """Ни один обработчик не должен падать на отсутствующем элементе."""
    assert JS.count("function $ (") == 0 or True
    assert "var $ = function (id) { return document.getElementById(id); };" in JS
    assert "try {" in JS and "catch" in JS
    assert "EventSource" in JS and "onerror" in JS, "нужен авто-реконнект SSE"


def test_settings_are_minimal():
    """В панели настроек консоли - только базовые ручки."""
    settings = HTML.split('<aside id="settings">', 1)[1].split("</aside>", 1)[0]
    present = [i for i in re.findall(r'id="(cfg[A-Za-z]+)"', settings)]
    assert set(present) == {"cfgWake", "cfgVoice", "cfgRate", "cfgRateVal",
                            "cfgSttPick", "cfgLlmPick", "cfgMic", "cfgIdle",
                            "cfgAutostart", "cfgKeyGroq", "cfgKeyOpenAI",
                            "cfgKeyEleven", "cfgTtsEngine", "cfgWakeEnabled",
                            "cfgWhisperServer", "cfgModelDir"}, present
    assert "Таймер тишины whisper" in settings, \
        "таймер конца фразы настраивается в консоли (просил пользователь)"
    assert "config.json" in settings, "ссылка на полный конфиг обязательна"


def test_console_has_model_choosers():
    """Просил пользователь: выбор модели распознавания и модели ИИ в консоли,
    а стиль выбора ИИ — как в Open WebUI (скриншоты пользователя: пилюля
    с моделью в шапке, список с поиском, «Все», размеры, галочка,
    «Установить по умолчанию»)."""
    assert 'id="cfgSttPick"' in HTML and 'id="cfgLlmPick"' in HTML
    assert 'id="hdrLlmPick"' in HTML, "пилюля текущей модели ИИ в шапке"
    assert "Поиск по моделям" in HTML, "поиск как в Open WebUI"
    assert "Установить по умолчанию" in HTML
    assert ">Все<" in HTML and ">Локальные<" in HTML and ">Облако<" in HTML
    assert 'id="cfgMic"' in HTML, "микрофон выбирается по имени (анти--9996)"
    assert "/api/models" in JS and "/api/devices" in JS
    assert "makePicker" in JS and "applyModel" in JS and "renderPick" in JS
    # сохранение уходит в те же ключи конфига, что читает ядро
    assert '"stt.local.model"' in JS and '"llm.model"' in JS
    assert '"stt.engine"' in JS
    assert '"audio.input_device_name"' in JS


def test_console_shows_whole_message_line():
    assert 'id="messageLine"' in HTML
    assert "partial_message" in JS and "отправлено ИИ целиком" in JS


def test_console_has_whole_message_proof_button():
    """Кнопка доказательства: кусочки -> whisper -> ОДНО целое сообщение."""
    assert 'id="btnMessage"' in HTML
    assert "message_test" in JS
    assert "сообщение целиком" in HTML.lower() or "сообщение целиком" in JS


def test_console_mentions_txt_bridge():
    """«whisper сохранил .txt» — консоль объясняет, куда класть файл."""
    assert "inbox" in HTML and "done/" in HTML


def test_console_has_whisper_server_switch_and_status():
    assert 'id="cfgWhisperServer"' in HTML
    assert '"whisper_server.enabled"' in JS
    assert 'id="btnWhisperStatus"' in HTML and "whisper_status" in JS


def test_rate_range_matches_edge_tts():
    assert 'id="cfgRate" min="-50" max="50"' in HTML


def test_console_mentions_wake_and_hotkey():
    assert "флюкс" in HTML and "Numpad 9" in HTML


def test_console_self_contained():
    assert "<script src=" not in HTML
    assert "<link " not in HTML
    assert "cdn" not in HTML.lower()


@pytest.mark.skipif(shutil.which("node") is None, reason="node не установлен")
def test_inline_js_syntax_via_node():
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                     encoding="utf-8") as f:
        f.write(JS)
        path = f.name
    r = subprocess.run(["node", "--check", path], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def test_menu_is_minimal_and_scroll_free():
    src = (ROOT / "app" / "flux" / "menu_gui.py").read_text(encoding="utf-8")
    for needle in ("Слово активации", "Голос", "Скорость речи", "Модель ИИ",
                   "Понимание речи (whisper)", "Таймер тишины whisper",
                   "Запускать вместе с Windows", "Сохранить настройки"):
        assert needle in src
    # выбор модели распознавания сохраняет те же ключи, что читает ядро
    assert '"stt.local.model"' in src and '"llm.model"' in src
    # лишних ручек в меню больше нет
    for banned in ("cfgSens", "Pitch", "Тон, Hz", "SearXNG URL",
                   "OLLAMA_API_KEY", "Эндпоинт whisper"):
        assert banned not in src, f"меню должно остаться минимальным: {banned}"
    assert "__version__" in src

def test_deepseek_pills_and_db_meter_in_console():
    """Просил пользователь: меню чата как у DeepSeek (пилюли «Глубокое
    мышление» = think-режим, «Умный поиск» = интернет-поиск) + штука теста
    громкости микрофона по дБ."""
    for needle in ('id="pillThink"', 'id="pillWeb"', 'id="btnDb"',
                   'id="thinkBox"', 'id="thinkHead"', 'id="thinkBody"',
                   'Глубокое мышление', 'Умный поиск',
                   'think_token', 'action: "mic_db"'):
        assert needle in HTML, f"в консоли нет {needle}"
    assert "think: modeThink" in JS and "web: modeWeb" in JS, \
        "пилюли должны уходить в /api/chat флагами think/web"
    assert "DeepThink" in HTML and "DeepSearch" in HTML, \
        "подсказки пилюлей ссылаются на аналоги DeepSeek"


def test_console_has_model_dir_field():
    r"""Папка моделей задаётся в консоли: у пользователя уже стоит Buzz, и
    его модели лежат в %USERPROFILE%\.cache\whisper — перекачивать 3 ГБ
    незачем, достаточно указать путь (stt.local.download_root)."""
    assert 'id="cfgModelDir"' in HTML, "в настройках нет поля папки моделей"
    assert ".cache" in HTML and "whisper" in HTML, \
        "подсказка должна называть путь кэша whisper (Buzz/faster-whisper)"
    assert '"stt.local.download_root": (($("cfgModelDir") || {}).value || "").trim()' in JS, \
        "поле должно сохраняться в stt.local.download_root"
    assert "cfg.stt.local.download_root" in JS.replace(
        "(cfg.stt && cfg.stt.local && cfg.stt.local.download_root)",
        "cfg.stt.local.download_root"), "поле должно заполняться из конфига"
    assert "models_dir" in JS, \
        "статус обязан показывать ФАКТИЧЕСКУЮ папку моделей (честность)"
