"""Тест агентного цикла против mock-Ollama (NDJSON-стриминг + tool_calls)."""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg
from flux.llm.agent import Agent
from flux.llm.ollama_client import OllamaClient
from flux.memory.store import MemoryStore
from flux.tools.registry import ToolResult, tool

CALLS = {"lookups": 0, "danger": 0}


@tool("mock_lookup", "Тестовый инструмент: возвращает справку по теме.",
      {"type": "object", "properties": {"topic": {"type": "string"}},
       "required": ["topic"]},
      category="general")
def _mock_lookup(ctx=None, topic: str = "") -> ToolResult:
    CALLS["lookups"] += 1
    return ToolResult(True, f"справка по теме {topic}: всё хорошо")


@tool("mock_danger", "Тестовый опасный инструмент.",
      {"type": "object", "properties": {}},
      dangerous=True, category="general")
def _mock_danger(ctx=None) -> ToolResult:
    CALLS["danger"] += 1
    return ToolResult(True, "опасное выполнено")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        msgs = body.get("messages", [])
        has_tool_msg = any(m.get("role") == "tool" for m in msgs)
        want_danger = any(m.get("role") == "user" and "опасн" in m.get("content", "")
                          for m in msgs)
        lines = []
        if not has_tool_msg and not want_danger:
            # круг 1: модель вызывает инструмент (контента почти нет)
            lines.append(json.dumps({"message": {"role": "assistant", "content": ""}}))
            lines.append(json.dumps({
                "message": {"role": "assistant", "content": "",
                            "tool_calls": [{"function": {"name": "mock_lookup",
                                                        "arguments": {"topic": "флюкс"}}}]},
                "done": True}))
        elif want_danger and not any(
                m.get("role") == "tool" and m.get("name") == "mock_danger"
                for m in msgs):
            lines.append(json.dumps({
                "message": {"role": "assistant", "content": "",
                            "tool_calls": [{"function": {"name": "mock_danger",
                                                        "arguments": {}}}]},
                "done": True}))
        else:
            final = ("Служебный ход мыслей, пользователь это не слышит. "
                     "*-Готово! Я проверил справку: всё хорошо. Могу помочь ещё?-* "
                     "подробности вне маркеров")
            # стримим по 5 символов
            for i in range(0, len(final), 5):
                lines.append(json.dumps(
                    {"message": {"role": "assistant", "content": final[i:i + 5]}}))
            lines.append(json.dumps({"message": {"role": "assistant", "content": ""},
                                     "done": True,
                                     "prompt_eval_count": 10, "eval_count": 40}))
        payload = ("\n".join(lines) + "\n").encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *a):
        pass


@pytest.fixture(scope="module")
def ollama_mock():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}"
    srv.shutdown()


@pytest.fixture()
def agent(ollama_mock, tmp_path, monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"llm": {"endpoint": ollama_mock, "model": "test-model",
                        "stream": True, "max_tool_rounds": 4},
                "memory": {"auto_recall": True}}, save=False)
    store = MemoryStore(str(tmp_path / "agent.db"))
    a = Agent(client=OllamaClient(endpoint=ollama_mock, model="test-model"),
              store=store)
    yield a
    store.close()


def test_agent_two_rounds_with_tool_and_markers(agent):
    spoken = []
    tokens = []
    res = agent.run("флюкс проверь справку",
                    on_token=tokens.append,
                    on_speak_chunk=lambda c: spoken.append(c.text))
    assert res.error == "", res.error
    assert CALLS["lookups"] == 1, "инструмент должен быть вызван ровно один раз"
    assert [t.name for t in res.tool_log] == ["mock_lookup"]
    assert res.tool_log[0].ok is True
    # озвучено ТОЛЬКО то, что внутри *-...-*
    joined = " ".join(spoken)
    assert "Готово" in joined and "всё хорошо" in joined
    assert "Служебный ход мыслей" not in joined
    assert "подробности вне маркеров" not in joined
    assert res.spoken == joined
    # в истории диалога остался полный ответ с маркерами
    assert res.rounds == 2
    assert tokens, "токены стриминга должны приходить"


def test_agent_gate_clears_speech_on_tool_round(agent):
    """Если в круге вызван инструмент, частичная речь этого круга сбрасывается."""
    spoken = []
    res = agent.run("флюкс проверь справку", on_speak_chunk=lambda c: spoken.append(c.text))
    # речь пришла только из финального круга
    assert all("Служебный" not in s for s in spoken)
    assert res.spoken_chunks == spoken


def test_agent_confirmation_denied(agent, tmp_path):
    denies = []
    agent.ctx.confirm = lambda name, args: (denies.append(name), False)[1]
    res = agent.run("сделай опасное действие", on_speak_chunk=lambda c: None)
    assert CALLS["danger"] == 0, "опасный инструмент не должен выполняться без согласия"
    assert res.cancelled == ["mock_danger"]
    assert denies == ["mock_danger"]


def test_agent_confirmation_allowed(agent):
    agent.ctx.confirm = lambda name, args: True
    res = agent.run("сделай опасное действие", on_speak_chunk=lambda c: None)
    assert CALLS["danger"] == 1
    assert res.confirmed == ["mock_danger"]
    assert res.tool_log[-1].name == "mock_danger" and res.tool_log[-1].ok


def test_agent_saves_history(agent):
    cid = agent.store.new_conversation("тест истории")
    agent.run("флюкс проверь справку", conv_id=cid, on_speak_chunk=lambda c: None)
    hist = agent.store.history(cid)
    assert [m["role"] for m in hist] == ["user", "assistant"]
    assert "*-Готово" in hist[1]["content"]


def test_agent_recall_injected(agent):
    agent.store.remember("пользователь любит зелёный чай", "вкус")
    msgs = agent.build_messages("какой чай я люблю?")
    sys_blocks = [m["content"] for m in msgs if m["role"] == "system"]
    assert any("зелёный чай" in b for b in sys_blocks), "память должна попадать в контекст"


def test_agent_llm_error_is_reported(tmp_path, monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"llm": {"endpoint": "http://127.0.0.1:1", "model": "x",
                        "fallback_models": []}}, save=False)
    a = Agent(client=OllamaClient(endpoint="http://127.0.0.1:1", model="x",
                                  timeout=2),
              store=MemoryStore(str(tmp_path / "e.db")))
    res = a.run("привет", on_speak_chunk=lambda c: None)
    assert res.error, "ошибка сети должна попадать в result.error, а не ронять всё"
    assert res.text == ""
