﻿<#
.SYNOPSIS
  Инсталлер FLUX: голосовой ИИ-ассистент (voice-only) с интернетом, файлами,
  компьютером и устройствами.
.DESCRIPTION
  Создаёт D:\flux, ставит зависимости в изолированный venv, компилирует
  FluxMenu.exe, вешает ярлык на рабочий стол, проверяет Ollama и SearXNG,
  прогоняет самотест голосового тракта и показывает отчёт.
.PARAMETER InstallDir
  Каталог установки. По умолчанию D:\flux.
.PARAMETER OllamaKey
  OLLAMA_API_KEY для облачных моделей (gemma4:31b-cloud). Можно оставить пустым
  и ввести позже в меню/консоли.
.PARAMETER SkipSelftest
  Не прогонять самотест в конце установки.
.PARAMETER Autostart
  Сразу включить автозагрузку вместе с Windows.
.PARAMETER PullLocalModel
  Дополнительно скачать локальную запасную модель (gemma4:e4b).
.PARAMETER WhisperModel
  Какую модель распознавания речи скачать сразу при установке
  (large-v3-turbo | large-v3 | medium | small | base | tiny | none).
  По умолчанию large-v3-turbo: это тот же whisper large, но в 4-8 раз быстрее.
  Если ставишь на машину без GPU и с 8 ГБ памяти — бери small или base.
#>
[CmdletBinding()]
param(
    [string]$InstallDir = "D:\flux",
    [string]$OllamaKey = "",
    [switch]$SkipSelftest,
    [switch]$Autostart,
    [switch]$PullLocalModel,
    [string]$SearxUrl = "http://localhost:8888",
    [string]$WhisperModel = "large-v3-turbo"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$script:Repo = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path (Join-Path $script:Repo "app"))) { $script:Repo = $PSScriptRoot }

function Log([string]$msg) { Write-Host "  $msg" }
function Step([string]$msg) { Write-Host ""; Write-Host "==> $msg" -ForegroundColor Cyan }

Step "FLUX installer"
Log "репозиторий: $script:Repo"
Log "установка:   $InstallDir"

# ---------------------------------------------------------------- каталоги
Step "1/9 Каталоги"
foreach ($d in @("", "app", "config", "data", "logs", "models")) {
    New-Item -ItemType Directory -Force -Path (Join-Path $InstallDir $d) | Out-Null
}
$logFile = Join-Path $InstallDir ("logs\install_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date))
Start-Transcript -Path $logFile -Append -ErrorAction SilentlyContinue | Out-Null

# ---------------------------------------------------------------- python
Step "2/9 Python 3.10+"
$py = $null
foreach ($cand in @("py", "python", "python3")) {
    try {
        $ver = & $cand -c "import sys;print(sys.version_info[:2]>= (3,10))" 2>$null
        if ($ver -eq "True") { $py = $cand; break }
    } catch {}
}
if (-not $py) {
    Log "Python 3.10+ не найден. Пытаюсь поставить через winget..."
    try { winget install -e --id Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements | Out-Null } catch {}
    foreach ($cand in @("py", "python")) {
        try {
            $ver = & $cand -c "import sys;print(sys.version_info[:2]>=(3,10))" 2>$null
            if ($ver -eq "True") { $py = $cand; break }
        } catch {}
    }
}
if (-not $py) { throw "Нужен Python 3.10+ (https://www.python.org/downloads/). После установки запусти инсталлер снова." }
$pyVer = & $py -c "import sys;print('.'.join(map(str,sys.version_info[:3])))"
Log "использую python: $py ($pyVer)"

# ---------------------------------------------------------------- venv + deps
Step "3/9 Виртуальное окружение и зависимости"
$venv = Join-Path $InstallDir ".venv"
$venvPy = Join-Path $venv "Scripts\python.exe"
if (-not (Test-Path $venvPy)) {
    Log "создаю venv..."
    & $py -m venv $venv | Out-Null
}
& $venvPy -m pip install --upgrade pip --quiet --disable-pip-version-check --no-cache-dir | Out-Null
$req = Join-Path $PSScriptRoot "requirements.txt"
Log "ставлю зависимости (может занять несколько минут)..."
# --no-cache-dir: обходим повреждённый/залоченный кэш pip (Errno 13 на
# pip\cache\wheels\...), из-за которого установка падала
& $venvPy -m pip install -r $req --quiet --disable-pip-version-check --no-cache-dir
if ($LASTEXITCODE -ne 0) {
    Log "повторная попытка: чищу кэш pip и ставлю без кэша..."
    & $venvPy -m pip cache purge 2>$null | Out-Null
    & $venvPy -m pip install -r $req --disable-pip-version-check --no-cache-dir
    if ($LASTEXITCODE -ne 0) {
        throw ("pip install не удался. Частые причины: антивирус держит файлы " +
               "кэша/venv, или кэш pip повреждён. Закрой антивирус на время " +
               "установки или удали папку %LOCALAPPDATA%\pip\cache и повтори.")
    }
}

# ---------------------------------------------------------------- payload
Step "4/9 Копирование приложения"
$srcApp = Join-Path $script:Repo "app"
$dstApp = Join-Path $InstallDir "app"
robocopy $srcApp $dstApp /MIR /XD __pycache__ .pytest_cache /NFL /NDL /NJH /NJS | Out-Null
$ver = ""
try {
    $m = Select-String -Path (Join-Path $dstApp "flux\__init__.py") -Pattern '__version__ = "([^"]+)"'
    if ($m) { $ver = $m.Matches[0].Groups[1].Value }
} catch {}
if ($ver) {
    Set-Content -Path (Join-Path $InstallDir "VERSION.txt") -Value $ver -Encoding ASCII
    Log "скопировано в $dstApp (версия приложения: $ver)"
} else {
    Log "скопировано в $dstApp"
}

# стартовые батники с правильными путями
@"
@echo off
cd /d "$dstApp"
"$venvPy" -m flux.main %*
pause
"@ | Set-Content -Path (Join-Path $InstallDir "Flux-console.bat") -Encoding ASCII

@"
@echo off
cd /d "$dstApp"
start "" /B "$venvPy" -m flux.main %*
"@ | Set-Content -Path (Join-Path $InstallDir "Flux.bat") -Encoding ASCII

$pythonw = Join-Path $venv "Scripts\pythonw.exe"
@"
@echo off
cd /d "$dstApp"
start "" /B "$pythonw" -m flux.main %*
"@ | Set-Content -Path (Join-Path $InstallDir "Fluxw.bat") -Encoding ASCII

@"
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "$dstApp"
WshShell.Run Chr(34) & "$pythonw" & Chr(34) & " -m flux.main", 0, False
"@ | Set-Content -Path (Join-Path $InstallDir "Fluxw.vbs") -Encoding ASCII

@"
@echo off
cd /d "$dstApp"
"$venvPy" -m flux.selftest %*
pause
"@ | Set-Content -Path (Join-Path $InstallDir "FluxDiag.bat") -Encoding ASCII

@"
@echo off
cd /d "$dstApp"
"$pythonw" -m flux.menu_gui %*
"@ | Set-Content -Path (Join-Path $InstallDir "FluxMenu.bat") -Encoding ASCII

# ---------------------------------------------------------------- config
Step "5/9 Конфигурация"
if ($OllamaKey) { $env:FLUX_OLLAMA_KEY = $OllamaKey }
$env:FLUX_SEARX_URL = $SearxUrl
& $venvPy (Join-Path $PSScriptRoot "scripts\init_config.py")
Log "config.json готов"

# ---------------------------------------------------------------- menu exe
Step "6/9 Меню FluxMenu.exe + ярлык на рабочем столе"
$menuExe = Join-Path $InstallDir "FluxMenu.exe"
$cs = Get-Content -Raw (Join-Path $PSScriptRoot "Launcher.cs")
try {
    Add-Type -TypeDefinition $cs -OutputAssembly $menuExe -OutputType WindowsApplication `
        -ReferencedAssemblies "System.Windows.Forms","System.Drawing" -IgnoreWarnings
    Log "FluxMenu.exe скомпилирован"
    $target = $menuExe
} catch {
    Log "компиляция C# не удалась ($_), использую FluxMenu.bat"
    $target = Join-Path $InstallDir "FluxMenu.bat"
}
try {
    $ws = New-Object -ComObject WScript.Shell
    $desktop = [Environment]::GetFolderPath("Desktop")
    $lnkPath = Join-Path $desktop "FLUX.lnk"
    $lnk = $ws.CreateShortcut($lnkPath)
    $lnk.TargetPath = $target
    $lnk.WorkingDirectory = $InstallDir
    $ico = Join-Path $dstApp "flux\ui\flux.ico"
    if (Test-Path $ico) { $lnk.IconLocation = "$ico,0" }
    $lnk.Description = "FLUX - голосовой ИИ-ассистент"
    $lnk.Save()
    Log "ярлык: $lnkPath -> $target"
} catch {
    Log "ярлык не создан: $_"
}

# ---------------------------------------------------------------- ollama
Step "7/9 Ollama и модель"
$ollamaOk = $false
try {
    $v = Invoke-RestMethod "http://localhost:11434/api/version" -TimeoutSec 5
    $ollamaOk = $true
    Log "локальный Ollama: $($v.version)"
} catch {
    Log "локальный Ollama не отвечает. Пытаюсь поставить (winget)..."
    try { winget install -e --id Ollama.Ollama --silent --accept-source-agreements --accept-package-agreements | Out-Null } catch {}
    try {
        Invoke-RestMethod "http://localhost:11434/api/version" -TimeoutSec 8 | Out-Null
        $ollamaOk = $true
        Log "Ollama поставлен и отвечает"
    } catch {
        Log "ВНИМАНИЕ: Ollama не поднят. Запусти приложение Ollama и выполни вход (ollama signin) для cloud-моделей."
    }
}
if ($ollamaOk -and $PullLocalModel) {
    Log "тяну локальную запасную модель gemma4:e4b..."
    & (Get-Command ollama -ErrorAction SilentlyContinue).Source pull gemma4:e4b
}
if ($OllamaKey) {
    try {
        $h = @{ Authorization = "Bearer $OllamaKey" }
        $tags = Invoke-RestMethod "https://ollama.com/api/tags" -Headers $h -TimeoutSec 10
        Log "Ollama Cloud доступен, моделей: $($tags.models.Count)"
    } catch {
        Log "ВНИМАНИЕ: Ollama Cloud с этим ключом не ответил: $_"
    }
}

# ---------------------------------------------------------------- searxng
Step "8/9 SearXNG ($SearxUrl)"
try {
    $r = Invoke-RestMethod "$SearxUrl/search?q=flux+test&format=json" -TimeoutSec 8
    Log "SearXNG отвечает, результатов: $($r.results.Count)"
} catch {
    Log "ВНИМАНИЕ: SearXNG на $SearxUrl не отвечает (формат json)."
    Log "Если контейнер не поднят: docker compose -f $InstallDir\docker\searxng\docker-compose.yml up -d"
}

# ------------------------------------------------- модель распознавания речи
Step "8.5/9 Модель whisper ($WhisperModel)"
if ($WhisperModel -eq "none") {
    Log "пропущено по флагу -WhisperModel none (скачается при первом запуске)"
} else {
    Push-Location $dstApp
    try {
        & $venvPy -c "import sys; from flux.stt import whisper_check; sys.exit(whisper_check.main(['2','$WhisperModel']))"
        $code = $LASTEXITCODE
        if ($code -eq 0) {
            Log "модель $WhisperModel скачана и проверена на микрофоне"
        } elseif ($code -eq 2) {
            Log "ВНИМАНИЕ: модель $WhisperModel скачана и РАБОТАЕТ, но микрофон не дал звука (устройство недоступно/занято). Это НЕ поломка whisper: проверь микрофон в консоли -> Настройки -> Микрофон и повтори тест из меню («Проверить whisper»)."
        } else {
            Log "ВНИМАНИЕ: модель $WhisperModel не завелась. FLUX сам возьмёт более лёгкую (large-v3-turbo -> large-v3 -> medium -> small -> base -> tiny), а причину напишет в лог. Модель меняется в консоли: Настройки -> Понимание речи."
        }
    } catch {
        Log "ВНИМАНИЕ: не удалось скачать модель ($_. Exception.Message). FLUX скачает её при первом запуске."
    }
    Pop-Location
}

# ---------------------------------------------------------------- selftest
Step "9/9 Самотест голосового тракта"
if ($SkipSelftest) {
    Log "пропущен по флагу -SkipSelftest"
} else {
    Push-Location $dstApp
    & $venvPy -m flux.selftest
    $code = $LASTEXITCODE
    Pop-Location
    if ($code -eq 0) {
        Log "САМОТЕСТ ПРОЙДЕН"
    } else {
        Log "ВНИМАНИЕ: самотест сообщил о проблемах (код $code). Отчёт в $InstallDir\logs\selftest_*.txt"
    }
}

if ($Autostart) {
    Push-Location $dstApp
    $env:FLUX_AUTOSTART = "1"
    & $venvPy (Join-Path $PSScriptRoot "scripts\set_autostart.py")
    Pop-Location
    Log "автозагрузка включена"
}

Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host " FLUX установлен в $InstallDir" -ForegroundColor Green
Write-Host " Ярлык на рабочем столе: FLUX (откроет скромное меню)" -ForegroundColor Green
Write-Host " Запуск: двойной клик по ярлыку -> 'Запустить ИИ'" -ForegroundColor Green
Write-Host " Активация голосом: скажи 'флюкс' + команда, или зажми Numpad 9" -ForegroundColor Green
Write-Host " Консоль: http://127.0.0.1:8790/ (Настройки -> выбор моделей)" -ForegroundColor Green
Write-Host " Сообщение уходит ИИ ЦЕЛИКОМ: whisper замолчал на 5 c (stream.word_idle_sec)" -ForegroundColor Green
Write-Host " Для внешнего whisper: POST http://127.0.0.1:8793/v1/audio/transcriptions" -ForegroundColor Green
Write-Host " Или положи .txt с текстом в D:\flux\data\inbox — FLUX подхватит и отправит ИИ целиком" -ForegroundColor Green
Write-Host " Лог установки: $logFile" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
