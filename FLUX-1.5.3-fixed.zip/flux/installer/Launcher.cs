// FLUX Menu launcher - тонкий нативный ярлык .exe для рабочего стола.
// Запускает скромное меню (Tkinter) скрытым процессом и завершается.
// Компилируется инсталлером через Add-Type (PowerShell 5.1 / .NET Framework).
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace Flux
{
    internal static class Launcher
    {
        [STAThread]
        private static void Main(string[] args)
        {
            try
            {
                string home = @"D:\flux";
                if (args.Length > 0 && Directory.Exists(args[0])) home = args[0];
                string appDir = Path.Combine(home, "app");
                string pythonw = Path.Combine(home, ".venv", "Scripts", "pythonw.exe");
                string python = Path.Combine(home, ".venv", "Scripts", "python.exe");
                string exe;
                if (File.Exists(pythonw)) exe = pythonw;
                else if (File.Exists(python)) exe = python;
                else
                {
                    // фолбэк: python из PATH
                    exe = "pythonw.exe";
                    try { Process.Start("pythonw.exe", "--version"); }
                    catch
                    {
                        MessageBox.Show(
                            "Не найден Python в D:\\flux\\.venv.\nЗапусти Flux-Installer.bat.",
                            "FLUX", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
                var psi = new ProcessStartInfo
                {
                    FileName = exe,
                    Arguments = "-m flux.menu_gui",
                    WorkingDirectory = appDir,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show("FLUX menu: " + ex.Message, "FLUX",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
