﻿<# Полное удаление FLUX: ярлык, автозагрузка, venv, каталог. Данные (память)
   сохраняются в D:\flux-backup, если не указан -WipeAll. #>
param([switch]$WipeAll, [string]$InstallDir = "D:\flux")
$ErrorActionPreference = "Stop"
Write-Host "Удаление FLUX из $InstallDir"
try {
    $ws = New-Object -ComObject WScript.Shell
    $lnk = Join-Path ([Environment]::GetFolderPath("Desktop")) "FLUX.lnk"
    if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Host "  ярлык удалён" }
} catch {}
try {
    $key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey(
        "Software\Microsoft\Windows\CurrentVersion\Run", $true)
    if ($key.GetValue("FluxAssistant")) { $key.DeleteValue("FluxAssistant"); Write-Host "  автозагрузка удалена" }
    $key.Close()
} catch {}
if (-not $WipeAll -and (Test-Path $InstallDir)) {
    $backup = "D:\flux-backup"
    New-Item -ItemType Directory -Force -Path $backup | Out-Null
    Copy-Item (Join-Path $InstallDir "data") $backup -Recurse -Force -ErrorAction SilentlyContinue
    Copy-Item (Join-Path $InstallDir "config") $backup -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "  память и конфиг сохранены в $backup"
}
if (Test-Path $InstallDir) { Remove-Item $InstallDir -Recurse -Force; Write-Host "  каталог удалён" }
Write-Host "Готово."
