"""Включение/выключение автозагрузки из инсталлера (флаг через env)."""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "app"))

from flux import autostart


def main() -> int:
    enabled = os.environ.get("FLUX_AUTOSTART", "0") == "1"
    ok = autostart.set_autostart(enabled)
    print("autostart:", "ok" if ok else "skip/unsupported")
    return 0 if ok or os.name != "nt" else 1


if __name__ == "__main__":
    sys.exit(main())
