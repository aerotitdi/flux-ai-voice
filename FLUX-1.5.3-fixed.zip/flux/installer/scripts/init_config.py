"""Создание/дополнение config.json при установке.

Значения передаются через переменные окружения, чтобы в install.ps1 не было
inline-кода Python (и связанных с ним проблем кавычек в PowerShell 5.1).
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "app"))

from flux import config, paths


def main() -> int:
    paths.ensure_dirs()
    config.load(force=True)
    key = os.environ.get("FLUX_OLLAMA_KEY", "").strip()
    if key:
        config.set_value("llm.api_key", key, save=False)
    searx = os.environ.get("FLUX_SEARX_URL", "").strip()
    if searx:
        config.set_value("search.searxng_url", searx, save=False)
    config.save_config()
    print("config.json готов:", paths.CONFIG_FILE)
    return 0


if __name__ == "__main__":
    sys.exit(main())
