@echo off
rem ============================================================
rem  FLUX - инсталлер. Запуск: двойной клик (или ПКМ -> Изменить
rem  для параметров). Ставит в D:\flux, вешает ярлык FLUX на
rem  рабочий стол, проверяет Ollama/SearXNG, гоняет самотест.
rem  Параметры можно передать так:
rem    Flux-Installer.bat -OllamaKey ollama_xxx -Autostart
rem ============================================================
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
pause
