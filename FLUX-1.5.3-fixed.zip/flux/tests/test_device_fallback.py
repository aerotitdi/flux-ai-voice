"""Баг -9996 «Invalid device»: устаревший индекс микрофона не роняет запись.

Живой лог установки пользователя: модель large-v3-turbo загрузилась
(cuda/int8, 179 c), а whisper-тест умер на «Error opening RawInputStream:
Invalid device [PaErrorCode -9996]» — в конфиге лежал численный индекс
PortAudio, который сместился после подключения/отключения устройств.
Здесь подставной sounddevice доказывает: FLUX идёт по цепочке
(запрошенное устройство -> настройка по имени -> устройство по умолчанию)
и честно пишет, каким микрофоном писал в итоге.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

import flux.audio.devices as devmod
from flux import config


class FakePaError(Exception):
    """Тот самый PaError sounddevice."""


DEVICES = [
    {"name": "Old Mic", "max_input_channels": 1, "hostapi": 0,
     "default_samplerate": 16000},
    {"name": "Good Mic", "max_input_channels": 1, "hostapi": 0,
     "default_samplerate": 16000},
    {"name": "Headset Mic", "max_input_channels": 1, "hostapi": 0,
     "default_samplerate": 16000},
]


class FakeSD:
    def __init__(self, fail=(), feed=True, default_in=1, loud=()):
        self.fail = set(fail)
        self.feed = feed
        self.loud = set(loud)   # устройства, дающие ЖИВОЙ сигнал в пробном замере
        self.default = (default_in, -1)
        self.opened = []

    def query_devices(self):
        return DEVICES

    def query_hostapis(self):
        return [{"name": "Windows WASAPI"}]

    def RawInputStream(self, **kw):  # noqa: N802 - имя из sounddevice
        sd = self
        idx = kw.get("device")

        class Stream:
            def __enter__(self):
                if idx in sd.fail:
                    raise FakePaError("Error opening RawInputStream: "
                                      "Invalid device [PaErrorCode -9996]")
                sd.opened.append(idx)
                if idx in sd.loud:
                    kw["callback"](np.full(800, 9000, dtype=np.int16), 800,
                                   None, None)
                elif sd.feed:
                    kw["callback"](np.full(800, 7, dtype=np.int16), 800,
                                   None, None)
                return self

            def __exit__(self, *a):
                return False

        return Stream()


@pytest.fixture()
def cfg_restore():
    saved = {k: config.get(f"audio.{k}") for k in ("input_device",
                                                   "input_device_name")}
    yield
    for k, v in saved.items():
        config.set_value(f"audio.{k}", v, save=False)


def test_stale_index_falls_back_to_default(monkeypatch, cfg_restore):
    config.set_value("audio.input_device_name", "", save=False)
    fake = FakeSD(fail={0})
    monkeypatch.setattr(devmod, "_load_sounddevice", lambda: fake)
    audio, info = devmod.record_seconds(0.01, device_spec=0)
    assert info["ok"] is True
    assert info["device"] == "Good Mic", info
    assert info["fallback_from"] == "Old Mic"
    assert audio.size > 0
    # [1, 2] - пробные замеры сигнала кандидатов фолбэка, затем [1] - запись:
    # молчаливые устройства остаются в исходном порядке (все ниже порога)
    assert fake.opened == [1, 2, 1], fake.opened


def test_fallback_prefers_live_mic_by_signal(monkeypatch, cfg_restore):
    """Запрошенное устройство мертво, а «первый открывшийся» (Good Mic)
    молчит. Раньше цепочка взяла бы его (как молчаливый Sound Mapper в
    живом логе). Теперь кандидаты ранжируются пробным замером: живой
    Headset Mic (пик 0.27) важнее порядка в списке."""
    config.set_value("audio.input_device_name", "", save=False)
    fake = FakeSD(fail={0}, loud={2})
    monkeypatch.setattr(devmod, "_load_sounddevice", lambda: fake)
    audio, info = devmod.record_seconds(0.01, device_spec=0)
    assert info["ok"] is True, info
    assert info["device"] == "Headset Mic", info
    assert info["signal_ranked"] is True
    assert info["fallback_from"] == "Old Mic"
    assert audio.size > 0


def test_rank_by_signal_orders_live_first():
    """Чистая проверка ранжирования: живой сигнал выше порога - в начало,
    по убыванию пика; молчаливые - в исходном порядке."""
    class Dev:
        def __init__(self, i, n):
            self.index, self.name = i, n
    devs = [Dev(1, "Silent Mapper"), Dev(2, "Quiet Mic"), Dev(3, "Live Mic")]
    peaks = {1: 0.0001, 2: 0.05, 3: 0.3}

    class FakeProbe:
        def RawInputStream(self, **kw):  # noqa: N802
            idx = kw.get("device")

            class Stream:
                def __enter__(self):
                    kw["callback"](np.full(800, int(peaks[idx] * 32767),
                                           dtype=np.int16), 800, None, None)
                    return self

                def __exit__(self, *a):
                    return False
            return Stream()

    import flux.audio.devices as dm
    old_load = dm._load_sounddevice
    dm._load_sounddevice = lambda: FakeProbe()
    try:
        got = dm.rank_by_signal(devs, probe_sec=0.01)
    finally:
        dm._load_sounddevice = old_load
    assert [d.name for d in got] == ["Live Mic", "Quiet Mic", "Silent Mapper"]


def test_all_devices_dead_is_honest_error(monkeypatch, cfg_restore):
    fake = FakeSD(fail={0, 1, 2})
    monkeypatch.setattr(devmod, "_load_sounddevice", lambda: fake)
    audio, info = devmod.record_seconds(0.01, device_spec=0)
    assert info["ok"] is False and audio.size == 0
    assert "-9996" in info["error"], info
    assert fake.opened == []


def test_name_from_config_wins_over_stale_index(monkeypatch, cfg_restore):
    config.set_value("audio.input_device", 0, save=False)
    config.set_value("audio.input_device_name", "Headset", save=False)
    assert devmod.configured_spec() == "Headset"
    fake = FakeSD(fail={0})
    monkeypatch.setattr(devmod, "_load_sounddevice", lambda: fake)
    audio, info = devmod.record_seconds(0.01, device_spec=0)
    assert info["ok"] is True and info["device"] == "Headset Mic"


def test_mic_self_test_falls_back_too(monkeypatch, cfg_restore):
    config.set_value("audio.input_device_name", "", save=False)
    fake = FakeSD(fail={1}, default_in=1)
    monkeypatch.setattr(devmod, "_load_sounddevice", lambda: fake)
    # умолчание (Good Mic) мертво -> цепочка дойдёт до следующего живого
    res = devmod.mic_self_test(seconds=0.01)
    assert res["ok"] is True, res
    assert res["device"] in ("Old Mic", "Headset Mic")


def test_mic_self_test_all_dead(monkeypatch, cfg_restore):
    fake = FakeSD(fail={0, 1, 2})
    monkeypatch.setattr(devmod, "_load_sounddevice", lambda: fake)
    res = devmod.mic_self_test(seconds=0.01)
    assert res["ok"] is False and "-9996" in res["error"]


def test_attempt_specs_dedups():
    specs = devmod.attempt_specs(None)
    assert specs == [None]
    specs = devmod.attempt_specs(3)
    assert specs[0] == 3 and specs[-1] is None
