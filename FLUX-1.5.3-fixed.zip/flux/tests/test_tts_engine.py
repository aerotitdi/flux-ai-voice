"""Тесты озвучки: формат параметров как в спейсе innoai/Edge-TTS-Text-to-Speech,
ретраи, фолбэки, маршрутизация движков."""
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.tts import engine as te


# --------------------------------------------------- форматы как в HF-спейсе
def test_rate_format_matches_space():
    assert te.rate_str(0) == "+0%"
    assert te.rate_str(25) == "+25%"
    assert te.rate_str(-50) == "-50%"
    assert te.rate_str(7) == "+7%"


def test_pitch_format_matches_space():
    assert te.pitch_str(0) == "+0Hz"
    assert te.pitch_str(-20) == "-20Hz"
    assert te.pitch_str(12) == "+12Hz"


def test_clamping_to_space_ranges():
    assert te.clamp_rate(100) == 50
    assert te.clamp_rate(-100) == -50
    assert te.clamp_pitch(99) == 20
    assert te.clamp_pitch(-99) == -20
    assert te.rate_str(100) == "+50%"
    assert te.pitch_str(99) == "+20Hz"


def test_voice_label_format_like_space_dropdown():
    v = te.VoiceInfo("ru-RU-DmitryNeural", "ru-RU", "Male")
    assert v.label == "ru-RU-DmitryNeural - ru-RU (Male)"


# ------------------------------------------------------------- валидация mp3
def test_valid_mp3_detection(tmp_path):
    good = tmp_path / "g.mp3"
    good.write_bytes(b"ID3" + b"\x00" * 900)
    assert te.EdgeTTSEngine._valid_mp3(str(good)) is True
    bad = tmp_path / "b.mp3"
    bad.write_bytes(b"<html>error</html>")
    assert te.EdgeTTSEngine._valid_mp3(str(bad)) is False
    tiny = tmp_path / "t.mp3"
    tiny.write_bytes(b"ID3")
    assert te.EdgeTTSEngine._valid_mp3(str(tiny)) is False
    assert te.EdgeTTSEngine._valid_mp3(str(tmp_path / "none.mp3")) is False


# ------------------------------------------------------- маршрутизация/фолбэк
class FakeEngine:
    def __init__(self, name, result=None, exc=None):
        self.name = name
        self.result = result
        self.exc = exc
        self.calls = 0

    def available(self):
        return True

    def synthesize(self, text, out_path=None):
        self.calls += 1
        if self.exc:
            raise self.exc
        return self.result


def test_router_falls_back_when_primary_fails(tmp_path):
    router = te.TTSRouter.__new__(te.TTSRouter)
    router._lock = __import__("threading").Lock()
    a = FakeEngine("edge", None)             # edge "сломан"
    b = FakeEngine("sapi5", str(tmp_path / "x.wav"))
    router.edge, router.hf, router.sapi5 = a, FakeEngine("hf_space", None), b
    router.preferred = "auto"
    router.enabled = True
    path, used = router.synthesize("привет")
    assert used == "sapi5" and path is not None
    assert a.calls == 1 and b.calls == 1


def test_router_prefers_edge_and_reports_engine(tmp_path):
    router = te.TTSRouter.__new__(te.TTSRouter)
    router._lock = __import__("threading").Lock()
    a = FakeEngine("edge", str(tmp_path / "e.mp3"))
    b = FakeEngine("sapi5", str(tmp_path / "s.wav"))
    router.edge, router.hf, router.sapi5 = a, FakeEngine("hf_space", None), b
    router.preferred = "auto"
    router.enabled = True
    path, used = router.synthesize("привет")
    assert used == "edge"
    assert b.calls == 0, "запасной не должен вызываться, если основной работает"


def test_router_disabled_and_empty_text():
    router = te.TTSRouter.__new__(te.TTSRouter)
    router._lock = __import__("threading").Lock()
    router.edge = router.hf = router.sapi5 = FakeEngine("edge", "x")
    router.preferred = "auto"
    router.enabled = False
    assert router.synthesize("текст") == (None, "disabled")
    router.enabled = True
    assert router.synthesize("   ") == (None, "disabled")
    assert router.synthesize("") == (None, "disabled")


def test_router_all_engines_fail():
    router = te.TTSRouter.__new__(te.TTSRouter)
    router._lock = __import__("threading").Lock()
    router.edge = FakeEngine("edge", None, exc=RuntimeError("net"))
    router.hf = FakeEngine("hf_space", None)
    router.sapi5 = FakeEngine("sapi5", None)
    router.preferred = "auto"
    router.enabled = True
    assert router.synthesize("привет") == (None, "none")


def test_preferred_engine_respected(tmp_path):
    router = te.TTSRouter.__new__(te.TTSRouter)
    router._lock = __import__("threading").Lock()
    a = FakeEngine("edge", str(tmp_path / "e.mp3"))
    s = FakeEngine("sapi5", str(tmp_path / "s.wav"))
    router.edge, router.hf, router.sapi5 = a, FakeEngine("hf_space", None), s
    router.preferred = "sapi5"
    router.enabled = True
    path, used = router.synthesize("привет")
    assert used == "sapi5"


# --------------------------------------------------------- реальный edge-tts
@pytest.mark.network
def test_real_edge_tts_synthesis_and_decode(tmp_path):
    """Реальный синтез (как в спейсе) + декодирование в PCM плеером."""
    eng = te.EdgeTTSEngine(voice="ru-RU-DmitryNeural", rate=0, pitch=0, retries=3)
    if not eng.available():
        pytest.skip("edge-tts не установлен")
    out = tmp_path / "speech.mp3"
    path = eng.synthesize("Флюкс на связи. Проверка озвучки.", str(out))
    assert path is not None, "edge-tts не смог синтезировать (сеть/лимиты)"
    assert os.path.getsize(path) > 1000
    from flux.audio.player import decode_audio_file
    data, sr = decode_audio_file(path, target_sr=24000)
    assert data.size > 24000 * 0.5, "аудио слишком короткое"
    assert abs(data).max() > 0.05, "аудио пустое"


@pytest.mark.network
def test_rate_and_pitch_actually_change_audio(tmp_path):
    eng_slow = te.EdgeTTSEngine(voice="ru-RU-DmitryNeural", rate=-30)
    eng_fast = te.EdgeTTSEngine(voice="ru-RU-DmitryNeural", rate=+30)
    if not eng_slow.available():
        pytest.skip("edge-tts не установлен")
    text = "Это проверка скорости речи для ассистента Флюкс."
    p1 = eng_slow.synthesize(text, str(tmp_path / "slow.mp3"))
    p2 = eng_fast.synthesize(text, str(tmp_path / "fast.mp3"))
    if not p1 or not p2:
        pytest.skip("сеть недоступна")
    from flux.audio.player import decode_audio_file
    d1, sr1 = decode_audio_file(p1)
    d2, sr2 = decode_audio_file(p2)
    assert len(d1) > len(d2) * 1.15, "rate=-30% должен быть заметно длиннее +30%"


def test_sapi5_unavailable_on_linux():
    if os.name == "nt":
        pytest.skip("тест для не-Windows")
    eng = te.SAPI5Engine()
    assert eng.available() is False


# ------------------------------------------------- ключевые движки (рекомендации)
def _mp3_bytes():
    return b"ID3" + b"\x00" * 900


def test_openai_tts_engine_against_mock(monkeypatch, tmp_path):
    import requests as _rq
    from flux.tts import engine as te

    calls = {}

    class R:
        status_code = 200
        content = _mp3_bytes()

        def raise_for_status(self):
            return None

    def fake_post(url, headers=None, json=None, timeout=None):
        calls["url"] = url; calls["json"] = json; calls["headers"] = headers
        return R()

    monkeypatch.setattr(_rq, "post", fake_post)
    monkeypatch.setattr(te.config, "get",
                        lambda k, d=None: {"keys.openai": "sk-test",
                                           "tts.openai": {}}.get(k, d))
    eng = te.OpenAITTSEngine()
    out = eng.synthesize("привет", str(tmp_path / "o.mp3"))
    assert out is not None
    assert calls["url"].endswith("/audio/speech")
    assert calls["headers"]["Authorization"] == "Bearer sk-test"
    assert calls["json"]["voice"] and calls["json"]["model"]


def test_elevenlabs_engine_against_mock(monkeypatch, tmp_path):
    import requests as _rq
    from flux.tts import engine as te

    calls = {}

    class R:
        status_code = 200
        content = _mp3_bytes()

        def raise_for_status(self):
            return None

    def fake_post(url, headers=None, json=None, params=None, timeout=None):
        calls["url"] = url; calls["headers"] = headers; calls["params"] = params
        return R()

    monkeypatch.setattr(_rq, "post", fake_post)
    monkeypatch.setattr(te.config, "get",
                        lambda k, d=None: {"keys.elevenlabs": "el-key",
                                           "tts.elevenlabs": {}}.get(k, d))
    eng = te.ElevenLabsEngine()
    out = eng.synthesize("привет", str(tmp_path / "e.mp3"))
    assert out is not None
    assert "/v1/text-to-speech/" in calls["url"]
    assert calls["headers"]["xi-api-key"] == "el-key"
    assert calls["params"]["model_id"].startswith("eleven_")


def test_router_prefers_key_engines(monkeypatch):
    from flux.tts import engine as te
    monkeypatch.setattr(te.config, "get",
                        lambda k, d=None: {"keys.openai": "sk", "keys.elevenlabs": "el",
                                           "tts": {"engine": "auto", "enabled": True,
                                                   "edge": {}, "sapi5": {}}}.get(k, d)
                        if k in ("keys.openai", "keys.elevenlabs", "tts")
                        else te.config.__dict__.get("get", lambda *a, **kw: d)(k, d))
    r = te.TTSRouter.__new__(te.TTSRouter)
    import threading as _th
    r._lock = _th.Lock()
    r.edge = te.EdgeTTSEngine(); r.sapi5 = te.SAPI5Engine(); r.hf = te.HFSpaceEngine()
    r.openai_tts = type("E", (), {"name": "openai", "available": lambda self: True})()
    r.elevenlabs = type("E", (), {"name": "elevenlabs",
                                  "available": lambda self: True})()
    r.preferred = "auto"
    names = [e.name for e in r._order()]
    assert names[:2] == ["openai", "elevenlabs"], names
    assert "edge" in names and "sapi5" in names


def test_sapi5_skips_cyrillic_without_ru_voice(monkeypatch):
    from flux.tts import engine as te
    eng = te.SAPI5Engine()
    monkeypatch.setattr(te.SAPI5Engine, "_has_ru_voice", staticmethod(lambda: False))
    monkeypatch.setattr(te, "os", type("OS", (), {"name": "nt"})())
    assert eng.synthesize("привет мир") is None, \
        "без русского голоса SAPI5 не должен бубнить по-русски английским"


def test_stt_preset_groq_from_keys(monkeypatch):
    from flux import config as cfg
    from flux.stt.api import WhisperAPISTT
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"keys": {"groq": "gsk-123"}}, save=False)
    stt = WhisperAPISTT()
    assert stt.preset == "groq"
    assert stt.base_url == "https://api.groq.com/openai/v1"
    assert stt.model == "whisper-large-v3-turbo"
    assert stt.enabled() is True
