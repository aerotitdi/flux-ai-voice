"""Штука для проверки локального whisper (кнопка/меню/CLI)."""
from __future__ import annotations

from types import SimpleNamespace

import numpy as np

from flux.stt import whisper_check


def _dummy_model(text: str):
    class M:
        def transcribe(self, arr, **kw):
            segs = []
            if text:
                segs.append(SimpleNamespace(text=text, avg_logprob=-0.1,
                                            start=0.0, end=1.0))
            return iter(segs), SimpleNamespace(language="ru")
    return M()


def _patch(monkeypatch, text: str):
    import flux.audio.devices as devmod
    import flux.stt.local as L

    audio = (np.sin(np.linspace(0, 120, 96000)) * 2500).astype(np.int16)
    monkeypatch.setattr(devmod, "record_seconds",
                        lambda seconds=4.0, sample_rate=16000, device_spec=None:
                        (audio, {"ok": True, "device": "TestMic", "index": 0}))
    monkeypatch.setattr(L, "get_model",
                        lambda *a, **k: (_dummy_model(text), "base"))
    return audio


def test_check_reports_numbers_and_text(monkeypatch):
    _patch(monkeypatch, "флюкс проверь себя")
    d = whisper_check.check(seconds=6.0)
    assert d["ok"] is True
    assert d["mic"] == "TestMic"
    assert d["rec_sec"] == 6.0
    assert d["tr_sec"] >= 0 and d["rtf"] >= 0
    assert d["text"] == "флюкс проверь себя"
    assert d["peak"] > 0.01 and d["dbfs"] < 0


def _patch_silence(monkeypatch, text):
    """Микрофон молчит (пик -74 dBFS, как в живом логе пользователя)."""
    import flux.audio.devices as devmod
    import flux.stt.local as L
    silence = np.zeros(96000, dtype=np.int16)
    monkeypatch.setattr(devmod, "record_seconds",
                        lambda seconds=4.0, sample_rate=16000, device_spec=None:
                        (silence, {"ok": True, "device": "Sound Mapper",
                                   "index": 3}))
    monkeypatch.setattr(L, "get_model",
                        lambda *a, **k: (_dummy_model(text), "base"))
    return silence


def test_silence_with_hallucination_is_mic_failure(monkeypatch):
    """Живой баг пользователя: пик -74.7 dBFS, whisper галлюцинировал
    («Субтитры создавал DimaTorzok»), а тест рапортовал успех. Теперь
    тишина = провал стадии mic, а текст помечен галлюцинацией."""
    _patch_silence(monkeypatch, "Субтитры создавал DimaTorzok")
    d = whisper_check.check(seconds=6.0)
    assert d["ok"] is False and d["stage"] == "mic"
    assert d["silent"] is True and d["hallucination"] is True
    assert "галлюцинация" in d["error"]
    rep = whisper_check.report(d)
    assert "МОЛЧИТ" in rep and "галлюцинац" in rep.lower()
    assert whisper_check.main(["2"]) == 2   # install.ps1: честное предупреждение


def test_silence_without_text_is_mic_failure_too(monkeypatch):
    _patch_silence(monkeypatch, "")
    d = whisper_check.check(seconds=6.0)
    assert d["ok"] is False and d["stage"] == "mic" and d["silent"] is True
    assert d["hallucination"] is False
    assert "молчит" in d["error"]


def test_check_mic_failure(monkeypatch):
    import flux.audio.devices as devmod
    import flux.stt.local as L
    monkeypatch.setattr(devmod, "record_seconds",
                        lambda seconds=4.0, sample_rate=16000, device_spec=None:
                        (np.zeros(0, dtype=np.int16),
                         {"ok": False, "error": "микрофон не найден"}))
    monkeypatch.setattr(L, "get_model",
                        lambda *a, **k: (_dummy_model("x"), "base"))
    d = whisper_check.check(seconds=6.0)
    assert d["ok"] is False and "микрофон" in d["error"]
    assert "НЕ прошёл" in whisper_check.report(d)


def test_report_mentions_gpu_and_rtf(monkeypatch):
    _patch(monkeypatch, "привет")
    rep = whisper_check.report(whisper_check.check(seconds=6.0))
    assert "модель:" in rep and "RTF" in rep and "микрофон:" in rep


def test_quiet_mic_warning(monkeypatch):
    import flux.audio.devices as devmod
    import flux.stt.local as L
    quiet = (np.sin(np.linspace(0, 120, 96000)) * 100).astype(np.int16)
    monkeypatch.setattr(devmod, "record_seconds",
                        lambda seconds=4.0, sample_rate=16000, device_spec=None:
                        (quiet, {"ok": True, "device": "QuietMic", "index": 1}))
    monkeypatch.setattr(L, "get_model",
                        lambda *a, **k: (_dummy_model(""), "base"))
    rep = whisper_check.report(whisper_check.check(seconds=6.0))
    assert "очень тихий" in rep and "НЕ усиливает" in rep

def test_main_returns_1_when_model_is_dead(monkeypatch, capsys):
    def boom(*a, **k):
        raise RuntimeError("ни одна whisper-модель не загрузилась")

    monkeypatch.setattr(whisper_check, "check", boom)
    assert whisper_check.main(["2", "base"]) == 1
    out = capsys.readouterr().out
    assert "более лёгкую" in out and "Понимание речи" in out


def test_main_returns_2_when_mic_gave_nothing(monkeypatch, capsys):
    monkeypatch.setattr(whisper_check, "check",
                        lambda seconds=6.0, model_size=None: {
                            "ok": False, "model": "base",
                            "device_compute": "cpu",
                            "error": "микрофон не дал данных"})
    assert whisper_check.main(["2"]) == 2
    assert "НЕ прошёл" in capsys.readouterr().out


def test_main_returns_0_on_success(monkeypatch, capsys):
    monkeypatch.setattr(whisper_check, "check",
                        lambda seconds=6.0, model_size=None: {
                            "ok": True, "model": "base", "requested_model": "base",
                            "model_fallback": False, "words": 4,
                            "device_compute": "cpu", "compute_type": "int8",
                            "load_sec": 1.0, "mic": "TestMic", "rec_sec": 2.0,
                            "tr_sec": 0.5, "rtf": 0.25, "peak": 0.2,
                            "dbfs": -14.0, "engine": "local",
                            "text": "флюкс включи свет"})
    assert whisper_check.main(["2"]) == 0
    out = capsys.readouterr().out
    assert "слов с метками времени: 4" in out


# ---------------------------------------------------------------- стадии ошибок
def test_stage_model_error_report_and_code(monkeypatch, capsys):
    """Модель умерла -> код 1 и совет про запасную цепочку моделей."""
    import flux.audio.devices as devmod
    import flux.stt.local as L

    def boom(*a, **k):
        raise RuntimeError("OOM: large-v3-turbo не влезла в память")

    monkeypatch.setattr(L, "get_model", boom)
    monkeypatch.setattr(devmod, "record_seconds",
                        lambda *a, **k: (_ for _ in ()).throw(
                            AssertionError("до микрофона дело не дошло")))
    d = whisper_check.check(seconds=2.0)
    assert d["ok"] is False and d["stage"] == "model"
    rep = whisper_check.report(d)
    assert "МОДЕЛЬ" in rep and "более лёгкую" in rep
    assert whisper_check.main([]) == 1
    assert "МОДЕЛЬ" in capsys.readouterr().out


def test_stage_mic_error_says_mic_not_model(monkeypatch, capsys):
    """Микрофон мёртв -> код 2, и в отчёте НЕ пишется «модель не загрузилась»."""
    import flux.audio.devices as devmod
    import flux.stt.local as L

    def mic_dead(*a, **k):
        raise OSError("Error opening RawInputStream: Invalid device "
                      "[PaErrorCode -9996]")

    monkeypatch.setattr(L, "get_model", lambda *a, **k: (_dummy_model("x"), "base"))
    monkeypatch.setattr(devmod, "record_seconds", mic_dead)
    d = whisper_check.check(seconds=2.0)
    assert d["ok"] is False and d["stage"] == "mic"
    rep = whisper_check.report(d)
    assert "МИКРОФОН недоступен" in rep and "-9996" in rep
    assert "ЗАГРУЗИЛАСЬ" in rep, "модель живая — отчёт не должен врать"
    assert "модель не загрузилась" not in rep.lower()
    assert whisper_check.main([]) == 2
    out = capsys.readouterr().out
    assert "МИКРОФОН" in out


def test_mic_fallback_is_reported(monkeypatch):
    """Писали не запрошенным микрофоном — отчёт говорит об этом прямо."""
    import flux.audio.devices as devmod
    import flux.stt.local as L

    audio = (np.sin(np.linspace(0, 120, 96000)) * 2500).astype(np.int16)
    monkeypatch.setattr(devmod, "record_seconds",
                        lambda seconds=4.0, sample_rate=16000, device_spec=None:
                        (audio, {"ok": True, "device": "Good Mic", "index": 1,
                                 "fallback_from": "Old Mic"}))
    monkeypatch.setattr(L, "get_model",
                        lambda *a, **k: (_dummy_model("привет"), "base"))
    rep = whisper_check.report(whisper_check.check(seconds=6.0))
    assert "Old Mic" in rep and "не открылось" in rep
