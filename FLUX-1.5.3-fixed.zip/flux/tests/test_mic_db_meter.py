"""Измеритель громкости микрофона в дБ (кнопка «🔊 дБ», действие mic_db).

Просил пользователь: «кста предлагаю ещё добавить штуку теста громкости
микро по дб для тестов». Цифры считаются по СЫРЫМ отсчётам (звук не
изменяется), шкала dBFS: 0 = максимум тракта int16.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import paths
from flux.audio import meter
from flux.main import FluxApp


def test_dbfs_matches_known_amplitude():
    sr = 16000
    t = np.linspace(0, 1, sr, endpoint=False)
    a = (np.sin(2 * np.pi * 100 * t) * 3276.7).astype(np.int16)  # пик 0.1
    d = meter.db_stats(a, sr)
    assert abs(d["peak_dbfs"] - (-20.0)) < 0.2
    assert abs(d["rms_dbfs"] - (-23.0)) < 0.3     # RMS синуса = пик / корень(2)
    assert d["silent"] is False
    assert "нормальная речь" in d["verdict"]
    assert len(d["per_sec"]) == 1
    assert d["per_sec"][0]["bar"].count("█") > 0


def test_silence_is_silence():
    d = meter.db_stats(np.zeros(32000, dtype=np.int16), 16000)
    assert d["silent"] is True and d["peak_dbfs"] <= -120
    assert "тишина" in d["verdict"]
    assert d["bar"] == "░" * 24
    assert len(d["per_sec"]) == 2          # две полные секунды


def test_verdict_ladder_matches_real_levels():
    assert "тишина" in meter.verdict_ru(0.0001, 0.00005)    # -80 dBFS
    assert "очень тихо" in meter.verdict_ru(0.004, 0.001)   # -48 dBFS
    assert "тихая речь" in meter.verdict_ru(0.01, 0.008)    # -40 dBFS
    assert "нормальная речь" in meter.verdict_ru(0.05, 0.03)
    assert "громко" in meter.verdict_ru(0.5, 0.3)


def test_console_action_mic_db_reports_and_saves_wav(monkeypatch, tmp_path):
    import flux.audio.devices as devmod

    sr = 16000
    audio = (np.sin(np.linspace(0, 200, sr * 5)) * 4000).astype(np.int16)
    monkeypatch.setattr(devmod, "record_seconds",
                        lambda seconds=5.0, sample_rate=16000, device_spec=None:
                        (audio, {"ok": True, "device": "TestMic", "index": 0}))
    monkeypatch.setattr(paths, "DATA_DIR", tmp_path)
    monkeypatch.setattr(paths, "ensure_dirs", lambda: None)
    out = FluxApp.console_action(object(), "mic_db", {"seconds": 5})
    assert out["ok"] is True and out["device"] == "TestMic"
    assert -25 < out["peak_dbfs"] < -15          # пик 0.122 = -18.3 dBFS
    assert out["rms_dbfs"] < out["peak_dbfs"]
    assert out["silent"] is False
    assert len(out["per_sec"]) == 5
    # запись сохранена: curl для проверки whisper-сервера больше не падает
    # с (26) file not found из чужой папки
    assert out["wav"] == str(tmp_path / "speech.wav")
    assert (tmp_path / "speech.wav").exists()
    assert out["curl"].endswith("/v1/audio/transcriptions")
    assert out["wav"] in out["curl"]


def test_console_action_mic_db_silent_verdict(monkeypatch, tmp_path):
    import flux.audio.devices as devmod

    monkeypatch.setattr(devmod, "record_seconds",
                        lambda seconds=5.0, sample_rate=16000, device_spec=None:
                        (np.zeros(80000, dtype=np.int16),
                         {"ok": True, "device": "Sound Mapper", "index": 3}))
    monkeypatch.setattr(paths, "DATA_DIR", tmp_path)
    monkeypatch.setattr(paths, "ensure_dirs", lambda: None)
    out = FluxApp.console_action(object(), "mic_db", {"seconds": 5})
    assert out["ok"] is True and out["silent"] is True
    assert "тишина" in out["verdict"]


def test_console_action_mic_db_dead_mic_is_honest(monkeypatch):
    import flux.audio.devices as devmod

    monkeypatch.setattr(devmod, "record_seconds",
                        lambda seconds=5.0, sample_rate=16000, device_spec=None:
                        (np.zeros(0, dtype=np.int16),
                         {"ok": False, "error": "микрофон не найден"}))
    out = FluxApp.console_action(object(), "mic_db", {"seconds": 5})
    assert out["ok"] is False and "микрофон" in out["error"]
