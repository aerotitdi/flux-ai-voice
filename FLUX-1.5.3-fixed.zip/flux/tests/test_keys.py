"""flux.keys: расшифровка ошибок API-ключей (Groq/OpenAI/ElevenLabs).

Повод: в логе установки было «ключ groq — HTTP 403» без причины, а на
дашборде Groq «0 API Calls». Теперь код печатает, ЧТО это значит и ЧТО делать,
и никогда не светит ключ целиком.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import keys as keymod

KEY = "gsk_ksItYJpUXKfABCDEFGHIJKLMNOP1234567890wxyz"


class Resp:
    def __init__(self, code, text=""):
        self.status_code = code
        self.text = text


class FakeRequests:
    """get -> код списка моделей, post -> код чата."""

    def __init__(self, get_code=200, post_code=200, get_exc=None, post_exc=None):
        self.get_code, self.post_code = get_code, post_code
        self.get_exc, self.post_exc = get_exc, post_exc
        self.calls = []

    def get(self, url, headers=None, timeout=None):
        self.calls.append(("GET", url, headers))
        if self.get_exc:
            raise self.get_exc
        return Resp(self.get_code, '{"data":[]}' if self.get_code == 200
                    else '{"error":{"message":"Forbidden"}}')

    def post(self, url, headers=None, json=None, timeout=None):
        self.calls.append(("POST", url, headers))
        if self.post_exc:
            raise self.post_exc
        body = ('{"choices":[]}' if self.post_code == 200
                else '{"error":{"message":"Forbidden"}}')
        return Resp(self.post_code, body)


# ------------------------------------------------------------------ маскировка
def test_mask_key_never_reveals_whole_key():
    m = keymod.mask_key(KEY)
    assert m.startswith("gsk_ksI") and m.endswith(f"wxyz ({len(KEY)} симв.)")
    assert KEY[10:-4] not in m


def test_mask_key_short_and_empty():
    assert keymod.mask_key("") == "(пусто)"
    assert "симв." in keymod.mask_key("abc123")


# ---------------------------------------------------------------------- коды
def test_ok_200():
    r = keymod.check("groq", KEY, requests_mod=FakeRequests())
    assert r["ok"] is True and r["warn"] is False
    assert r["detail"] == "валиден"


def test_models_forbidden_but_chat_works_is_ok_with_warning():
    r = keymod.check("groq", KEY, requests_mod=FakeRequests(get_code=403))
    assert r["ok"] is True and r["warn"] is True
    assert "чат отвечает" in r["detail"]


def test_403_on_both_endpoints_explains_reasons():
    rq = FakeRequests(get_code=403, post_code=403)
    r = keymod.check("groq", KEY, requests_mod=rq)
    assert r["ok"] is False and r["code"] == 403
    d = r["detail"]
    assert "403" in d
    assert "console.groq.com" in d, "нужно сказать, куда смотреть"
    assert "api.groq.com" in d, "нужно имя хоста для исключения в антивирусе"
    assert "TLS" in d, "у пользователя АВ режет TLS — это одна из причин"
    assert "faster-whisper" in d, "важно: FLUX без ключа всё равно работает"
    assert KEY[10:-4] not in d
    assert "Forbidden" in d, "тело ответа провайдера полезно"
    assert [c[1] for c in rq.calls] == [
        "https://api.groq.com/openai/v1/models",
        "https://api.groq.com/openai/v1/chat/completions"]


def test_401_and_429_hints():
    assert "неверный" in keymod.check("groq", KEY,
                                      requests_mod=FakeRequests(401, 401))["detail"]
    assert "лимит" in keymod.check("groq", KEY,
                                   requests_mod=FakeRequests(429, 429))["detail"]


def test_unknown_code_falls_back():
    d = keymod.check("openai", KEY, requests_mod=FakeRequests(418, 418))["detail"]
    assert "Проверить ключи" in d


def test_500_hint_mentions_provider():
    d = keymod.check("openai", KEY, requests_mod=FakeRequests(500, 500))["detail"]
    assert "провайдера" in d


def test_network_error_is_warning_not_failure():
    r = keymod.check("groq", KEY,
                     requests_mod=FakeRequests(get_exc=OSError("no route")))
    assert r["ok"] is False and r["warn"] is True
    assert "сеть" in r["detail"]


def test_chat_network_error_is_reported():
    r = keymod.check("groq", KEY,
                     requests_mod=FakeRequests(get_code=403,
                                               post_exc=OSError("reset")))
    assert r["ok"] is False
    assert "чат-проверка не прошла" in r["detail"]


def test_empty_key():
    r = keymod.check("groq", "  ")
    assert r["ok"] is False and r["warn"] is True and r["detail"] == "нет ключа"


def test_elevenlabs_uses_xi_header_and_no_chat_probe():
    rq = FakeRequests(get_code=403)
    r = keymod.check("elevenlabs", "xi" + "a" * 30, requests_mod=rq)
    assert r["ok"] is False
    assert len(rq.calls) == 1, "чат-допроса у ElevenLabs нет"
    assert rq.calls[0][2] == {"xi-api-key": "xi" + "a" * 30}


def test_bearer_header_for_openai_like():
    rq = FakeRequests()
    keymod.check("openai", KEY, requests_mod=rq)
    assert rq.calls[0][2]["Authorization"] == f"Bearer {KEY}"


# ------------------------------------------------------------- check_all/summary
def test_check_all_skips_absent_keys():
    store = {"groq": KEY, "openai": "", "elevenlabs": ""}
    out = keymod.check_all(lambda n: store.get(n, ""),
                           requests_mod=FakeRequests())
    assert list(out) == ["groq"]


def test_summary_lines():
    store = {"groq": KEY}
    out = keymod.check_all(lambda n: store.get(n, ""),
                           requests_mod=FakeRequests(get_code=403, post_code=403))
    text = keymod.summary(out)
    assert text.startswith("[ОШИБКА] groq: HTTP 403")
    assert keymod.summary({}) == "ключи не заданы"


def test_short_status():
    assert keymod.short({"ok": True, "warn": False}) == "OK"
    assert keymod.short({"ok": True, "warn": True}) == "OK (модел. список закрыт)"
    assert keymod.short({"ok": False, "detail": "HTTP 403: x"}) == "HTTP 403: x"
