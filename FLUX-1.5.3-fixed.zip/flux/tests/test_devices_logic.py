"""Чистая (тестируемая без Windows) логика модуля устройств."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.tools import devices as dev

ARP_WINDOWS = """
Интерфейс: 192.168.1.50 --- 0xb
  адрес в Интернете      Физический адрес      Тип
  192.168.1.1            a4-83-e7-11-22-33     динамический
  192.168.1.20           54-ef-44-aa-bb-cc     динамический
  192.168.1.255          ff-ff-ff-ff-ff-ff     статический
  192.168.1.1            a4-83-e7-11-22-33     динамический
"""

ARP_LINUX = """
? (192.168.1.1) at a4:83:e7:11:22:33 [ether] on eth0
? (10.0.0.7) at 00:16:3e:12:34:56 [ether] on eth0
"""


def test_parse_arp_windows():
    out = dev.parse_arp(ARP_WINDOWS)
    assert len(out) == 2, "дубликаты и broadcast должны отбрасываться"
    assert out[0]["ip"] == "192.168.1.1"
    assert out[0]["mac"] == "A4:83:E7:11:22:33"
    assert out[0]["vendor"] == "Apple"
    assert out[1]["vendor"] == "TP-Link"


def test_parse_arp_linux():
    out = dev.parse_arp(ARP_LINUX)
    assert {d["ip"] for d in out} == {"192.168.1.1", "10.0.0.7"}
    assert out[1]["vendor"] == "Xen"


def test_parse_arp_garbage():
    assert dev.parse_arp("") == []
    assert dev.parse_arp("случайный текст\nбез mac и ip") == []


def test_magic_packet_structure():
    pkt = dev.build_magic_packet("AA:BB:CC:DD:EE:FF")
    assert len(pkt) == 6 + 16 * 6
    assert pkt[:6] == b"\xff" * 6
    assert pkt[6:12] == bytes.fromhex("AABBCCDDEEFF")
    assert pkt[6:] == bytes.fromhex("AABBCCDDEEFF") * 16


def test_magic_packet_formats():
    a = dev.build_magic_packet("aa-bb-cc-dd-ee-ff")
    b = dev.build_magic_packet("aabbccddeeff")
    assert a == b


@pytest.mark.parametrize("bad", ["", "gg:bb:cc:dd:ee:ff", "aa:bb:cc", "12345"])
def test_magic_packet_rejects_bad_mac(bad):
    with pytest.raises(ValueError):
        dev.build_magic_packet(bad)


def test_subnet_hosts_count():
    hosts = dev.subnet_hosts("192.168.1.0/24")
    assert len(hosts) == 254
    assert hosts[0] == "192.168.1.1" and hosts[-1] == "192.168.1.254"
    assert "192.168.1.0" not in hosts and "192.168.1.255" not in hosts


def test_subnet_hosts_bad_cidr():
    assert dev.subnet_hosts("не-cidr") == []
    assert dev.subnet_hosts("1.2.3") == []


def test_local_subnet_shape():
    cidr = dev.local_subnet()
    if cidr is None:
        pytest.skip("нет сети в песочнице")
    assert cidr.endswith(".0/24")


def test_vendor_unknown():
    assert dev.vendor_by_mac("11:22:33:44:55:66") == "неизвестный производитель"


def test_wake_on_lan_tool_bad_mac():
    from flux.tools import registry as reg
    from flux.tools import import_all
    import_all()
    res = reg.dispatch("wake_on_lan", {"mac": "не-мак"}, None)
    assert res.ok is False and "MAC" in res.text
