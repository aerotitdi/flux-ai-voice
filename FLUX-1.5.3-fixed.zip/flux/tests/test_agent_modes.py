"""Пилюли чата в стиле DeepSeek: «Глубокое мышление» и «Умный поиск».

Глубокое мышление = нативный think Ollama (токены рассуждения стримятся
в консоль блоком «Размышление»); у OpenAI-совместимых подключений think
нет — просим рассуждать системной инструкцией. Умный поиск = интернет-
поиск (SearXNG -> DuckDuckGo) ДО ответа, результаты системным блоком и
запись web_search в журнал инструментов.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

import flux.llm.ollama_client as oc
from flux.llm import agent as agentmod
from flux.llm.ollama_client import LLMResponse


class FakeClient:
    def __init__(self):
        self.calls = []

    def chat(self, messages, tools=None, on_token=None, think=None,
             on_thinking=None, **kw):
        self.calls.append({"messages": messages, "think": think})
        thinking = ""
        if think:
            thinking = "шаг 1: уточнить запрос"
            if on_thinking:
                on_thinking(thinking)
        return LLMResponse(content="ответ", thinking=thinking)


def make_agent(client):
    ag = agentmod.Agent.__new__(agentmod.Agent)   # без импорта инструментов
    ag.client = client
    ag.store = None
    ag.ctx = agentmod.AgentContext(store=None)
    return ag


def test_think_pill_passes_native_flag_and_streams():
    client = FakeClient()
    seen = []
    res = make_agent(client).run("привет", think=True,
                                 on_thinking=seen.append)
    assert client.calls[0]["think"] is True
    assert seen == ["шаг 1: уточнить запрос"]
    assert res.thinking.startswith("шаг 1")
    assert res.text == "ответ"


def test_no_think_by_default():
    client = FakeClient()
    make_agent(client).run("привет")
    assert client.calls[0]["think"] is False


def test_native_payload_has_think_flag():
    c = oc.OllamaClient.__new__(oc.OllamaClient)
    msgs = [{"role": "user", "content": "x"}]
    p = c._build_payload("m", msgs, None, False, None, think=True)
    assert p["think"] is True
    assert "think" not in c._build_payload("m", msgs, None, False, None)


def test_openai_connection_think_adds_instruction(monkeypatch):
    captured = {}

    def fake_post(url, json=None, headers=None, timeout=None):
        captured["payload"] = json

        class Resp:
            status_code = 200

            def raise_for_status(self):
                pass

            def json(self):
                return {"choices": [{"message": {"content": "ok"}}],
                        "model": "m"}
        return Resp()

    monkeypatch.setattr(oc.requests, "post", fake_post)
    c = oc.OllamaClient.__new__(oc.OllamaClient)
    c.timeout = 5
    conn = {"name": "x", "base_url": "http://x/v1", "api_key": "", "model": "m"}
    c._chat_openai(conn, "m", [{"role": "user", "content": "q"}], None, None,
                   think=True)
    msgs = captured["payload"]["messages"]
    assert msgs[0]["role"] == "system"
    assert "глубокого мышления" in msgs[0]["content"]


def test_web_pill_injects_search_block_and_journal(monkeypatch):
    import flux.tools.web as webtools
    hits = [{"title": "Погода Казань", "url": "http://u1", "snippet": "+20"}]
    monkeypatch.setattr(webtools, "search", lambda q, *a: (hits, "searxng"))
    client = FakeClient()
    res = make_agent(client).run("погода в Казани", web=True)
    msgs = client.calls[0]["messages"]
    assert msgs[-1]["role"] == "user"
    assert msgs[-2]["role"] == "system"
    assert "Умного поиска" in msgs[-2]["content"] or "умного поиска" in msgs[-2]["content"]
    assert "http://u1" in msgs[-2]["content"] and "+20" in msgs[-2]["content"]
    assert [t.name for t in res.tool_log] == ["web_search"]
    assert res.tool_log[0].ok is True
    assert res.web_source == "searxng"


def test_web_pill_search_failure_is_honest(monkeypatch):
    import flux.tools.web as webtools

    def boom(q, *a):
        raise RuntimeError("SearXNG недоступен")

    monkeypatch.setattr(webtools, "search", boom)
    client = FakeClient()
    res = make_agent(client).run("запрос", web=True)
    entry = res.tool_log[0]
    assert entry.ok is False and "ошибка" in entry.preview
    block = client.calls[0]["messages"][-2]["content"]
    assert "результатов нет" in block and "ПРЕДУПРЕДИ" in block
