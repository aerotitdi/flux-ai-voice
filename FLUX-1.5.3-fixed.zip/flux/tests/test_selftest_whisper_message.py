"""Самотест обязан проверять НОВЫЕ правила пользователя:

  * whisper сам решает, когда фраза закончена, и отдаёт ОДНО целое сообщение;
  * есть приёмник, куда внешний whisper может ОТПРАВИТЬ звук/текст;
  * модель распознавания реально доступна (иначе честный WARN с причиной).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg  # noqa: E402
from flux import selftest  # noqa: E402

SRC = (Path(__file__).resolve().parents[1] / "app" / "flux" /
       "selftest.py").read_text(encoding="utf-8")


@pytest.fixture(autouse=True)
def _cfg(monkeypatch, tmp_path):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    monkeypatch.setattr("flux.paths.LOG_DIR", tmp_path)
    cfg.load(force=True)
    yield


def test_run_selftest_includes_new_checks():
    for needle in ("_check_whole_message(rep)", "_check_whisper_server(rep)",
                   "_check_stt_model(rep, quick)"):
        assert needle in SRC, f"в самотесте нет {needle}"


def test_whole_message_check_passes_and_reports_numbers():
    rep = selftest.Report()
    selftest._check_whole_message(rep)
    c = rep.checks[-1]
    assert c.ok, c.detail
    assert "одна отправка" in c.detail
    assert "включи свет" in c.detail


def test_whole_message_check_fails_if_sent_too_early(monkeypatch):
    """Если сообщение уйдёт раньше молчания — самотест обязан это поймать."""
    from flux.voice import stream as S

    class BrokenStream(S.WordStream):
        def feed(self, *a, **kw):
            evs = super().feed(*a, **kw)
            if self.partial and not evs:
                evs = evs + [S.StreamEvent(kind="send", text=self.partial)]
                self.reset()
            return evs

    monkeypatch.setattr(S, "WordStream", BrokenStream)
    rep = selftest.Report()
    selftest._check_whole_message(rep)
    assert rep.checks[-1].ok is False


def test_whisper_server_check_really_posts_audio():
    rep = selftest.Report()
    selftest._check_whisper_server(rep)
    c = rep.checks[-1]
    assert c.ok, c.detail
    assert "/v1/audio/transcriptions" in c.detail


def test_whisper_server_check_skips_when_disabled():
    cfg.update({"whisper_server": {"enabled": False}}, save=False)
    rep = selftest.Report()
    selftest._check_whisper_server(rep)
    c = rep.checks[-1]
    assert c.ok and c.warn and "выключен" in c.detail


def test_stt_model_check_quick_is_warn_only():
    rep = selftest.Report()
    selftest._check_stt_model(rep, quick=True)
    c = rep.checks[-1]
    assert c.ok and c.warn
    assert str(cfg.get("stt.local.model")) in c.detail


def test_stt_model_check_reports_fallback(monkeypatch):
    from flux.stt import local as L

    def size_now():
        return str(cfg.get("stt.local.model"))

    monkeypatch.setattr(L, "get_model", lambda size, **kw: (object(), "base"))
    monkeypatch.setattr(L, "last_error",
                        lambda: {"model": size_now(), "error": "нет сети",
                                 "fallback": "base"})
    monkeypatch.setattr(L, "status",
                        lambda: {"device": "cpu", "compute_type": "int8"})

    rep = selftest.Report()
    selftest._check_stt_model(rep, quick=False)
    c = rep.checks[-1]
    assert c.ok and c.warn
    assert "работаю на base" in c.detail and "нет сети" in c.detail
