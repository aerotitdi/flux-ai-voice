"""Диагностика самотеста: расшифровка ошибок API-ключей и «второй экземпляр».

Повод из лога установки пользователя:
  [FAIL] ключ groq — HTTP 403        (без причины было непонятно, что делать)
  консоль FLUX: http://127.0.0.1:8791/ (порт занят — молча уехали на +1)
"""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import selftest
from flux.ui.server import _another_flux_here


# ----------------------------------------------- ключи -> общий модуль flux.keys
KEY = "gsk_ksItYJpUXKfABCDEFGHIJKLMNOP1234567890wxyz"


class _Resp:
    def __init__(self, code, text='{"error":{"message":"Forbidden"}}'):
        self.status_code = code
        self.text = text


class _ForbiddenRequests:
    """И список моделей, и чат отвечают 403 — как на машине пользователя."""

    def get(self, url, headers=None, timeout=None):
        return _Resp(403)

    def post(self, url, headers=None, json=None, timeout=None):
        return _Resp(403)


@pytest.fixture()
def app(tmp_path, monkeypatch):
    from flux import config as cfg
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"ui": {"enabled": False}, "hotkey": {"enabled": False}},
               save=False)
    monkeypatch.setattr("flux.paths.DB_FILE", str(tmp_path / "diag.db"))
    from flux.main import FluxApp
    return FluxApp(enable_ui=False, enable_tray=False, greet=False)


def test_console_check_keys_explains_403(app, monkeypatch):
    """Кнопка «Проверить ключи» в консоли даёт причину, а не голый код."""
    import requests as real_requests

    from flux import config as cfg
    cfg.set_value("keys.groq", KEY, save=False)
    monkeypatch.setattr(real_requests, "get",
                        lambda *a, **k: _ForbiddenRequests().get(*a, **k))
    monkeypatch.setattr(real_requests, "post",
                        lambda *a, **k: _ForbiddenRequests().post(*a, **k))
    out = app.console_action("check_keys", {})
    assert out["groq"].startswith("HTTP 403")
    assert "console.groq.com" in out["groq"]
    assert KEY[10:-4] not in out["groq"], "ключ не светим"


def test_console_check_keys_without_keys_says_local(app):
    out = app.console_action("check_keys", {})
    assert "_note" in out and "локальные движки" in out["_note"]


def test_selftest_reports_keys_through_shared_module(monkeypatch, tmp_path):
    """Строка самотеста «ключ groq» = тот же текст, что и в консоли."""
    import requests as real_requests

    from flux import config as cfg
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.set_value("keys.groq", KEY, save=False)
    monkeypatch.setattr(real_requests, "get",
                        lambda *a, **k: _ForbiddenRequests().get(*a, **k))
    monkeypatch.setattr(real_requests, "post",
                        lambda *a, **k: _ForbiddenRequests().post(*a, **k))

    rep = selftest.Report()
    monkeypatch.setattr(sys.stdout, "write", lambda *a, **k: 0)
    selftest._check_keys(rep)
    rows = [(c.name, c.ok, c.detail, c.warn) for c in rep.checks]
    assert len(rows) == 1
    name, ok, detail, warn = rows[0]
    assert name == "ключ groq" and ok is False and warn is False
    assert detail.startswith("HTTP 403")
    assert "faster-whisper" in detail
    assert KEY[10:-4] not in detail


# ------------------------------------------------------- второй экземпляр
class _Handler(BaseHTTPRequestHandler):
    payload = b"{}"

    def do_GET(self):
        body = self.payload
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


def _serve(payload: dict):
    handler = type("H", (_Handler,), {"payload": json.dumps(payload).encode()})
    srv = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def test_detects_another_flux_on_port():
    srv, port = _serve({"state": "idle", "app": "flux"})
    try:
        assert _another_flux_here("127.0.0.1", port) is True
    finally:
        srv.shutdown()
        srv.server_close()


def test_foreign_service_on_port_is_not_flux():
    srv, port = _serve({"hello": "world"})
    try:
        assert _another_flux_here("127.0.0.1", port) is False
    finally:
        srv.shutdown()
        srv.server_close()


def test_free_port_is_not_flux():
    srv, port = _serve({"state": "idle"})
    srv.shutdown()
    srv.server_close()
    assert _another_flux_here("127.0.0.1", port) is False


# ------------------------------------------------- список устройств + дубли
def test_list_input_devices_collapses_duplicates(monkeypatch):
    """8 записей PortAudio -> 3 уникальных микрофона (картина машины юзера)."""
    from flux.audio import devices as devmod

    raw = [
        {"name": "Mic (MCHOSE V9 PRO)", "max_input_channels": 2,
         "hostapi": 0, "default_samplerate": 48000},
        {"name": "Mic (MCHOSE V9 PRO)", "max_input_channels": 2,
         "hostapi": 1, "default_samplerate": 48000},
        {"name": "Mic (MCHOSE V9 PRO)", "max_input_channels": 2,
         "hostapi": 2, "default_samplerate": 48000},
        {"name": "Headset Hands-Free", "max_input_channels": 1,
         "hostapi": 0, "default_samplerate": 16000},
        {"name": "Headset Hands-Free", "max_input_channels": 1,
         "hostapi": 2, "default_samplerate": 16000},
        {"name": "Headset Hands-Free AG Audio", "max_input_channels": 1,
         "hostapi": 2, "default_samplerate": 16000},
        {"name": "Динамики (Realtek)", "max_input_channels": 0,
         "max_output_channels": 2, "hostapi": 0, "default_samplerate": 48000},
        {"name": "Стерео микшер (Realtek)", "max_input_channels": 2,
         "hostapi": 0, "default_samplerate": 48000},
    ]

    class FakeSD:
        default = ((2, -1))   # sounddevice.default = (input_idx, output_idx)

        @staticmethod
        def query_devices():
            return raw

        @staticmethod
        def query_hostapis():
            return [{"name": "MME"}, {"name": "DirectSound"},
                    {"name": "Windows WASAPI"}]

    monkeypatch.setattr(devmod, "_load_sounddevice", lambda: FakeSD)

    raw_all = devmod.build_device_list(raw, FakeSD.query_hostapis(), 2)
    all_devs = devmod.list_input_devices(include_loopback=True)
    mics = devmod.list_input_devices()
    assert len(raw_all) == 7, "сырых записей записи: 7 (без динамиков)"
    assert len(mics) == 3, "MCHOSE x3 + Hands-Free x2 + AG Audio -> 3 уникальных"
    assert len(all_devs) == 4, "+ стерео микшер (петля)"

    chosen = devmod.resolve_input_device(None)
    assert chosen.name == "Mic (MCHOSE V9 PRO)"
    assert chosen.host_api == "Windows WASAPI", "предпочитаем WASAPI, не MME"
    assert chosen.index == 2, "устройство по умолчанию важнее алфавита"
    assert "MME(7)" in devmod.inventory(all_devs)  # петля
    assert devmod.inventory(all_devs).count("MCHOSE") == 1

    # поиск по подстроке имени работает и по схлопнутому списку
    assert devmod.resolve_input_device("mchose").index == 2
    # явный индекс PortAudio тоже проходит, даже если это «дубль» MME/DirectSound
    assert devmod.resolve_input_device(0).name == "Mic (MCHOSE V9 PRO)"
    assert devmod.resolve_input_device(0).index == 2, "дубль ведёт к лучшей записи"
    assert devmod.resolve_input_device("1").name == "Mic (MCHOSE V9 PRO)"
    # устройство воспроизведения в список записи не попадает ВООБЩЕ
    assert all("Динамики" not in d.name for d in all_devs)


def test_build_device_list_skips_outputs_and_marks_loopback():
    from flux.audio.devices import build_device_list
    rows = [{"name": "Speakers", "max_input_channels": 0, "hostapi": 0},
            {"name": "Стерео микшер", "max_input_channels": 2, "hostapi": 0},
            {"name": "Mic", "max_input_channels": 1, "hostapi": 9}]
    out = build_device_list(rows, [{"name": "MME"}], default_in=2)
    assert [d.name for d in out] == ["Стерео микшер", "Mic"]
    assert out[0].is_loopback is True
    assert out[1].is_default_input is True
    assert out[1].host_api == "", "несуществующий API не роняет сборку"


def test_collapse_duplicates_can_be_disabled(monkeypatch):
    """audio.collapse_duplicates=false -> показываем все записи PortAudio."""
    from flux import config
    from flux.audio import devices as devmod

    raw = [{"name": "Mic (X)", "max_input_channels": 1, "hostapi": 0,
            "default_samplerate": 16000},
           {"name": "Mic (X)", "max_input_channels": 1, "hostapi": 2,
            "default_samplerate": 16000}]

    class FakeSD:
        default = ((0, -1))

        @staticmethod
        def query_devices():
            return raw

        @staticmethod
        def query_hostapis():
            return [{"name": "MME"}, {"name": "DirectSound"},
                    {"name": "Windows WASAPI"}]

    monkeypatch.setattr(devmod, "_load_sounddevice", lambda: FakeSD)
    real_get = config.get

    def fake_get(path, default=None):
        if path == "audio.collapse_duplicates":
            return False
        return real_get(path, default)

    monkeypatch.setattr(config, "get", fake_get)
    assert len(devmod.list_input_devices()) == 2
