"""Голосовой агент: куски звука -> whisper -> слова; barge-in; сигналы."""
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg
from flux.stt.base import Transcript


@pytest.fixture()
def app(tmp_path, monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"ui": {"enabled": False}, "hotkey": {"enabled": False}},
               save=False)
    monkeypatch.setattr("flux.paths.DB_FILE", str(tmp_path / "va.db"))
    from flux.main import FluxApp
    return FluxApp(enable_ui=False, enable_tray=False, greet=False)


def fake_capture(audio):
    return SimpleNamespace(get_window=lambda sec: audio,
                           get_window_since=lambda ts: audio,
                           clear_ring=lambda: None, pause=lambda: None,
                           resume=lambda: None, speaking=False)


class FakeCapture:
    """Честная подделка микрофона: на шкале времени t0..t0+dur лежит звук,
    и get_window_since(курсор) отдаёт только НОВЫЙ участок (как в жизни)."""

    def __init__(self, t0: float, dur: float, sr: int = 16000,
                 chunk_sec: float = 3.0):
        self.t0 = float(t0)
        self.dur = float(dur)
        self.sr = int(sr)
        self.chunk_sec = float(chunk_sec)

    def get_window_since(self, ts):
        import numpy as _np
        start = max(0.0, float(ts) - self.t0)
        end = min(self.dur, start + self.chunk_sec)   # столько, сколько накопилось
        n = int(max(0.0, end - start) * self.sr)
        return _np.zeros(n, dtype=_np.int16)

    def get_window(self, sec):
        return self.get_window_since(self.t0 + self.dur - sec)

    def clear_ring(self):
        pass

    pause = clear_ring
    resume = clear_ring


class FakeSTT:
    """whisper-подделка: отдаёт заготовленные тексты по порядку, дальше тишину."""

    def __init__(self, texts, engine="api", model="base"):
        self.texts = list(texts)
        self.calls = 0
        self.engine = engine
        self.model = model

    def transcribe(self, audio, sr=16000):
        self.calls += 1
        text = self.texts[self.calls - 1] if self.calls <= len(self.texts) else ""
        return Transcript(text=text, engine=self.engine, model=self.model,
                          window_sec=len(audio) / float(sr))


class FakeClock:
    """Управляемые часы: поток слов живёт по шкале ЗВУКА, а не по wall-clock."""

    def __init__(self, t0=1000.0):
        self.t = t0

    def monotonic(self):
        return self.t

    def advance(self, sec):
        self.t += sec
        return self.t


def use_clock(app, monkeypatch, t0=1000.0):
    clock = FakeClock(t0)
    import flux.main as m
    monkeypatch.setattr(m.time, "monotonic", clock.monotonic)
    app._cursor_ts = 0.0
    return clock


def test_chunk_with_wake_command_reaches_model(app, monkeypatch):
    """«Флюкс, включи свет» -> команда уходит модели ЦЕЛИКОМ одной отправкой."""
    sent = []
    app._process_command = lambda t: sent.append(t)
    stt = FakeSTT(["флюкс включи свет"])
    app.cmd_stt = stt
    clock = use_clock(app, monkeypatch)
    app.capture = FakeCapture(clock.t, 60.0)
    app._consume_chunk()                  # whisper услышал слова
    assert sent == [], "сразу не отправляем: ждём вердикт whisper о тишине"
    clock.advance(1.5)                    # 1.5 c звука без слов — ещё рано
    app._consume_chunk()
    assert sent == [], "сообщение не рвём: whisper молчит меньше 5 c"
    clock.advance(4.0)                    # итого 5.5 c молчания
    app._consume_chunk()
    assert sent == ["включи свет"]
    assert app.last_utterance is not None
    assert app.last_utterance.text == "флюкс включи свет"
    assert app.last_utterance.silence_sec >= 1.2


def test_chunk_without_wake_is_ignored(app, monkeypatch):
    sent = []
    app._process_command = lambda t: sent.append(t)
    app.cmd_stt = FakeSTT(["соседи снова сверлят"] * 10)
    clock = use_clock(app, monkeypatch)
    app.capture = FakeCapture(clock.t, 60.0)
    for _ in range(4):
        app._consume_chunk()
        clock.advance(3)
    assert sent == []


def test_whisper_silence_5s_sends_accumulated_command(app, monkeypatch):
    """Сообщение копится из нескольких кусков и уходит ОДНИМ целым текстом."""
    sent = []
    app._process_command = lambda t: sent.append(t)
    app.say = lambda text: None
    app.cmd_stt = FakeSTT(["флюкс", "открой браузер", "и почту"])
    clock = use_clock(app, monkeypatch)
    app.capture = FakeCapture(clock.t, 60.0)
    app._consume_chunk()          # «флюкс»
    clock.advance(3)
    app._consume_chunk()          # «открой браузер» (копится, не отправляется)
    assert sent == []
    clock.advance(3)
    app._consume_chunk()          # «и почту»
    assert sent == [], "пока whisper слышит слова — сообщение не рвём"
    clock.advance(3)
    app._consume_chunk()          # пусто, 3 c тишины
    assert sent == []
    clock.advance(3)
    app._consume_chunk()          # пусто, 6 c тишины -> ОДНА отправка
    assert sent == ["открой браузер и почту"]
    assert len(sent) == 1
    assert app.stream.state == "idle"
    assert app.last_utterance.silence_sec >= 5.0
    assert app.last_utterance.text == "флюкс открой браузер и почту"


def test_each_sound_chunk_is_listened_once(app, monkeypatch):
    """Курсор звука: один и тот же участок не уходит в whisper дважды."""
    sizes = []
    stt = FakeSTT([])
    orig = stt.transcribe

    def spy(audio, sr=16000):
        sizes.append(len(audio))
        return orig(audio, sr)

    stt.transcribe = spy
    app.cmd_stt = stt
    clock = use_clock(app, monkeypatch)
    app.capture = FakeCapture(clock.t, 60.0)
    app._consume_chunk()
    first_cursor = app._cursor_ts
    clock.advance(3)
    app._consume_chunk()
    assert stt.calls == 2
    assert sizes[1] == pytest.approx(sizes[0], abs=64), \
        "второй заход слушает НОВЫЕ 3 секунды, а не те же самые"
    assert app._cursor_ts > first_cursor, "курсор звука двигается вперёд"


def test_external_whisper_can_send_text_to_flux(app, monkeypatch):
    """Внешний whisper ПРИСЫЛАЕТ текст — он попадает в ту же копилку."""
    sent = []
    app._process_command = lambda t: sent.append(t)
    app.say = lambda text: None
    clock = use_clock(app, monkeypatch)
    app.on_external_words("флюкс")
    clock.advance(1.5)
    app.on_external_words("")               # whisper замолчал -> «Слушаю»
    assert app.stream.state == "awake"
    app.on_external_words("выключи музыку")
    clock.advance(6.0)
    app.on_external_words("")
    assert sent == ["выключи музыку"]


def test_digital_silence_does_not_call_whisper(app, monkeypatch):
    calls = []
    app.cmd_stt = SimpleNamespace(
        transcribe=lambda a, sr=16000: calls.append(1) or Transcript(text=""))
    use_clock(app, monkeypatch)
    app.capture = fake_capture(np.zeros(100, dtype=np.int16))   # звука НЕТ
    app._consume_chunk()
    assert calls == [], "цифровую тишину не отправляем (звука нет вовсе)"


def test_no_beep_on_sound_and_cooldown_elsewhere(app):
    cfg.update({"audio": {"feedback_sounds": True}}, save=False)
    app.player._queue.clear()
    app._last_beep_at = 0.0
    app._feedback(1560)
    app._feedback(1560)
    assert len(app.player._queue) == 1


def test_barge_in_interrupts_speech(app, monkeypatch):
    cfg.update({"audio": {"barge_in": True, "barge_rms": 0.10,
                          "tail_guard_sec": 0.0}}, save=False)
    calls = []
    app.player.interrupt = lambda: calls.append(1)
    app.player.speaking = True
    app._last_tts_end = 0.0
    loud = np.full(480, 9000, dtype=np.int16)
    for _ in range(12):
        app._on_frame(loud, 0.4)
    assert calls


def test_followup_and_stream_defaults():
    cfg.load(force=True)
    assert cfg.get("stream.word_idle_sec") == 5.0
    assert cfg.get("stream.chunk_sec") == 3.0
    assert cfg.get("audio.open_on_any_sound") is True


def test_chain_test_reports_every_stage(app, monkeypatch):
    """Диагностика цепи даёт факты по каждому этапу (микрофон->whisper->слово)."""
    import numpy as _np
    from flux.stt.base import Transcript
    from flux.audio import devices as devmod

    audio = (_np.sin(_np.linspace(0, 90, 16000)) * 3000).astype(_np.int16)
    monkeypatch.setattr(devmod, "record_seconds",
                        lambda seconds=6.0, sample_rate=16000, device_spec=None:
                        (audio, {"ok": True, "device": "TestMic", "index": 0}))
    app.cmd_stt = SimpleNamespace(
        transcribe=lambda a, sr=16000: Transcript(text="флюкс открой браузер",
                                                  engine="api"))
    out = app.console_action("chain_test", {"seconds": 6})
    assert out["ok"] is True
    assert out["device"] == "TestMic"
    assert out["raw_dbfs"] < 0
    assert out["modified"] is False      # звук до whisper НЕ изменяется
    assert out["engine"] == "api"
    assert out["wake"] is True and out["command"] == "открой браузер"


def test_echo_tail_removed_from_ring(app):
    """После собственной озвучки кольцо чистится: хвост не едет в whisper."""
    calls = []
    app.capture = SimpleNamespace(pause=lambda: calls.append("pause"),
                                  resume=lambda: calls.append("resume"),
                                  clear_ring=lambda: calls.append("clear"))
    app._on_speech_start()
    assert "clear" in calls and "pause" in calls
