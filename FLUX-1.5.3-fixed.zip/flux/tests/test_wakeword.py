"""Тесты детектора слова-активации.

Позитивные примеры - РЕАЛЬНЫЕ выводы faster-whisper (tiny/base), полученные
при синтезе фраз через edge-tts (см. tests/test_e2e_voice_real.py).
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.wakeword import WakeDetector, levenshtein, normalize, fold_lat, fold_ru

DET = WakeDetector(words=["флюкс", "flux"], sensitivity=1)

# ------------------------------------------------------------------ позитивные
POSITIVE = [
    # (фраза как распознал Whisper, ожидаемая команда)
    ("Флюкс", ""),
    ("флюкс", ""),
    ("Флюкс.", ""),
    ("Флюкс!", ""),
    ("Флюкс, включи свет на кухне.", "включи свет на кухне"),
    ("Флюкс включи свет на кухне.", "включи свет на кухне"),
    ("Флюкс.  Найди в интернете погоду в Москве.", "найди в интернете погоду в москве"),
    ("флюкс который час", "который час"),
    ("Флёкс включи сверхно кухне.", "включи сверхно кухне"),          # tiny: ё/е
    ("Флюк с которой час.", "которой час"),                            # base: слово разбито
    ("флёкскоторый час.", "который час"),                              # tiny: слипание
    ("ФЛЮКС ЗАКРОЙ БРАУЗЕР", "закрой браузер"),
    ("  флюкс   покажи файлы на рабочем столе  ", "покажи файлы на рабочем столе"),
    ("Эй, Флюкс, сделай громче", "сделай громче"),                     # филлер перед словом
    ("ну флюкс выключи компьютер", "выключи компьютер"),
    ("flux turn on the light", "turn on the light"),                   # латиница
    ("Flux, what time is it?", "what time is it"),
    ("Флукс, открой браузер", "открой браузер"),                       # оглушение
    ("Флюкс что нового в мире?", "что нового в мире"),
]


@pytest.mark.parametrize("text,expected_command", POSITIVE)
def test_positive(text, expected_command):
    m = DET.check(text)
    assert m.matched, f"НЕ распознано слово-активация в: {text!r}"
    assert m.command.strip().lower() == expected_command.strip().lower(), (
        f"команда={m.command!r} ожидалось={expected_command!r} (фраза {text!r})")
    assert m.confidence >= 0.5


# ------------------------------------------------------------------ негативные
NEGATIVE = [
    "Плюкс, запусти музыку",   # ф/п не путаем: иначе «плюс два градуса» = активация
    "Люкс апартаменты забронированы",
    "Включи свет на кухне.",
    "плюс два градуса на улице.",
    "плюс минус ноль",
    "Моя флешка не определяется",
    "Флуктуации на рынке растут",
    "флюорография обязательна раз в год",
    "Флюгер сломался от ветра",
    "Флейта звучит красиво",
    "Флот вышел в море",
    "Фрукты надо купить сегодня",
    "Минус пять градусов",
    "Сделай резервную копию файлов",
    "Какая погода в Москве",
    "Плюхнулся на диван",
    "Флексоры руки болят",
    "Люкс апартаменты забронированы",
    "Флюиды в двигателе надо проверить",
    "Открой браузер и зайди на сайт",
    "Эй ты, включи музыку",
    "Плюхаю по клавиатуре",
    "Флеш плеер не работает",
    "Флюгерный датчик ветра",
    "Мне нужен плюс один",
    "Флокс зацвёл в саду",
    "Флюоресцентная лампа мигает",
    "Флюсовочный станок",
    "Флюсовка металла",
]


@pytest.mark.parametrize("text", NEGATIVE)
def test_negative(text):
    m = DET.check(text)
    assert not m.matched, f"ЛОЖНОЕ срабатывание на {text!r} (wake={m.wake!r} d={m.distance})"


# ------------------------------------------------------------------- поведение
def test_wake_word_required_at_start():
    det = WakeDetector(words=["флюкс"], require_at_start=True)
    assert not det.check("а теперь скажи флюкс что-нибудь").matched
    det2 = WakeDetector(words=["флюкс"], require_at_start=False)
    m = det2.check("а теперь скажи флюкс что-нибудь")
    assert m.matched and m.command.startswith("что-нибудь")


def test_custom_wake_word_from_settings():
    det = WakeDetector(words=["джарвис"], sensitivity=1)
    m = det.check("Джарвис, открой шторы")
    assert m.matched and m.command == "открой шторы"
    assert not det.check("Флюкс, открой шторы").matched


def test_custom_wake_word_short():
    det = WakeDetector(words=["ира"], sensitivity=0)
    assert det.check("Ира включи свет").matched
    assert not det.check("Ирина включила свет").matched


def test_sensitivity_levels():
    strict = WakeDetector(words=["флюкс"], sensitivity=0)
    soft = WakeDetector(words=["флюкс"], sensitivity=2)
    assert strict.check("флюкс включи свет").matched          # точное совпадение
    assert not strict.check("флёкс включи свет").matched       # строго: ё->е даёт флекс != флюкс
    assert soft.check("флёкс включи свет").matched
    # на максимальной чувствительности появляются ложные срабатывания - это ожидаемо
    assert soft.check("плюс два градуса").matched


def test_wake_only_detection():
    m = DET.check("Флюкс!")
    assert m.matched and DET.is_wake_only(m)
    m2 = DET.check("Флюкс включи свет")
    assert m2.matched and not DET.is_wake_only(m2)


def test_empty_and_garbage():
    assert not DET.check("").matched
    assert not DET.check("   ").matched
    assert not DET.check("...").matched
    assert not DET.check("!!!").matched
    assert not DET.check("а").matched


def test_confidence_and_span():
    m = DET.check("Флюкс включи свет")
    assert m.distance == 0
    assert m.confidence == 1.0
    assert m.span == (0, 5)          # ровно слово, без пробела
    assert m.canonical == "флюкс"
    assert m.wake == "Флюкс"         # исходный регистр


def test_command_keeps_original_case_and_punctuation():
    m = DET.check("Флюкс. Найди в интернете, пожалуйста, погоду!")
    assert m.matched
    assert m.command == "Найди в интернете, пожалуйста, погоду"


def test_stop_stems_do_not_block_custom_wake_word():
    det = WakeDetector(words=["флора"], sensitivity=1)
    assert det.check("Флора, включи свет").matched


def test_command_preserves_punctuation():
    m = DET.check("Флюкс напиши письмо: привет, как дела?")
    assert m.matched
    assert m.command == "напиши письмо: привет, как дела"


# ------------------------------------------------------------------ утилиты
def test_levenshtein():
    assert levenshtein("", "") == 0
    assert levenshtein("abc", "abc") == 0
    assert levenshtein("abc", "abd") == 1
    assert levenshtein("abc", "") == 3
    assert levenshtein("флюкс", "флекс") == 1
    assert levenshtein("флюкс", "плюкс") == 1


def test_normalize():
    assert normalize("Флюкс,  ПРИВЕТ!") == "флюкс привет"
    assert normalize("Флёкс") == "флекс"
    assert normalize("") == ""
    assert normalize("a—b…c") == "a b c"


def test_fold_spaces():
    assert fold_ru("Флюкс") == "флукс"
    assert fold_lat("Флюкс") == "fluks"
    assert fold_lat("flux") == "fluks"
    assert " " not in fold_lat("флюкс привет")


def test_quick_contains():
    assert DET.quick_contains("там где-то флюкс был")
    assert not DET.quick_contains("обычная фраза без активации")
