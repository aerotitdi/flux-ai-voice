"""ЖИВАЯ цепочка: настоящий микрофон-поток (WavCapture) -> сырое кольцо ->
настоящий faster-whisper -> копилка слов -> ОДНО целое сообщение -> команда.

Здесь нет ни одной подделки распознавания: звук (живая русская речь, синтез
edge-tts) идёт байт-в-байт тем же путём, что и в бою, а решения принимает
whisper: он возвращает слова с метками времени, по ним считается тишина, и
сообщение уходит модели ЦЕЛИКОМ одной отправкой.

Требует интернет (edge-tts) и скачанную модель whisper `base`.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.audio.capture import WavCapture  # noqa: E402
from flux.stt.local import LocalWhisperSTT  # noqa: E402
from flux.voice.stream import WordStream  # noqa: E402
from flux.wakeword import WakeDetector  # noqa: E402

SR = 16000
PHRASE = "Флюкс, включи свет на кухне."


def _speech_pcm() -> np.ndarray:
    import asyncio

    import edge_tts

    from flux.audio.player import decode_audio_file

    tmp = Path("/tmp") if Path("/tmp").is_dir() else Path.cwd()
    mp3 = tmp / "flux_e2e_speech.mp3"
    asyncio.run(edge_tts.Communicate(PHRASE, "ru-RU-DmitryNeural").save(str(mp3)))
    data, sr = decode_audio_file(str(mp3), target_sr=SR)
    return (np.asarray(data) * 32767.0).astype(np.int16)


@pytest.fixture(scope="module")
def speech() -> np.ndarray:
    try:
        pcm = _speech_pcm()
    except Exception as e:                      # нет интернета / edge-tts
        pytest.skip(f"нужен живой синтез речи: {e}")
    if pcm.size < SR:
        pytest.skip("синтез дал меньше секунды звука")
    return pcm


def _run_pipeline(speech: np.ndarray, idle: float = 2.0, tail_silence: float = 6.0):
    """Прогнать звук через кольцо захвата и настоящий whisper."""
    audio = np.concatenate([speech,
                            np.zeros(int(SR * tail_silence), dtype=np.int16)])
    stt = LocalWhisperSTT(size="base")
    st = WordStream(WakeDetector(words=["флюкс"], sensitivity=1),
                    word_idle_sec=idle, wake_idle_sec=1.2)
    cap = WavCapture(audio, sample_rate=SR)
    cap.start()

    clock = {"t": 1000.0}
    cap._t0 = clock["t"]
    cap.run()                                   # кадры легли в сырое кольцо

    events, pos = [], 0.0
    chunk = 3.0
    step = int(SR * chunk)
    for i in range(0, len(audio), step):
        piece = audio[i:i + step]
        if piece.size < int(SR * 0.3):
            break
        pos += piece.size / float(SR)
        clock["t"] += chunk
        tr = stt.transcribe_audio(piece, SR)     # СЫРОЙ звук -> whisper
        assert tr.engine == "local"
        for ev in st.feed(text=tr.text, tr=tr, end_sec=pos,
                          sec=piece.size / float(SR)):
            events.append(ev)
    return events, st, tr


@pytest.mark.network
def test_whisper_word_timestamps_are_real(speech):
    stt = LocalWhisperSTT(size="base")
    tr = stt.transcribe_audio(speech, SR)
    assert tr.words, "faster-whisper обязан вернуть слова с метками времени"
    assert tr.window_sec == pytest.approx(speech.size / SR, abs=0.01)
    ends = [w["end"] for w in tr.words]
    assert ends == sorted(ends), "метки времени идут по порядку"
    assert ends[-1] <= tr.window_sec + 0.5


@pytest.mark.network
def test_one_whole_message_reaches_the_command(speech):
    events, st, _ = _run_pipeline(speech, idle=2.0)
    sends = [e for e in events if e.kind == "send"]
    assert len(sends) == 1, f"сообщение должно уйти ОДНО, а не {len(sends)}"
    ev = sends[0]
    text = ev.text.lower()
    assert "включи" in text and "свет" in text, ev.text
    assert ev.match is not None and ev.match.matched, "слово-активация найдена"
    utt = ev.utterance
    assert utt.silence_sec >= 2.0, "отправили раньше, чем whisper замолчал"
    assert utt.word_count >= 3
    assert utt.engine == "local" and utt.model == "base"
    assert st.state == "idle" and st.messages_sent == 1


@pytest.mark.network
def test_longer_silence_does_not_send_twice(speech):
    """После отправки копилка пуста: лишней тишины не боимся."""
    events, st, _ = _run_pipeline(speech, idle=2.0, tail_silence=12.0)
    sends = [e for e in events if e.kind == "send"]
    assert len(sends) == 1
    assert st.partial == ""
    assert st.asm.pushes > 3
    assert st.asm.silent_pushes >= 2, "whisper сам сообщил о кусках без речи"


@pytest.mark.network
def test_no_wake_word_means_no_command(speech):
    """Та же речь, но слово-активация другое -> ничего не отправляется."""
    audio = np.concatenate([speech, np.zeros(SR * 6, dtype=np.int16)])
    stt = LocalWhisperSTT(size="base")
    st = WordStream(WakeDetector(words=["джексон"], sensitivity=0),
                    word_idle_sec=2.0)
    pos = 0.0
    sends = []
    step = SR * 3
    for i in range(0, len(audio), step):
        piece = audio[i:i + step]
        if piece.size < int(SR * 0.3):
            break
        pos += piece.size / float(SR)
        tr = stt.transcribe_audio(piece, SR)
        for ev in st.feed(text=tr.text, tr=tr, end_sec=pos,
                          sec=piece.size / float(SR)):
            if ev.kind == "send":
                sends.append(ev)
    assert sends == []
    assert st.messages_sent == 0
