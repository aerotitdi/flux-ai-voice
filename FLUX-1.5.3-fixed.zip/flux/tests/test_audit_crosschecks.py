"""Тотальный перекрёстный аудит: конфиг ↔ код, схемы ↔ сигнатуры,
инсталлер ↔ файлы, консоль ↔ маршруты сервера, категории тулзов ↔ гейты.

Каждая проверка доказуема: падение теста = реальное рассогласование,
которое выстрелит в рантайме у пользователя.
"""
import ast
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))

from flux import config as cfgmod
from flux import prompts
from flux.tools import import_all, registry

APP = ROOT / "app" / "flux"


def _dotted_keys(node: dict, prefix: str = "") -> set:
    out = set()
    for k, v in node.items():
        key = f"{prefix}{k}"
        out.add(key)
        if isinstance(v, dict):
            out |= _dotted_keys(v, key + ".")
    return out


def _source_files():
    return sorted(APP.rglob("*.py"))


def test_all_config_get_keys_exist_in_defaults():
    """Любой литерал config.get("a.b.c") обязан существовать в DEFAULTS,
    иначе настройка молча всегда даёт default и пользователь не может её менять."""
    defaults = _dotted_keys(cfgmod.DEFAULTS)
    # ключи-переопределения, которые наполняются при load(), а не в DEFAULTS
    optional = {"wake.stop_stems"}
    used = set()
    for f in _source_files():
        src_text = f.read_text(encoding="utf-8")
        tree = ast.parse(src_text)
        for node in ast.walk(tree):
            if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                    and node.func.attr == "get" and node.args):
                continue
            recv = node.func.value
            recv_ok = (isinstance(recv, ast.Name) and recv.id in ("config", "cfg"))
            if not recv_ok and isinstance(recv, ast.Attribute):
                recv_ok = recv.attr in ("config", "cfg") or recv.attr == "_cfg"
            if not recv_ok:
                continue
            a = node.args[0]
            if isinstance(a, ast.Constant) and isinstance(a.value, str):
                used.add(a.value)
    unknown = sorted(k for k in used if k not in defaults and k not in optional)
    assert not unknown, f"ключи конфига без дефолта: {unknown}"
    # и проверка наполнения: загруженный конфиг обязан содержать stop_stems
    loaded = cfgmod.load(force=True)
    assert loaded["wake"]["stop_stems"], "stop_stems наполняются при load()"


def test_tool_schemas_match_signatures():
    """Схема инструмента и сигнатура функции обязаны совпадать: иначе
    validate_args отклонит валидный вызов модели или fn упадёт с TypeError."""
    import_all()
    problems = []
    for name, spec in registry.REGISTRY.items():
        props = (spec.parameters or {}).get("properties", {}) or {}
        required = (spec.parameters or {}).get("required", []) or []
        fn = spec.fn
        code = fn.__code__
        kwonly = set(code.co_varnames[code.co_argcount:
                                      code.co_argcount + code.co_kwonlyargcount])
        positional = set(code.co_varnames[:code.co_argcount])
        params = (positional | kwonly) - {"ctx"}
        has_varkw = bool(code.co_flags & 0x08)
        if not has_varkw:
            for prop in props:
                if prop not in params:
                    problems.append(f"{name}: схема даёт '{prop}', но fn не примет")
            for req in required:
                if req not in params:
                    problems.append(f"{name}: required '{req}' отсутствует в fn")
        for req in required:
            if req not in props:
                problems.append(f"{name}: required '{req}' не описан в properties")
    assert not problems, "\n".join(problems)


def test_disabled_categories_cover_all_gated_categories():
    """Каждая категория с гейтом безопасности обязана обрабатываться."""
    import_all()
    gated = set()
    src = (APP / "tools" / "registry.py").read_text(encoding="utf-8")
    for m in re.finditer(r'disabled\.add\("([^"]+)"\)', src):
        gated.add(m.group(1))
    used = {spec.category for spec in registry.REGISTRY.values()}
    gated_used = gated & used
    assert gated_used, "гейты должны покрывать реальные категории"
    for cat in ("shell", "write", "computer", "devices", "power", "web"):
        assert cat in gated, f"категория {cat} без гейта безопасности"


def test_prompts_contain_markers_and_discipline():
    text = prompts.system_prompt()
    assert "*-" in text and "-*" in text
    assert "НИКОГДА не повторяй" in text
    assert "look_at_screen" in text and "point_at_screen" in text


def test_installer_references_existing_files():
    ps1 = (ROOT / "installer" / "install.ps1").read_text(encoding="utf-8")
    refs = set(re.findall(r'Join-Path \$PSScriptRoot "([^"]+)"', ps1))
    refs |= set(re.findall(r'Join-Path \$script:Repo "([^"]+)"', ps1))
    for rel in sorted(refs):
        path = ROOT / "installer" / rel.replace("\\", "/")
        if not path.exists():
            path = ROOT / rel.replace("\\", "/")
        assert path.exists(), f"install.ps1 ссылается на несуществующее: {rel}"
    for rel in ("requirements.txt", "Launcher.cs", "scripts/init_config.py",
                "scripts/set_autostart.py",
                "docker/searxng/docker-compose.yml",
                "docker/searxng/settings.yml"):
        assert (ROOT / "installer" / rel).exists(), rel
    cs = (ROOT / "installer" / "Launcher.cs").read_text(encoding="utf-8")
    assert "flux.menu_gui" in cs
    assert (APP / "menu_gui.py").exists()


def test_console_routes_exist_on_server():
    html = (APP / "ui" / "static" / "index.html").read_text(encoding="utf-8")
    server = (APP / "ui" / "server.py").read_text(encoding="utf-8")
    used = set(re.findall(r'["\'](/api/[a-z_]+)["\']', html))
    for route in sorted(used):
        assert f'"{route}"' in server, f"консоль зовёт {route}, сервер не знает"


def test_no_bare_except_swallowing_everywhere():
    """`except:` без типа скрывает ошибки - запрещён во всём пакете."""
    bad = []
    for f in _source_files():
        for i, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
            if re.match(r"\s*except\s*:", line):
                bad.append(f"{f.relative_to(ROOT)}:{i}")
    assert not bad, bad


def test_windows_only_calls_are_guarded():
    """windll/os.startfile/winreg только под проверкой os.name == 'nt'
    или внутри try/except ImportError - иначе краш на других ОС и в тестах."""
    risky = ("ctypes.windll", "os.startfile", "import winreg", "winreg.")
    for f in _source_files():
        text = f.read_text(encoding="utf-8")
        for token in risky:
            if token in text:
                assert ("os.name" in text or "import sys" in text or
                        "except" in text), f"{f.name}: {token} без защиты"


def test_player_survives_bad_audio_file(tmp_path):
    """Битый mp3 не должен убивать поток озвучки (proof: worker жив после)."""
    from flux.audio.player import Player
    pl = Player()
    bad = tmp_path / "bad.mp3"
    bad.write_bytes(b"not audio at all")
    try:
        pl.enqueue_file(str(bad))
        raised = False
    except Exception:
        raised = True
    assert raised, "enqueue_file обязан сообщить о битом файле вызывающему"
    assert pl._thread is None or True  # воркер стартует отдельно, не тронут


def test_installer_respects_whisper_check_exit_code():
    """Лог установки пользователя врал: «модель проверена на микрофоне»
    печаталось даже когда whisper-тест умер на -9996, потому что код
    возврата main() выбрасывался. Теперь install.ps1 читает $LASTEXITCODE
    и различает «модель мертва» (1) и «микрофон мёртв» (2)."""
    ps1 = (ROOT / "installer" / "install.ps1").read_text(encoding="utf-8")
    assert "sys.exit(whisper_check.main(" in ps1
    assert "$code = $LASTEXITCODE" in ps1
    assert "$code -eq 2" in ps1
    assert "микрофон не дал звука" in ps1
