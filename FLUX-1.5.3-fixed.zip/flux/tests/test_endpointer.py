"""Тесты правила «5 секунд чтобы продолжить фразу» и выделения сегментов.

Аудио синтетическое, часы виртуальные - тест детерминированный и быстрый.
"""
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.audio.endpointer import Endpointer, IDLE, LISTENING, segment_to_wav_bytes
from flux.audio.vad import VAD, VadConfig, rms_float, dbfs

SR = 16000
FRAME_MS = 30
FRAME = int(SR * FRAME_MS / 1000)   # 480 отсчётов


class FakeClock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t

    def advance(self, dt):
        self.t += dt


class StubVAD:
    """Речь = громкий кадр. Детерминированно, без зависимостей."""

    def __init__(self, threshold=0.02):
        self.threshold = threshold
        self.engine = "stub"
        self.noise_floor = 0.0

    def is_speech(self, samples, frame_ms=FRAME_MS):
        return rms_float(samples) > self.threshold


def speech_frame(amp=6000, freq=220.0, phase=0.0):
    n = np.arange(FRAME)
    return (amp * np.sin(2 * math.pi * freq * n / SR + phase)).astype(np.int16)


def silence_frame(amp=0):
    return np.full(FRAME, amp, dtype=np.int16)


def make_ep(silence_timeout=5.0, **kw):
    clock = FakeClock()
    kw.setdefault("open_on_any_sound", False)   # старые тесты = строгий режим
    ep = Endpointer(sample_rate=SR, frame_ms=FRAME_MS,
                    silence_timeout=silence_timeout,
                    vad=StubVAD(), clock=clock, **kw)
    return ep, clock


def run(ep, clock, frames):
    """Прогоняет кадры, продвигая часы; возвращает все события."""
    events = []
    for f in frames:
        clock.advance(FRAME_MS / 1000.0)
        events.extend(ep.push(f))
    return events


def pattern(speech_ms=500, silence_ms=0, amp=6000):
    out = []
    for _ in range(int(speech_ms / FRAME_MS)):
        out.append(speech_frame(amp))
    for _ in range(int(silence_ms / FRAME_MS)):
        out.append(silence_frame())
    return out


# ---------------------------------------------------------------- правило 5 сек
def test_segment_closes_exactly_after_5_seconds_of_silence():
    ep, clock = make_ep(silence_timeout=5.0)
    frames = pattern(500) + pattern(0, 8000)   # слово + 8 сек тишины
    events = run(ep, clock, frames)
    segs = [e.segment for e in events if e.kind == "segment"]
    assert len(segs) == 1, "сегмент должен закрыться ровно один раз"
    seg = segs[0]
    # 0.5 c речи + 5 c тишины (+-1 кадр)
    assert 5.3 <= seg.total_seconds <= 5.7, seg.total_seconds
    assert ep.state == IDLE


def test_no_cut_off_while_user_continues_within_5s():
    """Слово -> пауза 3 c -> слово -> пауза 5 c: всё в ОДНОМ сегменте."""
    ep, clock = make_ep(silence_timeout=5.0)
    frames = (pattern(500) + pattern(0, 3000) + pattern(600) + pattern(0, 6000))
    events = run(ep, clock, frames)
    segs = [e.segment for e in events if e.kind == "segment"]
    assert len(segs) == 1, "фраза не должна обрываться, если пауза < 5 сек"
    seg = segs[0]
    # 0.48 речи + 3.0 пауза + 0.6 речи + ровно ~5.0 тишины до закрытия
    assert 8.9 <= seg.total_seconds <= 9.4, seg.total_seconds
    assert seg.speech_seconds > 1.0


def test_pause_longer_than_5s_splits_into_two_segments():
    ep, clock = make_ep(silence_timeout=5.0)
    frames = (pattern(500) + pattern(0, 6000) + pattern(500) + pattern(0, 6000))
    events = run(ep, clock, frames)
    segs = [e.segment for e in events if e.kind == "segment"]
    assert len(segs) == 2
    assert ep.stats["segments"] == 2


def test_timeout_is_configurable():
    for timeout, expected in ((2.0, 2.5), (5.0, 5.5), (8.0, 8.5)):
        ep, clock = make_ep(silence_timeout=timeout)
        frames = pattern(400) + pattern(0, int((timeout + 3) * 1000))
        events = run(ep, clock, frames)
        segs = [e.segment for e in events if e.kind == "segment"]
        assert len(segs) == 1
        assert abs(segs[0].total_seconds - expected) < 0.25, (timeout, segs[0].total_seconds)


def test_silence_left_countdown_for_ui():
    ep, clock = make_ep(silence_timeout=5.0)
    run(ep, clock, pattern(300))
    assert ep.state == LISTENING
    left_after_1s = None
    for _ in range(int(1000 / FRAME_MS)):
        clock.advance(FRAME_MS / 1000.0)
        ep.push(silence_frame())
        left_after_1s = ep.silence_left
    assert left_after_1s is not None
    assert 3.8 <= left_after_1s <= 4.2, left_after_1s


# ------------------------------------------------------------ горячая клавиша
def test_hold_key_ignores_silence_then_applies_5s_after_release():
    ep, clock = make_ep(silence_timeout=5.0, min_speech_sec=0.05)
    ev = ep.hold_start()
    assert ev.kind == "speech_start" and ev.data["reason"] == "hold"
    # речь + 10 секунд тишины при зажатой клавише - НЕ закрываем сегмент
    frames = pattern(500) + pattern(0, 10000)
    events = run(ep, clock, frames)
    assert not [e for e in events if e.kind == "segment"], "при зажатии обрывать нельзя"
    assert ep.state == LISTENING
    ep.hold_release()
    events = run(ep, clock, pattern(0, 6000))
    segs = [e.segment for e in events if e.kind == "segment"]
    assert len(segs) == 1, "после отпускания правило 5 секунд должно сработать"
    assert segs[0].total_seconds > 10.0


def test_hold_without_speech_is_discarded_not_sent():
    """Зажал клавишу в тишине и отпустил - в модель ничего не уйдёт."""
    ep, clock = make_ep(silence_timeout=5.0)
    ep.hold_start()
    run(ep, clock, pattern(0, 2000))
    ep.hold_release()
    events = run(ep, clock, pattern(0, 6000))
    kinds = [e.kind for e in events]
    assert "segment" not in kinds
    assert "discard" in kinds


def test_hold_records_speech_and_closes_5s_after_release():
    ep, clock = make_ep(silence_timeout=5.0)
    ep.hold_start()
    run(ep, clock, pattern(800))
    ep.hold_release()
    events = run(ep, clock, pattern(0, 6000))
    segs = [e.segment for e in events if e.kind == "segment"]
    assert len(segs) == 1
    assert 5.6 <= segs[0].total_seconds <= 6.1, segs[0].total_seconds
    assert segs[0].held is True


def test_cancel_drops_segment():
    ep, clock = make_ep()
    run(ep, clock, pattern(400))
    assert ep.state == LISTENING
    ep.cancel()
    assert ep.state == IDLE
    events = run(ep, clock, pattern(0, 6000))
    assert not [e for e in events if e.kind == "segment"]


# ------------------------------------------------------------------- фильтрация
def test_short_noise_is_discarded_not_sent_to_model():
    ep, clock = make_ep(min_speech_sec=0.30)
    frames = pattern(90) + pattern(0, 6000)      # 90 мс - не речь
    events = run(ep, clock, frames)
    kinds = [e.kind for e in events]
    assert "segment" not in kinds
    assert "discard" in kinds
    assert ep.stats["discarded_short"] == 1


def test_quiet_background_with_gate_does_not_start():
    """open_on_any_sound=False: тихий фон не открывает окно (старое поведение)."""
    ep, clock = make_ep(open_on_any_sound=False)
    frames = [silence_frame(amp=10) for _ in range(200)]   # тихий шум
    events = run(ep, clock, frames)
    assert ep.state == IDLE
    assert not [e for e in events if e.kind == "speech_start"]


def test_any_sound_reaches_whisper():
    """open_on_any_sound=True (требование пользователя): ЛЮБОЙ звук открывает
    окно и доезжает до сегмента - решать whisper, а не VAD."""
    ep, clock = make_ep(open_on_any_sound=True, min_speech_sec=0.0)

    class StubFloor:
        engine = "stub"; noise_floor = 0.001
        def is_speech(self, samples, frame_ms=FRAME_MS):
            return rms_float(samples) > 0.02

    ep.vad = StubFloor()
    events = run(ep, clock, [silence_frame(amp=12) for _ in range(10)])
    assert any(e.kind == "speech_start" for e in events), "тихий звук открыл окно"
    events += run(ep, clock, [silence_frame(amp=0) for _ in range(200)])
    segs = [e.segment for e in events if e.kind == "segment"]
    assert len(segs) == 1, "сегмент ушёл в распознавание (whisper решит сам)"
    assert ep.stats["discarded_noise"] == 0, "в этом режиме шум не отбрасываем"


def test_max_segment_forces_close():
    ep, clock = make_ep(silence_timeout=5.0, max_segment_sec=2.0)
    frames = [speech_frame() for _ in range(int(4000 / FRAME_MS))]  # 4 c речи подряд
    events = run(ep, clock, frames)
    segs = [e.segment for e in events if e.kind == "segment"]
    assert len(segs) >= 1
    assert segs[0].forced is True
    assert segs[0].total_seconds <= 2.2
    assert ep.stats["forced"] >= 1


def test_pre_roll_keeps_beginning_of_first_word():
    """Первые фонемы не теряются: в сегмент попадает pre-roll тишины/начала."""
    ep, clock = make_ep(pre_roll_sec=0.45, min_speech_sec=0.05)
    lead = [silence_frame() for _ in range(10)]     # 300 мс до речи
    frames = lead + pattern(300) + pattern(0, 6000)
    events = run(ep, clock, frames)
    segs = [e.segment for e in events if e.kind == "segment"]
    assert len(segs) == 1
    assert segs[0].total_seconds > 0.55, "pre-roll не попал в сегмент"


def test_segment_to_wav_is_valid():
    ep, clock = make_ep(min_speech_sec=0.05)
    events = run(ep, clock, pattern(400) + pattern(0, 6000))
    seg = [e.segment for e in events if e.kind == "segment"][0]
    wav = segment_to_wav_bytes(seg)
    assert wav[:4] == b"RIFF" and wav[8:12] == b"WAVE"
    import io
    import wave
    with wave.open(io.BytesIO(wav)) as w:
        assert w.getframerate() == SR
        assert w.getnchannels() == 1
        assert w.getsampwidth() == 2
        assert w.getnframes() == len(seg.audio)


# ------------------------------------------------------------------------- VAD
def test_energy_vad_detects_speech_and_silence():
    vad = VAD(VadConfig(engine="energy", sample_rate=SR, frame_ms=FRAME_MS,
                        noise_floor_auto=False, energy_threshold=0.012))
    assert vad.is_speech(speech_frame(6000)) is True
    assert vad.is_speech(silence_frame(0)) is False
    assert vad.is_speech(silence_frame(5)) is False


def test_rms_and_dbfs():
    assert rms_float(silence_frame(0)) == 0.0
    assert rms_float(speech_frame(32767)) > 0.6
    assert dbfs(0.0) == -120.0
    assert -70 < dbfs(0.01) < 0


def test_vad_engine_autodetect():
    vad = VAD(VadConfig(engine="auto", sample_rate=SR))
    assert vad.engine in ("webrtcvad", "energy")
    assert "energy" in vad.available_engines


def test_vad_accepts_float_and_int16():
    vad = VAD(VadConfig(engine="energy", noise_floor_auto=False))
    ints = speech_frame(6000)
    floats = ints.astype(np.float32) / 32768.0
    assert vad.is_speech(ints) is True
    assert vad.is_speech(floats) is True
