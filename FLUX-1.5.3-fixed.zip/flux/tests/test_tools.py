"""Тесты инструментов: реестр, файлы всех форматов, веб (mock SearXNG), shell."""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.tools import import_all as import_all_tools
from flux.tools import registry as reg
from flux.tools import web as webtools

import_all_tools()


class Ctx:
    def __init__(self, confirm_result=True):
        self.confirm_result = confirm_result
        self.confirms = []
        self.events = []

    def confirm(self, name, args):
        self.confirms.append((name, args))
        return self.confirm_result

    def emit(self, *a, **kw):
        self.events.append((a, kw))


# --------------------------------------------------------------------- registry
def test_registry_has_core_tools():
    names = reg.list_names()
    for need in ("web_search", "fetch_webpage", "read_file", "write_file",
                 "list_dir", "run_command", "screenshot", "list_devices",
                 "remember", "recall", "set_timer", "system_info"):
        assert need in names, f"нет инструмента {need}"


def test_schemas_are_openai_shape():
    for s in reg.schemas():
        assert s["type"] == "function"
        fn = s["function"]
        assert fn["name"] and fn["description"]
        assert fn["parameters"]["type"] == "object"


def test_validate_args_required_and_types():
    spec = reg.get("read_file")
    assert reg.validate_args(spec, {}) is not None          # нет path
    assert reg.validate_args(spec, {"path": 5}) is not None # path не строка
    assert reg.validate_args(spec, {"path": "/x"}) is None
    spec2 = reg.get("set_volume")
    assert reg.validate_args(spec2, {"level": "громко"}) is not None
    assert reg.validate_args(spec2, {"level": 55}) is None


def test_dispatch_unknown_tool():
    res = reg.dispatch("no_such_tool", {}, Ctx())
    assert res.ok is False and "неизвестный" in res.text


def test_dispatch_does_not_ask_confirmation_anymore():
    """Подтверждения действий ВЫРЕЗАНЫ (просьба пользователя).

    dispatch() больше не дёргает ctx.confirm: агент ПК выполняет инструмент
    сразу. Раньше гейт стоял и здесь, и в agent._execute — пользователя
    спрашивали ДВА РАЗА подряд, и второй вопрос обычно уходил в таймаут.
    """
    ctx = Ctx(confirm_result=False)
    res = reg.dispatch("delete_file", {"path": "/tmp/nope"}, ctx)
    assert ctx.confirms == [], "dispatch не должен спрашивать подтверждение"
    assert "отменил" not in res.text


def test_dispatch_exception_is_caught(tmp_path):
    @reg.tool("boom_test", "тест падения")
    def _boom(ctx=None):
        raise RuntimeError("взрыв")
    try:
        res = reg.dispatch("boom_test", {}, Ctx())
        assert res.ok is False and "взрыв" in res.text
    finally:
        reg.REGISTRY.pop("boom_test", None)


# ------------------------------------------------------------------------ files
def test_read_write_edit_roundtrip(tmp_path):
    p = tmp_path / "note.txt"
    r = reg.dispatch("write_file", {"path": str(p), "content": "строка один\nстрока два"}, Ctx())
    assert r.ok, r.text
    r = reg.dispatch("read_file", {"path": str(p)}, Ctx())
    assert r.ok and "строка один" in r.text
    r = reg.dispatch("edit_file", {"path": str(p), "old_text": "строка два",
                                   "new_text": "строка ДВА!"}, Ctx())
    assert r.ok, r.text
    r = reg.dispatch("read_file", {"path": str(p)}, Ctx())
    assert "строка ДВА!" in r.text and "строка два" not in r.text


def test_read_encoding_cp1251(tmp_path):
    p = tmp_path / "win.txt"
    p.write_bytes("привет из windows".encode("cp1251"))
    r = reg.dispatch("read_file", {"path": str(p)}, Ctx())
    assert r.ok and "привет из windows" in r.text


def test_read_json_pretty(tmp_path):
    p = tmp_path / "d.json"
    p.write_text('{"a":1,"b":[1,2]}', encoding="utf-8")
    r = reg.dispatch("read_file", {"path": str(p)}, Ctx())
    assert r.ok and '"a": 1' in r.text


def test_read_csv(tmp_path):
    p = tmp_path / "t.csv"
    p.write_text("a,b\n1,2\n3,4\n", encoding="utf-8")
    r = reg.dispatch("read_file", {"path": str(p)}, Ctx())
    assert r.ok and "1,2" in r.text


def test_read_pdf(tmp_path):
    from fpdf import FPDF
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", size=14)
    pdf.cell(0, 10, "FLUX PDF TEST DOCUMENT", new_x="LMARGIN", new_y="NEXT")
    out = tmp_path / "doc.pdf"
    pdf.output(str(out))
    r = reg.dispatch("read_file", {"path": str(out)}, Ctx())
    assert r.ok, r.text
    assert "FLUX PDF TEST DOCUMENT" in r.text


def test_read_docx(tmp_path):
    import docx
    d = docx.Document()
    d.add_paragraph("Первый абзац докx")
    d.add_paragraph("Второй абзац")
    out = tmp_path / "doc.docx"
    d.save(str(out))
    r = reg.dispatch("read_file", {"path": str(out)}, Ctx())
    assert r.ok and "Первый абзац докx" in r.text


def test_read_xlsx(tmp_path):
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["имя", "значение"])
    ws.append(["флюкс", 42])
    out = tmp_path / "t.xlsx"
    wb.save(str(out))
    r = reg.dispatch("read_file", {"path": str(out)}, Ctx())
    assert r.ok and "флюкс" in r.text and "42" in r.text


def test_read_pptx(tmp_path):
    from pptx import Presentation
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    slide.shapes.title.text = "Заголовок слайда FLUX"
    out = tmp_path / "p.pptx"
    prs.save(str(out))
    r = reg.dispatch("read_file", {"path": str(out)}, Ctx())
    assert r.ok and "Заголовок слайда FLUX" in r.text


def test_read_image_attaches_for_vision(tmp_path):
    from PIL import Image
    p = tmp_path / "img.png"
    Image.new("RGB", (64, 32), (200, 30, 30)).save(p)
    r = reg.dispatch("read_file", {"path": str(p)}, Ctx())
    assert r.ok
    assert r.attach_images == [str(p)], "изображение должно прикладываться к модели"
    assert "64x32" in r.text


def test_read_binary_hexdump(tmp_path):
    p = tmp_path / "bin.dat"
    p.write_bytes(bytes(range(64)))
    r = reg.dispatch("read_file", {"path": str(p)}, Ctx())
    assert r.ok and "бинарный" in r.text and "00 01 02" in r.text


def test_read_missing_and_dir(tmp_path):
    assert reg.dispatch("read_file", {"path": str(tmp_path / "nope.txt")}, Ctx()).ok is False
    assert reg.dispatch("read_file", {"path": str(tmp_path)}, Ctx()).ok is False


def test_list_dir_and_find(tmp_path):
    (tmp_path / "a.txt").write_text("x")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "b.py").write_text("y")
    r = reg.dispatch("list_dir", {"path": str(tmp_path)}, Ctx())
    assert r.ok and "a.txt" in r.text and "[D]" in r.text
    r = reg.dispatch("list_dir", {"path": str(tmp_path), "recursive": True}, Ctx())
    assert "b.py" in r.text
    r = reg.dispatch("find_files", {"pattern": "*.py", "root": str(tmp_path)}, Ctx())
    assert r.ok and str(tmp_path / "sub" / "b.py") in r.text


def test_grep(tmp_path):
    (tmp_path / "a.py").write_text("def flux():\n    return 'флюкс'\n")
    (tmp_path / "b.py").write_text("nothing here\n")
    r = reg.dispatch("grep_files", {"pattern": "флюкс", "root": str(tmp_path)}, Ctx())
    assert r.ok and "a.py:2" in r.text


def test_copy_move_delete(tmp_path):
    src = tmp_path / "s.txt"
    src.write_text("данные")
    ctx = Ctx()
    assert reg.dispatch("copy_file", {"src": str(src), "dst": str(tmp_path / "c.txt")}, ctx).ok
    assert reg.dispatch("move_file", {"src": str(tmp_path / "c.txt"),
                                      "dst": str(tmp_path / "m.txt")}, ctx).ok
    assert (tmp_path / "m.txt").exists() and not (tmp_path / "c.txt").exists()
    assert reg.dispatch("delete_file", {"path": str(tmp_path / "m.txt")}, ctx).ok
    assert not (tmp_path / "m.txt").exists()


def test_denied_path_is_blocked(tmp_path, monkeypatch):
    from flux import config as cfg
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    bad = tmp_path / "windows" / "system32" / "config" / "sam"
    bad.parent.mkdir(parents=True)
    bad.write_text("x")
    r = reg.dispatch("delete_file", {"path": str(bad)}, Ctx())
    assert r.ok is False and "запрещён" in r.text


# ------------------------------------------------------------------------- web
class _SearxHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        from urllib.parse import parse_qs, urlparse
        q = parse_qs(urlparse(self.path).query)
        assert q.get("format") == ["json"], "SearXNG должен вызываться с format=json"
        payload = json.dumps({
            "results": [
                {"title": "Погода в Москве", "url": "https://a.example/1",
                 "content": "Сегодня +5, облачно", "engine": "google"},
                {"title": "Второй", "url": "https://b.example/2",
                 "content": "ещё сниппет", "engine": "ddg"},
            ]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *a):
        pass


@pytest.fixture()
def searx(monkeypatch):
    srv = ThreadingHTTPServer(("127.0.0.1", 0), _SearxHandler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    from flux import config as cfg
    monkeypatch.setattr(cfg, "get",
                        lambda k, d=None: (f"http://127.0.0.1:{srv.server_address[1]}"
                                           if k == "search.searxng_url"
                                           else {"search.enabled": True,
                                                 "search.language": "ru-RU",
                                                 "search.safesearch": 1,
                                                 "search.max_results": 6,
                                                 "search.timeout_sec": 5,
                                                 "search.fallback_ddg": False,
                                                 "search.fetch_max_chars": 5000,
                                                 "search.fetch_timeout_sec": 5}.get(k, d)))
    yield
    srv.shutdown()


def test_searxng_search_tool(searx):
    r = reg.dispatch("web_search", {"query": "погода в москве"}, Ctx())
    assert r.ok, r.text
    assert "Погода в Москве" in r.text
    assert "https://a.example/1" in r.text
    assert r.data["source"] == "searxng"


def test_fetch_webpage_tool(monkeypatch):
    html = "<html><head><title>Тест</title></head><body><script>x()</script>" \
           "<h1>Заголовок</h1><p>Текст страницы про флюкс.</p></body></html>"

    class R:
        status_code = 200
        headers = {"Content-Type": "text/html"}
        text = html

        def raise_for_status(self):
            return None

    monkeypatch.setattr(webtools.requests, "get", lambda *a, **k: R())
    r = reg.dispatch("fetch_webpage", {"url": "https://x.example/p"}, Ctx())
    assert r.ok
    assert "Текст страницы про флюкс" in r.text
    assert "script" not in r.text and "x()" not in r.text
    assert r.data["title"] == "Тест"


def test_fetch_rejects_non_http():
    r = reg.dispatch("fetch_webpage", {"url": "ftp://x"}, Ctx())
    assert r.ok is False


# ----------------------------------------------------------------------- shell
def test_run_command_echo():
    r = reg.dispatch("run_command", {"command": "echo FLUX_OK", "timeout": 20}, Ctx())
    assert r.ok and "FLUX_OK" in r.text


def test_run_command_failure_code():
    r = reg.dispatch("run_command", {"command": "exit 3", "timeout": 20}, Ctx())
    assert r.ok is False and "exit=3" in r.text


def test_run_python_tool():
    r = reg.dispatch("run_python", {"code": "print(2+2)", "timeout": 30}, Ctx())
    assert r.ok and "4" in r.text


def test_run_command_executes_without_confirmation():
    """run_command выполняется сразу: подтверждений больше нет."""
    ctx = Ctx(confirm_result=False)
    r = reg.dispatch("run_command", {"command": "echo x"}, ctx)
    assert ctx.confirms == [], "оболочку больше не переспрашиваем"
    assert r.ok is True and "x" in r.text


def test_dangerous_tools_are_gated_by_config_categories(monkeypatch):
    """Единственный оставшийся барьер — категории в security.*, а не вопросы.

    Подтверждения вырезаны, поэтому доступ к опасным возможностям обязан
    регулироваться настройкой: выключил allow_shell — инструмент исчезает
    из схем, которые видит модель, и dispatch его отклоняет.
    """
    from flux import config as cfg

    assert reg.get("run_command").dangerous is True
    assert reg.get("delete_file").dangerous is True
    monkeypatch.setitem(cfg.load()["security"], "allow_shell", False)
    assert "shell" in reg._disabled_categories()
    names = {s["function"]["name"] for s in reg.schemas()}
    assert "run_command" not in names and "run_python" not in names
