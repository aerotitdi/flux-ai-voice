"""ДОКАЗАТЕЛЬСТВО РАБОТОСПОСОБНОСТИ полного голосового цикла без Windows:

  edge-tts (голос Дмитрия) -> mp3 -> PCM 16k
  -> WavCapture (имитация микрофона) -> Endpointer (правило 5 c)
  -> faster-whisper -> детектор «флюкс» -> команда
  -> Agent (mock Ollama: tool call + финальный ответ с разметкой)
  -> потоковая озвучка *-...-* -> edge-tts -> декодирование PCM

Каждое звеноassert'ится отдельно: если цепочка рвётся, тест показывает, ГДЕ.
"""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.audio.capture import WavCapture
from flux.audio.endpointer import Endpointer
from flux.audio.player import decode_audio_file
from flux.audio.vad import VadConfig
from flux.llm.agent import Agent
from flux.llm.ollama_client import OllamaClient
from flux.memory.store import MemoryStore
from flux.tts.engine import EdgeTTSEngine, TTSRouter
from flux.wakeword import WakeDetector

SR = 16000
FRAME_MS = 30


class MockOllama(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        msgs = body.get("messages", [])
        lines = []
        if not any(m.get("role") == "tool" for m in msgs):
            lines.append(json.dumps({"message": {"role": "assistant", "content": "",
                                                 "tool_calls": [{"function": {
                                                     "name": "current_time",
                                                     "arguments": {}}}]},
                                     "done": True}))
        else:
            final = ("Служебное: время получено. "
                     "*-Сейчас примерно полдень. Погода плюс пять, облачно.*-")
            for i in range(0, len(final), 7):
                lines.append(json.dumps({"message": {"role": "assistant",
                                                     "content": final[i:i + 7]}}))
            lines.append(json.dumps({"message": {"role": "assistant",
                                                 "content": ""}, "done": True}))
        payload = ("\n".join(lines) + "\n").encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *a):
        pass


@pytest.mark.network
def test_full_voice_pipeline_headless(tmp_path):
    # 1) речь пользователя синтезом
    eng = EdgeTTSEngine(voice="ru-RU-DmitryNeural")
    mp3 = tmp_path / "user.mp3"
    path = eng.synthesize("Флюкс, какая сейчас погода", str(mp3))
    if not path:
        pytest.skip("edge-tts недоступен (сеть/лимиты)")
    data, sr = decode_audio_file(path, target_sr=SR)
    audio = (data * 32767.0).astype(np.int16)
    assert audio.size > SR * 0.7, "звук пользователя слишком короткий"

    # 2) «микрофон»: звук + 6 секунд тишины -> сегмент по правилу 5 c
    silence = np.zeros(SR * 6, dtype=np.int16)
    stream = np.concatenate([audio, silence])
    # виртуальные часы: кадр = 30 мс модельного времени (иначе 5 c тишины
    # не наступят при мгновенном прогоне файла)
    clock_state = {"n": 0}
    ep = Endpointer(sample_rate=SR, frame_ms=FRAME_MS, silence_timeout=5.0,
                    vad_cfg=VadConfig(engine="energy", energy_threshold=0.008,
                                      noise_floor_auto=False),
                    clock=lambda: 1000.0 + clock_state["n"] * (FRAME_MS / 1000.0))
    segments = []

    def on_frame(frame, rms):
        clock_state["n"] += 1
        segments.extend(e.segment for e in ep.push(frame, FRAME_MS)
                        if e.kind == "segment" and e.segment is not None)

    cap = WavCapture(stream, sample_rate=SR, frame_ms=FRAME_MS,
                     on_frame=on_frame)
    cap.start()
    cap.run()
    cap.stop()
    assert len(segments) == 1, f"ожидался один сегмент, получено {len(segments)}"
    seg = segments[0]
    assert seg.speech_seconds > 0.7, "речь не детектирована VAD"

    # 3) whisper + детектор слова
    from flux.stt.local import LocalWhisperSTT
    tr = LocalWhisperSTT(size="base").transcribe_audio(seg.audio, SR)
    assert tr.text.strip(), "whisper не распознал сегмент"
    match = WakeDetector(words=["флюкс", "flux"]).check(tr.text)
    assert match.matched, f"активация не найдена в {tr.text!r}"
    assert "погода" in match.command.lower(), match.command

    # 4) агент с инструментом и разметкой ответа
    srv = ThreadingHTTPServer(("127.0.0.1", 0), MockOllama)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_address[1]}"
    try:
        from flux import config as cfg
        cfg.update({"llm": {"endpoint": base, "model": "m", "stream": True,
                            "max_tool_rounds": 4}}, save=False)
        store = MemoryStore(str(tmp_path / "pipe.db"))
        agent = Agent(client=OllamaClient(endpoint=base, model="m", timeout=15),
                      store=store)
        spoken: list[str] = []
        res = agent.run(match.command,
                        on_speak_chunk=lambda c: spoken.append(c.text))
        assert [t.name for t in res.tool_log] == ["current_time"]
        assert res.tool_log[0].ok
        joined = " ".join(spoken)
        assert "плюс пять" in joined, joined
        assert "Служебное" not in joined, "служебный текст не должен озвучиваться"
        store.close()
    finally:
        srv.shutdown()

    # 5) озвучка ответа серверным TTS и декодирование
    router = TTSRouter()
    out, engine = router.synthesize(joined, str(tmp_path / "answer.mp3"))
    assert out, f"ozvuchka ne udalas ({engine})"
    pcm, psr = decode_audio_file(out, target_sr=24000)
    assert pcm.size > 24000 * 0.8, "ответ слишком короткий для озвучки"
