"""Тесты парсера озвучки *-...-* (в т.ч. потокового, по токенам)."""
import random
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import tts_markup as tm


def collect(text, **kw):
    """Прогон через потоковый парсер (как в реальном стриме LLM)."""
    p = tm.MarkupStreamParser(**kw)
    out = [c.text for c in p.feed(text) if c.text]
    out += [c.text for c in p.flush() if c.text]
    return out


def stream_collect(text, chunk=1, seed=7, **kw):
    """Кормим посимвольно/кусками - результат должен совпадать с разовым."""
    rnd = random.Random(seed)
    p = tm.MarkupStreamParser(**kw)
    out = []
    i = 0
    while i < len(text):
        n = chunk if chunk > 0 else rnd.randint(1, 6)
        for c in p.feed(text[i:i + n]):
            if c.text:
                out.append(c.text)
        i += n
    for c in p.flush():
        if c.text:
            out.append(c.text)
    return out


# ------------------------------------------------------------- базовое поведение
def test_only_marked_text_is_spoken():
    text = "Служебная заметка (не озвучивается). *-Привет, я Флюкс!-* И ещё код:\n```py\nx=1\n```"
    res = tm.parse(text)
    assert res.spoken == ["Привет, я Флюкс!"]
    assert "Служебная заметка" not in res.spoken_text
    assert "x=1" not in res.spoken_text


def test_multiple_marked_blocks_in_order():
    text = "*-Первый блок-* молча *-Второй блок-* тишина *-Третий-*"
    assert tm.extract_spoken(text) == ["Первый блок", "Второй блок", "Третий"]


def test_no_markers_nothing_spoken():
    text = "Обычный ответ без маркеров вообще."
    assert tm.extract_spoken(text) == []
    assert tm.has_speech(text) is False
    assert tm.parse(text).spoken == []


def test_empty_and_none():
    assert tm.extract_spoken("") == []
    assert tm.parse("").spoken == []
    assert tm.strip_markers("") == ""


def test_unbalanced_marker_still_spoken():
    text = "*-Начал говорить и не закрыл маркер"
    assert tm.extract_spoken(text) == ["Начал говорить и не закрыл маркер"]


def test_adjacent_markers():
    assert tm.extract_spoken("*--*") == []
    assert tm.extract_spoken("*-а-*-*-б-*") == ["а", "б"]


def test_display_text_marks_speech_and_hides_markers():
    text = "лог: ok *-Сделано!-* конец"
    d = tm.strip_markers(text)
    assert "*-" not in d and "-*" not in d
    assert "Сделано!" in d and "🔊" in d
    assert "лог: ok" in d


def test_wrap_helper():
    assert tm.wrap("привет") == "*-привет-*"


# ------------------------------------------------------------- очистка для речи
def test_markdown_and_emoji_cleaned():
    text = "*-**Жирный** текст, `код`, [ссылка](http://x.y), эмодзи 🚀 и # заголовок-*"
    out = tm.extract_spoken(text)[0]
    assert "**" not in out and "`" not in out and "http" not in out
    assert "🚀" not in out and "#" not in out
    assert "Жирный текст" in out
    assert "ссылка" in out


def test_code_fence_not_spoken_inside_marker():
    text = "*-Вот код: ```python\nprint(1)\n``` готово-*"
    out = tm.extract_spoken(text)[0]
    assert "print" not in out
    assert "Вот код" in out and "готово" in out


def test_newlines_collapsed():
    out = tm.extract_spoken("*-строка1\nстрока2\n\nстрока3-*")[0]
    assert "\n" not in out
    assert "строка1 строка2 строка3" == out


def test_dashes_become_pauses():
    out = tm.extract_spoken("*-Флюкс - ваш ассистент — на связи-*")[0]
    assert " - " not in out and "—" not in out


# ------------------------------------------------------------- потоковый режим
SAMPLES = [
    "*-Привет! Я Флюкс. Чем помочь?-*",
    "думает... *-Готово. Файл создан на рабочем столе. Проверь, пожалуйста.-* хвост",
    "*-Раз. Два. Три. Четыре. Пять. Шесть. Семь. Восемь. Девять. Десять. Одиннадцать.-*",
    "*-Незакрытый маркер с текстом",
    "без маркеров",
    "*-а-* и *-б-*",
]


@pytest.mark.parametrize("text", SAMPLES)
def test_streaming_equals_oneshot(text):
    expected = " ".join(tm.extract_spoken(text))
    for chunk in (1, 2, 3, 5, 13):
        got = " ".join(stream_collect(text, chunk=chunk))
        got = " ".join(got.split())
        exp = " ".join(expected.split())
        assert got == exp, f"chunk={chunk}\n got={got!r}\n exp={exp!r}"


def test_streaming_emits_before_end():
    """Первый кусок озвучки приходит ДО конца стрима (низкая задержка)."""
    text = ("*-Первое предложение уже закончилось. Второе ещё печатается и продолжается"
            " довольно долго, чтобы проверить потоковую выдачу кусков. Третье короткое-*")
    p = tm.MarkupStreamParser()
    first = None
    chunks = []
    for i in range(0, len(text), 3):
        for c in p.feed(text[i:i + 3]):
            if c.text:
                chunks.append(c.text)
                if first is None:
                    first = (i, c.text)
    chunks += [c.text for c in p.flush() if c.text]
    assert first is not None, "ничего не выдано до конца потока"
    assert first[0] < len(text) - 20, "озвучка началась только в самом конце"
    assert "Первое предложение" in first[1]
    joined = " ".join(chunks)
    assert "Третье короткое" in joined, "хвост потерян"
    assert joined.split() == " ".join(tm.extract_spoken(text)).split()


def test_partial_marker_not_split_across_chunks():
    """Маркер, разрезанный между чанками, обязан собраться."""
    text = "тишина *-Говорю-* тишина"
    # режем ровно посередине маркеров
    for cut in range(len(text)):
        p = tm.MarkupStreamParser()
        out = []
        for c in p.feed(text[:cut]):
            out.append(c.text)
        for c in p.feed(text[cut:]):
            out.append(c.text)
        for c in p.flush():
            out.append(c.text)
        joined = " ".join(x for x in out if x)
        assert "Говорю" in joined, f"cut={cut} -> {joined!r}"
        assert "тишина" not in joined, f"cut={cut} -> {joined!r}"


def test_custom_markers():
    text = "<<скажи это>> а это молча"
    assert tm.extract_spoken(text, "<<", ">>") == ["скажи это"]


def test_chunk_sizes_respect_limits():
    long_sentence = "слово " * 200
    text = f"*-{long_sentence}-*"
    chunks = collect(text, min_chunk_chars=30, max_chunk_chars=200)
    assert len(chunks) > 1
    for c in chunks:
        assert len(c) <= 260


def test_sentence_splitting_respects_abbreviations():
    text = "*-Сделал т.д. и т.п. в 5 м. Всё готово!-*"
    chunks = collect(text, min_chunk_chars=1)
    joined = " ".join(chunks)
    assert "т.д." in joined and "т.п." in joined
    assert "5 м." in joined


def test_min_chunk_merges_short_sentences():
    text = "*-Да. Нет. Ок. Может быть. Конечно. Поехали. Готово. Принято. Хорошо. Ясно.-*"
    chunks = collect(text, min_chunk_chars=25)
    assert len(chunks) < 6, chunks
    assert " ".join(chunks).count("Да") == 1


def test_no_duplicate_or_lost_text_under_random_chunking():
    text = ("*-Альфа. Бета! Гамма? Дельта-* молчание *-Эпсилон. Зета. Эта. Тета.-*"
            " служебное *-Йота-*")
    expected = " ".join(tm.extract_spoken(text)).split()
    for seed in range(12):
        got = " ".join(stream_collect(text, chunk=0, seed=seed)).split()
        assert got == expected, f"seed={seed}\n{got}\n{expected}"
