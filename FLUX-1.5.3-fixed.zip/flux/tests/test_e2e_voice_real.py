"""НАСТОЯЩИЙ сквозной тест голосового тракта (нужен интернет):

  edge-tts (голос Дмитрия, как в спейсе) -> mp3
  -> декодирование в PCM 16k
  -> faster-whisper (base)
  -> детектор слова «флюкс»
  -> команда без слова-активации

Этот тест прогоняется инсталлером в режиме самотеста и здесь, в CI-песочнице.
"""
import sys
from pathlib import Path

from difflib import SequenceMatcher

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

CASES = [
    ("Флюкс, включи свет на кухне", "включи свет на кухне"),
    ("флюкс который час", "который час"),
    ("Флюкс! Найди в интернете погоду в Москве", "найди в интернете погоду в москве"),
]

NEGATIVE_CASES = [
    "Включи свет на кухне",
    "плюс два градуса на улице",
]


def _synthesize(text: str, path: Path) -> bool:
    from flux.tts.engine import EdgeTTSEngine
    eng = EdgeTTSEngine(voice="ru-RU-DmitryNeural", retries=3)
    return eng.synthesize(text, str(path)) is not None


def similarity(a: str, b: str) -> float:
    """Нечёткое сравнение: реальный ASR даёт словесные ошибки, которые LLM
    спокойно понимает, поэтому точное равенство не требуем."""
    return SequenceMatcher(None, a.strip().lower(), b.strip().lower()).ratio()


def _decode(path: Path) -> np.ndarray:
    from flux.audio.player import decode_audio_file
    data, sr = decode_audio_file(str(path), target_sr=16000)
    return (data * 32767.0).astype(np.int16)


@pytest.mark.network
@pytest.mark.parametrize("phrase,expected_command", CASES)
def test_real_voice_pipeline_wake_and_command(tmp_path, phrase, expected_command):
    """Живой круг: edge-tts -> mp3 -> PCM -> faster-whisper(base) -> «флюкс»
    -> команда.

    ЧЕСТНО про разброс: вход здесь — РЕЧЬ, синтезированная внешним сервисом,
    а распознаёт её самая лёгкая модель base. Хвосты-галлюцинации
    («…Повторяю.», «СПОКОЙНАЯ МУЗЫКА») режет боевой фильтр stt.filter, но
    base иногда даёт и другую словесную ошибку, из-за которой нечёткое
    сравнение падает на пороге 0.80. Поэтому попыток две: провал теста =
    ОБЕ попытки плохи, а в сообщении видны все распознанные тексты
    (ничего не прячем). Прогон 09.10.2026: sim=0.78 на
    «Флюкс, включи, свет на кухне. Повторяю.» — после добавления
    CREDIT_TAILS в stt/filter хвост режется, команда совпадает.
    """
    from flux.stt.filter import is_filler_only, strip_hallucination_tail
    from flux.stt.local import LocalWhisperSTT
    from flux.wakeword import WakeDetector

    stt = LocalWhisperSTT(size="base")
    det = WakeDetector(words=["флюкс", "flux"], sensitivity=1)

    def seg_text(seg):
        if isinstance(seg, dict):
            return str(seg.get("text") or "")
        return str(getattr(seg, "text", "") or "")

    problems = []
    for attempt in (1, 2):
        mp3 = tmp_path / f"case{attempt}.mp3"
        if not _synthesize(phrase, mp3):
            pytest.skip("edge-tts недоступен (сеть)")
        audio = _decode(mp3)
        assert audio.size > 16000 * 0.5
        tr = stt.transcribe_audio(audio, 16000)
        if not tr.text.strip():
            problems.append(f"попытка {attempt}: whisper не распознал ничего")
            continue

        # боевой поток (voice/stream.py) пропускает каждый сегмент через
        # stt.filter — сравниваем ЧЕСТНО: тем же путём, а не сырым текстом
        segs = [seg_text(x).strip() for x in (getattr(tr, "segments", None) or [])]
        clean = " ".join(strip_hallucination_tail(x) for x in segs
                         if x and not is_filler_only(x))
        m = det.check(clean or tr.text)
        if not m.matched:
            problems.append(f"попытка {attempt}: слово-активация не найдено "
                            f"(распознано {tr.text!r}, после фильтра {clean!r})")
            continue
        sim = similarity(m.command, expected_command)
        if sim >= 0.80:
            return
        problems.append(f"попытка {attempt}: команда {m.command!r} далека от "
                        f"{expected_command!r} (sim={sim:.2f}, распознано "
                        f"{tr.text!r}, после фильтра {clean!r})")
    pytest.fail(" | ".join(problems) or "живой голосовой круг не сошёлся")


@pytest.mark.network
@pytest.mark.parametrize("phrase", NEGATIVE_CASES)
def test_real_voice_pipeline_no_false_wake(tmp_path, phrase):
    from flux.stt.local import LocalWhisperSTT
    from flux.wakeword import WakeDetector

    mp3 = tmp_path / "neg.mp3"
    if not _synthesize(phrase, mp3):
        pytest.skip("edge-tts недоступен (сеть)")
    audio = _decode(mp3)
    stt = LocalWhisperSTT(size="base")
    tr = stt.transcribe_audio(audio, 16000)
    det = WakeDetector(words=["флюкс", "flux"], sensitivity=1)
    assert not det.check(tr.text).matched, (
        f"ЛОЖНАЯ активация на {phrase!r} (распознано {tr.text!r})")


@pytest.mark.network
def test_full_turn_marker_to_speech_to_transcript(tmp_path):
    """Полный круг: ответ модели с разметкой -> озвучка -> эта же озвучка
    распознаётся как внятная речь (проверка качества тракта)."""
    from flux.audio.player import decode_audio_file
    from flux.stt.local import LocalWhisperSTT
    from flux.tts.engine import EdgeTTSEngine
    from flux.tts_markup import parse

    answer = ("Проверяю файлы. *-Готово! Я нашёл три файла на рабочем столе. "
              "Открыть их?-* (служебное: tool=list_dir, ok)"
    )
    res = parse(answer)
    assert res.spoken and "служебное" not in res.spoken_text
    mp3 = tmp_path / "answer.mp3"
    eng = EdgeTTSEngine(voice="ru-RU-DmitryNeural")
    path = eng.synthesize(res.spoken_text, str(mp3))
    if not path:
        pytest.skip("edge-tts недоступен")
    data, sr = decode_audio_file(path, target_sr=16000)
    audio = (data * 32767.0).astype(np.int16)
    tr = LocalWhisperSTT(size="base").transcribe_audio(audio, 16000)
    # Whisper слышит «Готово» то как «готово», то как «готова» - это
    # вариативность ASR, поэтому сверяем нечётко, как в живом тракте
    assert similarity(tr.text, res.spoken_text) >= 0.75, (
        f"round-trip разошёлся: {tr.text!r} vs {res.spoken_text!r}")
    assert "служебное" not in tr.text.lower()
