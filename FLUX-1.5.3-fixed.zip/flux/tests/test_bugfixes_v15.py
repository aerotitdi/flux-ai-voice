"""Регрессионные тесты на баги, найденные аудитом v1.5 (09.10.2026).

Каждый тест назван по багу и содержит доказательство «до/после»: все они
ПАДАЮТ на исходном коде из FLUX-installer.zip и проходят после правок.
Штатный набор (496 тестов) ни один из этих багов не ловил — поэтому здесь
отдельный файл с явной привязкой к находке.

Список находок и их статус — в БАГИ_И_ПРАВКИ.md.
"""
from __future__ import annotations

import io
import json
import logging
import sys
import threading
import time
import wave
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg  # noqa: E402
from flux import logger as logmod  # noqa: E402
from flux import paths  # noqa: E402


def _code_only(path: Path) -> str:
    """Исполняемый код модуля БЕЗ комментариев и докстрингов.

    Проверять «нет ли в файле X» по сырому тексту нельзя: X закономерно
    упоминается в пояснениях к правке. Разбираем AST, выкидываем докстринги
    и собираем код обратно через ast.unparse.
    """
    import ast as _ast

    tree = _ast.parse(path.read_text(encoding="utf-8"))
    for node in _ast.walk(tree):
        if isinstance(node, (_ast.Module, _ast.ClassDef, _ast.FunctionDef,
                             _ast.AsyncFunctionDef)):
            body = getattr(node, "body", None)
            if (body and isinstance(body[0], _ast.Expr)
                    and isinstance(body[0].value, _ast.Constant)
                    and isinstance(body[0].value.value, str)):
                node.body = body[1:] or [_ast.Pass()]
    return _ast.unparse(tree)


@pytest.fixture(autouse=True)
def _fresh_config(monkeypatch, tmp_path):
    """Свой config.json в tmp: тесты не должны писать в репозиторий."""
    monkeypatch.setattr(cfg, "_CONFIG", None)
    monkeypatch.setattr(paths, "CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(paths, "CONFIG_DIR", tmp_path)
    cfg.load(force=True)
    yield
    monkeypatch.setattr(cfg, "_CONFIG", None)


# ══════════════════════════════════════════════════════════════════════════
# БАГ №1 (КРИТИЧЕСКИЙ): фолбэк cuda->cpu оставлял compute_type=float16,
# а ctranslate2 на CPU его не поддерживает -> локальный whisper умирал ЦЕЛИКОМ.
# ══════════════════════════════════════════════════════════════════════════
def test_ctranslate2_really_rejects_float16_on_cpu():
    """Доказательство premises: float16 НЕТ в списке compute-типов для CPU."""
    ct2 = pytest.importorskip("ctranslate2")
    assert "float16" not in ct2.get_supported_compute_types("cpu")


def test_compute_for_device_maps_float16_to_int8():
    from flux.stt import local as L
    assert L.compute_for_device("float16", "cpu") == "int8"
    assert L.compute_for_device("auto", "cpu") == "int8"
    assert L.compute_for_device("", "cpu") == "int8"
    assert L.compute_for_device("int8", "cpu") == "int8"
    assert L.compute_for_device("float32", "cpu") == "float32"
    # на GPU float16 остаётся: там он поддерживается и быстрее
    assert L.compute_for_device("float16", "cuda") == "float16"
    assert L.compute_for_device("auto", "cuda") == "auto"


def test_cuda_failure_falls_back_to_cpu_with_usable_compute_type(monkeypatch):
    """Главный сценарий пользователя: GPU виден, но cublas64_12.dll нет.

    ДО ФИКСА: вторая попытка шла как cpu/float16 и падала ValueError
    «Requested float16 compute type, but the target device or backend do not
    support efficient float16 computation» — не грузилась НИ ОДНА модель.
    """
    import types

    from flux.stt import local as L

    attempts: list[tuple] = []

    class FakeModel:
        def __init__(self, size, **kw):
            attempts.append((kw.get("device"), kw.get("compute_type")))
            if kw.get("device") == "cuda":
                raise RuntimeError("Library cublas64_12.dll is not found")
            if kw.get("compute_type") == "float16":
                # ровно та ошибка, которую даёт настоящий ctranslate2
                raise ValueError(
                    "Requested float16 compute type, but the target device or "
                    "backend do not support efficient float16 computation.")

        def transcribe(self, *a, **kw):
            return [], types.SimpleNamespace(language="ru")

    fake = types.ModuleType("faster_whisper")
    fake.WhisperModel = FakeModel
    monkeypatch.setitem(sys.modules, "faster_whisper", fake)
    monkeypatch.setattr(L, "_models", {})
    cfg.update({"stt": {"local": {"compute_type": "auto", "device": "cuda",
                                  "cpu_threads": 0, "download_root": ""}}},
               save=False)

    model, eff = L.get_model("base", device="cuda", compute_type="auto")
    assert model is not None and eff == "base"
    assert attempts[0] == ("cuda", "float16"), attempts
    # ВТОРАЯ попытка обязана быть cpu/ЧТО-ТО-ПОДДЕРЖИВАЕМОЕ, а не cpu/float16
    assert attempts[1][0] == "cpu"
    assert attempts[1][1] in L.CPU_COMPUTE_TYPES, (
        f"фолбэк на cpu с compute_type={attempts[1][1]!r} снова упадёт")


def test_load_one_cpu_retries_with_another_compute_type(monkeypatch):
    """Если и cpu/<выбранный тип> не подошёл — пробуем следующий, не сдаёмся."""
    import types

    from flux.stt import local as L

    tried: list[str] = []

    class FakeModel:
        def __init__(self, size, **kw):
            tried.append(kw.get("compute_type"))
            if kw.get("compute_type") != "int8":
                raise RuntimeError("не поддержан")

    fake = types.ModuleType("faster_whisper")
    fake.WhisperModel = FakeModel
    monkeypatch.setitem(sys.modules, "faster_whisper", fake)
    model, dev, comp = L._load_one("tiny", "cpu", "int16", "", 0)
    assert model is not None and dev == "cpu"
    assert tried[0] == "int16" and "int8" in tried


# ══════════════════════════════════════════════════════════════════════════
# БАГ №3: подтверждение запрашивалось ДВАЖДЫ (agent._execute + registry.dispatch)
# ══════════════════════════════════════════════════════════════════════════
def test_registry_dispatch_never_confirms():
    from flux.tools import registry as reg
    asks: list = []

    class Ctx:
        def confirm(self, name, args):
            asks.append(name)
            return False

    res = reg.dispatch("delete_file", {"path": "/tmp/__нет__"}, Ctx())
    assert asks == [], "dispatch больше не спрашивает подтверждение"
    assert "отменил" not in res.text


def test_confirmations_are_off_by_default():
    assert bool(cfg.get("security.confirm_destructive", False)) is False


def test_confirm_state_is_gone_from_main():
    src = _code_only(Path(__file__).resolve().parents[1] / "app" / "flux"
                     / "main.py")
    assert "CONFIRM" not in src, "состояние «жду подтверждения» должно быть удалено"
    assert "_confirm_request" not in src
    assert "VOICE_CONFIRM_QUESTION" not in src, \
        "голосовой вопрос «Подтверждаешь операцию?» больше не задаётся"


def test_system_prompt_forbids_asking_confirmation():
    from flux import prompts
    sp = prompts.system_prompt()
    assert "НИКОГДА не спрашивай" in sp and "подтверждения" in sp


# ══════════════════════════════════════════════════════════════════════════
# БАГ №6: ctx.search_shown копился вечно -> web_search умирал навсегда
# ══════════════════════════════════════════════════════════════════════════
def test_search_shown_is_reset_on_every_request(monkeypatch):
    from flux.llm.agent import Agent
    from flux.llm.ollama_client import LLMResponse
    from flux.tools import registry as reg
    from flux.tools.registry import ToolResult

    reg.tool("__probe_search", "тест", {"type": "object", "properties": {}})(
        lambda ctx=None: (setattr(ctx, "search_shown",
                                  int(getattr(ctx, "search_shown", 0)) + 250),
                          ToolResult(True, "ок"))[1])

    class FakeClient:
        def __init__(self):
            self.n = 0

        def chat(self, messages, tools=None, on_token=None, think=False,
                 on_thinking=None, **kw):
            self.n += 1
            if self.n == 1:
                from flux.llm.ollama_client import ToolCall
                return LLMResponse(tool_calls=[ToolCall("__probe_search", {})])
            return LLMResponse(content="*-готово-*")

    client = FakeClient()
    a = Agent(client=client)
    a.ctx.search_shown = 999                 # «наследие» прошлых запросов
    a.run("первый запрос")
    assert a.ctx.search_shown == 250, "счётчик обязан обнуляться в начале запроса"
    client.n = 0                             # второй запрос — снова инструмент
    a.run("второй запрос")
    assert a.ctx.search_shown == 250, (
        "второй запрос начал счётчик ЗАНОВО, а не продолжил с 250")


def test_web_search_limit_is_per_request_not_forever(monkeypatch):
    from flux.tools import web as webtools

    class Ctx:
        search_shown = 0

    monkeypatch.setattr(webtools, "search",
                        lambda q, n=None: ([{"title": "t", "url": "u",
                                             "snippet": "s"}] * 5, "searxng"))
    ctx = Ctx()
    for i in range(40):                      # 40 × 5 = 200 < cap(250)
        assert webtools.t_web_search(ctx=ctx, query="q",
                                     max_results=5).ok, f"итерация {i}"
    assert ctx.search_shown == 200
    # внутри запроса лимит всё-таки действует (защита от зацикливания модели)
    ctx.search_shown = 250
    blocked = webtools.t_web_search(ctx=ctx, query="q", max_results=5)
    assert blocked.ok is False and "лимит" in blocked.text
    # НОВЫЙ запрос: Agent.run() обнуляет счётчик — поиск снова работает.
    # ДО ФИКСА он оставался 250 навсегда, и web_search умирал до перезапуска.
    ctx.search_shown = 0
    assert webtools.t_web_search(ctx=ctx, query="q", max_results=5).ok


# ══════════════════════════════════════════════════════════════════════════
# БАГ №4: _run_agent без try/finally -> state=THINKING навсегда -> микрофон глох
# ══════════════════════════════════════════════════════════════════════════
def test_run_agent_returns_to_idle_even_if_agent_crashes(monkeypatch):
    from flux import main as M

    app = M.FluxApp.__new__(M.FluxApp)
    app.state_lock = threading.Lock()
    app.state = M.IDLE
    app.ui = type("U", (), {"broadcast": lambda *a, **k: None})()
    app.conv_id = None
    app._last_tool_log = []
    app.last_answer = ""
    app._last_spoken_text = ""
    said = []
    app.say = lambda text: said.append(text)

    class Boom:
        def run(self, *a, **k):
            raise RuntimeError("модель отвалилась")
    app.agent = Boom()

    app._process_command.__wrapped__ if False else None
    # вызываем сам worker (в обход нити), предварительно поставив THINKING
    with app.state_lock:
        app.state = M.THINKING
    app._run_agent("флюкс сделай что-нибудь")
    assert app.state == M.IDLE, "после сбоя Флюкс ОБЯЗАН вернуться в IDLE"
    assert said, "пользователю нужно сказать, что случился сбой"


def test_consume_chunk_listens_after_agent_crash(monkeypatch):
    """Следствие того же бага: при THINKING микрофон не слушается вовсе."""
    from flux import main as M
    src = Path(M.__file__).read_text(encoding="utf-8")
    assert "if self.state == THINKING:\n                    self.state = IDLE" in src \
        or "finally:" in src


# ══════════════════════════════════════════════════════════════════════════
# БАГ №5: голосовой путь не передавал think/web — по голосу Флюкс не думал
# ══════════════════════════════════════════════════════════════════════════
def test_voice_command_passes_think_and_web(monkeypatch):
    from flux import main as M

    app = M.FluxApp.__new__(M.FluxApp)
    app.state_lock = threading.Lock()
    app.state = M.IDLE
    app.ui = type("U", (), {"broadcast": lambda *a, **k: None})()
    app.conv_id = None
    app._last_tool_log = []
    app.last_answer = ""
    app._last_spoken_text = ""
    app.say = lambda text: None
    app._tts_cv = threading.Condition()
    app.tts_queue = []

    seen: dict = {}

    class Spy:
        def run(self, text, **kw):
            seen.update(kw)
            from flux.llm.agent import AgentResult
            return AgentResult(text="*-ок-*")
    app.agent = Spy()

    cfg.update({"agent": {"think_by_default": True, "web_by_default": True}},
               save=False)
    app._run_agent("флюкс найди погоду")
    assert seen.get("think") is True, "голосовая команда обязана думать"
    assert seen.get("web") is True, "голосовая команда обязана искать в интернете"
    assert seen.get("on_thinking") is not None, "токены рассуждения идут в консоль"


def test_voice_modes_follow_config():
    from flux import main as M
    app = M.FluxApp.__new__(M.FluxApp)
    cfg.update({"agent": {"think_by_default": False, "web_by_default": True}},
               save=False)
    assert app._voice_modes() == (False, True)


# ══════════════════════════════════════════════════════════════════════════
# БАГ №7: автозагрузка писала в реестр несуществующий Flux.exe
# ══════════════════════════════════════════════════════════════════════════
def test_autostart_command_points_to_real_entrypoint():
    from flux import autostart
    cmd = autostart.autostart_command()
    assert "flux.main" in cmd and "--autostart" in cmd
    assert "Flux.exe" not in cmd, "инсталлер не создаёт Flux.exe"


def test_main_delegates_autostart_to_single_module():
    src = _code_only(Path(__file__).resolve().parents[1] / "app" / "flux"
                     / "main.py")
    assert "Flux.exe" not in src, "main.py больше не выдумывает Flux.exe"
    assert "winreg" not in src, "main.py не должен сам лезть в реестр"
    assert "from .autostart import set_autostart" in src, \
        "автозагрузка обязана делегировать единственному модулю"
    assert src.count("winreg.SetValueEx") == 0, \
        "в main.py не должно остаться второй записи в реестр"


def test_installer_never_creates_flux_exe():
    ps = (Path(__file__).resolve().parents[1] / "installer" / "install.ps1"
          ).read_text(encoding="utf-8", errors="replace")
    assert "Flux.exe" not in ps, "проверка premise: инсталлер делает Flux*.bat"


# ══════════════════════════════════════════════════════════════════════════
# БАГ №8: ~15 RotatingFileHandler на один flux.log -> ротация падала на Windows
# ══════════════════════════════════════════════════════════════════════════
def test_only_one_file_handler_for_whole_project(monkeypatch, tmp_path):
    monkeypatch.setattr(logmod, "_LOG", None)
    monkeypatch.setattr(paths, "HOME", tmp_path)
    monkeypatch.setattr(paths, "LOG_DIR", tmp_path / "logs")
    cfg.update({"logging": {"file": "logs/flux.log", "console": False}},
               save=False)

    # корень "flux" уже создан на импортах модулей (и указывал на настоящий
    # HOME): снимаем с него хендлеры, чтобы _ensure_root() собрал их заново
    root = logging.getLogger("flux")
    for h in list(root.handlers):
        root.removeHandler(h)
        try:
            h.close()
        except Exception:
            pass
    for name in list(logging.root.manager.loggerDict):
        if name.startswith("flux."):
            logging.getLogger(name).handlers.clear()

    names = ["flux.main", "flux.tools", "flux.stt", "flux.agent", "flux.ui",
             "flux.tts", "flux.memory", "flux.audio.capture", "flux.menu"]
    loggers = [logmod.get_logger(n) for n in names]
    loggers.append(logmod.get_logger("flux"))

    seen: dict[int, logging.Handler] = {}
    for lg in loggers:
        cur = lg
        while cur is not None:
            for h in cur.handlers:
                if isinstance(h, logging.handlers.RotatingFileHandler):
                    seen[id(h)] = h
            cur = cur.parent if cur.propagate else None
    assert len(seen) == 1, (
        f"на один файл {len(seen)} ротаторов — на Windows ротация падает "
        f"с WinError 32 (файл занят другим процессом)")
    # все ДОЧЕРНИЕ логгеры пишут в корень, а не заводят свой ротатор
    for lg in loggers:
        if lg.name == "flux":
            continue                      # корень владеет хендлером легально
        assert not [h for h in lg.handlers
                    if isinstance(h, logging.handlers.RotatingFileHandler)], \
            f"{lg.name} завёл собственный ротатор"
        assert lg.propagate is True, f"{lg.name} не пишет в корень"

    for lg, name in zip(loggers, names + ["flux"]):
        lg.info("проверка %s", name)
    text = (tmp_path / "logs" / "flux.log").read_text(encoding="utf-8")
    for name in names:
        assert f"проверка {name}" in text, f"запись {name} не дошла до файла"
    monkeypatch.setattr(logmod, "_LOG", None)


def test_child_loggers_have_no_own_handlers(monkeypatch, tmp_path):
    monkeypatch.setattr(logmod, "_LOG", None)
    monkeypatch.setattr(paths, "HOME", tmp_path)
    cfg.update({"logging": {"console": False}}, save=False)
    lg = logmod.get_logger("flux.whatever.deep")
    assert lg.handlers == [], "дочерний логгер пишет в корень через propagate"
    assert lg.propagate is True
    monkeypatch.setattr(logmod, "_LOG", None)


# ══════════════════════════════════════════════════════════════════════════
# БАГ №9/№10: DeepThink не работал на OpenAI-подключениях и ронял запрос
#             на моделях без reasoning (Ollama 400)
# ══════════════════════════════════════════════════════════════════════════
def test_openai_connection_receives_think_flag(monkeypatch):
    from flux.llm.ollama_client import OllamaClient

    seen: dict = {}

    def fake_post(url, json=None, headers=None, timeout=None, **kw):
        seen["url"] = url
        seen["messages"] = json.get("messages")
        return type("R", (), {"status_code": 200,
                              "raise_for_status": lambda s: None,
                              "json": lambda s: {"choices": [{"message": {
                                  "content": "привет",
                                  "reasoning": "думаю пошагово"}}],
                                  "model": "m"}})()
    monkeypatch.setattr("requests.post", fake_post)
    c = OllamaClient(endpoint="http://127.0.0.1:1", model="m")
    monkeypatch.setattr(c, "connections", lambda: [
        {"name": "x", "base_url": "http://openai.local/v1", "api_key": "k",
         "model": ""}])
    got: list = []
    resp = c._chat_openai(c.connections()[0], "m",
                          [{"role": "user", "content": "привет"}], None, None,
                          think=True, on_thinking=got.append)
    assert any("DeepThink" in str(m.get("content", ""))
               for m in seen["messages"]), "инструкция рассуждения не ушла"
    assert got == ["думаю пошагово"], "токены рассуждения не доехали до консоли"
    assert resp.thinking == "думаю пошагово"


def test_chat_passes_think_to_openai_connections(monkeypatch):
    """Раньше в вызове _chat_openai(...) аргументы think/on_thinking терялись."""
    src = (Path(__file__).resolve().parents[1] / "app" / "flux" / "llm"
           / "ollama_client.py").read_text(encoding="utf-8")
    import re
    m = re.search(r"resp = self\._chat_openai\(([^)]*)\)", src, re.S)
    assert m, "вызов _chat_openai не найден"
    args = m.group(1)
    assert "think=think" in args and "on_thinking=on_thinking" in args, args


def test_think_400_retries_without_think(monkeypatch):
    """Ollama отвечает 400 «model does not support thinking» — не роняем чат."""
    from flux.llm.ollama_client import OllamaClient

    calls: list = []

    class Resp:
        def __init__(self, code, body):
            self.status_code = code
            self.text = body
            self.ok = code == 200

        def raise_for_status(self):
            if self.status_code >= 400:
                raise RuntimeError(f"HTTP {self.status_code}")

        def json(self):
            return {"message": {"content": "ответ"}, "done": True}

        def close(self):
            pass

    def fake_post(url, json=None, headers=None, timeout=None, stream=None, **kw):
        calls.append(dict(json or {}))
        if (json or {}).get("think"):
            return Resp(400, '{"error":"model does not support thinking"}')
        return Resp(200, "")
    monkeypatch.setattr("requests.post", fake_post)

    c = OllamaClient(endpoint="http://127.0.0.1:1", model="m")
    c.timeout = 5
    resp = c.chat([{"role": "user", "content": "привет"}], stream=False,
                  think=True)
    assert resp.content == "ответ", "чат обязан выжить на модели без reasoning"
    assert len(calls) == 2 and "think" not in calls[1]
    assert c.think_unsupported is True


# ══════════════════════════════════════════════════════════════════════════
# БАГ №11: смена микрофона теряла sample_rate/block_ms
# ══════════════════════════════════════════════════════════════════════════
def test_config_change_keeps_sample_rate_on_new_capture(monkeypatch):
    src = (Path(__file__).resolve().parents[1] / "app" / "flux" / "main.py"
           ).read_text(encoding="utf-8")
    block = src.split("смена микрофона на", 1)[1][:1200]
    assert "sample_rate=" in block and "block_ms=" in block, (
        "новый MicCapture создавался без частоты: захват шёл на 16000, "
        "а конвейер считал по config.audio.sample_rate")


# ══════════════════════════════════════════════════════════════════════════
# БАГ №15: multipart strip(b"\r\n") откусывал байты звука
# ══════════════════════════════════════════════════════════════════════════
def test_parse_multipart_preserves_trailing_crlf_bytes_of_audio():
    from flux.whisper_server import parse_multipart

    # звук, который ЗАКАНЧИВАЕТСЯ на 0x0D 0x0A — старый strip() их съедал
    payload = b"RIFFxxxxWAVEfmt " + bytes(range(16)) + b"\x0d\x0a\x0d\x0a"
    body = (b"--B\r\n"
            b'Content-Disposition: form-data; name="file"; filename="a.wav"\r\n'
            b"Content-Type: audio/wav\r\n\r\n"
            + payload +
            b"\r\n--B\r\n"
            b'Content-Disposition: form-data; name="model"\r\n\r\n'
            b"large-v3-turbo"
            b"\r\n--B--\r\n")
    audio, fields = parse_multipart(body, "multipart/form-data; boundary=B")
    assert audio == payload, "байты звука обязаны проходить насквозь неизменными"
    assert fields.get("model") == "large-v3-turbo"


def test_parse_multipart_handles_leading_crlf_body():
    from flux.whisper_server import parse_multipart
    body = (b"\r\n--B\r\n"
            b'Content-Disposition: form-data; name="file"; filename="a.wav"\r\n'
            b"\r\nDATA\r\n--B--\r\n")
    audio, _ = parse_multipart(body, "multipart/form-data; boundary=B")
    assert audio == b"DATA"


def test_parse_multipart_without_boundary_is_safe():
    from flux.whisper_server import parse_multipart
    assert parse_multipart(b"whatever", "application/json") == (None, {})
    assert parse_multipart(b"", "multipart/form-data; boundary=") == (None, {})


def test_whisper_server_roundtrip_wav_is_byte_exact():
    """WAV, чей последний отсчёт = 0x0A0D, проходит через сервер без потерь."""
    from flux.stt.base import Transcript
    from flux.whisper_server import WhisperServer, wav_to_pcm

    t = np.linspace(0, 0.2, 3200, endpoint=False)
    pcm = (np.sin(2 * np.pi * 440 * t) * 8000).astype(np.int16)
    pcm[-1] = 0x0A0D                      # «опасный» хвост
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
        w.writeframes(pcm.tobytes())
    raw = buf.getvalue()

    srv = WhisperServer(transcribe=lambda a, sr: Transcript(text="флюкс",
                                                            engine="fake"))
    out = srv.handle_audio(raw, {})
    assert out["text"] == "флюкс"
    arr, sr = wav_to_pcm(raw)
    assert sr == 16000 and arr.size == pcm.size


# ══════════════════════════════════════════════════════════════════════════
# БАГ №16: interrupt() не прерывал цикл записи — Esc/barge-in срабатывали поздно
# ══════════════════════════════════════════════════════════════════════════
def test_player_interrupt_breaks_write_loop():
    from flux.audio import player as P

    written: list = []

    class FakeStream:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def write(self, data):
            written.append(len(data))
            time.sleep(0.01)

        def abort(self):
            pass

        def stop(self):
            pass

    class FakeSd:
        OutputStream = staticmethod(lambda **kw: FakeStream())

    monkey_sd = P.sd
    P.sd = FakeSd
    try:
        p = P.Player(volume=1.0)
        p._interrupted = False
        data = np.ones(16000 * 5, dtype=np.float32)   # 5 секунд
        th = threading.Thread(target=p._play_pcm, args=(data, 16000))
        th.start()
        time.sleep(0.08)
        p.interrupt()
        th.join(timeout=3)
        assert not th.is_alive(), "цикл записи обязан прерваться по interrupt()"
        assert len(written) < 20, f"записано {len(written)} кусков — прерывания нет"
    finally:
        P.sd = monkey_sd


def test_player_interrupt_sets_flag_and_clears_queue():
    from flux.audio.player import Player
    p = Player()
    p.enqueue_pcm(np.zeros(100, dtype=np.float32), 16000)
    p.interrupt()
    assert p.queue_size() == 0
    assert p._interrupted is True


# ══════════════════════════════════════════════════════════════════════════
# БАГ №17: status() показывал модель по алфавиту, а не фактическую
# ══════════════════════════════════════════════════════════════════════════
def test_status_reports_the_actually_loaded_model(monkeypatch):
    from flux.stt import local as L
    monkeypatch.setattr(L, "_models", {"base|cpu|int8": object(),
                                        "large-v3-turbo|cuda|float16": object()})
    monkeypatch.setattr(L, "_last_load", {"model": "large-v3-turbo",
                                          "device": "cuda",
                                          "compute": "float16"})
    st = L.status()
    assert st["effective_model"] == "large-v3-turbo", (
        "sorted(loaded)[0] дал бы 'base' — не ту модель, на которой работаем")


# ══════════════════════════════════════════════════════════════════════════
# БАГ №18: iter_stream был «стримингом», который сначала ждал весь ответ
# ══════════════════════════════════════════════════════════════════════════
def test_iter_stream_yields_tokens_before_chat_finishes():
    from flux.llm.ollama_client import OllamaClient, iter_stream

    class SlowClient(OllamaClient):
        def chat(self, messages, tools=None, on_token=None, **kw):
            for piece in ("раз ", "два ", "три "):
                if on_token:
                    on_token(piece)
                time.sleep(0.05)
            from flux.llm.ollama_client import LLMResponse
            return LLMResponse(content="раз два три ")

    got: list = []
    t0 = time.time()
    for tok in iter_stream(SlowClient(endpoint="http://127.0.0.1:1"), []):
        got.append((tok, round(time.time() - t0, 3)))
    assert [g[0] for g in got] == ["раз ", "два ", "три "]
    # первый токен обязан прийти РАНЬШЕ, чем закончится вся генерация
    assert got[0][1] < got[-1][1], "токены отдаются пачкой в конце — это не стрим"


# ══════════════════════════════════════════════════════════════════════════
# БАГ №19: ollama-whisper считался доступным, хотя точно не умеет транскрипцию
# ══════════════════════════════════════════════════════════════════════════
def test_ollama_asr_unavailable_when_all_bases_bad():
    from flux.stt.ollama_asr import OllamaWhisperSTT
    s = OllamaWhisperSTT()
    s._bad_bases = {b: time.time() for b in s.bases()}
    assert s.all_bases_bad() is True
    assert s.available() is False, "не дёргаем заведомо мёртвый эндпоинт"
    s._bad_bases = {b: time.time() - 999 for b in s.bases()}
    assert s.all_bases_bad() is False, "метка протухла — пробуем снова"


# ══════════════════════════════════════════════════════════════════════════
# Безопасность: copy_file/move_file обходили denied_path_parts
# ══════════════════════════════════════════════════════════════════════════
def test_copy_and_move_respect_denied_paths(tmp_path):
    from flux.tools import registry as reg
    src = tmp_path / "a.txt"
    src.write_text("x", encoding="utf-8")
    cfg.update({"security": {"denied_path_parts": ["windows/system32/config"]}},
               save=False)
    denied = str(tmp_path / "windows" / "system32" / "config" / "sam")
    r1 = reg.dispatch("copy_file", {"src": str(src), "dst": denied})
    assert r1.ok is False and "запрещён" in r1.text
    r2 = reg.dispatch("move_file", {"src": denied, "dst": str(tmp_path / "b")})
    assert r2.ok is False and "запрещён" in r2.text
    # обычное копирование при этом работает
    ok = reg.dispatch("copy_file", {"src": str(src),
                                    "dst": str(tmp_path / "b.txt")})
    assert ok.ok is True


# ══════════════════════════════════════════════════════════════════════════
# Меню: cfg.get("a.b") мимо вложенного dict (меню всегда показывало дефолты)
# ══════════════════════════════════════════════════════════════════════════
def test_menu_loads_saved_settings_headless(monkeypatch, tmp_path):
    """СОБРАННОЕ меню обязано показать СОХРАНЁННЫЕ значения, а не дефолты."""
    harness = Path(__file__).resolve().parent / "_harness"
    sys.path.insert(0, str(harness))
    try:
        import faketk
    except Exception as e:                      # pragma: no cover
        pytest.skip(f"нет harness: {e}")
    tk, ttk, mb = faketk.install()

    from flux import menu_gui

    cfg.update({
        "wake": {"words": ["флюкс", "jarvis"], "sensitivity": 2},
        "tts": {"edge": {"voice": "ru-RU-SvetlanaNeural", "rate": "-25%",
                         "pitch": "+7Hz"}, "volume": 0.8},
        "agent": {"think_by_default": True, "web_by_default": True},
        "stream": {"word_idle_sec": 2.5},
        "llm": {"model": "qwen3:14b"},
        "stt": {"local": {"model": "small"}},
        "whisper_server": {"port": 8899},
        "audio": {"barge_in": True},
    }, save=False)

    app = menu_gui.MenuApp()
    assert app.wake.get() == "флюкс, jarvis"
    assert app.rate.get() == -25.0
    assert app.pitch.get() == 7.0
    assert app.volume.get() == 80.0
    assert app.voice.get() == "ru-RU-SvetlanaNeural"
    assert app.model.get() == "qwen3:14b"
    assert app.stt_model.get() == "small"
    assert app.idle.get() == "2.5"
    assert app.wsrv_port.get() == "8899"
    assert app.think.get() is True and app.web.get() is True
    assert app.barge.get() is True
    assert app.sens.get() == "2"


def test_menu_save_writes_config_and_applies_to_running(monkeypatch, tmp_path):
    harness = Path(__file__).resolve().parent / "_harness"
    sys.path.insert(0, str(harness))
    import faketk
    faketk.install()
    from flux import menu_gui

    posted: list = []
    monkeypatch.setattr(menu_gui, "_http_json",
                        lambda path, body=None, timeout=2.0:
                        (posted.append((path, body)),
                         {"ok": True} if body is not None else None)[1])
    app = menu_gui.MenuApp()
    app.wake.delete(0, "end"); app.wake.insert(0, "джарвис")
    app.think.set(True); app.rate.set(30); app.volume.set(55)
    app.save_settings()
    # применение к живому Флюксу теперь асинхронное: ждём именно /api/config
    # (posted непустой сразу из-за стартовых опросов /api/state)
    import time as _t
    deadline = _t.time() + 5
    while _t.time() < deadline and not any(p == "/api/config" for p, _ in posted):
        _t.sleep(0.03)
        app.root.flush_after()

    raw = json.loads(paths.CONFIG_FILE.read_text(encoding="utf-8"))
    assert raw["wake"]["words"] == ["джарвис"]
    assert raw["agent"]["think_by_default"] is True
    assert raw["tts"]["edge"]["rate"] == "+30%"
    assert raw["tts"]["volume"] == 0.55
    # скорость доезжает и до офлайн-SAPI5
    assert raw["tts"]["sapi5"]["rate"] == 6 and raw["tts"]["sapi5"]["volume"] == 55
    # живой Флюкс получил те же настройки без перезапуска
    assert any(p == "/api/config" for p, _ in posted), posted


def test_menu_is_scrollable():
    harness = Path(__file__).resolve().parent / "_harness"
    sys.path.insert(0, str(harness))
    import faketk
    faketk.install()
    from flux import menu_gui
    app = menu_gui.MenuApp()
    assert hasattr(app, "scroll") and app.scroll.canvas is not None
    canvases = faketk.REGISTRY.get("canvas", [])
    assert canvases, "меню обязано жить в прокручиваемом Canvas"
    scrollbars = faketk.REGISTRY.get("scrollbar", [])
    assert scrollbars, "нужен вертикальный скроллбар"


# ══════════════════════════════════════════════════════════════════════
# Браузер-микрофон как источник речи (опция вместо локального whisper)
# ══════════════════════════════════════════════════════════════════════
def test_browser_source_is_off_by_default_and_configurable():
    assert cfg.get("stt.browser_source") is False
    cfg.update({"stt": {"browser_source": True}}, save=False)
    assert cfg.get("stt.browser_source") is True


def test_browser_source_pauses_local_capture():
    """Два живых источника задвоили бы каждую фразу — локальный ставится на паузу."""

    from flux import main as M

    app = M.FluxApp.__new__(M.FluxApp)
    app.ui = type("U", (), {"broadcast": lambda *a, **k: None})()
    app._cursor_ts = 0.0

    class Cap:
        def __init__(self):
            self.paused = False
            self.cleared = 0

        def pause(self):
            self.paused = True

        def resume(self):
            self.paused = False

        def clear_ring(self):
            self.cleared += 1

    cap = Cap()
    app.capture = cap

    cfg.update({"stt": {"browser_source": True}}, save=False)
    app._apply_browser_source()
    assert cap.paused is True and cap.cleared == 1

    cfg.update({"stt": {"browser_source": False}}, save=False)
    app._apply_browser_source()
    assert cap.paused is False, "выключили браузер — локальный микрофон ожил"


def test_consume_chunk_ignores_local_ring_in_browser_mode():
    src = _code_only(Path(__file__).resolve().parents[1] / "app" / "flux"
                     / "main.py")
    fn = src.split("def _consume_chunk", 1)[1].split("def on_external_words", 1)[0]
    assert "browser_source_on()" in fn, \
        "в браузер-режиме локальное кольцо не должно кормить whisper"


def test_console_browser_mic_sends_straight_to_chat():
    """Браузер-микрофон отдаёт распознанное ТОЧНО как кнопка 🎤: в sendChat(),
    то есть сразу в /api/chat — без слова «флюкс» и без 5 секунд тишины.
    Так просил пользователь: «именно так передавать с микро к флюксу».
    """
    html = (Path(__file__).resolve().parents[1] / "app" / "flux" / "ui"
            / "static" / "index.html").read_text(encoding="utf-8")
    assert 'id="pillBrowserMic"' in html
    js = html.split("<script>", 1)[1].rsplit("</script>", 1)[0]
    blk = js.split("var bmRecog = null", 1)[1].split("/* ---- пилюли режимов", 1)[0]
    # прямой путь в чат, а не в словесный конвейер whisper
    assert "sendChat(txt)" in blk, "финал распознавания обязан идти в sendChat"
    assert "external_text" not in blk, \
        "больше не гоним браузер через словесный поток whisper"
    assert "continuous = true" in blk, "сессия живёт постоянно, не по клику"
    # анти-эхо: не слушать себя, пока Флюкс говорит/думает или браузер озвучивает
    assert 'curState === "speaking"' in blk
    assert "speechSynthesis.speaking" in blk
    # переключение источника дёргает конфиг, чтобы Флюкс поставил паузу локалу
    assert '"stt.browser_source"' in js
    # sendChat — тот же обработчик, что у кнопки отправки и Enter в чате
    assert "function sendChat(text)" in js
    assert 'api("/api/chat"' in js


def test_browser_mic_button_and_pill_share_one_path():
    """🎤 и пилюля «браузер» — ОДИН тумблер и один путь в sendChat.

    Пользователь проверил руками кнопку 🎤 («нажимаю микрофон и с него текст
    напрямую идёт в чат») и потребовал именно его. Поэтому 🎤 больше не
    разовая запись: это постоянный тумблер, общий с пилюлей, и каждый
    финальный кусок идёт в sendChat().
    """
    html = (Path(__file__).resolve().parents[1] / "app" / "flux" / "ui"
            / "static" / "index.html").read_text(encoding="utf-8")
    js = html.split("<script>", 1)[1].rsplit("</script>", 1)[0]
    mic_btn = js.split('bind("btnChatMic"', 1)[1].split("makePicker", 1)[0]
    assert "setBrowserMic(!bmOn)" in mic_btn, \
        "🎤 обязан включать тот же режим, что и пилюля"
    pill = js.split("var bmRecog = null", 1)[1].split("/* ---- пилюли режимов", 1)[0]
    assert "sendChat(txt)" in pill, "финал распознавания идёт в sendChat"
    assert 'bind("pillBrowserMic", function () { setBrowserMic(!bmOn); })' in js
    # выбор переживает перезагрузку страницы
    assert "localStorage" in js and "flux.browserMic" in js
    # непрерывная сессия: говорим сколько угодно, не переза кликая
    assert "continuous = true" in pill


def test_menu_status_is_live():
    src = (Path(__file__).resolve().parents[1] / "app" / "flux" / "menu_gui.py"
           ).read_text(encoding="utf-8")
    assert "_poll_status" in src and "after(3000" in src
    assert '"/api/state"' in src, "живой статус берётся из работающего Флюкса"


# ══════════════════════════════════════════════════════════════════════
# БАГ v1.5.1: шапка консоли вечно показывала «подключение…»
# ══════════════════════════════════════════════════════════════════════
def test_sse_pushes_state_immediately_on_connect(tmp_path):
    """Живой сервер: первый же SSE-кадр обязан нести состояние.

    Раньше бейдж обновлялся только событиями "state", а при старте Флюкс не
    шлёт ни одного (состояние ставится в __init__ без broadcast) — пока
    ассистент молчит, шапка вечно сидела на «подключение…».
    """
    import socket
    import threading

    from flux import config as C
    from flux import main as M
    from flux.ui.server import UiServer

    C.update({"ui": {"port": 8947}}, save=False)
    app = M.FluxApp.__new__(M.FluxApp)
    app.state = M.IDLE
    app.state_lock = threading.Lock()
    app.level = 0.07
    app.last_whisper_words = ""
    app._last_tool_log = []
    app.capture = None
    app.conv_id = None
    app.stream = type("S", (), {"partial": "", "silence_left": 2.5})()
    app.ui = type("U", (), {"broadcast": lambda *a, **k: None})()
    app.whisper_srv = type("W", (), {"info": lambda s: {}})()
    app.player = type("P", (), {"speaking": False,
                                "queue_size": lambda s: 0})()
    app._mic_cache = None
    app._mic_cache_at = 0.0
    app.tts = type("T", (), {"last_engine": ""})()
    app.hotkey = type("H", (), {"backend": "keyboard"})()
    app.store = type("ST", (), {"history": lambda s, c, l: []})()

    srv = UiServer(app)
    assert srv.start()
    try:
        s = socket.create_connection(("127.0.0.1", 8947), timeout=5)
        s.sendall(b"GET /api/events HTTP/1.1\r\nHost: x\r\n\r\n")
        s.settimeout(4)
        buf = b""
        try:
            while b"data:" not in buf:
                buf += s.recv(4096)
        except socket.timeout:
            pass
        s.close()
    finally:
        srv.stop()
    i = buf.find(b"data: ")
    assert i != -1, f"SSE не прислал ни одного кадра: {buf[:200]!r}"
    frame = json.loads(buf[i + 6:buf.find(b"\n", i)])
    assert frame.get("event") == "state", frame
    assert frame.get("state") == "idle" and frame.get("label"), frame


# ══════════════════════════════════════════════════════════════════════
# БАГ v1.5.2: меню ЛАГАЛО — сетевой/звуковой I/O шёл в главном потоке Tk
# ══════════════════════════════════════════════════════════════════════
def test_menu_does_no_blocking_io_on_the_tk_thread():
    """«Менюшка логает»: при открытии окна в главном цикле Tk выполнялись
    перечисление микрофонов (PortAudio), HTTP к Ollama (/api/tags), скан
    папки моделей и edge-tts list_voices (таймаут 15 c!), а каждые 3 c ещё и
    блокирующий HTTP /api/state. Окно замирало на секунды.

    Теперь вся эта работа уходит в фоновые нити (_async), а виджеты
    обновляются через root.after. Тест ловит любую попытку выполнить эти
    вызовы синхронно в главном потоке.
    """
    import threading
    import time

    harness = Path(__file__).resolve().parent / "_harness"
    sys.path.insert(0, str(harness))
    import faketk
    faketk.install()
    from flux import menu_gui

    main_tid = threading.get_ident()
    calls: list = []

    def spy(name, real):
        def wrapper(*a, **kw):
            calls.append((name, threading.get_ident() == main_tid))
            return real(*a, **kw)
        return wrapper

    monkey_targets = {
        "_mic_choices": menu_gui.MenuApp._mic_choices,
        "_llm_choices": menu_gui.MenuApp._llm_choices,
        "_voice_choices": menu_gui.MenuApp._voice_choices,
        "_stt_choices": menu_gui.MenuApp._stt_choices,
    }
    for name, real in monkey_targets.items():
        setattr(menu_gui.MenuApp, name, staticmethod(spy(name, real)))
    orig_http = menu_gui._http_json
    menu_gui._http_json = spy("_http_json", orig_http)
    try:
        app = menu_gui.MenuApp()          # само построение окна
        # синхронно в главном потоке не должно быть НИ ОДНОГО тяжёлого вызова
        blocking = [n for n, on_main in calls if on_main]
        assert not blocking, (
            f"тяжёлый I/O в главном потоке Tk (меню будет лагать): {blocking}")
        # но в фоне они обязаны выполниться и наполнить списки
        deadline = time.time() + 5
        while time.time() < deadline and not app._choices_loaded:
            time.sleep(0.05)
            app.root.flush_after()        # выполняем отложенные after()
        names = {n for n, _ in calls}
        assert {"_mic_choices", "_llm_choices", "_stt_choices"} <= names, names
        assert app._choices_loaded is True, "списки не наполнились из нити"
    finally:
        for name, real in monkey_targets.items():
            setattr(menu_gui.MenuApp, name, real)
        menu_gui._http_json = orig_http


def test_menu_status_poll_is_non_blocking():
    src = _code_only(Path(__file__).resolve().parents[1] / "app" / "flux"
                     / "menu_gui.py")
    fn = src.split("def _refresh_status", 1)[1].split("def _poll_status", 1)[0]
    assert "self._async(" in fn, "опрос статуса обязан идти через фоновую нить"
    assert "_http_json" not in fn.split("def worker", 1)[0], \
        "HTTP не должен вызываться синхронно в _refresh_status"
    paint = src.split("def _paint_status", 1)[1].split("def _refresh_status", 1)[0]
    assert "_http_json" not in paint and "is_running()" not in paint, \
        "отрисовка шапки не должна делать сетевых вызовов"


def test_menu_clicks_do_not_block_the_ui():
    """«Менюшка логает» на КЛИКАХ: stop() ждал процесс до 6 c (+taskkill 15 c),
    launch() делал HTTP, save_settings() — HTTP до 8 c, всё в главном потоке.
    Теперь каждое из этих действий уходит в нить через _async.
    """
    src = _code_only(Path(__file__).resolve().parents[1] / "app" / "flux"
                     / "menu_gui.py")
    stop = src.split("def stop(self)", 1)[1].split("def open_console", 1)[0]
    assert "def worker()" in stop and "self._async(worker, then)" in stop, \
        "остановка процесса обязана идти в нити"
    assert "pr.wait(timeout=6)" in stop and "taskkill" in stop
    launch = src.split("def launch(self)", 1)[1].split("def stop(self)", 1)[0]
    assert "self._async(worker, then)" in launch, "запуск — в нити"
    assert "is_running()" not in launch.split("def worker", 1)[0], \
        "HTTP-проверка не должна выполняться синхронно при клике"
    save = src.split("def save_settings(self)", 1)[1].split("def reload_form", 1)[0]
    assert "self._async(worker, then)" in save, "применение настроек — в нити"
    assert "_apply_to_running" in save.split("def worker", 1)[1], \
        "HTTP применения живому Флюксу — внутри worker, не в главном потоке"
    assert "_write_config(values)" in save.split("def worker", 1)[0], \
        "локальная запись конфига остаётся синхронной (она быстрая)"
