"""Мост «whisper положил .txt -> FLUX отправил ИИ целиком».

Пользователь: «ПО ФАКТУ WHISPER ОТПРАВЛЯЕТ .TXT — ОН СОХРАНЯЕТ В .TXT,
А ФЛЮКС НЕ ЗНАЕТ ЭТОГО». faster-whisper внутри FLUX ничего на диск не
пишет (библиотека), а вот whisper.cpp/Buzz/скрипты — пишут. Эти тесты
доказывают, что FLUX такой файл подхватит ровно ОДИН раз, отправит
сообщение целиком и уберёт файл в done/.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config
from flux.txt_bridge import TxtBridge, default_dir


@pytest.fixture()
def bridge_cfg():
    """Возвращаем настройки bridge. назад, чтобы не портить другие тесты."""
    saved = {k: config.get(f"bridge.{k}") for k in ("enabled", "txt_dir",
                                                    "poll_sec")}
    yield
    for k, v in saved.items():
        config.set_value(f"bridge.{k}", v, save=False)


def make_bridge(tmp_path, on_message, **kw):
    return TxtBridge(on_message, directory=str(tmp_path), **kw)


def test_default_dir_is_inbox():
    assert default_dir().endswith("inbox"), default_dir()


def test_scan_finds_only_txt_in_root(tmp_path):
    (tmp_path / "a.txt").write_text("флюкс включи свет", encoding="utf-8")
    (tmp_path / "b.wav").write_bytes(b"x")          # звук не трогаем
    (tmp_path / "done").mkdir()
    (tmp_path / "done" / "old.txt").write_text("x", encoding="utf-8")
    b = make_bridge(tmp_path, lambda t, s: True)
    assert [Path(p).name for p in b.scan_once()] == ["a.txt"], \
        "done/ не перечитываем, не-.txt не трогаем"


def test_scan_order_is_mtime(tmp_path):
    f1 = tmp_path / "1.txt"
    f2 = tmp_path / "2.txt"
    f1.write_text("первое", encoding="utf-8")
    old = time.time() - 100
    import os
    os.utime(f1, (old, old))
    f2.write_text("второе", encoding="utf-8")
    b = make_bridge(tmp_path, lambda t, s: True)
    names = [Path(p).name for p in b.scan_once()]
    assert names == ["1.txt", "2.txt"]


def test_process_file_sends_whole_and_archives(tmp_path):
    got = []
    (tmp_path / "msg.txt").write_text("флюкс включи свет на кухне",
                                      encoding="utf-8")
    b = make_bridge(tmp_path, lambda t, s: got.append((t, s)) or True)
    assert b.process_file(str(tmp_path / "msg.txt")) is True
    assert got == [("флюкс включи свет на кухне", "txt-bridge")]
    assert not (tmp_path / "msg.txt").exists(), "файл прочитан ровно один раз"
    done = tmp_path / "done" / "msg.txt"
    assert done.exists() and "включи" in done.read_text(encoding="utf-8")
    assert b.processed_count == 1 and b.last_file == "msg.txt"


def test_archive_does_not_overwrite(tmp_path):
    (tmp_path / "done").mkdir()
    (tmp_path / "done" / "msg.txt").write_text("старое", encoding="utf-8")
    (tmp_path / "msg.txt").write_text("новое", encoding="utf-8")
    b = make_bridge(tmp_path, lambda t, s: True)
    b.process_file(str(tmp_path / "msg.txt"))
    texts = sorted(p.read_text(encoding="utf-8")
                   for p in (tmp_path / "done").iterdir())
    assert texts == ["новое", "старое"]


def test_empty_file_not_sent_but_archived(tmp_path):
    got = []
    (tmp_path / "empty.txt").write_text("   \n ", encoding="utf-8")
    b = make_bridge(tmp_path, lambda t, s: got.append(t) or True)
    assert b.process_file(str(tmp_path / "empty.txt")) is False
    assert got == [] and b.processed_count == 0
    assert not (tmp_path / "empty.txt").exists()


def test_thread_picks_up_new_file(tmp_path):
    got = []
    b = make_bridge(tmp_path, lambda t, s: got.append(t) or True,
                    poll_sec=0.05)
    assert b.start() is True
    try:
        (tmp_path / "live.txt").write_text("флюкс который час",
                                           encoding="utf-8")
        for _ in range(100):
            if got:
                break
            time.sleep(0.05)
    finally:
        b.stop()
    assert got == ["флюкс который час"]
    assert not (tmp_path / "live.txt").exists()
    assert b.running is False


def test_disabled_bridge_does_not_start(tmp_path, bridge_cfg):
    config.set_value("bridge.enabled", False, save=False)
    b = make_bridge(tmp_path, lambda t, s: True)
    assert b.enabled is False and b.start() is False


def test_reload_picks_new_dir(tmp_path, bridge_cfg):
    b = make_bridge(tmp_path, lambda t, s: True)
    other = tmp_path / "other"
    config.set_value("bridge.txt_dir", str(other), save=False)
    b.reload()
    try:
        assert b.directory == str(other)
    finally:
        b.stop()
        config.set_value("bridge.txt_dir", "", save=False)


def test_info_shows_dir_and_counters(tmp_path):
    b = make_bridge(tmp_path, lambda t, s: True)
    i = b.info()
    assert i["dir"] == str(tmp_path) and i["processed"] == 0
    assert i["enabled"] is True
