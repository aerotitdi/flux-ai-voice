"""whisper-сервер FLUX: КАК внешний whisper «отправляет» текст Флюксу.

Whisper — библиотека и сам никуда ничего не шлёт. Поэтому:
  * внутри FLUX результат каждого вызова whisper забирает main._consume_chunk
    и складывает слова в копилку (voice/utterance.py);
  * для внешних whisper поднят локальный HTTP-эндпоинт OpenAI-вида
    POST /v1/audio/transcriptions (multipart file=звук) и POST /text
    (готовый текст) — всё это попадает в ТУ ЖЕ копилку сообщения.
"""
from __future__ import annotations

import io
import json
import sys
import urllib.request
import wave
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg  # noqa: E402
from flux.stt.base import Transcript  # noqa: E402
from flux.whisper_server import WhisperServer, parse_multipart  # noqa: E402


def _wav_bytes(seconds: float = 1.0, freq: float = 440.0) -> bytes:
    t = np.linspace(0, seconds, int(16000 * seconds), endpoint=False)
    pcm = (np.sin(2 * np.pi * freq * t) * 8000).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


class FakeSTT:
    def __init__(self, text="флюкс включи свет"):
        self.text = text
        self.calls = 0

    def transcribe(self, audio, sr=16000):
        self.calls += 1
        return Transcript(text=self.text, engine="fake", model="base",
                          duration=0.05,
                          words=[{"word": "флюкс", "start": 0.1, "end": 0.8},
                                 {"word": "включи", "start": 0.9, "end": 1.4},
                                 {"word": "свет", "start": 1.5, "end": 2.0}])


# ------------------------------------------------------------------ multipart
def test_parse_multipart_extracts_file_and_fields():
    body = (b'--BOUND\r\n'
            b'Content-Disposition: form-data; name="model"\r\n\r\nbase\r\n'
            b'--BOUND\r\n'
            b'Content-Disposition: form-data; name="language"\r\n\r\nru\r\n'
            b'--BOUND\r\n'
            b'Content-Disposition: form-data; name="file"; filename="a.wav"\r\n'
            b'Content-Type: audio/wav\r\n\r\n' + _wav_bytes(0.2) +
            b'\r\n--BOUND--\r\n')
    audio, fields = parse_multipart(body, "multipart/form-data; boundary=BOUND")
    assert audio is not None and audio[:4] == b"RIFF"
    assert fields == {"model": "base", "language": "ru"}


def test_parse_multipart_without_file():
    body = (b'--B\r\nContent-Disposition: form-data; name="x"\r\n\r\n1\r\n--B--\r\n')
    audio, fields = parse_multipart(body, "multipart/form-data; boundary=B")
    assert audio is None and fields == {"x": "1"}


def test_parse_multipart_bad_content_type():
    assert parse_multipart(b"whatever", "application/json") == (None, {})


# --------------------------------------------------------------------- HTTP
@pytest.fixture()
def server(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"whisper_server": {"enabled": True, "host": "127.0.0.1",
                                   "port": 8993}}, save=False)
    got = []
    stt = FakeSTT()
    srv = WhisperServer(transcribe=stt.transcribe,
                        on_words=got.append,
                        models_provider=lambda: ["large-v3-turbo", "base"])
    assert srv.start() is True
    yield srv, got, stt
    srv.stop()


def _post(url: str, data: bytes, ctype: str) -> dict:
    req = urllib.request.Request(url, data=data,
                                headers={"Content-Type": ctype}, method="POST")
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def _get(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


def test_health_reports_url(server):
    srv, _, _ = server
    d = _get("http://127.0.0.1:8993/health")
    assert d["ok"] is True and d["running"] is True
    assert d["url"].endswith("/v1/audio/transcriptions")
    assert "curl.exe" in d["howto"]


def test_models_endpoint(server):
    d = _get("http://127.0.0.1:8993/v1/models")
    assert [m["id"] for m in d["data"]] == ["large-v3-turbo", "base"]


def test_transcriptions_accepts_wav_and_returns_words(server):
    srv, got, stt = server
    body = (b'--B\r\nContent-Disposition: form-data; name="file"; '
            b'filename="s.wav"\r\nContent-Type: audio/wav\r\n\r\n'
            + _wav_bytes(0.3) + b'\r\n--B--\r\n')
    d = _post("http://127.0.0.1:8993/v1/audio/transcriptions", body,
              "multipart/form-data; boundary=B")
    assert d["text"] == "флюкс включи свет"
    assert d["engine"] == "fake" and d["model"] == "base"
    assert len(d["words"]) == 3 and d["words"][0]["word"] == "флюкс"
    assert got == ["флюкс включи свет"], "текст ушёл в поток слов FLUX"
    assert stt.calls == 1


def test_transcriptions_json_base64(server):
    import base64

    srv, got, _ = server
    payload = json.dumps({"audio": base64.b64encode(_wav_bytes(0.2)).decode(),
                          "model": "base"}).encode()
    d = _post("http://127.0.0.1:8993/v1/audio/transcriptions", payload,
              "application/json")
    assert d["text"] == "флюкс включи свет"
    assert len(got) == 1


def test_transcriptions_inject_off_does_not_touch_stream(server):
    srv, got, _ = server
    body = (b'--B\r\nContent-Disposition: form-data; name="inject"\r\n\r\n0\r\n'
            b'--B\r\nContent-Disposition: form-data; name="file"; '
            b'filename="s.wav"\r\nContent-Type: audio/wav\r\n\r\n'
            + _wav_bytes(0.2) + b'\r\n--B--\r\n')
    d = _post("http://127.0.0.1:8993/v1/audio/transcriptions", body,
              "multipart/form-data; boundary=B")
    assert d["text"] and got == []


def test_text_endpoint_injects_ready_transcript(server):
    srv, got, stt = server
    d = _post("http://127.0.0.1:8993/text",
              json.dumps({"text": "флюкс выключи музыку"}).encode(),
              "application/json")
    assert d == {"text": "флюкс выключи музыку", "injected": True}
    assert got == ["флюкс выключи музыку"]
    assert stt.calls == 0, "готовый текст не нужно распознавать заново"


def test_bad_request_is_reported(server):
    with pytest.raises(Exception):
        _post("http://127.0.0.1:8993/v1/audio/transcriptions", b"{}",
              "application/json")


def test_unknown_route_404(server):
    with pytest.raises(Exception):
        _get("http://127.0.0.1:8993/nope")


def test_disabled_by_config(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"whisper_server": {"enabled": False}}, save=False)
    srv = WhisperServer(transcribe=lambda a, s: Transcript(text=""))
    assert srv.start() is False
    assert srv.info()["running"] is False


def test_port_conflict_is_reported_not_fatal(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"whisper_server": {"enabled": True, "host": "127.0.0.1",
                                   "port": 8994}}, save=False)
    a = WhisperServer(transcribe=lambda audio, sr: Transcript(text=""))
    b = WhisperServer(transcribe=lambda audio, sr: Transcript(text=""))
    assert a.start() is True
    try:
        assert b.start() is False
        assert "8994" in b.last_error
    finally:
        a.stop()


def test_info_shape(server):
    srv, _, _ = server
    info = srv.info()
    for key in ("enabled", "running", "url", "host", "port", "requests",
                "last_text", "howto"):
        assert key in info

# ---------------------------------------------- ЖИВОЙ звук через HTTP-приёмник
@pytest.mark.network
def test_real_speech_through_http_endpoint():
    """Доказательство «whisper ОТПРАВЛЯЕТ Флюксу»: живая русская речь
    (edge-tts) уходит POST-ом на приёмник FLUX, локальный faster-whisper её
    распознаёт и возвращает текст вместе с метками времени слов."""
    import asyncio

    import edge_tts

    from flux.audio.player import decode_audio_file
    from flux.stt.local import LocalWhisperSTT

    mp3 = Path("/tmp") / "flux_ws_real.mp3" if Path("/tmp").is_dir() \
        else Path.cwd() / "flux_ws_real.mp3"
    try:
        asyncio.run(edge_tts.Communicate("Флюкс, включи свет на кухне.",
                                         "ru-RU-DmitryNeural").save(str(mp3)))
        data, sr = decode_audio_file(str(mp3), target_sr=16000)
    except Exception as e:
        pytest.skip(f"нужны интернет и декодер: {e}")
    pcm = (np.asarray(data) * 32767.0).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes(pcm.tobytes())

    got = []
    stt = LocalWhisperSTT(size="base")
    cfg.update({"whisper_server": {"enabled": True, "host": "127.0.0.1",
                                   "port": 8996}}, save=False)
    srv = WhisperServer(transcribe=stt.transcribe_audio, on_words=got.append)
    assert srv.start()
    try:
        body = (b'--REAL\r\nContent-Disposition: form-data; name="file"; '
                b'filename="speech.wav"\r\nContent-Type: audio/wav\r\n\r\n'
                + buf.getvalue() + b'\r\n--REAL--\r\n')
        d = _post("http://127.0.0.1:8996/v1/audio/transcriptions", body,
                  "multipart/form-data; boundary=REAL")
    finally:
        srv.stop()
        cfg.update({"whisper_server": {"port": 8793}}, save=False)
    text = (d.get("text") or "").lower()
    assert "включи" in text and "свет" in text, d
    assert len(d.get("words") or []) >= 3, d
    assert got and "включи" in got[0].lower()
    assert d.get("engine") == "local"
