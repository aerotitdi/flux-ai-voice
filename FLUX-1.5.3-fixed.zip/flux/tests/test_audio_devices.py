"""Устройства записи: схлопывание дублей MME/DirectSound/WASAPI и инвентаризация.

Повод: самотест на машине пользователя показал «микрофоны — 14 шт.», хотя
физический микрофон один (MCHOSE V9 PRO). PortAudio перечисляет каждое
устройство по каждому звуковому API, плюс Windows добавляет виртуальные
записывающие устройства.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.audio.devices import (DeviceInfo, dedupe_devices, inventory,
                                is_loopback_name, sort_key)


def _dev(index, name, host, default=False, loop=False, ch=1):
    return DeviceInfo(index=index, name=name, channels=ch, host_api=host,
                      is_default_input=default, is_loopback=loop)


# Реалистичная картина Windows: один микрофон x3 API + Bluetooth Hands-Free
# (два профиля) + веб-камера + виртуальные устройства чата/стрима.
WIN_SET = [
    _dev(1, "Mic (MCHOSE V9 PRO)", "MME"),
    _dev(5, "Mic (MCHOSE V9 PRO)", "DirectSound"),
    _dev(12, "Mic (MCHOSE V9 PRO)", "Windows WASAPI", default=True),
    _dev(2, "Headset (WH-1000XM4 Hands-Free)", "MME"),
    _dev(6, "Headset (WH-1000XM4 Hands-Free)", "DirectSound"),
    _dev(13, "Headset (WH-1000XM4 Hands-Free)", "Windows WASAPI"),
    _dev(3, "Integrated Webcam", "MME"),
    _dev(7, "Integrated Webcam", "Windows WASAPI"),
    _dev(8, "Microphone (NVIDIA Broadcast)", "Windows WASAPI"),
    _dev(9, "CABLE Output (VB-Audio Cable)", "MME"),
    _dev(14, "Стерео микшер (Realtek)", "MME", loop=True),
    _dev(15, "Speakers (Realtek) [Loopback]", "Windows WASAPI", loop=True),
]


def test_dedupe_collapses_same_device_across_apis():
    real = [d for d in WIN_SET if not d.is_loopback]
    out = dedupe_devices(real)
    names = sorted({d.name for d in out})
    assert len(out) == len(names), "одно физическое устройство = одна запись"
    assert len(out) == 5  # было 10 записей


def test_dedupe_keeps_default_and_best_api():
    out = dedupe_devices([d for d in WIN_SET if not d.is_loopback])
    mchose = [d for d in out if "MCHOSE" in d.name][0]
    assert mchose.index == 12, "оставляем WASAPI-запись, она же по умолчанию"
    assert mchose.is_default_input
    headset = [d for d in out if "WH-1000XM4" in d.name][0]
    assert headset.host_api == "Windows WASAPI"


def test_dedupe_does_not_merge_loopback_with_mic():
    """Петля «Speakers (Realtek) [Loopback]» не должна склеиться с микрофоном."""
    out = dedupe_devices(WIN_SET)
    loops = [d for d in out if d.is_loopback]
    assert len(loops) == 2
    assert all(is_loopback_name(d.name) or "[Loopback]" in d.name for d in loops)


def test_dedupe_is_idempotent():
    once = dedupe_devices(WIN_SET)
    assert dedupe_devices(once) == once


def test_sort_key_puts_loopback_last_and_default_first():
    out = dedupe_devices(WIN_SET)
    assert out[0].is_default_input
    assert [d.is_loopback for d in out] == sorted(d.is_loopback for d in out)
    assert all(sort_key(a) <= sort_key(b) for a, b in zip(out, out[1:]))


def test_inventory_groups_indices_per_device():
    text = inventory(WIN_SET)
    line = [l for l in text.splitlines() if "MCHOSE" in l][0]
    assert "MME(1)" in line and "DirectSound(5)" in line and "WASAPI(12)" in line
    assert "*" in line, "помечено устройство по умолчанию"
    assert "[ПЕТЛЯ]" in text


def test_inventory_lists_every_device_once():
    text = inventory(WIN_SET)
    assert len([l for l in text.splitlines() if l.strip()]) == 7  # 5+2 петли


def test_loopback_names_detected():
    for n in ("Стерео микшер (Realtek)", "Stereo Mix", "What U Hear",
              "Voicemeeter Output", "Primary Sound Capture Driver"):
        assert is_loopback_name(n), n
    for n in ("Mic (MCHOSE V9 PRO)", "Микрофон (Realtek)"):
        assert not is_loopback_name(n), n
