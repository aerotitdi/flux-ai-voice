"""Защиты от циклов инструментов и корректная история (правки по live-логам:
remember x8, web_search x8, «превышено число кругов»)."""
import base64
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg
from flux.llm.agent import Agent, _b64_image
from flux.llm.ollama_client import OllamaClient
from flux.memory.store import MemoryStore
from flux.tools import registry as reg
from flux.tools.registry import ToolResult, tool

REQUESTS = []


class LoopHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    mode = "repeat"          # repeat | vision

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        REQUESTS.append(body)
        msgs = body.get("messages", [])
        tool_msgs = [m for m in msgs if m.get("role") == "tool"]
        lines = []
        if self.mode == "repeat":
            if len(tool_msgs) >= 4:
                # сервер «одумался»: финальный ответ
                final = "*-Окей, хватит вызовов.*-"
                lines.append(json.dumps({"message": {"role": "assistant",
                                                     "content": final},
                                         "done": True}))
            else:
                lines.append(json.dumps({
                    "message": {"role": "assistant", "content": "",
                                "tool_calls": [{"function": {
                                    "name": "loop_remember",
                                    "arguments": {"fact": "факт один"}}}]},
                    "done": True}))
        else:  # vision
            if any(m.get("role") == "user" and m.get("images") for m in msgs):
                lines.append(json.dumps({"message": {"role": "assistant",
                                                     "content": "*-Вижу экран-*"},
                                         "done": True}))
            else:
                lines.append(json.dumps({
                    "message": {"role": "assistant", "content": "",
                                "tool_calls": [{"function": {
                                    "name": "fake_shot", "arguments": {}}}]},
                    "done": True}))
        payload = ("\n".join(lines) + "\n").encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *a):
        pass


CALLS = {"loop_remember": 0, "fake_shot": 0}


@tool("loop_remember", "тестовый remember",
      {"type": "object", "properties": {"fact": {"type": "string"}},
       "required": ["fact"]})
def _loop_remember(ctx=None, fact: str = "") -> ToolResult:
    CALLS["loop_remember"] += 1
    return ToolResult(True, f"запомнил {fact}")


@tool("fake_shot", "тестовый скриншот с картинкой")
def _fake_shot(ctx=None) -> ToolResult:
    CALLS["fake_shot"] += 1
    png = (Path(__file__).parent / "dot.png")
    if not png.exists():
        from PIL import Image
        Image.new("RGB", (8, 8), (10, 200, 10)).save(png)
    res = ToolResult(True, "скриншот готов")
    res.attach_images = [str(png)]
    return res


@pytest.fixture()
def server():
    REQUESTS.clear()
    srv = ThreadingHTTPServer(("127.0.0.1", 0), LoopHandler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield srv
    srv.shutdown()


@pytest.fixture()
def agent(server, tmp_path, monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    base = f"http://127.0.0.1:{server.server_address[1]}"
    cfg.update({"llm": {"endpoint": base, "model": "m", "stream": True,
                        "max_tool_rounds": 6, "max_tool_calls": 12}}, save=False)
    store = MemoryStore(str(tmp_path / "loops.db"))
    a = Agent(client=OllamaClient(endpoint=base, model="m", timeout=10),
              store=store)
    yield a
    store.close()


def test_duplicate_tool_call_is_blocked(agent):
    LoopHandler.mode = "repeat"
    CALLS["loop_remember"] = 0
    res = agent.run("запомни факт", on_speak_chunk=lambda c: None)
    assert CALLS["loop_remember"] == 1, \
        "инструмент с теми же аргументами выполняется ровно один раз"
    assert res.text and "зациклился" in res.text, \
        "повторный круг прерывается с голосовым извинением"


def test_assistant_message_returns_tool_calls_to_model(agent):
    LoopHandler.mode = "repeat"
    agent.run("запомни факт", on_speak_chunk=lambda c: None)
    second = REQUESTS[1]
    assistants = [m for m in second["messages"] if m.get("role") == "assistant"]
    assert assistants and assistants[-1].get("tool_calls"), \
        "модель обязана видеть собственные tool_calls, иначе цикл"
    tools = [m for m in second["messages"] if m.get("role") == "tool"]
    assert tools and tools[-1].get("content"), "результат инструмента в истории"


def test_openai_converter_keeps_ids_and_images():
    from flux.llm.ollama_client import OllamaClient
    from flux.llm.ollama_client import ToolCall
    tc = ToolCall(name="remember", arguments={"fact": "x"}, id="call_7")
    msgs = [
        {"role": "assistant", "content": "", "tool_calls": [
            {"function": {"name": "remember", "arguments": {"fact": "x"}}}],
         "_openai_tool_calls": [tc]},
        {"role": "tool", "content": "ok", "name": "remember",
         "tool_call_id": "call_7"},
        {"role": "user", "content": "смотри", "images": ["QUJD"]},
    ]
    out = OllamaClient._openai_messages(msgs)
    assert out[0]["tool_calls"][0]["id"] == "call_7"
    assert out[0]["tool_calls"][0]["function"]["arguments"] == '{"fact": "x"}'
    assert out[1]["tool_call_id"] == "call_7"
    assert out[2]["content"][1]["image_url"]["url"].startswith("data:image/png;base64,")
    native = OllamaClient._native_messages(msgs)
    assert "_openai_tool_calls" not in native[0]
    assert "tool_call_id" not in native[1]
    assert "images" not in native[1]


def test_max_tool_calls_cap(agent, monkeypatch):
    LoopHandler.mode = "repeat"
    monkeypatch.setattr(cfg, "get",
                        lambda k, d=None: {"llm.max_tool_calls": 2,
                                           "llm.max_tool_rounds": 8}.get(k, d)
                        if k in ("llm.max_tool_calls", "llm.max_tool_rounds")
                        else cfg.__dict__.get("_orig_get", lambda *a, **k: d)(k, d))
    # проще: перезапустим агент с конфигом через update
    cfg.update({"llm": {"max_tool_calls": 2, "max_tool_rounds": 8}}, save=False)
    CALLS["loop_remember"] = 0
    res = agent.run("запомни факт", on_speak_chunk=lambda c: None)
    executed = [t for t in res.tool_log if t.ok]
    assert len(executed) <= 2
    assert res.text and "зациклился" in res.text, \
        "при остановке по лимиту пользователь получает голосовое извинение"


def test_vision_image_attached_as_user_message(agent):
    LoopHandler.mode = "vision"
    CALLS["fake_shot"] = 0
    res = agent.run("что на экране", on_speak_chunk=lambda c: None)
    assert CALLS["fake_shot"] == 1
    second = REQUESTS[1]
    img_msgs = [m for m in second["messages"]
                if m.get("role") == "user" and m.get("images")]
    assert img_msgs, "скриншот прикладывается к диалогу как user-сообщение"
    raw = base64.b64decode(img_msgs[0]["images"][0])
    assert raw[:8] == b"\x89PNG\r\n\x1a\n"
    assert "Вижу экран" in res.text


def test_b64_image_limits(tmp_path):
    big = tmp_path / "big.png"
    big.write_bytes(b"\x00" * (9_000_000))
    assert _b64_image(str(big)) is None
    assert _b64_image(str(tmp_path / "nope.png")) is None


def test_web_search_session_cap(monkeypatch):
    from flux.tools import web as webtools

    class Ctx:
        search_shown = 250

    monkeypatch.setattr(webtools, "search",
                        lambda q, n=None: ([{"title": "t", "url": "u",
                                             "snippet": "s"}], "searxng"))
    res = reg.dispatch("web_search", {"query": "погода"}, Ctx())
    assert res.ok is False and "250" in res.text


def test_web_search_per_call_clamp(monkeypatch):
    from flux.tools import web as webtools
    got = {}

    def fake_search(q, n=None):
        got["n"] = n
        return [{"title": "t", "url": "u", "snippet": "s"}], "searxng"

    monkeypatch.setattr(webtools, "search", fake_search)

    class Ctx:
        search_shown = 0

    reg.dispatch("web_search", {"query": "погода", "max_results": 999}, Ctx())
    assert got["n"] == 50, "за раз не больше 50 результатов"


def test_prompts_contain_discipline():
    from flux import prompts
    text = prompts.system_prompt()
    assert "НИКОГДА не повторяй" in text
    assert "look_at_screen" in text and "point_at_screen" in text
