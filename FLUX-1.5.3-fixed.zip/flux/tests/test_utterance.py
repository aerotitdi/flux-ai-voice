"""Сборка ЦЕЛОГО сообщения из слов whisper (voice/utterance.py).

Здесь же — доказательство на НАСТОЯЩЕМ звуке и НАСТОЯЩЕМ whisper:
фраза режется на куски, каждый кусок уходит в faster-whisper, слова с метками
времени копятся, и после молчания FLUX получает ОДНО целое сообщение.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

import numpy as np  # noqa: E402

from flux.stt.base import Transcript  # noqa: E402
from flux.voice.utterance import (Utterance, UtteranceAssembler, Word,  # noqa: E402
                                  clean_word_text, words_from_any)


def test_words_from_transcript_prefers_word_timestamps():
    tr = Transcript(text="привет мир", words=[Word("привет", 0.1, 0.5),
                                              Word("мир", 0.6, 0.9)],
                    segments=[{"start": 0.1, "end": 0.9, "text": "привет мир"}])
    got = words_from_any(tr=tr)
    assert [w.text for w in got] == ["привет", "мир"]
    assert got[1].end == 0.9


def test_words_from_segments_when_no_word_timestamps():
    tr = Transcript(text="привет мир",
                    segments=[{"start": 0.1, "end": 0.9, "text": "привет мир"}])
    got = words_from_any(tr=tr)
    assert len(got) == 1 and got[0].text == "привет мир"
    assert got[0].end == 0.9


def test_words_from_plain_text_without_marks():
    got = words_from_any(text="включи свет")
    assert len(got) == 1 and got[0].start == 0.0 and got[0].end == 0.0


def test_clean_word_text_removes_brackets():
    assert clean_word_text("флюкс (музыка) включи [аплодисменты] свет") == \
        "флюкс включи свет"


def test_assembler_needs_silence_after_last_word():
    asm = UtteranceAssembler(idle_sec=5.0)
    tr = Transcript(text="флюкс включи свет", engine="local", model="base",
                    duration=3.4, window_sec=3.4,
                    words=[Word("флюкс", 0.2, 0.9), Word("включи", 1.0, 1.6),
                           Word("свет", 1.7, 2.2)])
    assert asm.push(tr=tr, end_sec=3.4, sec=3.4) is None
    assert asm.last_word_end == pytest.approx(2.2)
    assert asm.idle_sec_now == pytest.approx(1.2)
    empty = Transcript(text="", engine="local", duration=2.0, window_sec=2.0)
    assert asm.push(tr=empty, end_sec=5.4, sec=2.0) is None
    utt = asm.push(tr=empty, end_sec=7.4, sec=2.0)     # 5.2 c молчания
    assert isinstance(utt, Utterance)
    assert utt.text == "флюкс включи свет"
    assert utt.silence_sec >= 5.0
    assert utt.word_count == 3
    assert utt.engine == "local" and utt.model == "base"
    assert asm.empty, "после отправки копилка пуста"


def test_assembler_counts_whisper_silence_pushes():
    asm = UtteranceAssembler(idle_sec=5.0)
    asm.push(text="привет", end_sec=3.0, sec=3.0)
    asm.push(text="", end_sec=6.0, sec=3.0)
    asm.push(text="", end_sec=9.0, sec=3.0)
    assert asm.pushes == 3
    assert asm.silent_pushes == 2, "whisper сам сказал: в двух кусках слов нет"


def test_assembler_drops_overlap_duplicates():
    asm = UtteranceAssembler(idle_sec=5.0)
    tr1 = Transcript(text="флюкс включи", duration=3.4, window_sec=3.4,
                     words=[Word("флюкс", 0.2, 0.9), Word("включи", 2.6, 3.2)])
    asm.push(tr=tr1, end_sec=3.4, sec=3.4)
    tr2 = Transcript(text="включи свет", duration=3.4, window_sec=3.4,
                     words=[Word("включи", 0.2, 0.8), Word("свет", 1.0, 1.5)])
    asm.push(tr=tr2, end_sec=6.8, sec=3.4)
    assert asm.partial == "флюкс включи свет"


def test_assembler_keeps_repeated_words_in_new_windows():
    """Одинаковые слова в РАЗНЫХ кусках — это не дубль, а речь."""
    asm = UtteranceAssembler(idle_sec=30.0)
    for i in range(4):
        asm.push(text="свет", end_sec=3.0 * (i + 1), sec=3.0)
    assert asm.partial.count("свет") == 4


def test_assembler_filters_whisper_hallucinations():
    asm = UtteranceAssembler(idle_sec=5.0)
    asm.push(text="(музыка)", end_sec=3.0, sec=3.0)
    asm.push(text="Субтитры сделал DimaTorzok", end_sec=6.0, sec=3.0)
    assert asm.empty


def test_assembler_max_sec_forces_long_message():
    asm = UtteranceAssembler(idle_sec=5.0, max_sec=10.0)
    utt = None
    for i in range(8):
        utt = asm.push(text="рассказываю историю", end_sec=2.0 * (i + 1),
                       sec=2.0) or utt
    assert utt is not None and utt.forced


# ------------------------------------------------------- НАСТОЯЩИЙ whisper
def _real_speech_wav(tmp_path: Path, text: str) -> Path:
    """Живая русская речь через edge-tts (нужен интернет)."""
    import asyncio

    import edge_tts

    out = tmp_path / "speech.mp3"

    async def run():
        await edge_tts.Communicate(text, "ru-RU-DmitryNeural").save(str(out))

    asyncio.run(run())
    return out


@pytest.mark.network
def test_real_whisper_gives_word_timestamps(tmp_path):
    from flux.audio.player import decode_audio_file
    from flux.stt.local import LocalWhisperSTT

    try:
        mp3 = _real_speech_wav(tmp_path, "Флюкс, включи свет на кухне.")
    except Exception as e:                            # нет интернета/edge-tts
        pytest.skip(f"edge-tts недоступен: {e}")
    data, sr = decode_audio_file(str(mp3), target_sr=16000)
    audio = (np.asarray(data) * 32767.0).astype(np.int16)
    tr = LocalWhisperSTT(size="base").transcribe_audio(audio, 16000)
    assert tr.words, "faster-whisper обязан вернуть слова с метками времени"
    assert tr.words[0]["start"] >= 0.0 and tr.words[-1]["end"] > 0.0
    assert tr.window_sec == pytest.approx(len(audio) / 16000.0, abs=0.01)
    assert "флюкс" in tr.text.lower() or "включи" in tr.text.lower()


@pytest.mark.network
def test_real_pipeline_delivers_one_whole_message(tmp_path):
    """ПОЛНАЯ цепочка на живом звуке: микрофон-кусочки -> whisper -> ОДНО
    целое сообщение после того, как whisper замолчал."""
    from flux.audio.player import decode_audio_file
    from flux.stt.local import LocalWhisperSTT
    from flux.voice.stream import WordStream
    from flux.wakeword import WakeDetector

    try:
        mp3 = _real_speech_wav(tmp_path, "Флюкс, включи свет на кухне.")
    except Exception as e:
        pytest.skip(f"edge-tts недоступен: {e}")
    data, sr = decode_audio_file(str(mp3), target_sr=16000)
    audio = (np.asarray(data) * 32767.0).astype(np.int16)
    tail = np.zeros(16000 * 7, dtype=np.int16)        # 7 c тишины после речи
    audio = np.concatenate([audio, tail])

    stt = LocalWhisperSTT(size="base")
    st = WordStream(WakeDetector(words=["флюкс"], sensitivity=1),
                    word_idle_sec=2.0, wake_idle_sec=1.2)
    sends = []
    chunk = 3.0
    step = int(16000 * chunk)
    pos = 0.0
    for i in range(0, len(audio), step):
        piece = audio[i:i + step]
        if piece.size < 1600:
            break
        pos += piece.size / 16000.0
        tr = stt.transcribe_audio(piece, 16000)
        for ev in st.feed(text=tr.text, tr=tr, end_sec=pos,
                          sec=piece.size / 16000.0):
            if ev.kind == "send":
                sends.append(ev)
    assert sends, "whisper замолчал — сообщение обязано уйти"
    assert len(sends) == 1, f"сообщение должно быть ОДНО, а не {len(sends)}"
    text = sends[0].text.lower()
    assert "включи" in text and "свет" in text, text
    assert sends[0].utterance.silence_sec >= 2.0
    assert sends[0].utterance.word_count >= 3
