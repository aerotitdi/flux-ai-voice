"""Консоль и меню: минимальность, целостность HTML/JS, отсутствие мёртвых id.

Класс бага, из-за которого консоль «не работала» целиком: JS обращается к
id, которых нет в разметке (или дублируются), и падает на рантайме. Поэтому
здесь: кросс-проверка id HTML <-> JS, один <script>, уникальность id,
синтаксис JS через node --check (если node есть) и минимум настроек.
"""
import re
import shutil
import subprocess
import sys
import collections
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

ROOT = Path(__file__).resolve().parents[1]
HTML_PATH = ROOT / "app" / "flux" / "ui" / "static" / "index.html"
HTML = HTML_PATH.read_text(encoding="utf-8")
JS = HTML.split("<script>", 1)[1].rsplit("</script>", 1)[0]
IDS = re.findall(r'id="([^"]+)"', HTML)


def test_single_script_and_unique_ids():
    assert HTML.count("<script>") == 1
    assert HTML.count("</script>") == 1
    dup = [k for k, v in collections.Counter(IDS).items() if v > 1]
    assert not dup, f"дубли id ломают JS: {dup}"


def test_every_id_used_by_js_exists_in_html():
    # ВАЖНО: ловим ОБА стиля кавычек. Прежняя регулярка искала только $('id'),
    # а консоль всюду пишет $("id") — то есть проверка была пустой и не
    # поймала бы ни одного мёртвого id.
    used = set(re.findall(r"""\$\(\s*['"]([A-Za-z0-9_-]+)['"]\s*\)""", JS))
    used |= set(re.findall(r"""(?:setTxt|setHtml|setCls|bind)\(\s*['"]([A-Za-z0-9_-]+)['"]""", JS))
    missing = sorted(u for u in used if u not in IDS)
    assert not missing, f"JS обращается к несуществующим id: {missing}"


# вызов функции: имя, перед которым НЕТ точки/кавычек (методы и строки не в счёт)
CALL_RE = re.compile(r"""(?<![\w$.'"])([A-Za-z_$][\w$]*)\s*\(""")


def _js_code_only(js: str) -> str:
    """JS без комментариев и строковых литералов.

    Без этого регулярка ловит «вызовы» внутри обычного текста — например
    подсказку «живой ответ Ollama /api/tags (если Ollama не отвечает)»,
    где ``tags (`` выглядит как вызов функции.
    """
    out = re.sub(r"/\*.*?\*/", " ", js, flags=re.S)          # /* ... */
    out = re.sub(r"(?m)(?<!:)//[^\n]*", " ", out)              # // ...
    out = re.sub(r'"(?:[^"\\\n]|\\.)*"', '""', out)        # "..."
    out = re.sub(r"'(?:[^'\\\n]|\\.)*'", "''", out)        # '...'
    return out

# Имена функций/констант, которые JS вызывает, но нигде не определяет.
_JS_BUILTINS = {
    "if", "for", "while", "switch", "catch", "function", "return", "typeof",
    "new", "else", "do", "try", "in", "of", "delete", "void", "instanceof",
    "parseInt", "parseFloat", "String", "Number", "Boolean", "Array", "Object",
    "JSON", "Math", "Date", "RegExp", "Error", "Map", "Set", "Promise",
    "fetch", "encodeURIComponent", "decodeURIComponent", "isNaN", "alert",
    "setTimeout", "setInterval", "clearTimeout", "clearInterval",
    "EventSource", "SpeechRecognition", "webkitSpeechRecognition",
    "SpeechSynthesisUtterance", "MediaRecorder", "Blob", "FileReader",
    "Audio", "AudioContext", "webkitAudioContext", "Uint8Array", "FormData",
    "Text", "console", "document", "window", "navigator", "localStorage",
}


def test_js_has_no_undefined_function_calls():
    """В JS консоли не должно быть вызовов неопределённых функций.

    РЕАЛЬНЫЙ БАГ, который этот тест теперь ловит: кнопка «💾 Сохранить»
    вызывала sttEngineValue() -> sttSel(), а функция sttSel() НЕ СУЩЕСТВОВАЛА.
    Клик ронял ReferenceError, и НАСТРОЙКИ НЕ СОХРАНЯЛИСЬ ВОВСЕ — при этом
    `node --check` (синтаксис) проходил, а кросс-проверка id ничего не
    находила, так что баг доехал до релиза.
    """
    code = _js_code_only(JS)
    defined = set(re.findall(r"function\s+([A-Za-z_$][\w$]*)\s*\(", code))
    defined |= set(re.findall(r"(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*function", code))
    defined |= set(re.findall(r"(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=", code))
    # локальные параметры функций и стрелочные/вложенные объявления
    for params in re.findall(r"function\s*[\w$]*\s*\(([^)]*)\)", code):
        defined |= {p.strip() for p in params.split(",") if p.strip()}
    called = set(re.findall(CALL_RE, code))
    undef = sorted(n for n in called - defined - _JS_BUILTINS
                   if not n[0].isupper())
    assert not undef, f"JS вызывает несуществующие функции: {undef}"


def test_state_badge_cannot_stay_on_connecting():
    """БАГ: бейдж шапки жил только на SSE-событиях "state", а при старте Флюкс
    не шлёт ни одного (состояние ставится в __init__ без broadcast) — пока
    ассистент молчит, шапка вечно показывала «подключение…».
    Теперь: (а) сервер шлёт снимок состояния сразу при подключении SSE,
    (б) опрос /api/state красит бейдж сам.
    """
    srv = (ROOT / "app" / "flux" / "ui" / "server.py").read_text(encoding="utf-8")
    assert '"event": "state"' in srv and "_STATE_LABEL" in srv, \
        "сервер обязан_push-ить состояние сразу после подключения SSE"
    # опрос /api/state обновляет бейдж (а не только уровень микрофона)
    poll = JS.split('fetch("/api/state")', 1)[1].split("}, 700);", 1)[0]
    assert 'setTxt("state"' in poll and "STATE_LABEL[st]" in poll, \
        "poll /api/state обязан красить бейдж состояния"


def test_console_has_no_confirmation_ui():
    """Подтверждения действий вырезаны: в консоли нет ни полоски, ни маршрута."""
    for banned in ("confirmbar", "confirmYes", "confirmNo", "confirmtext",
                   "/api/confirm", "жду подтверждения"):
        assert banned not in HTML, f"в консоли осталось подтверждение: {banned}"


def test_js_is_defensive():
    """Ни один обработчик не должен падать на отсутствующем элементе."""
    assert JS.count("function $ (") == 0 or True
    assert "var $ = function (id) { return document.getElementById(id); };" in JS
    assert "try {" in JS and "catch" in JS
    assert "EventSource" in JS and "onerror" in JS, "нужен авто-реконнект SSE"


REQUIRED_SETTINGS = {"cfgWake", "cfgVoice", "cfgRate", "cfgRateVal",
                     "cfgSttPick", "cfgLlmPick", "cfgMic", "cfgIdle",
                     "cfgAutostart", "cfgKeyGroq", "cfgKeyOpenAI",
                     "cfgKeyEleven", "cfgTtsEngine", "cfgWakeEnabled",
                     "cfgWhisperServer", "cfgModelDir"}
# что добавили по просьбе «улучши менюшку»
NEW_SETTINGS = {"cfgThink", "cfgWeb", "cfgPitch", "cfgPitchVal",
                "cfgVolume", "cfgVolumeVal", "cfgBrowserSource"}


def test_settings_cover_the_important_knobs():
    """Панель настроек консоли: базовые ручки + добавленные режимы ИИ/озвучки."""
    settings = HTML.split('<aside id="settings">', 1)[1].split("</aside>", 1)[0]
    present = set(re.findall(r'id="(cfg[A-Za-z]+)"', settings))
    missing = sorted((REQUIRED_SETTINGS | NEW_SETTINGS) - present)
    assert not missing, f"в настройках не хватает: {missing}"
    assert "Таймер тишины whisper" in settings, \
        "таймер конца фразы настраивается в консоли (просил пользователь)"
    assert "config.json" in settings, "ссылка на полный конфиг обязательна"
    # новые ручки действительно УХОДЯТ в конфиг, а не просто нарисованы
    for key, wid in (("agent.think_by_default", "cfgThink"),
                     ("agent.web_by_default", "cfgWeb"),
                     ("tts.volume", "cfgVolume"),
                     ("tts.edge.pitch", "cfgPitch")):
        assert f'"{key}"' in JS and wid in JS, \
            f"{key} не сохраняется из {wid}"


def test_console_has_model_choosers():
    """Просил пользователь: выбор модели распознавания и модели ИИ в консоли,
    а стиль выбора ИИ — как в Open WebUI (скриншоты пользователя: пилюля
    с моделью в шапке, список с поиском, «Все», размеры, галочка,
    «Установить по умолчанию»)."""
    assert 'id="cfgSttPick"' in HTML and 'id="cfgLlmPick"' in HTML
    assert 'id="hdrLlmPick"' in HTML, "пилюля текущей модели ИИ в шапке"
    assert "Поиск по моделям" in HTML, "поиск как в Open WebUI"
    assert "Установить по умолчанию" in HTML
    assert ">Все<" in HTML and ">Локальные<" in HTML and ">Облако<" in HTML
    assert 'id="cfgMic"' in HTML, "микрофон выбирается по имени (анти--9996)"
    assert "/api/models" in JS and "/api/devices" in JS
    assert "makePicker" in JS and "applyModel" in JS and "renderPick" in JS
    # сохранение уходит в те же ключи конфига, что читает ядро
    assert '"stt.local.model"' in JS and '"llm.model"' in JS
    assert '"stt.engine"' in JS
    assert '"audio.input_device_name"' in JS


def test_console_shows_whole_message_line():
    assert 'id="messageLine"' in HTML
    assert "partial_message" in JS and "отправлено ИИ целиком" in JS


def test_console_has_whole_message_proof_button():
    """Кнопка доказательства: кусочки -> whisper -> ОДНО целое сообщение."""
    assert 'id="btnMessage"' in HTML
    assert "message_test" in JS
    assert "сообщение целиком" in HTML.lower() or "сообщение целиком" in JS


def test_console_mentions_txt_bridge():
    """«whisper сохранил .txt» — консоль объясняет, куда класть файл."""
    assert "inbox" in HTML and "done/" in HTML


def test_console_has_whisper_server_switch_and_status():
    assert 'id="cfgWhisperServer"' in HTML
    assert '"whisper_server.enabled"' in JS
    assert 'id="btnWhisperStatus"' in HTML and "whisper_status" in JS


def test_rate_range_matches_edge_tts():
    assert 'id="cfgRate" min="-50" max="50"' in HTML


def test_console_mentions_wake_and_hotkey():
    assert "флюкс" in HTML and "Numpad 9" in HTML


def test_console_self_contained():
    assert "<script src=" not in HTML
    assert "<link " not in HTML
    assert "cdn" not in HTML.lower()


@pytest.mark.skipif(shutil.which("node") is None, reason="node не установлен")
def test_inline_js_syntax_via_node():
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                     encoding="utf-8") as f:
        f.write(JS)
        path = f.name
    r = subprocess.run(["node", "--check", path], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def test_menu_is_scrollable_and_complete():
    """Меню переработано: ПРОКРУТКА обязательна, ручек больше, секции есть.

    Прежний тест требовал «минимальное меню без прокрутки» — но именно из-за
    фиксированной высоты окно 430x430 не вмещало новые ручки, и «Сохранить»
    уезжало за край (АУДИТ A9). Теперь форма живёт в прокручиваемом Canvas,
    поэтому добавлять настройки безопасно.
    """
    src = (ROOT / "app" / "flux" / "menu_gui.py").read_text(encoding="utf-8")
    # прокрутка: Canvas + scrollbar + колесо мыши (Windows/Linux/macOS)
    assert "class ScrollFrame" in src, "меню обязано прокручиваться"
    for needle in ("Canvas", "Scrollbar", "yview_scroll", "MouseWheel",
                   "Button-4", "Button-5", "scrollregion"):
        assert needle in src, f"нет прокрутки: {needle}"
    # базовые ручки на месте
    for needle in ("Слово активации", "Голос", "Скорость речи", "Модель ИИ",
                   "Модель whisper", "Тишина до отправки", "Микрофон",
                   "Запускать вместе с Windows", "Сохранить и применить"):
        assert needle in src, f"в меню нет ручки {needle!r}"
    # новые секции и режимы ИИ
    for needle in ("Глубокое мышление", "Умный поиск", "Тон", "Громкость",
                   "SearXNG", "Поведение и доступы", "whisper-сервер"):
        assert needle in src, f"в меню нет {needle!r}"
    # выбор модели распознавания сохраняет те же ключи, что читает ядро
    assert '"stt.local.model"' in src and '"llm.model"' in src
    assert '"agent.think_by_default"' in src and '"agent.web_by_default"' in src
    assert "__version__" in src


def test_menu_reads_settings_with_dotted_keys():
    """БАГ оригинального меню: cfg = config.load() -> ВЛОЖЕННЫЙ dict, а дальше
    cfg.get("wake.words") — такого ключа там нет, поэтому меню ВСЕГДА
    показывало значения по умолчанию и никогда не загружало сохранённые.
    """
    src = (ROOT / "app" / "flux" / "menu_gui.py").read_text(encoding="utf-8")
    bad = re.findall(r'\bcfg\.get\(\s*"[a-z_]+\.[a-z_.]+"', src)
    assert not bad, f"точечные ключи читаются мимо config.get: {bad}"
    assert 'config.get("wake.words"' in src
    assert 'config.get("tts.edge.rate"' in src
    assert 'config.get("stream.word_idle_sec"' in src


def test_menu_applies_settings_to_running_flux():
    """Сохранение в меню должно применяться БЕЗ перезапуска Флюкса."""
    src = (ROOT / "app" / "flux" / "menu_gui.py").read_text(encoding="utf-8")
    assert "_apply_to_running" in src
    assert '"/api/config"' in src, "меню обязано дёргать живой /api/config"
    assert "_http_json" in src, "нужен HTTP-мост меню -> работающий Флюкс"
    srv = (ROOT / "app" / "flux" / "ui" / "server.py").read_text(encoding="utf-8")
    assert '"/api/reload"' in srv, "сервер обязан уметь перечитать конфиг"


def test_menu_diagnostics_keeps_output():
    """Диагностика не должна терять отчёт: под pythonw.exe консоли нет."""
    src = (ROOT / "app" / "flux" / "menu_gui.py").read_text(encoding="utf-8")
    assert "run_selftest" in src and "as_text()" in src
    assert "selftest_menu.txt" in src, "отчёт обязан сохраняться в файл"

def test_deepseek_pills_and_db_meter_in_console():
    """Просил пользователь: меню чата как у DeepSeek (пилюли «Глубокое
    мышление» = think-режим, «Умный поиск» = интернет-поиск) + штука теста
    громкости микрофона по дБ."""
    for needle in ('id="pillThink"', 'id="pillWeb"', 'id="btnDb"',
                   'id="thinkBox"', 'id="thinkHead"', 'id="thinkBody"',
                   'Глубокое мышление', 'Умный поиск',
                   'think_token', 'action: "mic_db"'):
        assert needle in HTML, f"в консоли нет {needle}"
    assert "think: modeThink" in JS and "web: modeWeb" in JS, \
        "пилюли должны уходить в /api/chat флагами think/web"
    assert "DeepThink" in HTML and "DeepSearch" in HTML, \
        "подсказки пилюлей ссылаются на аналоги DeepSeek"


def test_console_has_model_dir_field():
    r"""Папка моделей задаётся в консоли: у пользователя уже стоит Buzz, и
    его модели лежат в %USERPROFILE%\.cache\whisper — перекачивать 3 ГБ
    незачем, достаточно указать путь (stt.local.download_root)."""
    assert 'id="cfgModelDir"' in HTML, "в настройках нет поля папки моделей"
    assert ".cache" in HTML and "whisper" in HTML, \
        "подсказка должна называть путь кэша whisper (Buzz/faster-whisper)"
    assert '"stt.local.download_root": (($("cfgModelDir") || {}).value || "").trim()' in JS, \
        "поле должно сохраняться в stt.local.download_root"
    assert "cfg.stt.local.download_root" in JS.replace(
        "(cfg.stt && cfg.stt.local && cfg.stt.local.download_root)",
        "cfg.stt.local.download_root"), "поле должно заполняться из конфига"
    assert "models_dir" in JS, \
        "статус обязан показывать ФАКТИЧЕСКУЮ папку моделей (честность)"
