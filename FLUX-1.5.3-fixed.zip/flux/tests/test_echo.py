"""Тесты анти-эха и защиты от ложных активаций (правки по live-логу)."""
import sys
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.audio.echo import (in_speech_window, looks_like_echo,
                             should_accept_wake_segment, text_similarity)


def test_speech_window_blocks_during_and_right_after_tts():
    assert in_speech_window(True, 99.0) is True          # говорим прямо сейчас
    assert in_speech_window(False, 0.3) is True          # хвост из динамиков
    assert in_speech_window(False, 0.89) is True
    assert in_speech_window(False, 5.0) is False         # давно отговорили
    assert in_speech_window(False, 1.0, tail_guard_sec=0.5) is False


def test_echo_text_detected():
    last = "Готово! Я нашёл три файла на рабочем столе. Открыть их?"
    assert looks_like_echo(last, last) is True
    assert looks_like_echo("Открыть их?", last) is True      # хвост собственной речи
    assert looks_like_echo("флюкс включи свет", last) is False
    assert looks_like_echo("", last) is False
    assert looks_like_echo("привет", "") is False


def test_similarity_bounds():
    assert text_similarity("абв", "абв") == 1.0
    assert text_similarity("абв", "") == 0.0
    assert 0.0 <= text_similarity("флюкс включи свет", "флюкс выключи свет") < 1.0


def test_wake_segment_guards():
    ok, reason = should_accept_wake_segment(0.2, 0.35, 10.0, 1.5)
    assert ok is False and "короче" in reason
    ok, reason = should_accept_wake_segment(1.0, 0.35, 0.4, 1.5)
    assert ok is False and "частые" in reason
    ok, reason = should_accept_wake_segment(1.0, 0.35, 9.0, 1.5)
    assert ok is True and reason == ""


def test_main_anti_echo_and_word_stream():
    src = (Path(__file__).resolve().parents[1] / "app" / "flux" / "main.py"
           ).read_text(encoding="utf-8")
    for needle in ("self.player.speaking", "tail_guard_sec", "WordStream",
                   "_consume_chunk", "get_window"):
        assert needle in src, f"main потерял защиту/поток: {needle}"
