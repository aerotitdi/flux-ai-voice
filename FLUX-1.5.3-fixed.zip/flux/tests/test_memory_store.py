"""Тесты SQLite-памяти: диалоги, факты+FTS, заметки, знания, таймеры."""
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.memory.store import MemoryStore


@pytest.fixture()
def store(tmp_path):
    s = MemoryStore(str(tmp_path / "m.db"))
    yield s
    s.close()


def test_conversations_and_history(store):
    cid = store.new_conversation("тест")
    store.add_message(cid, "user", "привет")
    store.add_message(cid, "assistant", "*-привет!-*")
    h = store.history(cid)
    assert [m["role"] for m in h] == ["user", "assistant"]
    assert h[1]["content"] == "*-привет!-*"
    assert store.history(cid, limit=1)[0]["role"] == "assistant"
    assert store.message_count(cid) == 2


def test_conversation_list_and_rename_delete(store):
    a = store.new_conversation("один")
    b = store.new_conversation("два")
    store.add_message(b, "user", "x")
    convs = store.list_conversations()
    assert convs[0]["id"] == b, "свежеобновлённый диалог первым"
    assert store.rename_conversation(a, "переименован")
    assert store.delete_conversation(a)
    assert all(c["id"] != a for c in store.list_conversations())


def test_remember_recall(store):
    store.remember("люблю кофе по утрам", "вкус,привычки")
    store.remember("живу в Москве на Тверской", "адрес")
    store.remember("работаю программистом python", "работа")
    hits = store.recall("кофе")
    assert hits and "кофе" in hits[0]["text"]
    hits = store.recall("москва тверская")
    assert hits and "Тверской" in hits[0]["text"]
    assert store.recall("ничего такого нет") == []


def test_recall_empty_query(store):
    assert store.recall("") == []


def test_forget(store):
    store.remember("секрет один")
    store.remember("секрет два")
    n = store.forget("секрет")
    assert n == 2
    assert store.list_memories() == []


def test_notes_crud(store):
    nid = store.note_save("список покупок", "хлеб, молоко")
    assert store.note_list()[0]["title"] == "список покупок"
    got = store.note_get(nid)
    assert got["content"] == "хлеб, молоко"
    store.note_save("список покупок", "хлеб, молоко, сыр", note_id=nid)
    assert store.note_get(nid)["content"].endswith("сыр")
    assert store.note_delete(nid)
    assert store.note_get(nid) is None


def test_knowledge_ingest_and_search(store):
    chunks = ["флюкс это голосовой ассистент", "он умеет управлять устройствами",
              "совершенно посторонний текст про квантовую физику"]
    assert store.knowledge_ingest("docs/flux.md", chunks) == 3
    hits = store.knowledge_search("управление устройствами")
    assert hits and "устройствами" in hits[0]["chunk"]
    srcs = store.knowledge_sources()
    assert srcs[0]["source"] == "docs/flux.md" and srcs[0]["chunks"] == 3
    # повторный ingest того же источника заменяет, а не дублирует
    store.knowledge_ingest("docs/flux.md", chunks[:1])
    assert store.knowledge_sources()[0]["chunks"] == 1


def test_timers(store):
    now = time.time()
    t1 = store.timer_add("timer", now - 5, "прошлое")
    t2 = store.timer_add("reminder", now + 3600, "будущее")
    due = store.timers_due(now)
    assert [t["id"] for t in due] == [t1]
    store.timer_done(t1)
    assert store.timers_due(now) == []
    assert store.timer_cancel(t2)
    assert store.timer_list() == []


def test_persistence_across_reopen(tmp_path):
    path = str(tmp_path / "p.db")
    s1 = MemoryStore(path)
    s1.new_conversation("персист")
    s1.remember("факт для проверки")
    s1.close()
    s2 = MemoryStore(path)
    assert s2.list_conversations()[0]["title"] == "персист"
    assert s2.recall("факт")[0]["text"] == "факт для проверки"
    s2.close()
