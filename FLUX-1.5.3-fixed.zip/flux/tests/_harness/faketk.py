"""Мини-tkinter для headless-проверки меню FLUX.

В песочнице/CI нет ни дисплея, ни самого tkinter, а menu_gui.py исторически
не был покрыт тестами ВОВСЕ — именно поэтому в релиз уехало «меню не
прокручивается, Сохранить за краем» (АУДИТ A9). Этот модуль подменяет
tkinter/tree.ttk/messagebox достаточным количеством поведения, чтобы можно
было СОБРАТЬ настоящее MenuApp, дёрнуть его методы и поймать AttributeError /
NameError / KeyError без единого пикселя на экране.

Каждый виджет записывает себя в реестр, поэтому тест может проверить, что
нужные ручки действительно созданы, и прочитать/записать их значения.
"""
from __future__ import annotations

import sys
import types
from typing import Any, Optional

REGISTRY: dict[str, list] = {}


class _Var:
    def __init__(self, value: Any = None, master=None, name: str = "") -> None:
        self._v = value

    def get(self):
        return self._v

    def set(self, value) -> None:
        self._v = value


class BooleanVar(_Var):
    def __init__(self, master=None, value: bool = False, name: str = "") -> None:
        super().__init__(bool(value), master, name)

    def get(self) -> bool:
        return bool(self._v)


class StringVar(_Var):
    def __init__(self, master=None, value: str = "", name: str = "") -> None:
        super().__init__(str(value), master, name)

    def get(self) -> str:
        return str(self._v)


class IntVar(_Var):
    pass


class DoubleVar(_Var):
    pass


class Widget:
    _kind = "widget"

    def __init__(self, master=None, **kw) -> None:
        self.master = master
        self.kw = dict(kw)
        self.children: list = []
        self.text = str(kw.get("text", ""))
        self._values: list = list(kw.get("values", []) or [])
        self._value: Any = ""
        self._grid: Optional[dict] = None
        if master is not None and hasattr(master, "children"):
            master.children.append(self)
        REGISTRY.setdefault(self._kind, []).append(self)

    # ---- геометрия/внешность (ничего не рисуем, только запоминаем)
    def pack(self, **kw):
        self._grid = {"how": "pack", **kw}
        return self

    def grid(self, **kw):
        self._grid = {"how": "grid", **kw}
        return self

    def place(self, **kw):
        self._grid = {"how": "place", **kw}
        return self

    def pack_forget(self):
        self._grid = None

    def configure(self, **kw):
        self.kw.update(kw)
        if "text" in kw:
            self.text = str(kw["text"])
        if "values" in kw:
            self._values = list(kw["values"] or [])
        return self

    config = configure

    def cget(self, key):
        return self.kw.get(key)

    def bind(self, *a, **kw):
        return self

    def bind_all(self, *a, **kw):
        return self

    def unbind_all(self, *a, **kw):
        return self

    def winfo_width(self):
        return 600

    def winfo_height(self):
        return 700

    def destroy(self):
        if self.master is not None and self in getattr(self.master, "children", []):
            self.master.children.remove(self)

    def columnconfigure(self, *a, **kw):
        return self

    def rowconfigure(self, *a, **kw):
        return self


class Frame(Widget):
    _kind = "frame"


class LabelFrame(Frame):
    _kind = "labelframe"


class Label(Widget):
    _kind = "label"


class Button(Widget):
    _kind = "button"

    def invoke(self):
        cmd = self.kw.get("command")
        if callable(cmd):
            return cmd()
        return None


class Separator(Widget):
    _kind = "separator"


class Scrollbar(Widget):
    _kind = "scrollbar"

    def set(self, *a):
        return self


class Canvas(Widget):
    _kind = "canvas"

    def __init__(self, master=None, **kw) -> None:
        super().__init__(master, **kw)
        self._items = 1
        self.scroll_calls: list = []

    def create_window(self, *a, **kw):
        self._items += 1
        return self._items

    def bbox(self, *a):
        return (0, 0, 600, 700)

    def itemconfigure(self, *a, **kw):
        return self

    def yview(self, *a):
        self.scroll_calls.append(a)
        return self

    def yview_scroll(self, *a):
        self.scroll_calls.append(("scroll",) + a)
        return self


class _EntryLike(Widget):
    _kind = "entry"

    def get(self) -> str:
        return str(self._value)

    def insert(self, index, text) -> None:
        if index in (0, "0"):
            self._value = str(text) + str(self._value)
        elif index == "end":
            self._value = str(self._value) + str(text)
        else:
            self._value = str(text)

    def delete(self, first, last=None) -> None:
        self._value = ""

    def set(self, value) -> None:
        self._value = value

    def selection_clear(self):
        return self


class Entry(_EntryLike):
    pass


class Spinbox(_EntryLike):
    _kind = "spinbox"


class Combobox(_EntryLike):
    _kind = "combobox"

    def current(self, i=None):
        if i is None:
            try:
                return self._values.index(self.get())
            except ValueError:
                return -1
        self._value = self._values[i]
        return i


class Scale(Widget):
    _kind = "scale"

    def __init__(self, master=None, **kw) -> None:
        super().__init__(master, **kw)
        self._value = float(kw.get("from_", 0))
        self._cmd = kw.get("command")

    def get(self) -> float:
        return self._value

    def set(self, value) -> None:
        self._value = float(value)
        if callable(self._cmd):
            self._cmd(str(self._value))

    def configure(self, **kw):
        if "command" in kw:
            self._cmd = kw["command"]
        return super().configure(**kw)

    config = configure


class Checkbutton(Widget):
    _kind = "checkbutton"

    def __init__(self, master=None, **kw) -> None:
        super().__init__(master, **kw)
        self.var = kw.get("variable")

    def select(self):
        if self.var is not None:
            self.var.set(True)

    def deselect(self):
        if self.var is not None:
            self.var.set(False)

    def invoke(self):
        if self.var is not None:
            self.var.set(not self.var.get())
        cmd = self.kw.get("command")
        if callable(cmd):
            cmd()


class Radiobutton(Checkbutton):
    _kind = "radiobutton"


class Style:
    _themes = ("clam", "default", "alt", "classic")

    def __init__(self, master=None) -> None:
        self._styles: dict = {}

    def theme_use(self, name: Optional[str] = None):
        if name is None:
            return "clam"
        if name not in self._themes:
            raise Exception(f"тема {name} недоступна")
        return name

    def configure(self, style=None, **kw):
        self._styles[style or "."] = kw

    def map(self, style, **kw):
        self._styles.setdefault(style, {})["map"] = kw

    def layout(self, *a, **kw):
        return []

    def lookup(self, *a, **kw):
        return ""


class Tk(Widget):
    _kind = "tk"

    def __init__(self, **kw) -> None:
        super().__init__(None, **kw)
        self._after_q: list = []
        self._protocol: dict = {}
        self._title = ""
        self._geometry = ""

    def title(self, t=None):
        if t is None:
            return self._title
        self._title = t
        return self

    def geometry(self, g=None):
        if g is None:
            return self._geometry
        self._geometry = g
        return self

    def minsize(self, *a):
        return self

    def iconbitmap(self, *a, **kw):
        return self

    def protocol(self, name, fn=None):
        self._protocol[name] = fn
        return self

    def after(self, ms, fn=None, *a):
        self._after_q.append((ms, fn, a))
        return len(self._after_q)

    def after_cancel(self, *a):
        return self

    def update(self):
        return self

    def update_idletasks(self):
        return self

    def mainloop(self, n=0):
        return self

    def option_add(self, *a, **kw):
        return self

    def eval(self, *a):
        return ""

    def flush_after(self) -> list:
        """Выполнить все отложенные after() и вернуть их список (для теста)."""
        q, self._after_q = self._after_q, []
        for _ms, fn, args in q:
            if callable(fn):
                fn(*args)
        return q


class _Messagebox(types.ModuleType):
    def __init__(self) -> None:
        super().__init__("tkinter.messagebox")
        self.calls: list = []
        self.answer_yes = True

    def showinfo(self, title, message, **kw):
        self.calls.append(("showinfo", title, message))
        return True

    def showwarning(self, title, message, **kw):
        self.calls.append(("showwarning", title, message))
        return True

    def showerror(self, title, message, **kw):
        self.calls.append(("showerror", title, message))
        return True

    def askyesno(self, title, message, **kw):
        self.calls.append(("askyesno", title, message))
        return self.answer_yes

    def askokcancel(self, title, message, **kw):
        self.calls.append(("askokcancel", title, message))
        return self.answer_yes


class _FileDialog(types.ModuleType):
    def __init__(self) -> None:
        super().__init__("tkinter.filedialog")
        self.calls = []

    def askopenfilename(self, **kw):
        self.calls.append(("askopenfilename", kw))
        return ""

    def askdirectory(self, **kw):
        self.calls.append(("askdirectory", kw))
        return ""


def install() -> tuple:
    """Ставит фейковый tkinter в sys.modules. Возвращает (tk, ttk, messagebox)."""
    REGISTRY.clear()
    tk = types.ModuleType("tkinter")
    ttk = types.ModuleType("tkinter.ttk")
    mb = _Messagebox()
    fd = _FileDialog()

    for name in ("BooleanVar", "StringVar", "IntVar", "DoubleVar", "Variable"):
        setattr(tk, name, globals()[name] if name in globals() else _Var)
    tk.Variable = _Var
    tk.Tk = Tk
    tk.Frame = Frame
    tk.LabelFrame = LabelFrame
    tk.Label = Label
    tk.Button = Button
    tk.Canvas = Canvas
    tk.Entry = Entry
    tk.Scale = Scale
    tk.Checkbutton = Checkbutton
    tk.Radiobutton = Radiobutton
    tk.Scrollbar = Scrollbar
    tk.Separator = Separator
    tk.Widget = Widget
    tk.Messagebox = mb
    tk.N = "n"; tk.S = "s"; tk.E = "e"; tk.W = "w"
    tk.NW = "nw"; tk.NE = "ne"; tk.SW = "sw"; tk.SE = "se"
    tk.LEFT = "left"; tk.RIGHT = "right"; tk.TOP = "top"; tk.BOTTOM = "bottom"
    tk.BOTH = "both"; tk.X = "x"; tk.Y = "y"; tk.NONE = "none"
    tk.HORIZONTAL = "horizontal"; tk.VERTICAL = "vertical"
    tk.END = "end"; tk.INSERT = "insert"; tk.SEL = "sel"
    tk.NORMAL = "normal"; tk.DISABLED = "disabled"; tk.READONLY = "readonly"
    tk.CENTER = "center"

    class _TkWidgetProxy:
        @staticmethod
        def winfo_containing(*a, **kw):
            return None
    tk.Widget = Widget
    Widget.winfo_containing = staticmethod(lambda *a, **kw: None)

    for name in ("Frame", "LabelFrame", "Label", "Button", "Entry", "Combobox",
                 "Scale", "Checkbutton", "Radiobutton", "Scrollbar", "Separator",
                 "Style", "Spinbox", "PanedWindow", "Notebook", "Treeview",
                 "Progressbar", "Sizegrip", "Labelframe"):
        setattr(ttk, name, globals().get(name, Widget))
    ttk.Labelframe = LabelFrame

    tk.ttk = ttk
    tk.messagebox = mb
    tk.filedialog = fd
    sys.modules["tkinter"] = tk
    sys.modules["tkinter.ttk"] = ttk
    sys.modules["tkinter.messagebox"] = mb
    sys.modules["tkinter.filedialog"] = fd
    return tk, ttk, mb
