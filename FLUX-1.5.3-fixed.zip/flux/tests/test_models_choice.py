"""Выбор моделей в консоли: «Понимание речи» (STT) и «ИИ для ответа» (LLM).

Списки должны быть ЧЕСТНЫМИ: только то, что реально есть на машине
(локальные модели faster-whisper + уже скачанные, whisper-эндпоинты, модели
из Ollama /api/tags, подключения), и текущая модель из конфига всегда
присутствует — иначе настройка «пропадает» из списка.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg  # noqa: E402
from flux import models as models_mod  # noqa: E402
from flux.stt import local as local_stt  # noqa: E402


@pytest.fixture(autouse=True)
def _cfg(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    yield


# ------------------------------------------------------------------- каталог
def test_stt_catalog_contains_local_models_and_current():
    d = models_mod.stt_models()
    ids = [m["id"] for m in d["models"]]
    assert "local:large-v3-turbo" in ids
    assert "local:base" in ids and "local:small" in ids
    assert d["current"] == "local:large-v3-turbo"
    for m in d["models"]:
        assert m["label"] and m["value"], m


def test_stt_catalog_marks_ollama_whisper_honestly(monkeypatch):
    """Сток-Ollama whisper-модель НЕ запускает: в API Ollama нет
    /audio/transcriptions (docs.ollama.com/api). Каталог обязан это сказать."""
    from flux.stt import ollama_asr

    monkeypatch.setattr(ollama_asr.OllamaWhisperSTT, "probe",
                        lambda self, ttl=20.0: None)
    d = models_mod.stt_models()
    oll = [m for m in d["models"] if m["engine"] == "ollama"]
    assert oll and oll[0]["cached"] is False
    assert "не работает" in oll[0]["note"]
    assert d["ollama_ok"] is False


def test_stt_catalog_says_when_ollama_whisper_works(monkeypatch):
    from flux.stt import ollama_asr

    monkeypatch.setattr(ollama_asr.OllamaWhisperSTT, "probe",
                        lambda self, ttl=20.0: "http://localhost:22434/v1")
    monkeypatch.setattr(ollama_asr.OllamaWhisperSTT, "model_present",
                        lambda self: True)
    d = models_mod.stt_models()
    assert d["ollama_ok"] is True
    oll = [m for m in d["models"] if m["engine"] == "ollama"][0]
    assert "работает" in oll["note"]


def test_llm_catalog_uses_ollama_tags(monkeypatch):
    monkeypatch.setattr(models_mod, "_ollama_models",
                        lambda timeout=2.0: (
                            [{"name": "gemma4:31b-cloud", "size": "31B"},
                             {"name": "llama3.1:8b", "size": "8B"}], ""))
    d = models_mod.llm_models()
    values = [m["value"] for m in d["models"]]
    assert "gemma4:31b-cloud" in values and "llama3.1:8b" in values
    assert d["current"] == "gemma4:31b-cloud"
    assert d["error"] == ""


def test_llm_catalog_keeps_current_when_ollama_is_down(monkeypatch):
    monkeypatch.setattr(models_mod, "_ollama_models",
                        lambda timeout=2.0: ([], "localhost:11434: ConnectionError"))
    d = models_mod.llm_models()
    assert d["current"] in [m["value"] for m in d["models"]]
    assert d["error"], "причину недоступности Ollama нужно показывать"


def test_llm_catalog_includes_connections(monkeypatch):
    cfg.update({"llm": {"connections": [
        {"name": "openrouter", "base_url": "https://openrouter.ai/api/v1",
         "api_key": "x", "model": "openai/gpt-4o"}]}}, save=False)
    monkeypatch.setattr(models_mod, "_ollama_models", lambda timeout=2.0: ([], ""))
    d = models_mod.llm_models()
    assert any(m["engine"] == "openai-conn" and m["value"] == "openai/gpt-4o"
               for m in d["models"])


def test_catalog_has_both_lists():
    d = models_mod.catalog()
    assert "stt" in d and "llm" in d
    assert d["stt"]["models"] and d["llm"]["models"]


# ------------------------------------------------------- локальный whisper
def test_model_chain_starts_with_user_choice():
    chain = local_stt.model_chain("small")
    assert chain[0] == "small"
    assert "base" in chain and "large-v3-turbo" in chain
    assert len(chain) == len(set(chain))


def test_cached_models_lists_downloaded(tmp_path, monkeypatch):
    for name in ("models--Systran--faster-whisper-base",
                 "models--mobiuslabsgmbh--faster-whisper-large-v3-turbo",
                 "models--openai--something-else",
                 "unrelated-dir"):
        (tmp_path / name).mkdir()
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"stt": {"local": {"download_root": str(tmp_path)}}}, save=False)
    monkeypatch.setattr(local_stt, "model_bytes_on_disk",
                        lambda size, root=None: 100 * 1024 * 1024)
    got = local_stt.cached_models()
    assert got == ["large-v3-turbo", "base"], got   # лучшие модели первыми


def test_cached_models_hides_broken_downloads(tmp_path, monkeypatch):
    """Недокачанная модель не должна выглядеть как готовая."""
    (tmp_path / "models--Systran--faster-whisper-medium").mkdir()
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"stt": {"local": {"download_root": str(tmp_path)}}}, save=False)
    monkeypatch.setattr(local_stt, "model_bytes_on_disk",
                        lambda size, root=None: 3 * 1024 * 1024)
    assert local_stt.cached_models() == []


def test_get_model_skips_half_downloaded_model(tmp_path, monkeypatch):
    import types

    monkeypatch.setattr(local_stt, "fits_in_ram", lambda size, device: (True, ""))

    calls = []

    class FakeModel:
        def __init__(self, size, **kw):
            calls.append(size)
            self.size = size

    fake_mod = types.ModuleType("faster_whisper")
    fake_mod.WhisperModel = FakeModel
    monkeypatch.setitem(sys.modules, "faster_whisper", fake_mod)
    monkeypatch.setattr(local_stt, "_models", {})
    monkeypatch.setattr(local_stt, "model_bytes_on_disk",
                        lambda size, root=None: 5 * 1024 * 1024
                        if size == "large-v3-turbo" else 0)
    removed = []
    monkeypatch.setattr(local_stt, "_remove_broken_model",
                        lambda size, root: removed.append(size))
    model, eff = local_stt.get_model("large-v3-turbo")
    assert eff == "large-v3", eff       # огрызок пропущен, взята следующая
    assert removed == ["large-v3-turbo"]
    assert "large-v3-turbo" not in calls
    assert "загрузка оборвалась" in local_stt.last_error()["error"]


def test_get_model_falls_back_to_lighter_model(monkeypatch):
    """Если выбранная модель не скачалась/не загрузилась — берём запасную,
    чтобы распознавание РАБОТАЛО, а не молчало."""
    import types

    monkeypatch.setattr(local_stt, "fits_in_ram", lambda size, device: (True, ""))

    calls = []

    class FakeModel:
        def __init__(self, size, **kw):
            calls.append(size)
            if size in ("large-v3-turbo", "large-v3", "medium"):
                raise OSError("не скачалась: нет доступа к huggingface")
            self.size = size

    fake_mod = types.ModuleType("faster_whisper")
    fake_mod.WhisperModel = FakeModel
    monkeypatch.setitem(sys.modules, "faster_whisper", fake_mod)
    monkeypatch.setattr(local_stt, "_models", {})
    model, eff = local_stt.get_model("large-v3-turbo")
    assert eff == "small", eff
    assert model is not None
    err = local_stt.last_error()
    assert err["model"] == "large-v3-turbo" and err["fallback"] == "small"
    assert "huggingface" in err["error"]


def test_get_model_raises_when_nothing_works(monkeypatch):
    import types

    monkeypatch.setattr(local_stt, "fits_in_ram", lambda size, device: (True, ""))

    class FakeModel:
        def __init__(self, size, **kw):
            raise OSError("нет модели")

    fake_mod = types.ModuleType("faster_whisper")
    fake_mod.WhisperModel = FakeModel
    monkeypatch.setitem(sys.modules, "faster_whisper", fake_mod)
    monkeypatch.setattr(local_stt, "_models", {})
    with pytest.raises(RuntimeError) as e:
        local_stt.get_model("base")
    assert "ни одна whisper-модель" in str(e.value)


def test_status_reports_device_and_cached(monkeypatch):
    monkeypatch.setattr(local_stt, "cached_models", lambda root=None: ["base"])
    st = local_stt.status()
    assert st["configured_model"] == "large-v3-turbo"
    assert st["cached_models"] == ["base"]
    assert st["device"] in ("cpu", "cuda")
    assert st["compute_type"] in ("int8", "float16", "auto")
    assert st["installed"] in (True, False)

# --------------------------------------------------------- консоль (HTTP)
def _make_app(received: list):
    class App:
        def public_state(self):
            return {"state": "idle"}

        def last_snapshot(self):
            return {}

        def recent_history(self, limit=40):
            return []

        def console_action(self, action, body):
            received.append((action, body))
            return {}

        def resolve_confirmation(self, cid, answer):
            return True

        def on_config_changed(self):
            received.append(("config_changed", {}))

        def console_chat(self, text, speak=False, browser_speak=False):
            return {"ok": True}

    return App()


def test_console_api_models_route(monkeypatch):
    """GET /api/models отдаёт оба списка — их рисует консоль в селекторах."""
    import json as _json
    import urllib.request

    from flux.ui.server import UiServer

    monkeypatch.setattr(models_mod, "_ollama_models",
                        lambda timeout=2.0: (
                            [{"name": "gemma4:31b-cloud", "size": "31B"}], ""))
    got: list = []
    srv = UiServer(_make_app(got))
    cfg.update({"ui": {"port": 8901}}, save=False)
    assert srv.start()
    try:
        with urllib.request.urlopen("http://127.0.0.1:8901/api/models",
                                    timeout=10) as r:
            d = _json.loads(r.read().decode("utf-8"))
    finally:
        srv.stop()
        cfg.update({"ui": {"port": 8790}}, save=False)
    assert [m["id"] for m in d["llm"]["models"]][:1] == ["ollama:gemma4:31b-cloud"]
    assert any(m["id"] == "local:large-v3-turbo" for m in d["stt"]["models"])
    assert d["stt"]["current"].startswith("local:")


def test_console_saves_chosen_models(monkeypatch, tmp_path):
    """Сохранение из консоли пишет ровно те ключи, которые читает ядро.

    config.json теста уезжает в tmp_path: POST /api/config реально
    сохраняет файл, и он не должен остаться в репозитории/у пользователя.
    """
    import json as _json
    import urllib.request

    from flux import paths
    from flux.ui.server import UiServer

    monkeypatch.setattr(paths, "CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    got: list = []
    srv = UiServer(_make_app(got))
    cfg.update({"ui": {"port": 8902}}, save=False)
    assert srv.start()
    try:
        req = urllib.request.Request(
            "http://127.0.0.1:8902/api/config",
            data=_json.dumps({"set": {"stt.local.model": "small",
                                      "stt.engine": "local",
                                      "llm.model": "llama3.1:8b",
                                      "stream.word_idle_sec": 7.0,
                                      "whisper_server.enabled": False}}).encode(),
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=10) as r:
            assert _json.loads(r.read().decode("utf-8")) == {"ok": True}
    finally:
        srv.stop()
        cfg.update({"ui": {"port": 8790}}, save=False)
    assert (tmp_path / "config.json").exists(), "консоль обязана сохранить файл"
    assert cfg.get("stt.local.model") == "small"
    assert cfg.get("stt.engine") == "local"
    assert cfg.get("llm.model") == "llama3.1:8b"
    assert cfg.get("stream.word_idle_sec") == 7.0
    assert cfg.get("whisper_server.enabled") is False
    assert ("config_changed", {}) in got

# ------------------------------------------------- память и честный фолбэк
def test_fits_in_ram_rejects_heavy_model_on_weak_cpu(monkeypatch):
    monkeypatch.setattr(local_stt, "available_ram_mb", lambda: 700.0)
    ok, why = local_stt.fits_in_ram("large-v3-turbo", "cpu")
    assert ok is False and "2200" in why and "700" in why
    assert local_stt.fits_in_ram("base", "cpu")[0] is True


def test_fits_in_ram_never_blocks_gpu(monkeypatch):
    """На GPU модель живёт в видеопамяти — оперативную не проверяем."""
    monkeypatch.setattr(local_stt, "available_ram_mb", lambda: 100.0)
    assert local_stt.fits_in_ram("large-v3", "cuda") == (True, "")


def test_fits_in_ram_tolerates_unknown_measure(monkeypatch):
    monkeypatch.setattr(local_stt, "available_ram_mb", lambda: 0.0)
    assert local_stt.fits_in_ram("large-v3", "cpu") == (True, "")


def test_available_ram_mb_is_sane():
    mb = local_stt.available_ram_mb()
    assert mb == 0.0 or 50.0 < mb < 4_000_000.0


def test_get_model_skips_models_that_do_not_fit(monkeypatch):
    """Слабая машина: тяжёлые модели даже НЕ пробуем грузить (без OOM)."""
    import types

    loaded = []

    class FakeModel:
        def __init__(self, size, **kw):
            loaded.append(size)

    fake_mod = types.ModuleType("faster_whisper")
    fake_mod.WhisperModel = FakeModel
    monkeypatch.setitem(sys.modules, "faster_whisper", fake_mod)
    monkeypatch.setattr(local_stt, "_models", {})
    monkeypatch.setattr(local_stt, "model_bytes_on_disk", lambda *a, **k: 0)
    monkeypatch.setattr(local_stt, "fits_in_ram",
                        lambda size, device: (size in ("base", "tiny"),
                                              f"{size}: мало памяти"))
    _, eff = local_stt.get_model("large-v3-turbo")
    assert eff == "base"
    assert loaded == ["base"], loaded
    assert "мало памяти" in local_stt.last_error()["error"]


def test_status_shows_ram_facts(monkeypatch):
    monkeypatch.setattr(local_stt, "available_ram_mb", lambda: 1234.0)
    st = local_stt.status()
    assert st["ram_free_mb"] == 1234
    assert st["ram_need_mb"] == local_stt.RAM_NEED_MB[st["configured_model"]]


# --------------------------------------- размеры моделей, как в Open WebUI
def test_fmt_size_human():
    from flux.models import fmt_size
    assert fmt_size(32_700_000_000) == "32.7B"
    assert fmt_size(1_600_000_000) == "1.6B"
    assert fmt_size(117_000_000_000) == "117B"
    assert fmt_size(75_000_000) == "75M"
    assert fmt_size(0) == "" and fmt_size(None) == "" and fmt_size("x") == ""


def test_ollama_tags_gives_param_size(monkeypatch):
    """Бейдж размера берём из details.parameter_size (так же показывает
    Open WebUI), а при его отсутствии — из размера файла на диске."""
    import flux.models as M

    class R:
        def raise_for_status(self):
            return None

        def json(self):
            return {"models": [
                {"name": "gemma4:31b-cloud", "size": 32_700_000_000,
                 "details": {"parameter_size": "31B"}},
                {"name": "llama3.1:8b", "size": 4_700_000_000,
                 "details": {}},
            ]}

    monkeypatch.setattr(M.requests, "get", lambda *a, **k: R())
    models, err = M._ollama_models()
    assert err == ""
    assert models[0]["size"] == "31B"
    assert models[1]["size"] == "4.7B"


def test_llm_items_carry_scope_and_cloud_flag(monkeypatch):
    """Чипы «Локальные/Облако» в пикере питаются полем scope."""
    import flux.models as M

    monkeypatch.setattr(M, "_ollama_models", lambda timeout=2.0: (
        [{"name": "gemma4:31b-cloud", "size": "31B"},
         {"name": "llama3.1:8b", "size": "8B"}], ""))
    d = M.llm_models()
    by = {m["value"]: m for m in d["models"]}
    assert by["gemma4:31b-cloud"]["scope"] == "cloud"
    assert by["gemma4:31b-cloud"]["cloud"] is True
    assert by["llama3.1:8b"]["scope"] == "local"
    assert by["llama3.1:8b"]["size"] == "8B"


def test_buzz_cache_is_reused_as_download_root(tmp_path, monkeypatch):
    """Папка моделей задаётся конфигом: кэш уже установленного Buzz
    (%USERPROFILE%\\.cache\\whisper) переиспользуется БЕЗ повторного
    скачивания, а статус показывает ФАКТИЧЕСКУЮ папку (models_dir)."""
    import types

    from flux import paths as flux_paths

    root = tmp_path / "buzz-cache" / "whisper"
    (root / "models--Systran--faster-whisper-large-v3-turbo" / "snapshots").mkdir(
        parents=True)

    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"stt": {"local": {"download_root": str(root),
                                  "model": "large-v3-turbo"}}}, save=False)
    monkeypatch.setattr(local_stt, "model_bytes_on_disk",
                        lambda size, r=None: 1600 * 1024 * 1024)
    monkeypatch.setattr(local_stt, "fits_in_ram", lambda size, device: (True, ""))

    seen: list[dict] = []

    class FakeModel:
        def __init__(self, size, **kw):
            seen.append({"size": size, **kw})
            self.size = size

    fake_mod = types.ModuleType("faster_whisper")
    fake_mod.WhisperModel = FakeModel
    fake_mod.__version__ = "1.2.1"
    monkeypatch.setitem(sys.modules, "faster_whisper", fake_mod)
    monkeypatch.setattr(local_stt, "_models", {})

    assert local_stt.cached_models() == ["large-v3-turbo"]
    model, eff = local_stt.get_model("large-v3-turbo")
    assert eff == "large-v3-turbo"
    assert seen and seen[0]["download_root"] == str(root), seen
    assert seen[0]["download_root"] != str(flux_paths.MODELS_DIR)

    st = local_stt.status()
    assert st["models_dir"] == str(root), st["models_dir"]
    assert "large-v3-turbo" in st["cached_models"]


def test_download_root_default_is_install_models_dir(monkeypatch):
    """Пустой download_root = models\\ внутри установки (как было)."""
    from flux import paths as flux_paths

    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"stt": {"local": {"download_root": ""}}}, save=False)
    assert local_stt.status()["models_dir"] == str(flux_paths.MODELS_DIR)


def test_download_root_roundtrip_through_config_file(tmp_path, monkeypatch):
    """Путь из поля консоли доезжает до config.json и обратно в статус —
    ровно тот маршрут, которым ходит POST /api/config (set_value → save →
    load → status()["models_dir"]).

    config.json теста уезжает в tmp_path: save_config() пишет реальный файл,
    и он не должен остаться в репозитории (или в установке пользователя).
    """
    from flux import paths

    monkeypatch.setattr(paths, "CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(paths, "CONFIG_DIR", tmp_path)
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    target = str(tmp_path / "buzz" / "whisper")
    for dotted, value in {"stt.local.download_root": target}.items():
        cfg.set_value(dotted, value, save=False)
    cfg.save_config()
    assert cfg.as_dict()["stt"]["local"]["download_root"] == target

    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    assert cfg.get("stt.local.download_root") == target
    assert local_stt.status()["models_dir"] == target
