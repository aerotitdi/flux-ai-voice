"""Сырой тракт: микрофон -> whisper БЕЗ какой-либо обработки звука.

Правило пользователя (2026-10-08): «ДО WHISPER ДОЛЖЕН ДОХОДИТЬ ЧИСТЫЙ
ИДЕАЛЬНЫЙ ЗВУК». Поэтому:
  * модуль AGC удалён вовсе (импорт падает);
  * кадры захвата кладутся в кольцо байт-в-байт;
  * роутер и local не нормализуют и не усиливают сигнал;
  * «извлечение речи» делает Silero VAD ВНУТРИ faster-whisper (как
    галочка Extract speech в Buzz), а не обработка микрофона.
"""
from __future__ import annotations

import importlib

import numpy as np
import pytest

from flux.audio.capture import MicCapture, WavCapture
from flux.stt.base import Transcript
from flux.stt.router import STTRouter


def test_agc_module_is_gone():
    with pytest.raises(ModuleNotFoundError):
        importlib.import_module("flux.audio.agc")


def test_capture_callback_stores_frames_byte_for_byte():
    cap = MicCapture(None)
    frame = (np.sin(np.linspace(0, 40, 480)) * 3000).astype(np.int16)
    quiet = (np.sin(np.linspace(0, 40, 480)) * 7).astype(np.int16)
    for f in (frame, quiet):
        cap._callback(f.tobytes(), len(f), None, None)
    stored = [f for _, f in cap.ring]
    assert len(stored) == 2
    assert np.array_equal(stored[0], frame)
    assert np.array_equal(stored[1], quiet)      # тихий кадр НЕ усилен
    assert not hasattr(cap, "agc"), "AGC в захвате больше не живёт"


def test_wav_capture_emits_raw_frames():
    src = (np.sin(np.linspace(0, 200, 16000)) * 1234).astype(np.int16)
    got = []
    cap = WavCapture(src, sample_rate=16000, frame_ms=10,
                     on_frame=lambda f, rms: got.append(f))
    cap.start()
    cap.run()
    cap.stop()
    assert np.array_equal(np.concatenate(got), src)


def test_router_hands_raw_audio_to_engine():
    router = STTRouter()
    seen = {}

    class L:
        name = "local"

        def available(self):
            return True

        def transcribe_audio(self, a, sr=16000):
            seen["a"] = np.asarray(a)
            return Transcript(text="тест", engine="local")

    router.local = L()
    quiet = (np.sin(np.linspace(0, 90, 4800)) * 500).astype(np.int16)
    router.transcribe(quiet, 16000)
    assert np.array_equal(seen["a"], quiet), "до движка дошёл изменённый сигнал"


def test_local_stt_does_not_rescale_input(monkeypatch):
    """Пик-нормализации больше нет: модель получает сырой уровень."""
    from flux.stt import local as L

    seen = {}

    class DummyModel:
        def transcribe(self, arr, **kw):
            seen["peak"] = float(np.max(np.abs(arr)))
            return iter([]), type("I", (), {"language": "ru"})()

    monkeypatch.setattr(L, "get_model",
                        lambda *a, **k: (DummyModel(), "base"))
    quiet = (np.sin(np.linspace(0, 90, 16000)) * 500).astype(np.int16)
    stt = L.LocalWhisperSTT(size="tiny")
    stt.transcribe_audio(quiet, 16000)
    expected = float(np.max(np.abs(quiet))) / 32768.0
    assert seen["peak"] == pytest.approx(expected, rel=1e-6), \
        "сигнал перед моделью усилен/нормализован"
