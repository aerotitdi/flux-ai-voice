"""Тесты распознавания через локальный whisper в Ollama (mannix/whisper).

Поднят mock OpenAI-совместимый сервер /v1/audio/transcriptions: проверяем,
что аудио уходит multipart-полем file (base64 внутри клиента), модель та,
что в настройках, и что маршрутизатор корректно падает на faster-whisper,
когда эндпоинт мёртв.
"""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg
from flux.stt import ollama_asr as oa
from flux.stt.router import STTRouter

SEEN = {"requests": []}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    text = "флюкс включи свет на кухне"
    want_auth = False

    def do_GET(self):
        if self.path.endswith("/models"):
            if self.want_auth and not self.headers.get("Authorization"):
                self.send_response(401); self.end_headers(); return
            body = json.dumps({"models": [{"id": "mannix/whisper:large-v3-turbo"}]}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers(); self.wfile.write(body)
            return
        self.send_response(404); self.end_headers()

    def do_POST(self):
        length = int(self.headers["Content-Length"])
        body = self.rfile.read(length)
        ctype = self.headers.get("Content-Type", "")
        SEEN["requests"].append({"path": self.path, "ctype": ctype, "body": body})
        if not self.path.endswith("/audio/transcriptions"):
            self.send_response(404); self.end_headers(); return
        payload = json.dumps({"text": self.text, "language": "ru"}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers(); self.wfile.write(payload)

    def log_message(self, *a):
        pass


@pytest.fixture()
def mock_v1():
    SEEN["requests"].clear()
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_address[1]}/v1"
    yield base
    srv.shutdown()


@pytest.fixture()
def cfg_ollama(mock_v1, monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"stt": {"ollama": {"enabled": True,
                                   "model": "mannix/whisper:large-v3-turbo",
                                   "base_url": mock_v1,
                                   "fallback_base_urls": [],
                                   "language": "ru", "timeout_sec": 5,
                                   "use_for_wake": False},
                        "engine": "auto"}}, save=False)
    return mock_v1


def test_transcribe_sends_multipart_file_and_model(cfg_ollama):
    stt = oa.OllamaWhisperSTT()
    wav = b"RIFF" + b"\x00" * 4 + b"WAVE" + b"\x00" * 40
    tr = stt.transcribe_wav(wav)
    assert tr.text == "флюкс включи свет на кухне"
    assert tr.engine == "ollama-whisper"
    req = SEEN["requests"][-1]
    assert req["path"].endswith("/audio/transcriptions")
    assert "multipart/form-data" in req["ctype"]
    assert b'name="file"' in req["body"]
    assert b"mannix/whisper:large-v3-turbo" in req["body"]


def test_probe_detects_live_endpoint(cfg_ollama):
    stt = oa.OllamaWhisperSTT()
    assert stt.probe(ttl=0) == cfg_ollama
    assert stt.available() is True


def test_probe_dead_endpoint_fast(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"stt": {"ollama": {"enabled": True,
                                   "base_url": "http://127.0.0.1:1/v1",
                                   "fallback_base_urls": []}}}, save=False)
    stt = oa.OllamaWhisperSTT()
    import time
    t0 = time.time()
    assert stt.probe(ttl=0) is None
    assert time.time() - t0 < 5, "проба мёртвого эндпоинта должна быть быстрой"
    assert stt.available() is False


def test_fallback_to_second_base(monkeypatch):
    dead = "http://127.0.0.1:1/v1"
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    alive = f"http://127.0.0.1:{srv.server_address[1]}/v1"
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"stt": {"ollama": {"enabled": True, "base_url": dead,
                                   "fallback_base_urls": [alive],
                                   "timeout_sec": 4}}}, save=False)
    stt = oa.OllamaWhisperSTT()
    tr = stt.transcribe_wav(b"RIFF\x00\x00\x00\x00WAVE" + b"\x00" * 20)
    assert tr.text, "должен доехать до живого запасного эндпоинта"
    srv.shutdown()


def test_router_prefers_local_even_with_live_ollama(cfg_ollama, monkeypatch):
    """Локальный faster-whisper — ПЕРВЫЙ движок: цепочка пользователя
    микрофон -> whisper -> FLUX; ollama-whisper только запасным."""
    router = STTRouter()
    order = router._order("auto")
    assert order[0] == "local" and "ollama" in order
    calls = []
    router.local = type("L", (), {"available": lambda self: True,
                                  "transcribe_audio": lambda self, a, s=16000:
                                  (calls.append("local"),
                                   __import__("flux.stt.base", fromlist=["Transcript"])
                                   .Transcript(text="локально", engine="local"))[1]})()
    res = router.transcribe(np.zeros(800, dtype=np.int16))
    assert res.engine == "local", "локальный whisper отвечает первым"
    assert calls == ["local"]


def test_router_falls_back_when_ollama_dead(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"stt": {"ollama": {"enabled": True,
                                   "base_url": "http://127.0.0.1:1/v1",
                                   "fallback_base_urls": []}}}, save=False)
    router = STTRouter()
    router.local = type("L", (), {"available": lambda self: True,
                                  "transcribe_audio": lambda self, a, s=16000:
                                  __import__("flux.stt.base", fromlist=["Transcript"])
                                  .Transcript(text="из faster-whisper", engine="local")})()
    res = router.transcribe(np.zeros(800, dtype=np.int16))
    assert res.engine == "local", "при мёртвом ollama падает на faster-whisper"


def test_router_mode_ollama_only(cfg_ollama):
    router = STTRouter()
    assert router._order("ollama") == ["ollama", "local"]
    assert router._order("local") == ["local"]


def test_wake_engine_local_router_without_keys_and_ollama(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"keys": {"groq": "", "openai": ""},
                "stt": {"ollama": {"enabled": False}}}, save=False)
    router = STTRouter()
    eng = router.wake_engine()
    # локальный faster-whisper установлен -> слово ищется тем же точным
    # роутером (первый движок - local), лёгкая модель не нужна
    assert eng is router, "без ключей и xOllama активация идёт локальным whisper"


def test_wake_engine_uses_router_when_ollama_available(cfg_ollama):
    router = STTRouter()
    eng = router.wake_engine()
    assert eng is router, "при живом whisper-эндпоинте активация идёт через него"


def test_wake_engine_can_use_ollama(cfg_ollama, monkeypatch):
    cfg.update({"stt": {"ollama": {"use_for_wake": True}}}, save=False)
    router = STTRouter()
    eng = router.wake_engine()
    assert eng.name == "ollama-whisper"


def test_disabled_engine_skipped_at_runtime(cfg_ollama, monkeypatch):
    """Выключенный/мёртвый движок пропускается ВО ВРЕМЯ вызова: порядок
    всегда local-first, но до ollama/api дело не доходит."""
    cfg.update({"stt": {"ollama": {"enabled": False}}}, save=False)
    router = STTRouter()
    assert router._order("auto")[0] == "local"
    called = []
    router.local = type("L", (), {"available": lambda self: True,
                                  "transcribe_audio": lambda self, a, s=16000:
                                  (called.append("local"),
                                   __import__("flux.stt.base", fromlist=["Transcript"])
                                   .Transcript(text="", engine="local"))[1]})()
    router.ollama.transcribe_audio = lambda *a, **k: (_ for _ in ()).throw(
        AssertionError("выключенный ollama не вызывается"))
    res = router.transcribe(np.zeros(800, dtype=np.int16))
    assert called == ["local"] and res.engine == "local"


# ---------------------------------------------------------- правки по live-логу
def test_probe_404_is_not_alive():
    """Сток-Ollama не должен маскироваться под живой whisper-эндпоинт."""
    class H404(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(404); self.end_headers()

        def log_message(self, *a):
            pass

    srv = ThreadingHTTPServer(("127.0.0.1", 0), H404)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_address[1]}/v1"
    try:
        stt = oa.OllamaWhisperSTT(base_url=base, model="mannix/whisper:large-v3-turbo")
        stt.fallback_bases = []
        assert stt.probe(ttl=0) is None
        assert stt.available() is False
    finally:
        srv.shutdown()


def test_model_present_detection(monkeypatch):
    class HModels(BaseHTTPRequestHandler):
        payload = b'{"data": [{"id": "gemma4:31b-cloud"}]}'

        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(self.payload)))
            self.end_headers(); self.wfile.write(self.payload)

        def log_message(self, *a):
            pass

    srv = ThreadingHTTPServer(("127.0.0.1", 0), HModels)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_address[1]}/v1"
    try:
        stt = oa.OllamaWhisperSTT(base_url=base)
        stt.fallback_bases = []
        assert stt.probe(ttl=0) == base
        assert stt.model_present() is False, "без whisper-модели движок недоступен"
        assert stt.available() is False
    finally:
        srv.shutdown()


def test_local_stt_does_not_use_incompatible_decoder():
    """faster_whisper.audio.decode_audio несовместим с PyAV>=16 - его быть не должно."""
    src = (Path(__file__).resolve().parents[1] / "app" / "flux" / "stt" /
           "local.py").read_text(encoding="utf-8")
    assert "from faster_whisper.audio import" not in src
    assert "decode_audio_file" in src


def test_buffer_to_int16_accepts_cffi_like_buffers():
    from flux.audio.devices import buffer_to_int16
    raw = (np.arange(480, dtype=np.int16) * 10).tobytes()
    for view in (raw, memoryview(raw), np.frombuffer(raw, dtype=np.int16)):
        out = buffer_to_int16(view)
        assert out.dtype == np.int16 and out.shape == (480,)
        assert out[10] == 100
    out = buffer_to_int16(memoryview(raw))
    out[0] = 999
    assert np.frombuffer(raw, dtype=np.int16)[0] == 0, "копия не должна alias-ить буфер"


def test_run_async_works():
    from flux.tts.engine import _run_async
    import asyncio
    assert _run_async(asyncio.sleep(0, result=7)) == 7


def test_wake_engine_uses_router_when_key_present(monkeypatch):
    """С ключом Groq слово-активация проверяется точным облачным whisper."""
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"keys": {"groq": "gsk-test"},
                "stt": {"router_for_wake": True}}, save=False)
    router = STTRouter()
    eng = router.wake_engine()
    assert eng is router, "wake идёт через роутер (Groq), не через локальный base"


def test_wake_engine_local_when_no_keys(monkeypatch):
    """Без ключей слово ищется ЛОКАЛЬНЫМ whisper (через роутер: local-first)."""
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"keys": {"groq": "", "openai": ""}}, save=False)
    router = STTRouter()
    eng = router.wake_engine()
    assert eng is router or eng.name == "local"


def test_sapi5_powershell_sets_utf8():
    src = (Path(__file__).resolve().parents[1] / "app" / "flux" / "tts" /
           "engine.py").read_text(encoding="utf-8")
    assert "[Console]::InputEncoding = [System.Text.Encoding]::UTF8" in src, \
        "без UTF-8 на входе SAPI5 говорит моложаву (причина мусорной транскрипции)"


def test_console_has_server_mic_proof_button():
    html = (Path(__file__).resolve().parents[1] / "app" / "flux" / "ui" / "static"
            / "index.html").read_text(encoding="utf-8")
    assert 'id="btnServerMic"' in html and "mic_transcribe" in html


def test_selftest_prints_wake_word():
    src = (Path(__file__).resolve().parents[1] / "app" / "flux" /
           "selftest.py").read_text(encoding="utf-8")
    assert "слово активации" in src and "STTRouter().transcribe" in src


def test_groq_key_does_not_override_local_first(monkeypatch):
    """Ключ Groq больше не ставит облако первым: из РФ оно отвечает 403 по
    региону, основной распознаватель - локальный faster-whisper."""
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"keys": {"groq": "gsk-x"}}, save=False)
    router = STTRouter()
    order = router._order("auto")
    assert order[0] == "local", order
    assert "api" in order            # облако остаётся запасным
    assert router.wake_engine() is router
