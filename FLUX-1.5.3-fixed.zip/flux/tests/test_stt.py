"""Тесты распознавания: mock Whisper-API сервер, фильтр шума, маршрутизатор."""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg
from flux.stt import filter as sf
from flux.stt.api import WhisperAPISTT
from flux.stt.base import Transcript, audio_to_wav_bytes
from flux.stt.router import STTRouter


# --------------------------------------------------------------------- WAV
def test_audio_to_wav_bytes_valid():
    arr = (np.sin(np.linspace(0, 10, 1600)) * 10000).astype(np.int16)
    wav = audio_to_wav_bytes(arr, 16000)
    assert wav[:4] == b"RIFF" and wav[8:12] == b"WAVE"
    import io, wave
    with wave.open(io.BytesIO(wav)) as w:
        assert w.getnframes() == 1600
        assert w.getframerate() == 16000
        assert w.getnchannels() == 1


# ------------------------------------------------------------------ mock API
class _Handler(BaseHTTPRequestHandler):
    response_text = "флюкс включи свет"

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        if not self.path.endswith("/audio/transcriptions"):
            self.send_response(404); self.end_headers(); return
        if not self.headers.get("Authorization", "").startswith("Bearer "):
            self.send_response(401); self.end_headers()
            self.wfile.write(b'{"error":"no key"}'); return
        if b"speech.wav" not in body:
            self.send_response(400); self.end_headers(); return
        payload = json.dumps({"text": self.response_text, "language": "ru"}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *a):
        pass


@pytest.fixture()
def mock_api():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{srv.server_address[1]}/v1"
    srv.shutdown()


def test_api_stt_against_mock_server(mock_api):
    stt = WhisperAPISTT(base_url=mock_api, model="whisper-large-v3-turbo",
                        api_key="test-key", language="ru")
    arr = np.zeros(8000, dtype=np.int16)
    res = stt.transcribe_audio(arr, 16000)
    assert res.text == "флюкс включи свет"
    assert res.engine == "api"


def test_api_stt_requires_key():
    stt = WhisperAPISTT(base_url="http://x", api_key="", )
    assert stt.enabled() is False
    assert stt.available() is False


# ------------------------------------------------------------------- фильтр
@pytest.mark.parametrize("bad", [
    "Субтитры сделал DimaTorzok",
    "спасибо за просмотр, подписывайтесь",
    "Thank you for watching",
    "повтор повтор повтор повтор повтор",
])
def test_hallucinations_detected(bad):
    assert sf.is_hallucination(bad) is True


@pytest.mark.parametrize("good", [
    "включи свет на кухне",
    "который час",
    "найди в интернете погоду",
])
def test_normal_phrases_not_hallucinations(good):
    assert sf.is_hallucination(good) is False


@pytest.mark.parametrize("filler", ["э", "эээ", "ну", "ага", "ммм", "", "   "])
def test_filler_only_detected(filler):
    assert sf.is_filler_only(filler) is True


@pytest.mark.parametrize("real", ["включи свет", "флюкс который час", "давай файл"])
def test_real_not_filler(real):
    assert sf.is_filler_only(real) is False


def test_noise_filter_decisions():
    f = sf.NoiseFilter(enabled=True, min_chars=2)
    assert f.should_drop("")[0] is True
    assert f.should_drop("э")[0] is True
    assert f.should_drop("Субтитры сделал DimaTorzok")[0] is True
    assert f.should_drop("включи свет")[0] is False
    ok, reason = f.should_drop("ну")
    assert ok is True and "паразит" in reason


def test_noise_filter_disabled_passthrough():
    f = sf.NoiseFilter(enabled=False)
    assert f.should_drop("э")[0] is False
    assert f.should_drop("Субтитры")[0] is False


def test_clean_transcript():
    assert sf.clean_transcript("  включи   свет  ") == "включи свет"
    assert sf.clean_transcript("--привет--") == "привет"


# ---------------------------------------------------------------- маршрутизатор
def test_router_prefers_local_when_api_disabled(monkeypatch):
    router = STTRouter()
    router.local = type("L", (), {"available": lambda self: True,
                                  "transcribe_audio": lambda self, a, s=16000:
                                  Transcript(text="локально", engine="local")})()
    router.api = type("A", (), {"enabled": lambda self: False,
                                "transcribe_audio": lambda self, a, s=16000:
                                Transcript(text="api", engine="api")})()
    monkeypatch.setattr("flux.stt.router.config.get",
                        lambda k, d=None: {"stt.engine": "auto"}.get(k, d))
    res = router.transcribe(np.zeros(100, dtype=np.int16))
    assert res.engine == "local"


def test_local_silence_is_final_verdict(monkeypatch):
    """«whisper промолчал» — окончательный вердикт: фолбэк на облако НЕ ходит
    (тишину решает whisper и таймер тишины, а не другой движок)."""
    router = STTRouter()
    router.local = type("L", (), {"available": lambda self: True,
                                  "transcribe_audio": lambda self, a, s=16000:
                                  Transcript(text="", engine="local")})()

    def _boom(self, a, s=16000):
        raise AssertionError("api не должен вызываться на вердикте локального whisper")

    router.api = type("A", (), {"enabled": lambda self: True,
                                "transcribe_audio": _boom})()
    router.ollama = type("O", (), {"available": lambda self: False,
                                   "enabled": lambda self: False})()
    monkeypatch.setattr("flux.stt.router.config.get",
                        lambda k, d=None: {"stt.engine": "auto"}.get(k, d))
    res = router.transcribe(np.zeros(100, dtype=np.int16))
    assert res.engine == "local" and res.text == ""


def test_router_order_local_first(monkeypatch):
    router = STTRouter()
    monkeypatch.setattr("flux.stt.router.config.get",
                        lambda k, d=None: {"stt.engine": "auto"}.get(k, d))
    assert router._order("auto")[0] == "local"


def test_wake_engine_light_model_when_router_for_wake_off(monkeypatch):
    router = STTRouter()
    monkeypatch.setattr("flux.stt.router.config.get",
                        lambda k, d=None: {"stt.router_for_wake": False,
                                           "stt.local.wake_model": "tiny",
                                           "stt.language": "ru",
                                           "stt.local.beam_size": 1}.get(k, d))
    eng = router.wake_engine()
    assert eng.size == "tiny"
    assert eng.name == "local"


# ------------------------------------------- проверенные параметры транскрипции
def test_proven_whisper_params_passed(monkeypatch):
    """Как в wyoming-faster-whisper (STT Home Assistant): Silero VAD внутри
    транскрипции, condition_on_previous_text=False, initial_prompt со словом
    активации, язык зафиксирован."""
    import sys as _sys
    import types

    from flux.stt import local as L

    captured = {}

    class FakeModel:
        def transcribe(self, audio, **kw):
            captured.update(kw)
            return [], types.SimpleNamespace(language="ru")

    fake = types.ModuleType("faster_whisper")
    fake.WhisperModel = lambda *a, **k: FakeModel()
    monkeypatch.setitem(_sys.modules, "faster_whisper", fake)
    monkeypatch.setattr(L, "_models", {})
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    stt = L.LocalWhisperSTT(size="base")
    import numpy as _np
    stt.transcribe_audio(_np.zeros(1600, dtype=_np.int16), 16000)
    assert captured.get("vad_filter") is True
    assert captured.get("condition_on_previous_text") is False
    assert captured.get("language") == "ru"
    assert "Флюкс" in (captured.get("initial_prompt") or "")


def test_vad_filter_falls_back_when_silero_missing(monkeypatch):
    """Нет onnxruntime/Silero -> транскрипция всё равно работает без vad_filter."""
    import sys as _sys
    import types

    from flux.stt import local as L

    captured = {}

    class FakeModel:
        def transcribe(self, audio, **kw):
            if kw.get("vad_filter"):
                raise ImportError("onnxruntime not found")
            captured.update(kw)
            return [], types.SimpleNamespace(language="ru")

    fake = types.ModuleType("faster_whisper")
    fake.WhisperModel = lambda *a, **k: FakeModel()
    monkeypatch.setitem(_sys.modules, "faster_whisper", fake)
    monkeypatch.setattr(L, "_models", {})
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    stt = L.LocalWhisperSTT(size="base")
    import numpy as _np
    stt.transcribe_audio(_np.zeros(1600, dtype=_np.int16), 16000)
    assert captured.get("vad_filter") is False


def test_transcribe_file_no_nameerror(tmp_path, monkeypatch):
    """Аудит-находка: transcribe_file падал с NameError (np не импортирован)."""
    import sys as _sys
    import types

    import numpy as _np
    from wave import open as wave_open

    from flux.stt import local as L

    # wav на диске
    wav = tmp_path / "x.wav"
    with wave_open(str(wav), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
        w.writeframes((_np.sin(_np.linspace(0, 50, 1600)) * 8000)
                      .astype("<i2").tobytes())

    class FakeModel:
        def transcribe(self, audio, **kw):
            assert isinstance(audio, _np.ndarray)
            return [], types.SimpleNamespace(language="ru")

    fake = types.ModuleType("faster_whisper")
    fake.WhisperModel = lambda *a, **k: FakeModel()
    monkeypatch.setitem(_sys.modules, "faster_whisper", fake)
    monkeypatch.setattr(L, "_models", {})
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    stt = L.LocalWhisperSTT(size="base")
    tr = stt.transcribe_file(str(wav))     # раньше: NameError: name 'np'
    assert tr.engine == "local"

@pytest.mark.parametrize("tag", ["Звук.", "музыка", "(смех)", "Смех",
                                 "аплодисменты", "тишина"])
def test_tag_segments_are_hallucinations(tag):
    assert sf.is_hallucination(tag) is True


@pytest.mark.parametrize("cmd", ["включи звук громче", "сделай звук тише",
                                 "включи музыку", "поставь музыку послабее"])
def test_live_commands_with_sound_words_survive(cmd):
    """Раньше «звук»/«музыка» ловились подстрокой и живая команда умирала."""
    assert sf.is_hallucination(cmd) is False


@pytest.mark.parametrize("tail", ["Думаю, что это не было.",
                                  "думаю что это не было",
                                  "Флюкс, включи свет. Думаю, что это не было."])
def test_whisper_tail_hallucination_caught(tail):
    assert sf.is_hallucination(tail) is True



CAPS_TAGS = ["СПОКОЙНАЯ МУЗЫКА", "ТИХИЙ ГОЛОС", "(АПЛОДИСМЕНТЫ)", "ШУМ ВЕТРА"]


@pytest.mark.parametrize("tag", CAPS_TAGS)
def test_caps_tags_are_hallucinations(tag):
    assert sf.is_hallucination(tag) is True


LONG_CAPS = ["ВКЛЮЧИ СВЕТ НА КУХНЕ ПОЖАЛУЙСТА СЕЙЧАС", "Флюкс включи свет"]


@pytest.mark.parametrize("cmd", LONG_CAPS)
def test_caps_command_long_enough_survives(cmd):
    assert sf.is_hallucination(cmd) is False


# ------------------------------------------------------- «субтитровый» хвост
# Доказательство из живого прогона 2026-10-09 (edge-tts ru-Ru-DmitryNeural ->
# faster-whisper base): озвучено «Флюкс, включи свет на кухне», распознано
# «Флюкс, включи, свет на кухне. Повторяю.» — хвоста в речи не было. В том же
# прогоне вместо него прилетал Caps-тег «СПОКОЙНАЯ МУЗЫКА».
CREDIT_TAIL_CASES = [
    ("Флюкс, включи, свет на кухне. Повторяю.", "Флюкс, включи, свет на кухне"),
    ("включи свет на кухне. Повторяю", "включи свет на кухне"),
    ("флюкс который час. Повторяю.", "флюкс который час"),
    ("Флюкс, включи свет на кухне. СПОКОЙНАЯ МУЗЫКА",
     "Флюкс, включи свет на кухне"),
    ("найди в интернете погоду. перевод", "найди в интернете погоду"),
    ("включи музыку. титры", "включи музыку"),
]


@pytest.mark.parametrize("raw,clean", CREDIT_TAIL_CASES)
def test_credit_tail_is_cut_from_live_command(raw, clean):
    assert sf.strip_hallucination_tail(raw) == clean


def test_credit_tail_keeps_live_commands():
    """«повтори ещё раз» / «переведи на английский» — ЖИВЫЕ команды:
    подстрокой в HALLUCINATION_PHRASES такие слова класть нельзя."""
    for cmd in ("флюкс, повтори ещё раз", "флюкс, переведи на английский",
                "включи звук громче", "поставь музыку послабее"):
        assert sf.strip_hallucination_tail(cmd) == cmd, cmd
        assert sf.is_hallucination(cmd) is False, cmd


def test_credit_tail_needs_a_real_head():
    """Одинокое «Повторяю.» не режем в пустоту — решение о мусоре
    принимает is_hallucination/is_filler_only, а не обрезка хвоста."""
    assert sf.strip_credit_tail("Повторяю.") == "Повторяю."


def test_credits_tail_without_marker_is_not_cut():
    """КАПС-хвост без слова-маркера (музыка/звук/шум…) — это речь
    пользователя капсом, а не бирка whisper: не трогаем."""
    raw = "Флюкс, включи свет. ВКЛЮЧИ СВЕТ"
    assert sf.strip_credit_tail(raw) == raw
