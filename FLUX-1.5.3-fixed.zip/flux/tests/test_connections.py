"""Подключения в стиле Open WebUI: Ollama напрямую + OpenAI-совместимые
(base_url + ключ), env-переменные OLLAMA_BASE_URL / OPENAI_API_BASE_URLS /
OPENAI_API_KEYS, фолбэк чата и STT через подключения."""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux import config as cfg
from flux.llm.ollama_client import OllamaClient, OllamaError
from flux.stt.api import transcribe_with_connections


class OpenAIHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    with_stt = True

    def do_POST(self):
        body = self.rfile.read(int(self.headers["Content-Length"]))
        if self.path.endswith("/chat/completions"):
            req = json.loads(body)
            assert req.get("tools"), "инструменты должны передаваться провайдеру"
            payload = json.dumps({
                "model": req.get("model"),
                "choices": [{"message": {
                    "role": "assistant",
                    "content": "*-Ответ через OpenAI-подключение-*",
                    "tool_calls": [{"id": "c1", "type": "function",
                                    "function": {"name": "current_time",
                                                 "arguments": "{}"}}],
                }}],
                "usage": {"prompt_tokens": 5, "completion_tokens": 7},
            }).encode()
        elif self.path.endswith("/audio/transcriptions") and self.with_stt:
            payload = json.dumps({"text": "флюкс включи свет"}).encode()
        else:
            self.send_response(404); self.end_headers(); return
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers(); self.wfile.write(payload)

    def log_message(self, *a):
        pass


@pytest.fixture()
def openai_mock():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), OpenAIHandler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}/v1"
    srv.shutdown()


def test_env_overrides_like_open_webui(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    monkeypatch.setenv("OLLAMA_BASE_URL", "http://my-ollama:11434/")
    monkeypatch.setenv("OPENAI_API_BASE_URLS",
                       "https://openrouter.ai/api/v1;https://api.xkiro.com/v1")
    monkeypatch.setenv("OPENAI_API_KEYS", "sk-one,sk-two")
    c = cfg.load(force=True)
    assert c["llm"]["endpoint"] == "http://my-ollama:11434"
    conns = c["llm"]["connections"]
    assert [x["base_url"] for x in conns] == ["https://openrouter.ai/api/v1",
                                              "https://api.xkiro.com/v1"]
    assert [x["api_key"] for x in conns] == ["sk-one", "sk-two"]
    monkeypatch.delenv("OLLAMA_BASE_URL"); monkeypatch.delenv("OPENAI_API_BASE_URLS")
    monkeypatch.delenv("OPENAI_API_KEYS")


def test_chat_falls_back_to_connection(openai_mock, monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"llm": {"endpoint": "http://127.0.0.1:1",   # мёртвый нативный
                        "cloud_endpoint": "http://127.0.0.1:1",
                        "model": "gemma4:31b-cloud", "api_key": "",
                        "fallback_models": [],
                        "connections": [{"name": "openai-1",
                                         "base_url": openai_mock,
                                         "api_key": "sk-test",
                                         "model": "google/gemma-4-31b"}]}},
               save=False)
    client = OllamaClient(timeout=3)
    res = client.chat([{"role": "user", "content": "привет"}],
                      tools=[{"type": "function",
                              "function": {"name": "current_time",
                                           "description": "время",
                                           "parameters": {"type": "object",
                                                          "properties": {}}}}])
    assert "Ответ через OpenAI-подключение" in res.content
    assert res.tool_calls and res.tool_calls[0].name == "current_time"
    assert res.endpoint == openai_mock
    assert res.prompt_tokens == 5


def test_chat_raises_when_everything_dead(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"llm": {"endpoint": "http://127.0.0.1:1",
                        "cloud_endpoint": "http://127.0.0.1:1",
                        "model": "x", "fallback_models": [],
                        "connections": [{"base_url": "http://127.0.0.1:1/v1"}]}},
               save=False)
    client = OllamaClient(timeout=2)
    with pytest.raises(OllamaError):
        client.chat([{"role": "user", "content": "привет"}])


def test_stt_via_connections(openai_mock, monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"llm": {"connections": [{"base_url": openai_mock,
                                         "api_key": "sk", "stt_model": "whisper-1"}]}},
               save=False)
    tr = transcribe_with_connections(b"RIFF\x00\x00\x00\x00WAVE" + b"\x00" * 16)
    assert tr.text == "флюкс включи свет" and tr.engine == "openai-conn"


def test_stt_connections_skip_404(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"llm": {"connections": [{"base_url": "http://127.0.0.1:1/v1"}]}},
               save=False)
    tr = transcribe_with_connections(b"RIFF\x00\x00\x00\x00WAVE")
    assert tr.text == "" and tr.engine == "none"


# ------------------------------------------------- правки по live-логу 02:03
def test_cuda_failure_falls_back_to_cpu(monkeypatch):
    """cublas64_12.dll отсутствует -> ctranslate2 обязан упасть на CPU."""
    import sys as _sys
    import types

    from flux.stt import local as L

    calls = []

    class FakeModel:
        def __init__(self, size, **kw):
            calls.append(kw.get("device"))
            if kw.get("device") == "cuda":
                raise RuntimeError("Library cublas64_12.dll is not found")

        def transcribe(self, *a, **kw):
            return [], types.SimpleNamespace(language="ru")

    fake_mod = types.ModuleType("faster_whisper")
    fake_mod.WhisperModel = FakeModel
    monkeypatch.setitem(_sys.modules, "faster_whisper", fake_mod)
    monkeypatch.setattr(L, "_models", {})
    monkeypatch.setattr(cfg, "_CONFIG", None)
    cfg.load(force=True)
    cfg.update({"stt": {"local": {"compute_type": "int8", "device": "cuda",
                                  "cpu_threads": 1, "download_root": ""}}},
               save=False)
    model, eff = L.get_model("tiny", device="cuda")
    assert calls == ["cuda", "cpu"], f"ожидал фолбэк cuda->cpu, получено {calls}"
    assert model is not None and eff == "tiny"


def test_noise_suppression_off_by_default(monkeypatch):
    monkeypatch.setattr(cfg, "_CONFIG", None)
    c = cfg.load(force=True)
    assert c["stt"]["noise_filter"]["enabled"] is False, \
        "шумодав выключен по умолчанию: активация чисто по whisper"
    assert c["wake"]["min_confidence"] == 0.0


def test_chat_endpoint_runs_agent(monkeypatch):
    import json as _json
    import urllib.request

    from flux.ui.server import UiServer

    class App:
        def __init__(self):
            self.got = []

        def public_state(self):
            return {"state": "idle"}

        def recent_history(self, limit=40):
            return []

        def console_action(self, action, body):
            return {}

        def resolve_confirmation(self, cid, answer):
            return True

        def on_config_changed(self):
            return None

        def console_chat(self, text, speak=False, browser_speak=False,
                         think=False, web=False):
            self.got.append((text, speak, browser_speak, think, web))
            return {"ok": True}

    app = App()
    srv = UiServer(app)
    cfg.update({"ui": {"port": 8899}}, save=False)
    assert srv.start()
    try:
        req = urllib.request.Request(
            "http://127.0.0.1:8899/api/chat",
            data=_json.dumps({"text": "привет", "browser_speak": True}).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as r:
            payload = _json.loads(r.read())
        assert payload == {"ok": True}
        req = urllib.request.Request(
            "http://127.0.0.1:8899/api/chat",
            data=_json.dumps({"text": "погода", "think": True,
                              "web": True}).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as r:
            _json.loads(r.read())
        assert app.got == [("привет", False, True, False, False),
                           ("погода", False, False, True, True)], \
            "пилюли DeepSeek (think/web) должны доходить до приложения"
    finally:
        srv.stop()
        cfg.update({"ui": {"port": 8790}}, save=False)


def test_console_has_chat_and_browser_audio():
    html = (Path(__file__).resolve().parents[1] / "app" / "flux" / "ui" / "static"
            / "index.html").read_text(encoding="utf-8")
    for needle in ('id="chatInput"', 'id="btnChatSend"', 'id="btnChatMic"',
                   'id="chatBrowserTts"', 'id="bttsVoice"',
                   "webkitSpeechRecognition", "speechSynthesis",
                   'id="chatServerTts"'):
        assert needle in html, f"в консоли нет {needle}"
