"""Словесный поток: решения принимает ТОЛЬКО whisper, без порогов шума.

Архитектура (требование пользователя): whisper сам определяет тишину и
отдаёт FLUX ОДНО целое сообщение — не куски и не «догадки по громкости».

В тестах время — это ШКАЛА ЗВУКА, который прослушал whisper:
  * feed(text, now/end_sec=T)      — текст без меток времени (T = позиция);
  * feed(tr=..., end_sec=T, sec=L) — окно звука [T-L, T] и СЛОВА С МЕТКАМИ
    ВРЕМЕНИ whisper (word.start/word.end внутри окна).
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from flux.stt.base import Transcript
from flux.voice.stream import AWAKE, IDLE, WordStream
from flux.voice.utterance import Utterance, UtteranceAssembler, Word
from flux.wakeword import WakeDetector


def make_stream(idle=5.0, wake_idle=1.2, max_message=60.0):
    return WordStream(WakeDetector(words=["флюкс"], sensitivity=0),
                      word_idle_sec=idle, keep_sec=8.0, wake_idle_sec=wake_idle,
                      max_message_sec=max_message)


def tr(text, words, dur=3.4, engine="local", model="base"):
    return Transcript(text=text, engine=engine, model=model, duration=dur,
                      window_sec=dur, words=list(words))


# ------------------------------------------------------- базовое поведение
def test_wake_with_command_sends_whole_message():
    st = make_stream()
    st.feed("флюкс открой браузер", 100.0)          # whisper услышал слова
    evs = st.feed("", 101.5)                        # 1.5 c молчания: ещё рано
    assert not [e for e in evs if e.kind == "send"], \
        "команда не уходит по кускам/заранее — ждём 5 c молчания whisper"
    evs = st.feed("", 105.5)                        # 5.5 c молчания -> готово
    kinds = [e.kind for e in evs]
    assert "send" in kinds
    ev = [e for e in evs if e.kind == "send"][0]
    assert ev.text == "открой браузер"
    assert isinstance(ev.utterance, Utterance)      # отдали ЦЕЛОЕ сообщение
    assert ev.utterance.silence_sec >= 5.0
    assert st.state == IDLE
    assert st.messages_sent == 1


def test_wake_only_then_words_then_idle_sends():
    st = make_stream(idle=5.0)
    evs = st.feed("флюкс", 100.0)
    evs += st.feed("", 101.5)                       # «Слушаю» после 1.5 c молчания
    assert [e.kind for e in evs if e.kind != "words"] == ["wake_only"]
    assert st.state == AWAKE
    evs = st.feed("который час", 103.0)
    assert st.state == AWAKE and not [e for e in evs if e.kind == "send"]
    evs = st.feed("", 108.0)                        # whisper молчит 5 c
    sent = [e for e in evs if e.kind == "send"]
    assert sent and sent[0].text == "который час"
    assert st.state == IDLE


def test_no_wake_no_send():
    st = make_stream()
    for t in (100.0, 103.0, 110.0):
        evs = st.feed("просто разговор вокруг", t)
        assert not [e for e in evs if e.kind == "send"]
    assert st.state == IDLE


def test_hallucinations_are_not_words():
    st = make_stream()
    evs = st.feed("(музыка)", 100.0)
    assert [e.kind for e in evs] == []
    st.feed("флюкс [аплодисменты] включи свет", 101.0)
    evs = st.feed("", 107.0)                        # 6 c молчания
    sent = [e for e in evs if e.kind == "send"]
    assert sent and "включи свет" in sent[0].text


def test_old_words_pruned():
    st = make_stream()
    st.feed("флюкс", 100.0)
    st.feed("это было давно и не должно матчиться снова", 120.0)
    assert st.chunks and all(c.at >= 112.0 for c in st.chunks)


def test_idle_without_words_does_not_send():
    st = make_stream()
    evs = st.feed("", 100.0)
    evs += st.feed("", 106.0)
    assert not [e for e in evs if e.kind == "send"]


# ---------------------------- НОВОЕ: одно целое сообщение от whisper (5 c тишины)
def test_message_is_sent_once_and_whole():
    """Фраза из 4 кусков звука -> модель получает ОДИН целый текст, один раз."""
    st = make_stream(idle=5.0)
    sends = []
    for piece, end in (("флюкс", 3.0), ("найди в интернете", 6.0),
                       ("погоду в москве", 9.0), ("на завтра", 12.0)):
        evs = st.feed(piece, end_sec=end)
        sends += [e for e in evs if e.kind == "send"]
    assert not sends, "пока whisper не замолчал — ничего не отправляется"
    assert st.partial == "флюкс найди в интернете погоду в москве на завтра"
    evs = st.feed("", end_sec=17.5)                 # 5.5 c тишины по whisper
    sends = [e for e in evs if e.kind == "send"]
    assert len(sends) == 1
    assert sends[0].text == "найди в интернете погоду в москве на завтра"
    utt = sends[0].utterance
    assert utt.word_count == 4                      # 4 куска = 4 записи слов
    assert utt.silence_sec >= 5.0
    assert st.messages_sent == 1
    assert st.state == IDLE
    assert st.partial == ""                         # копилка пуста


def test_nothing_is_sent_while_whisper_still_hears_words():
    """Пока whisper даёт новые слова — сообщение НЕ отправляется (не рвём фразу)."""
    st = make_stream(idle=5.0)
    sends = []
    for i in range(20):
        sends += [e for e in st.feed("продолжаю говорить", end_sec=3.0 * (i + 1))
                  if e.kind == "send"]
    assert not sends
    assert st.partial.count("продолжаю") == 20


def test_word_timestamps_decide_the_timer_not_wall_clock():
    """Таймер конца фразы — метки времени WHISPER (word.start/word.end)."""
    st = make_stream(idle=5.0, wake_idle=99.0)      # ранний отклик выключен
    evs = st.feed(tr=tr("флюкс включи свет",
                        [Word("флюкс", 0.2, 0.9), Word("включи", 1.0, 1.6),
                         Word("свет", 1.7, 2.2)]),
                  end_sec=103.4, sec=3.4)           # окно звука [100.0, 103.4]
    assert not [e for e in evs if e.kind == "send"]
    assert st.asm.last_word_end == pytest.approx(102.2)     # 100.0 + 2.2
    assert st.asm.idle_sec_now == pytest.approx(1.2, abs=0.01)
    # ещё 2 c звука без слов -> 3.2 c молчания: рано
    evs = st.feed(tr=tr("", [], dur=2.0), end_sec=105.4, sec=2.0)
    assert not [e for e in evs if e.kind == "send"]
    # ещё 2 c -> 5.2 c молчания по шкале whisper: сообщение готово
    evs = st.feed(tr=tr("", [], dur=2.0), end_sec=107.4, sec=2.0)
    sent = [e for e in evs if e.kind == "send"]
    # слово-активация в команду не идёт: модели уходит ТОЛЬКО команда
    assert sent and sent[0].text == "включи свет"
    utt = sent[0].utterance
    assert utt.silence_sec >= 5.0
    assert utt.engine == "local" and utt.model == "base"
    assert utt.word_count == 3
    assert [w.text for w in utt.words] == ["флюкс", "включи", "свет"]


def test_overlap_does_not_duplicate_words():
    """Окна с нахлёстом: одно и то же слово не должно удваиваться."""
    st = make_stream(idle=5.0, wake_idle=99.0)
    st.feed(tr=tr("флюкс включи", [Word("флюкс", 0.2, 0.9),
                                   Word("включи", 2.6, 3.2)]),
            end_sec=103.4, sec=3.4)
    st.feed(tr=tr("включи свет", [Word("включи", 0.2, 0.8),
                                  Word("свет", 1.0, 1.5)]),
            end_sec=106.8, sec=3.4)
    assert st.partial == "флюкс включи свет", st.partial


def test_command_waits_for_full_silence_even_with_word_timestamps():
    """Даже с точными метками слов команда уходит только после 5 c молчания:
    сообщение должно быть ЦЕЛЫМ, а не порванным на полуслове."""
    st = make_stream(idle=5.0, wake_idle=1.2)
    evs = st.feed(tr=tr("флюкс включи свет",
                        [Word("флюкс", 0.2, 0.9), Word("включи", 1.0, 1.6),
                         Word("свет", 1.7, 2.2)]),
                  end_sec=103.4, sec=3.4)           # 1.2 c молчания после «свет»
    assert not [e for e in evs if e.kind == "send"]
    evs = st.feed(tr=tr("", [], dur=2.0), end_sec=105.4, sec=2.0)
    assert not [e for e in evs if e.kind == "send"]
    evs = st.feed(tr=tr("", [], dur=2.0), end_sec=107.4, sec=2.0)
    sent = [e for e in evs if e.kind == "send"]
    assert sent and sent[0].text == "включи свет"
    assert st.messages_sent == 1


def test_bare_wake_word_gives_listening_prompt():
    st = make_stream(idle=5.0, wake_idle=1.2)
    evs = st.feed(tr=tr("флюкс", [Word("флюкс", 0.2, 0.9)]),
                  end_sec=103.4, sec=3.4)           # 2.5 c молчания
    assert [e.kind for e in evs if e.kind != "words"] == ["wake_only"]
    assert st.state == AWAKE


def test_long_monologue_is_cut_by_max_message_sec():
    st = make_stream(idle=5.0, wake_idle=1.2, max_message=10.0)
    st.feed("флюкс", end_sec=0.0)
    st.feed("", end_sec=2.0)                        # «Слушаю»
    assert st.state == AWAKE
    evs = []
    for t in (4.0, 6.0, 8.0, 10.0, 12.0, 14.0):
        evs += st.feed("рассказываю длинную историю", end_sec=t)
    sent = [e for e in evs if e.kind == "send"]
    assert sent and sent[0].utterance.forced
    assert sent[0].text.count("рассказываю") == 5   # обрезано на 10 c


def test_silence_left_shrinks_for_ui():
    """Обратный отсчёт «сколько секунд осталось, чтобы продолжить фразу»."""
    st = make_stream(idle=5.0, wake_idle=1.2)
    evs = st.feed("флюкс", end_sec=0.0)
    evs += st.feed("", end_sec=1.5)                 # «Слушаю»
    assert [e.kind for e in evs if e.kind == "wake_only"]
    st.feed(tr=tr("включи свет", [Word("включи", 0.1, 0.6),
                                  Word("свет", 0.7, 1.2)], dur=3.4),
            end_sec=3.4, sec=3.4)                   # окно [0.0, 3.4]
    assert st.silence_left == pytest.approx(4.3)    # 5 - (3.4 - 1.2)
    st.feed("", end_sec=5.4)
    assert st.silence_left == pytest.approx(2.3)
    st.feed("", end_sec=8.4)                        # фраза закрыта и отправлена
    assert st.silence_left == 0.0
    assert st.last_message is not None
    assert st.last_message.text == "включи свет"


def test_word_idle_sec_is_reconfigurable():
    st = make_stream(idle=5.0)
    st.word_idle_sec = 2.0
    assert st.asm.idle_sec == 2.0
    st.feed("флюкс запомни это", end_sec=0.0)
    evs = st.feed("", end_sec=2.5)                  # 2.5 c >= 2.0
    assert [e for e in evs if e.kind == "send"]


# ------------------------------------------------------------------- копилка
def test_assembler_reports_silent_pushes():
    asm = UtteranceAssembler(idle_sec=5.0)
    asm.push(text="привет", end_sec=3.0, sec=3.0)
    asm.push(text="", end_sec=6.0, sec=3.0)
    assert asm.pushes == 2 and asm.silent_pushes == 1
    assert asm.partial == "привет"


def test_assembler_finish_returns_none_on_empty():
    asm = UtteranceAssembler(idle_sec=1.0)
    assert asm.finish() is None


def test_assembler_ignores_bracket_noise():
    asm = UtteranceAssembler(idle_sec=5.0)
    asm.push(text="(музыка) [аплодисменты]", end_sec=3.0, sec=3.0)
    assert asm.empty


def test_assembler_timeline_never_goes_back():
    asm = UtteranceAssembler(idle_sec=5.0)
    asm.push(text="привет", end_sec=10.0, sec=3.0)
    asm.push(text="", end_sec=4.0, sec=3.0)         # «кусок из прошлого»
    assert asm.now == 10.0 and asm.cursor == 10.0

def test_awake_session_times_out(monkeypatch):
    """«Слушаю» сказано, пользователь молчит — сессия закрывается сама."""
    st = make_stream(idle=5.0, wake_idle=1.2)
    st.awake_timeout_sec = 15.0
    clock = {"t": 1000.0}
    import time as _t
    monkeypatch.setattr(_t, "monotonic", lambda: clock["t"])
    st.feed("флюкс", end_sec=0.0)
    st.feed("", end_sec=1.5)
    assert st.state == AWAKE
    assert st.tick() is False
    clock["t"] += 16.0
    assert st.tick() is True
    assert st.state == IDLE


def test_hallucination_tail_cut_from_words_too():
    """Хвост-галлюцинация в ОДНОМ сегменте с командой: команда уезжает ИИ,
    хвост — нет (и словами из tr он тоже не просачивается)."""
    st = make_stream()
    t1 = tr("Флюкс включи свет. Думаю, что это не было.", [
        Word("Флюкс", 0.0, 0.4), Word("включи", 0.5, 0.9),
        Word("свет.", 1.0, 1.4), Word("Думаю,", 1.5, 1.9),
        Word("что", 2.0, 2.2), Word("это", 2.3, 2.5),
        Word("не", 2.6, 2.8), Word("было.", 2.9, 3.2)])
    st.feed(tr=t1, end_sec=3.4, sec=3.4)
    evs = st.feed("", 9.0)
    send = [e for e in evs if e.kind == "send"]
    assert send, "команда должна уйти целым сообщением"
    assert send[0].text.startswith("включи свет"), send[0].text
    assert "Думаю" not in send[0].text and "было" not in send[0].text
    assert all(w.text.strip(".,") not in ("Думаю", "было")
               for w in send[0].utterance.words)
