"""СБОРКА СООБЩЕНИЯ: whisper решает, когда фраза закончена, и отдаёт её ЦЕЛИКОМ.

Ответ на вопрос пользователя «а как whisper отправит это Флюксу?» — никак:
whisper это библиотека, он только ВОЗВРАЩАЕТ слова. «Отправкой» владеет FLUX,
но решает всё равно whisper, и вот как:

  1. микрофон -> сырое кольцо (без AGC/шумодава/гейтов) -> кусок в whisper;
  2. whisper возвращает СЛОВА С СОБСТВЕННЫМИ МЕТКАМИ ВРЕМЕНИ
     (faster-whisper word_timestamps=True: word.start / word.end в секундах
      звука) — это ЕГО шкала времени, а не часы FLUX;
  3. если в куске слов нет — whisper сам сказал «тут речи не было»
     (это решает Silero VAD внутри транскрипции, а не порог громкости);
  4. сообщение считается ЗАКОНЧЕННЫМ, когда по шкале whisper после
     последнего слова прошло stream.word_idle_sec (5 c) прослушанного звука;
  5. тогда всё накопленное отдаётся ОДНИМ ЦЕЛЫМ сообщением (Utterance) —
     модели уходит весь текст сразу, никогда не по кускам.

Акустики (дБ, пороги, «тишина по громкости») здесь нет вообще: единственный
источник истины — слова и метки времени whisper.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

from ..stt.filter import is_filler_only, is_hallucination


@dataclass
class Word:
    """Одно слово whisper с ЕГО меткой времени (секунды внутри звука)."""

    text: str
    start: float
    end: float
    prob: float = 0.0

    def clean(self) -> str:
        return self.text.strip()


@dataclass
class Utterance:
    """ГОТОВОЕ сообщение пользователя: то самое «одно целое», что ждёт ИИ."""

    text: str
    words: list = field(default_factory=list)
    started_at: float = 0.0        # метка whisper первого слова
    ended_at: float = 0.0          # метка whisper последнего слова
    heard_until: float = 0.0       # до какой секунды звука дослушали
    silence_sec: float = 0.0       # сколько whisper молчал после конца фразы
    engine: str = ""
    model: str = ""
    forced: bool = False           # закрыто по max_sec (очень длинная фраза)

    @property
    def word_count(self) -> int:
        return len(self.words)


def _words_from_transcript(tr) -> list:
    """Слова из Transcript: word_timestamps -> сегменты -> просто текст."""
    out: list = []
    for w in (getattr(tr, "words", None) or []):
        if isinstance(w, Word):
            out.append(w)
        elif isinstance(w, dict):
            out.append(Word(str(w.get("word") or w.get("text") or ""),
                            float(w.get("start") or 0.0),
                            float(w.get("end") or 0.0),
                            float(w.get("prob") or 0.0)))
        else:                                   # объект faster-whisper Word
            out.append(Word(str(getattr(w, "word", "")),
                            float(getattr(w, "start", 0.0) or 0.0),
                            float(getattr(w, "end", 0.0) or 0.0),
                            float(getattr(w, "probability", 0.0) or 0.0)))
    out = [w for w in out if w.text.strip()]
    if out:
        return out
    for s in (getattr(tr, "segments", None) or []):
        if isinstance(s, dict) and str(s.get("text") or "").strip():
            out.append(Word(str(s["text"]).strip(), float(s.get("start") or 0.0),
                            float(s.get("end") or 0.0)))
    return out


def words_from_any(tr=None, text: str = "",
                   words: Optional[Sequence] = None) -> list:
    """Единая точка: что бы ни вернул движок — делаем список Word."""
    if words:
        out = []
        for w in words:
            if isinstance(w, Word):
                out.append(w)
            elif isinstance(w, dict):
                out.append(Word(str(w.get("word") or w.get("text") or ""),
                                float(w.get("start") or 0.0),
                                float(w.get("end") or 0.0),
                                float(w.get("prob") or 0.0)))
            else:
                out.append(Word(str(w[0]), float(w[1]), float(w[2])))
        return out
    if tr is not None:
        got = _words_from_transcript(tr)
        if got:
            return got
        text = text or str(getattr(tr, "text", "") or "")
    if text and text.strip():
        return [Word(clean_word_text(text), 0.0, 0.0)]   # меток нет
    return []


def utterance_from_text(text: str, engine: str = "external",
                        model: str = "") -> Utterance:
    """Целое сообщение из ГОТОВОГО текста (whisper положил .txt, внешний сервис).

    Меток времени у такого текста нет — слова существуют, но start/end = 0:
    таймер тишины whisper по ним не нужен, сообщение уже закончено.
    """
    clean = " ".join((text or "").split())
    return Utterance(text=clean, words=words_from_any(text=clean),
                     started_at=0.0, ended_at=0.0, heard_until=0.0,
                     silence_sec=0.0, engine=engine, model=model)


def clean_word_text(text: str) -> str:
    """Убираем служебные пометки whisper вида (музыка)/[аплодисменты]."""
    import re

    text = re.sub(r"[\[\(][^\]\)]{0,40}[\]\)]", " ", text or "")
    return " ".join(text.split()).strip()


class UtteranceAssembler:
    """Копилка слов whisper -> одно законченное сообщение.

      idle_sec — сколько whisper должен молчать (по ЕГО шкале), чтобы фраза
                 считалась законченной (stream.word_idle_sec, 5 c);
      max_sec  — предохранитель от бесконечного монолога (stream.max_message_sec).
    """

    def __init__(self, idle_sec: float = 5.0, max_sec: float = 60.0) -> None:
        self.idle_sec = float(idle_sec)
        self.max_sec = float(max_sec)
        self.words: list = []
        self.now: float = 0.0            # до какой секунды звука дослушали
        self.cursor: float = 0.0         # граница уже обработанного звука
        self.last_word_end: float = 0.0
        self.last_push_end: float = 0.0
        self.last_push_words: int = 0
        self.engine: str = ""
        self.model: str = ""
        self.pushes: int = 0
        self.silent_pushes: int = 0
        self.started_timeline: float = 0.0
        self.utt_start: float = 0.0     # когда начали копить это сообщение
        self.messages: int = 0
        self.reset()

    # ------------------------------------------------------------------ state
    def reset(self) -> None:
        self.words = []
        self.last_word_end = 0.0
        self.engine = ""
        self.model = ""
        self.last_push_words = 0
        self.utt_start = 0.0

    @property
    def empty(self) -> bool:
        return not self.words

    @property
    def partial(self) -> str:
        """Незаконченное сообщение (живой показ в консоли)."""
        return " ".join(w.clean() for w in self.words).strip()

    @property
    def idle_sec_now(self) -> float:
        """Сколько whisper молчит после последнего слова (по его шкале)."""
        if not self.words:
            return 0.0
        return max(0.0, self.now - self.last_word_end)

    @property
    def silence_left(self) -> float:
        """Сколько секунд осталось, чтобы продолжить фразу (для UI)."""
        if not self.words:
            return 0.0
        return max(0.0, self.idle_sec - self.idle_sec_now)

    @property
    def started_at(self) -> float:
        return self.words[0].start if self.words else 0.0

    # ------------------------------------------------------------------- push
    def push(self, tr=None, text: str = "", words: Optional[Sequence] = None,
             now: Optional[float] = None, end_sec: Optional[float] = None,
             sec: Optional[float] = None) -> Optional[Utterance]:
        """Один кусок звука, прослушанный whisper.

        tr / text / words — ЧТО услышал whisper;
        end_sec           — до какой секунды ЗВУКА дослушали (шкала whisper);
        sec               — сколько секунд звука было в этом куске;
        now               — то же, что end_sec (позиция на шкале звука).
        Возвращает Utterance, если сообщение закончено, иначе None.
        """
        self.pushes += 1
        got = words_from_any(tr=tr, text=text, words=words)
        if tr is not None:
            self.engine = getattr(tr, "engine", "") or self.engine
            self.model = getattr(tr, "model", "") or self.model

        # --- где мы в шкале whisper после этого куска
        if end_sec is None and tr is not None:
            dur = float(getattr(tr, "duration", 0.0) or 0.0)
            if dur:
                end_sec = self.cursor + dur
        # --- позиция на шкале звука (монотонно, назад не идёт)
        cand = [v for v in (end_sec, now, self.now) if v is not None]
        pos = max(float(v) for v in cand) if cand else 0.0
        if not self.started_timeline:
            self.started_timeline = pos
        # --- окно звука: [pos - длительность куска, pos]
        if sec is None:
            sec = float(getattr(tr, "window_sec", 0.0) or 0.0) if tr is not None else 0.0
            if not sec:
                sec = pos - self.cursor                 # сколько нового звука
        sec = max(0.0, float(sec or 0.0))
        win_start = max(self.cursor, min(pos - sec, pos))
        win_end = max(pos, win_start)
        offset = win_start

        # --- новые слова (нахлёст окон не дублируем)
        fresh = 0
        for w in got:
            clean = clean_word_text(w.text)
            if not clean or is_hallucination(clean) or is_filler_only(clean):
                continue                     # whisper-мусор словами не считаем
            has_ts = bool(float(w.end or 0.0) > 0.0)
            rel_start = float(w.start or 0.0)      # метка внутри окна
            rel_end = float(w.end or 0.0)
            if not has_ts:
                # у движка нет word timestamps: слово «закончилось вместе
                # с куском» — этого достаточно для таймера тишины
                rel_start, rel_end = 0.0, 0.0
            start = rel_start + offset
            end = rel_end + offset if has_ts else win_end
            if self.words:
                last = self.words[-1]
                if end <= win_start + 0.05:
                    continue                     # слово целиком в прошлом окне
                # нахлёст окон: то же слово распознано повторно
                if (clean.lower() == last.clean().lower()
                        and (end <= self.cursor + 0.25
                             or (has_ts and rel_start < (win_end - win_start) * 0.35))):
                    continue
            start = max(start, offset)
            end = max(min(end, win_end), start + 0.01)
            self.words.append(Word(clean, start, end, float(w.prob or 0.0)))
            self.last_word_end = max(self.last_word_end, end)
            if not self.utt_start:
                self.utt_start = offset
            fresh += 1
        self.last_push_words = fresh
        if fresh == 0:
            self.silent_pushes += 1          # whisper: «в этом куске слов нет»

        self.now = pos
        self.last_push_end = pos
        self.cursor = pos                    # следующий кусок начнётся отсюда

        if not self.words:
            return None                      # говорить нечего — сообщения нет
        if self.idle_sec_now >= self.idle_sec:
            return self.finish()
        if self.max_sec and self.utt_start \
                and (self.now - self.utt_start) >= self.max_sec:
            return self.finish(forced=True)
        return None

    # ----------------------------------------------------------------- finish
    def finish(self, forced: bool = False) -> Optional[Utterance]:
        """Отдать сообщение ЦЕЛИКОМ и очистить копилку."""
        text = self.partial
        if not text.strip():
            self.reset()
            return None
        utt = Utterance(text=text, words=list(self.words),
                        started_at=self.started_at,
                        ended_at=self.last_word_end,
                        heard_until=self.now,
                        silence_sec=round(self.idle_sec_now, 3),
                        engine=self.engine, model=self.model, forced=forced)
        self.messages += 1
        self.reset()
        return utt
