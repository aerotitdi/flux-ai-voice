"""Словесный поток: whisper решает ВСЁ, а FLUX получает ОДНО целое сообщение.

Правила пользователя (без акустических порогов — в комнате тишины не бывает):

  * любой звук с микрофона уходит в whisper СЫРЫМ;
  * тишину определяет САМ whisper: нет слов в куске = «тут речи не было»
    (это решает Silero VAD внутри транскрипции, а не порог громкости);
  * конец фразы — когда после последнего СЛОВА whisper прошло
    stream.word_idle_sec (5 c) прослушанного звука (шкала времени whisper);
  * когда фраза закончена, всё накопленное отдаётся ОДНИМ ЦЕЛЫМ сообщением
    (voice.utterance.Utterance) — модели уходит весь текст сразу, не кусками.

Состояния:
  IDLE   — ждём слово-активацию («флюкс») в ЦЕЛОМ сообщении;
           «флюкс + команда» -> команда модели сразу (одним сообщением);
           только «флюкс»    -> «Слушаю» и AWAKE;
  AWAKE  — копим сообщение; whisper замолчал на word_idle_sec -> ОДНО целое
           сообщение уходит модели, сессия закрывается в IDLE.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Callable, Optional, Sequence

from ..stt.filter import (is_filler_only, strip_hallucination_tail)
from ..wakeword import WakeDetector, WakeMatch
from .utterance import (Utterance, UtteranceAssembler, clean_word_text,
                        words_from_any)

BRACKET_TAGS = re.compile(r"[\[\(][^\]\)]{0,40}[\]\)]")

IDLE = "idle"
AWAKE = "awake"


def _words_within_head(tr, head: str) -> list:
    """Слова сегмента, лежащие ВНУТРИ оставленной головы (хвост галлюцинации
    не должен доезжать до сообщения словами из tr)."""
    from ..stt.filter import _norm

    head_n = _norm(head)
    out, acc = [], ""
    for w in words_from_any(tr=tr):
        wn = _norm(w.text)
        if not wn:
            continue
        cand = (acc + " " + wn).strip()
        if not head_n.startswith(cand):
            break
        acc = cand
        out.append(w)
    return out


@dataclass
class StreamEvent:
    kind: str                     # wake_only | send | words
    text: str = ""
    match: Optional[WakeMatch] = None
    utterance: Optional[Utterance] = None


@dataclass
class WordChunk:
    text: str
    at: float


class WordStream:
    """Слова whisper -> ОДНО законченное сообщение -> событие FLUX."""

    def __init__(self, detector: WakeDetector, word_idle_sec: float = 5.0,
                 keep_sec: float = 8.0, wake_idle_sec: float = 1.2,
                 max_message_sec: float = 60.0, awake_timeout_sec: float = 15.0,
                 on_state: Optional[Callable[[str], None]] = None) -> None:
        self.det = detector
        self.keep_sec = float(keep_sec)
        # «флюкс» без команды: «Слушаю» говорим быстро, не ждём полные 5 c
        self.wake_idle_sec = float(wake_idle_sec)
        self.on_state = on_state
        self.state = IDLE
        self.asm = UtteranceAssembler(idle_sec=float(word_idle_sec),
                                      max_sec=float(max_message_sec))
        self.chunks: list[WordChunk] = []       # живая лента слов (для UI)
        self.last_message: Optional[Utterance] = None
        self.messages_sent = 0
        self.command_parts: list[str] = []     # отладка/совместимость
        self.last_words_at = 0.0
        self.last_chunk_at = 0.0
        self._early_wake = False
        self._seen_words = 0
        self.awake_timeout_sec = float(awake_timeout_sec)
        self.awake_since = 0.0

    # ------------------------------------------------------------------ props
    @property
    def word_idle_sec(self) -> float:
        return self.asm.idle_sec

    @word_idle_sec.setter
    def word_idle_sec(self, value: float) -> None:
        self.asm.idle_sec = float(value)

    @property
    def partial(self) -> str:
        """Что whisper уже услышал, но сообщение ещё не закрыто."""
        return self.asm.partial

    @property
    def silence_left(self) -> float:
        """Сколько секунд осталось, чтобы продолжить фразу (для UI)."""
        return self.asm.silence_left

    # ------------------------------------------------------------------ utils
    def _prune(self, now: float) -> None:
        cut = now - self.keep_sec
        self.chunks = [c for c in self.chunks if c.at >= cut]

    def _recent_text(self) -> str:
        return " ".join(c.text for c in self.chunks).strip()

    def _set_state(self, st: str) -> None:
        self.state = st
        self.awake_since = time.monotonic() if st == AWAKE else 0.0
        if self.on_state:
            self.on_state(st)

    def tick(self) -> bool:
        """«Слушаю» сказано, а пользователь молчит: не висим в AWAKE вечно.

        Возвращает True, если сессия сброшена (таймаут wake.awake_timeout_sec).
        """
        if self.state != AWAKE or not self.awake_timeout_sec:
            return False
        if time.monotonic() - self.awake_since < self.awake_timeout_sec:
            return False
        self.reset()
        return True

    def reset(self) -> None:
        self.state = IDLE
        self.asm.reset()
        self.chunks.clear()
        self.command_parts.clear()
        self.last_words_at = 0.0
        self._early_wake = False
        self._seen_words = 0

    def last_words(self) -> list:
        return list(self.asm.words)

    # ------------------------------------------------------------------- feed
    def feed(self, text: str = "", now: Optional[float] = None,
             tr=None, words: Optional[Sequence] = None,
             end_sec: Optional[float] = None,
             sec: Optional[float] = None) -> list[StreamEvent]:
        """Принять от whisper очередной кусок звука.

        text / words / tr — ЧТО услышал whisper;
        end_sec / now       — до какой секунды ЗВУКА дослушали (шкала whisper);
        sec                 — сколько секунд звука было в этом куске
                              (по умолчанию: pos - предыдущая позиция).
        Событие ``send`` ВСЕГДА несёт целое сообщение (Utterance).
        """
        # now/end_sec — ПОЗИЦИЯ на шкале звука (не длина куска!);
        # длина куска — только в sec (main.py передаёт её явно).
        pos = float(end_sec if end_sec is not None
                    else (now if now is not None else self.asm.now))
        self.last_chunk_at = pos

        events: list[StreamEvent] = []
        # текст сегмента: явно или из самого tr (боевой путь передаёт оба)
        clean0 = clean_word_text(
            text or (str(getattr(tr, "text", "") or "") if tr is not None else ""))
        got_words = words
        # галлюцинация: либо бирка целиком (-> ""), либо «команда + хвост»
        # (-> команда); пустышка-«ну/ээ» тоже словами не считается
        if clean0 and not is_filler_only(clean0):
            clean = strip_hallucination_tail(clean0)
        else:
            clean = ""
        if clean != clean0 and got_words is None and tr is not None:
            # отброшенный/обрезанный сегмент не отдаёт слова из tr: иначе
            # хвост галлюцинации доезжает до сообщения в обход фильтра
            got_words = _words_within_head(tr, clean) if clean else []
        got = words_from_any(tr=tr if got_words is None else None,
                             text=clean, words=got_words)

        # длина окна звука: явно (sec) или «сколько нового звука после курсора»
        push_sec = float(sec) if sec is not None else max(0.0, pos - self.asm.cursor)
        utt = self.asm.push(tr=tr, words=got, end_sec=pos, sec=push_sec)
        if self.asm.words:
            self.last_words_at = self.asm.last_word_end
        self._sync_chunks(pos)

        if utt is not None:
            events.extend(self._on_message(utt))
            return events

        if self.asm.last_push_words:
            events.append(StreamEvent(kind="words", text=self.asm.partial))

        # Сообщение ещё НЕ закрыто: whisper продолжает слушать тишину.
        # Единственное, что делаем раньше срока — отзываемся «Слушаю» на голое
        # слово-активацию (через wake_idle_sec молчания, audio.wake_silence_sec).
        # Команду НЕ отправляем: она уходит модели только вместе со всем
        # сообщением, когда whisper замолчал на word_idle_sec (5 c).
        if (self.state == IDLE and self.asm.words and not self._early_wake
                and self.asm.idle_sec_now
                >= min(self.wake_idle_sec, self.asm.idle_sec)):
            m = self.det.check(self.asm.partial)
            if m.matched and not m.command.strip():
                self._early_wake = True
                self.asm.reset()          # само слово «флюкс» в команду не идёт
                self._seen_words = 0
                self.chunks.clear()
                self._set_state(AWAKE)
                events.append(StreamEvent(kind="wake_only", text="", match=m))
        return events

    # -------------------------------------------------------------- internals
    def _sync_chunks(self, pos: float) -> None:
        """Лента слов для консоли (на решения не влияет)."""
        words = self.asm.words
        if len(words) < self._seen_words:
            self._seen_words = 0
        for w in words[self._seen_words:]:
            self.chunks.append(WordChunk(w.clean(), pos))
        self._seen_words = len(words)
        self._prune(pos)

    def _on_message(self, utt: Utterance) -> list[StreamEvent]:
        """Сообщение ЦЕЛИКОМ готово — единственное место, где оно идёт дальше."""
        self.last_message = utt
        self.command_parts = [utt.text]
        events: list[StreamEvent] = []
        text = utt.text.strip()
        if self.state == AWAKE:
            # сессия открыта («Слушаю» уже сказано) — это команда
            self.reset()
            if text:
                self.messages_sent += 1
                events.append(StreamEvent(kind="send", text=text, utterance=utt))
            else:                                  # послушали и тишина
                events.append(StreamEvent(kind="wake_only", text=""))
            return events

        # IDLE: ищем слово-активацию в ЦЕЛОМ сообщении
        match = self.det.check(text)
        self.reset()
        if not match.matched:
            return events
        if match.command.strip():
            self.messages_sent += 1
            events.append(StreamEvent(kind="send", text=match.command,
                                      match=match, utterance=utt))
        else:
            self._set_state(AWAKE)
            events.append(StreamEvent(kind="wake_only", text="", match=match,
                                      utterance=utt))
        return events
