"""Запуск/закрытие приложений, открытие файлов и URL."""
from __future__ import annotations

import os
import subprocess
import webbrowser

from .. import logger
from .registry import ToolResult, tool

log = logger.get_logger("flux.tools.apps")


@tool("open_path",
      "Открывает файл/папку/URL средствами системы (как двойной клик).",
      {"type": "object",
       "properties": {"target": {"type": "string",
                                 "description": "путь к файлу/папке или http(s) URL"}},
       "required": ["target"]},
      category="apps")
def t_open_path(ctx=None, target: str = "") -> ToolResult:
    t = target.strip()
    if not t:
        return ToolResult(False, "пустой target")
    try:
        if t.lower().startswith(("http://", "https://", "mailto:")):
            webbrowser.open(t)
            return ToolResult(True, f"открыто в браузере: {t}")
        if os.name == "nt":
            os.startfile(os.path.expanduser(t))  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", os.path.expanduser(t)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return ToolResult(True, f"открыто: {t}")
    except Exception as e:
        return ToolResult(False, f"не удалось открыть {t}: {e}")


@tool("launch_app",
      "Запускает приложение по имени или пути (notepad, chrome, calc, "
      "C:\\Program Files\\...).",
      {"type": "object",
       "properties": {"app": {"type": "string"},
                      "args": {"type": "string", "description": "аргументы"}},
       "required": ["app"]},
      category="apps")
def t_launch_app(ctx=None, app: str = "", args: str = "") -> ToolResult:
    cmd = [app] + (args.split() if args else [])
    try:
        if os.name == "nt":
            subprocess.Popen(cmd, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
                             | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        else:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return ToolResult(True, f"запущено: {app}")
    except Exception as e:
        return ToolResult(False, f"не удалось запустить {app}: {e}")


@tool("list_processes", "Список запущенных процессов (топ по памяти) или фильтр по имени.",
      {"type": "object",
       "properties": {"filter": {"type": "string", "description": "подстрока имени"},
                      "limit": {"type": "integer"}}},
      category="apps")
def t_list_processes(ctx=None, filter: str = "", limit: int = 30) -> ToolResult:
    try:
        import psutil
    except Exception as e:
        return ToolResult(False, f"psutil недоступен: {e}")
    procs = []
    for p in psutil.process_iter(["pid", "name", "memory_info"]):
        try:
            name = p.info["name"] or ""
            if filter and filter.lower() not in name.lower():
                continue
            mem = (p.info["memory_info"].rss if p.info["memory_info"] else 0)
            procs.append((mem, p.info["pid"], name))
        except Exception:
            continue
    procs.sort(reverse=True)
    lines = [f"{pid:7d} {mem // 2**20:6d} МБ  {name}" for mem, pid, name in procs[:limit]]
    return ToolResult(True, f"Процессов найдено: {len(procs)} (топ {len(lines)})\n"
                            + "\n".join(lines))


@tool("kill_process",
      "Завершает процесс по имени или PID. Опасно: спрашивай пользователя.",
      {"type": "object",
       "properties": {"target": {"type": "string", "description": "имя или pid"}},
       "required": ["target"]},
      dangerous=True, category="apps")
def t_kill_process(ctx=None, target: str = "") -> ToolResult:
    try:
        import psutil
    except Exception as e:
        return ToolResult(False, f"psutil недоступен: {e}")
    killed = []
    for p in psutil.process_iter(["pid", "name"]):
        try:
            name = (p.info["name"] or "").lower()
            if str(target).isdigit():
                if p.info["pid"] != int(target):
                    continue
            elif str(target).lower() not in name:
                continue
            p.kill()
            killed.append(f"{p.info['pid']}:{p.info['name']}")
        except Exception:
            continue
    if not killed:
        return ToolResult(False, f"процесс {target} не найден")
    return ToolResult(True, f"завершено: {', '.join(killed)}")
