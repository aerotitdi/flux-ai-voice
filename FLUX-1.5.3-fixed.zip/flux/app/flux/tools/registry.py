"""Реестр инструментов (function calling) с валидацией и безопасностью.

Каждый инструмент описан JSON-схемой в стиле OpenAI tools, которую получает
модель. Вызов идёт через dispatch(): проверка обязательных параметров и типов,
перехват исключений, логирование и событие для веб-консоли.

Запрос подтверждения здесь НЕ выполняется: единственная точка решения —
``llm/agent.py::_execute`` (см. комментарий в ``dispatch``). По умолчанию
подтверждения выключены вовсе (``security.confirm_destructive = false``).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .. import config, logger

log = logger.get_logger("flux.tools")


@dataclass
class ToolResult:
    ok: bool
    text: str = ""
    data: dict = field(default_factory=dict)
    speak: str = ""            # подсказка, что сказать голосом
    attach_images: list = field(default_factory=list)   # пути картинок для vision
    elapsed: float = 0.0

    def as_message_content(self) -> str:
        head = "OK" if self.ok else "ОШИБКА"
        body = self.text or ""
        return f"[{head}] {body}"


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: dict
    fn: Callable[..., ToolResult]
    dangerous: bool = False
    category: str = "general"
    platforms: tuple = ("win", "linux", "darwin")
    requires_config: str = ""     # dotted path, должен быть truthy

    def schema(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters or {"type": "object", "properties": {}},
            },
        }


REGISTRY: dict[str, ToolSpec] = {}


def tool(name: str, description: str, parameters: Optional[dict] = None,
         dangerous: bool = False, category: str = "general",
         platforms: tuple = ("win", "linux", "darwin"),
         requires_config: str = ""):
    def deco(fn):
        REGISTRY[name] = ToolSpec(
            name=name, description=description,
            parameters=parameters or {"type": "object", "properties": {}},
            fn=fn, dangerous=dangerous, category=category,
            platforms=platforms, requires_config=requires_config,
        )
        return fn
    return deco


def get(name: str) -> Optional[ToolSpec]:
    return REGISTRY.get(name)


def list_names() -> list[str]:
    return sorted(REGISTRY)


def schemas() -> list[dict]:
    import sys
    plat = "win" if sys.platform.startswith("win") else (
        "darwin" if sys.platform == "darwin" else "linux")
    out = []
    for spec in REGISTRY.values():
        if plat not in spec.platforms:
            continue
        if spec.requires_config and not config.get(spec.requires_config, True):
            continue
        if spec.category in _disabled_categories():
            continue
        out.append(spec.schema())
    return out


def _disabled_categories() -> set[str]:
    disabled = set()
    sec = config.get("security", {}) or {}
    if not sec.get("allow_shell", True):
        disabled.add("shell")
    if not sec.get("allow_file_write", True):
        disabled.add("write")
    if not sec.get("allow_computer_use", True):
        disabled.add("computer")
    if not sec.get("allow_device_control", True):
        disabled.add("devices")
    if not sec.get("allow_power_actions", True):
        disabled.add("power")
    if not config.get("search.enabled", True):
        disabled.add("web")
    return disabled


_TYPE_CHECKS = {
    "string": lambda v: isinstance(v, str),
    "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
    "number": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
    "boolean": lambda v: isinstance(v, bool),
    "array": lambda v: isinstance(v, list),
    "object": lambda v: isinstance(v, dict),
}


def validate_args(spec: ToolSpec, args: dict) -> Optional[str]:
    props = (spec.parameters or {}).get("properties", {}) or {}
    required = (spec.parameters or {}).get("required", []) or []
    if not isinstance(args, dict):
        return "аргументы должны быть объектом"
    for key in required:
        if key not in args or args[key] in (None, ""):
            return f"не указан обязательный параметр '{key}'"
    for key, value in args.items():
        schema = props.get(key)
        if not schema or value is None:
            continue
        t = schema.get("type")
        checker = _TYPE_CHECKS.get(t)
        if checker and not checker(value):
            return f"параметр '{key}' должен быть типа {t}, получено {type(value).__name__}"
        if t == "string" and schema.get("enum") and value not in schema["enum"]:
            return f"параметр '{key}' должен быть одним из {schema['enum']}"
    return None


def dispatch(name: str, args: dict, ctx: Any = None) -> ToolResult:
    """Выполняет инструмент. Все исключения превращаются в ToolResult(ok=False)."""
    spec = REGISTRY.get(name)
    t0 = time.time()
    if spec is None:
        return ToolResult(False, f"неизвестный инструмент: {name}")
    err = validate_args(spec, args or {})
    if err:
        return ToolResult(False, f"некорректные аргументы {name}: {err}")
    if spec.requires_config and not config.get(spec.requires_config, True):
        return ToolResult(False, f"инструмент {name} отключён в настройках")
    # ВАЖНО: запрос подтверждения здесь БОЛЬШЕ НЕ живёт.
    # Раньше гейт стоял и тут, и в llm/agent.py::_execute — из-за этого на
    # каждую опасную операцию пользователя спрашивали ДВА РАЗА подряд
    # (второй запрос обычно уходил в 20-секундный таймаут и отменял действие).
    # Единственная точка решения — Agent._execute, и по умолчанию она выключена
    # (security.confirm_destructive = false): Флюкс действует сразу.
    try:
        res = spec.fn(ctx=ctx, **(args or {}))
        if not isinstance(res, ToolResult):
            res = ToolResult(True, str(res))
        res.elapsed = round(time.time() - t0, 3)
        log.info("tool %s ok=%s %.2fs: %s", name, res.ok, res.elapsed,
                 (res.text or "")[:160].replace("\n", " "))
        if ctx is not None and getattr(ctx, "emit", None):
            try:
                ctx.emit("tool", name=name, ok=res.ok, elapsed=res.elapsed,
                         preview=(res.text or "")[:200])
            except Exception:
                pass
        return res
    except Exception as e:  # noqa: BLE001 - инструмент не должен ронять агента
        log.exception("tool %s crashed", name)
        return ToolResult(False, f"инструмент {name} упал: {type(e).__name__}: {e}",
                          elapsed=round(time.time() - t0, 3))


def describe_all() -> str:
    lines = []
    for name in list_names():
        spec = REGISTRY[name]
        flags = []
        if spec.dangerous:
            flags.append("опасно")
        if spec.requires_config:
            flags.append(f"нужен {spec.requires_config}")
        lines.append(f"- {name} [{spec.category}]{(' (' + ', '.join(flags) + ')') if flags else ''}: {spec.description}")
    return "\n".join(lines)
