"""Устройства: FLUX ВИДИТ все подключённые устройства и может ими управлять.

Источники:
  * сеть: ARP-таблица + ping-скан подсети (имя, IP, MAC, производитель по OUI-префиксу);
  * USB/PnP/PCI: Get-PnpDevice (Windows), lsusb/lspci (Linux);
  * диски и разделы: psutil;
  * принтеры, Bluetooth, мониторы, аудиоустройства: PowerShell/системные вызовы.

Управление: ping, Wake-on-LAN, вкл/выкл устройства (pnputil), извлечь USB-диск,
открыть устройство в диспетчере. Действия выполняются сразу: подтверждения
отключены (доступ к устройствам целиком регулирует security.allow_device_control).

Все «чистые» функции (парсинг ARP, magic-пакет, расчёт подсети) вынесены и
покрыты unit-тестами.
"""
from __future__ import annotations

import os
import re
import socket
import subprocess
from concurrent.futures import ThreadPoolExecutor

from .. import config, logger
from .registry import ToolResult, tool

log = logger.get_logger("flux.tools.devices")

# Префиксы OUI -> производитель (небольшая встроенная таблица для наглядности)
OUI_VENDORS = {
    "00:1A:2B": "Aygua/Netgear?", "3C:52:82": "Hewlett Packard", "00:15:5D": "Hyper-V VM",
    "B8:27:EB": "Raspberry Pi", "DC:A6:32": "Raspberry Pi", "00:50:56": "VMware",
    "08:00:27": "VirtualBox", "52:54:00": "QEMU/KVM", "F0:18:98": "Apple",
    "A4:83:E7": "Apple", "00:1C:BF": "Intel", "3C:97:0E": "Intel", "00:0C:29": "VMware",
    "2C:F0:5D": "Samsung", "00:16:3E": "Xen", "94:C6:91": "Xiaomi", "00:17:88": "Philips Hue",
    "54:EF:44": "TP-Link", "AC:84:C6": "TP-Link", "00:19:E0": "TP-Link",
}


# ------------------------------------------------------------------ pure logic
def parse_arp(text: str) -> list[dict]:
    """Разбор вывода `arp -a` (Windows и Linux) в записи."""
    out: list[dict] = []
    seen = set()
    # Windows: 192.168.1.10    aa-bb-cc-dd-ee-ff     динамический
    # Linux : 192.168.1.10 dev eth0 lladdr aa:bb:cc:dd:ee:ff REACHABLE
    win = re.compile(r"^\s*(\d{1,3}(?:\.\d{1,3}){3})\s+([0-9a-fA-F]{2}(?:[-:][0-9a-fA-F]{2}){5})")
    lin = re.compile(r"^\S+\s+\((\d{1,3}(?:\.\d{1,3}){3})\)\s+at\s+"
                     r"([0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5})")
    for line in text.splitlines():
        m = win.match(line) or lin.match(line)
        if not m:
            continue
        ip, mac = m.group(1), m.group(2).replace("-", ":").upper()
        if mac in ("FF:FF:FF:FF:FF:FF",) or (ip, mac) in seen:
            continue
        seen.add((ip, mac))
        out.append({"ip": ip, "mac": mac, "vendor": vendor_by_mac(mac)})
    return out


def vendor_by_mac(mac: str) -> str:
    prefix = mac.upper().replace("-", ":")[:8]
    return OUI_VENDORS.get(prefix, "неизвестный производитель")


def build_magic_packet(mac: str) -> bytes:
    """Wake-on-LAN пакет: 6x FF + 16x MAC."""
    m = mac.replace(":", "").replace("-", "").strip()
    if len(m) != 12 or any(c not in "0123456789abcdefABCDEF" for c in m):
        raise ValueError(f"некорректный MAC: {mac}")
    macb = bytes.fromhex(m)
    return b"\xff" * 6 + macb * 16


def local_subnet(prefix_len: int = 24) -> str | None:
    """Подсеть машины (192.168.x.0/24) через UDP-трюк без реального трафика."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
    except OSError:
        return None
    parts = ip.split(".")
    if len(parts) != 4:
        return None
    if prefix_len == 24:
        return ".".join(parts[:3]) + ".0/24"
    return ip + f"/{prefix_len}"


def subnet_hosts(cidr: str) -> list[str]:
    """Список host-адресов подсети CIDR (без сетевого и broadcast)."""
    base, _, bits = cidr.partition("/")
    try:
        octs = [int(x) for x in base.split(".")]
        n = int(bits) if bits else 24
    except ValueError:
        return []
    if len(octs) != 4 or not all(0 <= o <= 255 for o in octs):
        return []
    if not 0 <= n <= 30:
        return []
    start = (octs[0] << 24) | (octs[1] << 16) | (octs[2] << 8) | octs[3]
    mask = (0xFFFFFFFF << (32 - n)) & 0xFFFFFFFF
    network = start & mask
    count = min(1024, (2 ** (32 - n)) - 2)
    out: list[str] = []
    for i in range(1, count + 1):
        ip = network | i
        out.append(".".join(str((ip >> sh) & 0xFF) for sh in (24, 16, 8, 0)))
    return out


def ping_host(ip: str, timeout: float = 0.6) -> bool:
    """Быстрый TCP-ping (80/445) + ICMP fallback через системный ping."""
    for port in (445, 80, 135):
        try:
            with socket.create_connection((ip, port), timeout=timeout):
                return True
        except OSError:
            continue
    cmd = (["ping", "-n", "1", "-w", str(int(timeout * 1000)), ip] if os.name == "nt"
           else ["ping", "-c", "1", "-W", "1", ip])
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout + 2,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return r.returncode == 0
    except Exception:
        return False


def _ps(script: str, timeout: int = 30) -> tuple[int, str, str]:
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", script],
                           capture_output=True, text=True, timeout=timeout,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return r.returncode, r.stdout or "", r.stderr or ""
    except Exception as e:
        return 1, "", str(e)


def _arp_table() -> list[dict]:
    cmd = ["arp", "-a"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=10,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return parse_arp(r.stdout or "")
    except Exception:
        return []


def _pnp_devices() -> list[dict]:
    if os.name == "nt":
        code, out, _ = _ps(
            "Get-PnpDevice -PresentOnly | Select-Object Class,FriendlyName,Status,"
            "InstanceId | ConvertTo-Json -Compress")
        if code == 0 and out.strip():
            import json
            try:
                data = json.loads(out)
                if isinstance(data, dict):
                    data = [data]
                return [{"class": d.get("Class", ""), "name": d.get("FriendlyName", ""),
                         "status": d.get("Status", ""), "id": d.get("InstanceId", "")}
                        for d in data]
            except Exception:
                pass
        return []
    devs = []
    for cmd, cls in (("lsusb", "USB"), ("lspci", "PCI")):
        try:
            r = subprocess.run([cmd], capture_output=True, text=True, timeout=10)
            for line in (r.stdout or "").splitlines():
                if line.strip():
                    devs.append({"class": cls, "name": line.strip(),
                                 "status": "OK", "id": ""})
        except Exception:
            continue
    return devs


# --------------------------------------------------------------------- tools
@tool("list_devices",
      "ПОКАЗЫВАЕТ ВСЕ подключённые устройства: сеть (IP/MAC/производитель), "
      "USB/PnP/PCI, диски, принтеры, Bluetooth, мониторы, аудио. "
      "scan_network=True добавляет ping-скан локальной подсети.",
      {"type": "object",
       "properties": {
           "scan_network": {"type": "boolean", "description": "сканировать подсеть"},
           "include_pnp": {"type": "boolean"},
       }},
      category="devices")
def t_list_devices(ctx=None, scan_network: bool = False,
                   include_pnp: bool = True) -> ToolResult:
    sections: list[str] = []
    net = _arp_table()
    if scan_network:
        cidr = local_subnet()
        if cidr:
            alive = scan_network_hosts(cidr)
            known = {d["ip"] for d in net}
            for ip in alive:
                if ip not in known:
                    net.append({"ip": ip, "mac": "?", "vendor": "в сети, MAC неизвестен"})
    sections.append("== СЕТЬ ==")
    sections += [f"{d['ip']:16s} {d['mac']:18s} {d['vendor']}" for d in net] or ["(пусто)"]
    if include_pnp:
        pnp = _pnp_devices()
        sections.append(f"== USB/PnP/PCI ({len(pnp)}) ==")
        sections += [f"[{d['class'] or '?'}] {d['name']} ({d['status']})" for d in pnp[:60]]
    try:
        import psutil
        sections.append("== ДИСКИ ==")
        for part in psutil.disk_partitions(all=False):
            try:
                u = psutil.disk_usage(part.mountpoint)
                sections.append(f"{part.mountpoint} {part.fstype} "
                                f"{u.used // 2**30} ГБ из {u.total // 2**30} ГБ")
            except OSError:
                sections.append(f"{part.mountpoint} {part.fstype}")
    except Exception:
        pass
    if os.name == "nt":
        code, out, _ = _ps("Get-Printer | Select-Object -ExpandProperty Name")
        if code == 0 and out.strip():
            sections.append("== ПРИНТЕРЫ ==")
            sections += [f"- {l}" for l in out.splitlines() if l.strip()]
        code, out, _ = _ps(
            "Get-PnpDevice -Class Bluetooth -PresentOnly -ErrorAction SilentlyContinue | "
            "Select-Object -ExpandProperty FriendlyName")
        if code == 0 and out.strip():
            sections.append("== BLUETOOTH ==")
            sections += [f"- {l}" for l in out.splitlines() if l.strip()]
    return ToolResult(True, "\n".join(sections))


def scan_network_hosts(cidr: str, timeout: float | None = None) -> list[str]:
    hosts = subnet_hosts(cidr)
    timeout = timeout or float(config.get("devices.ping_timeout_sec", 0.6))
    threads = int(config.get("devices.scan_threads", 64))
    alive: list[str] = []
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futs = {ex.submit(ping_host, ip, timeout): ip for ip in hosts}
        for f in futs:
            try:
                if f.result():
                    alive.append(futs[f])
            except Exception:
                pass
    return sorted(alive, key=lambda ip: [int(x) for x in ip.split(".")])


@tool("scan_network",
      "Сканирует локальную подсеть (ping) и возвращает живые IP-адреса.",
      {"type": "object",
       "properties": {"subnet": {"type": "string",
                                 "description": "CIDR, напр. 192.168.1.0/24; пусто = авто"}}},
      category="devices")
def t_scan_network(ctx=None, subnet: str = "") -> ToolResult:
    cidr = subnet or local_subnet()
    if not cidr:
        return ToolResult(False, "не удалось определить локальную подсеть")
    alive = scan_network_hosts(cidr)
    if not alive:
        return ToolResult(True, f"в подсети {cidr} живых хостов не найдено")
    lines = []
    for ip in alive:
        mac_info = next((d for d in _arp_table() if d["ip"] == ip), None)
        lines.append(f"{ip:16s} {mac_info['mac'] if mac_info else '?':18s} "
                     f"{mac_info['vendor'] if mac_info else ''}")
    return ToolResult(True, f"Живые хосты в {cidr}: {len(alive)}\n" + "\n".join(lines))


@tool("ping_device", "Проверяет доступность устройства по IP или имени.",
      {"type": "object",
       "properties": {"host": {"type": "string", "description": "IP или hostname"}},
       "required": ["host"]},
      category="devices")
def t_ping_device(ctx=None, host: str = "") -> ToolResult:
    try:
        ip = socket.gethostbyname(host)
    except OSError:
        return ToolResult(False, f"имя не резолвится: {host}")
    ok = ping_host(ip, timeout=1.5)
    return ToolResult(ok, f"{host} ({ip}): {'доступен' if ok else 'не отвечает'}")


@tool("wake_on_lan",
      "Будит устройство в локальной сети magic-пакетом (Wake-on-LAN) по MAC.",
      {"type": "object",
       "properties": {"mac": {"type": "string", "description": "MAC вида AA:BB:CC:DD:EE:FF"},
                      "broadcast": {"type": "string"}},
       "required": ["mac"]},
      dangerous=True, category="devices")
def t_wake_on_lan(ctx=None, mac: str = "", broadcast: str = "") -> ToolResult:
    try:
        packet = build_magic_packet(mac)
    except ValueError as e:
        return ToolResult(False, str(e))
    bc = broadcast or str(config.get("devices.wol_broadcast", "255.255.255.255"))
    port = int(config.get("devices.wol_port", 9))
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.sendto(packet, (bc, port))
        s.close()
        return ToolResult(True, f"magic-пакет отправлен на {mac} ({bc}:{port})")
    except Exception as e:
        return ToolResult(False, f"не удалось отправить WOL: {e}")


@tool("device_control",
      "Управляет устройством Windows: включить/отключить (pnputil), извлечь "
      "USB-диск, открыть свойства. Выполняется сразу; нужны права администратора.",
      {"type": "object",
       "properties": {
           "action": {"type": "string",
                      "enum": ["disable", "enable", "eject", "properties"]},
           "target": {"type": "string",
                      "description": "InstanceID устройства или буква диска (E:)"},
       },
       "required": ["action", "target"]},
      dangerous=True, category="devices")
def t_device_control(ctx=None, action: str = "", target: str = "") -> ToolResult:
    if os.name != "nt":
        return ToolResult(False, "управление устройствами доступно только на Windows")
    if action in ("disable", "enable"):
        verb = "Disable-PnpDevice" if action == "disable" else "Enable-PnpDevice"
        code, out, err = _ps(
            f"{verb} -InstanceId '{target}' -Confirm:$false -ErrorAction Stop")
        return ToolResult(code == 0, out.strip() or err.strip() or f"{action}: ok")
    if action == "eject":
        drive = target.rstrip("\\/")
        code, out, err = _ps(
            "$vol = New-Object -ComObject Shell.Application; "
            f"$vol.Namespace(17).ParseName('{drive}\\').InvokeVerb('Eject')")
        return ToolResult(code == 0, f"извлечение {drive}: "
                                     f"{out.strip() or err.strip() or 'команда выполнена'}")
    if action == "properties":
        code, out, err = _ps(
            f"Get-PnpDevice -InstanceId '{target}' | Format-List *")
        return ToolResult(code == 0, out or err)
    return ToolResult(False, f"неизвестное действие {action}")
