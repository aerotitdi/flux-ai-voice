"""Инструменты памяти (паритет с Memory/Notes/Knowledge из Open WebUI)."""
from __future__ import annotations


from .. import logger
from .registry import ToolResult, tool

log = logger.get_logger("flux.tools.memory")

CHUNK = 1400


def _store(ctx):
    return getattr(ctx, "store", None)


@tool("remember",
      "Сохраняет важный факт о пользователе/задаче в долгосрочную память "
      "(имя, предпочтения, адреса, пароли-подсказки НЕ хранить).",
      {"type": "object",
       "properties": {"fact": {"type": "string", "description": "что запомнить"},
                      "tags": {"type": "string", "description": "метки через запятую"}},
       "required": ["fact"]},
      category="memory")
def t_remember(ctx=None, fact: str = "", tags: str = "") -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "память недоступна")
    if not fact.strip():
        return ToolResult(False, "пустой факт")
    mid = store.remember(fact.strip(), tags or "")
    return ToolResult(True, f"запомнил (id={mid}): {fact}")


@tool("recall",
      "Достаёт из долгосрочной памяти факты по запросу (полнотекстовый поиск).",
      {"type": "object",
       "properties": {"query": {"type": "string"},
                      "limit": {"type": "integer"}},
       "required": ["query"]},
      category="memory")
def t_recall(ctx=None, query: str = "", limit: int = 6) -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "память недоступна")
    items = store.recall(query, limit)
    if not items:
        return ToolResult(True, f"в памяти ничего не найдено по запросу «{query}»")
    lines = [f"- [{i['id']}] {i['text']}  (теги: {i['tags'] or '-'})" for i in items]
    return ToolResult(True, "Найдено в памяти:\n" + "\n".join(lines))


@tool("forget",
      "Удаляет факт из памяти по id или подстроке текста.",
      {"type": "object",
       "properties": {"match": {"type": "string", "description": "id или подстрока"}},
       "required": ["match"]},
      dangerous=True, category="memory")
def t_forget(ctx=None, match: str = "") -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "память недоступна")
    n = store.forget(match)
    return ToolResult(True, f"удалено записей памяти: {n}")


@tool("list_memories", "Показывает последние сохранённые факты памяти.",
      {"type": "object", "properties": {"limit": {"type": "integer"}}},
      category="memory")
def t_list_memories(ctx=None, limit: int = 30) -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "память недоступна")
    items = store.list_memories(limit)
    if not items:
        return ToolResult(True, "память пуста")
    return ToolResult(True, "\n".join(
        f"- [{i['id']}] {i['text']} (теги: {i['tags'] or '-'})" for i in items))


@tool("note_save", "Создаёт или обновляет заметку (аналог Notes в Open WebUI).",
      {"type": "object",
       "properties": {"title": {"type": "string"},
                      "content": {"type": "string"},
                      "note_id": {"type": "integer", "description": "если обновление"}},
       "required": ["title"]},
      category="memory")
def t_note_save(ctx=None, title: str = "", content: str = "",
                note_id: int | None = None) -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "память недоступна")
    nid = store.note_save(title, content, note_id)
    return ToolResult(True, f"заметка сохранена (id={nid}): {title}")


@tool("note_list", "Список заметок.",
      {"type": "object", "properties": {"limit": {"type": "integer"}}},
      category="memory")
def t_note_list(ctx=None, limit: int = 30) -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "память недоступна")
    notes = store.note_list(limit)
    if not notes:
        return ToolResult(True, "заметок нет")
    return ToolResult(True, "\n".join(
        f"- [{n['id']}] {n['title']} ({n['chars']} симв.)" for n in notes))


@tool("note_get", "Читает заметку целиком по id.",
      {"type": "object", "properties": {"note_id": {"type": "integer"}},
       "required": ["note_id"]},
      category="memory")
def t_note_get(ctx=None, note_id: int = 0) -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "память недоступна")
    n = store.note_get(int(note_id))
    if not n:
        return ToolResult(False, f"заметка {note_id} не найдена")
    return ToolResult(True, f"ЗАМЕТОКА {n['id']}: {n['title']}\n\n{n['content']}")


@tool("knowledge_ingest",
      "Добавляет файл в базу знаний (RAG): текст разбивается на куски и "
      "индексируется для поиска. Аналог Knowledge в Open WebUI.",
      {"type": "object",
       "properties": {"path": {"type": "string", "description": "путь к файлу"}},
       "required": ["path"]},
      category="memory")
def t_knowledge_ingest(ctx=None, path: str = "") -> ToolResult:
    from .files import _expand, read_any
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "память недоступна")
    p = _expand(path)
    if not p.is_file():
        return ToolResult(False, f"файл не найден: {p}")
    try:
        text, kind, _ = read_any(p)
    except Exception as e:
        return ToolResult(False, f"не читается: {e}")
    if kind in ("image", "binary"):
        return ToolResult(False, f"файл типа {kind} нельзя проиндексировать как текст")
    chunks = [text[i:i + CHUNK] for i in range(0, len(text), CHUNK)]
    n = store.knowledge_ingest(str(p), chunks)
    return ToolResult(True, f"в базу знаний добавлено {n} кусков из {p.name}")


@tool("knowledge_search",
      "Ищет по базе знаний (проиндексированные файлы/документы).",
      {"type": "object",
       "properties": {"query": {"type": "string"},
                      "limit": {"type": "integer"}},
       "required": ["query"]},
      category="memory")
def t_knowledge_search(ctx=None, query: str = "", limit: int = 5) -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "память недоступна")
    hits = store.knowledge_search(query, limit)
    if not hits:
        return ToolResult(True, f"в базе знаний ничего не найдено по «{query}»")
    lines = [f"--- {h['source']} (оценка {h['score']:.2f}) ---\n{h['chunk'][:900]}"
             for h in hits]
    return ToolResult(True, "\n\n".join(lines))
