"""Работа с ЛЮБЫМИ файлами: чтение (текст, PDF, DOCX, XLSX, PPTX, CSV, JSON,
изображения, бинарные), запись, правка, поиск, копирование, перемещение,
удаление. Требования ТЗ: «РАБОТАТЬ С КАЖДЫМ ФАЙЛОМ И ЧИТАТЬ КАЖДЫЙ ФАЙЛ».

Безопасность: список запрещённых путей из настроек, лимиты размера,
удаление/перезапись выполняются сразу: подтверждения отключены, а системные
папки защищает security.denied_path_parts.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import stat
import time
from pathlib import Path

from .. import config, logger
from .registry import ToolResult, tool

log = logger.get_logger("flux.tools.files")

TEXT_EXTS = {
    ".txt", ".md", ".markdown", ".rst", ".log", ".ini", ".cfg", ".conf", ".toml",
    ".yaml", ".yml", ".json", ".csv", ".tsv", ".xml", ".html", ".htm", ".css",
    ".js", ".ts", ".jsx", ".tsx", ".py", ".pyw", ".bat", ".cmd", ".ps1", ".sh",
    ".c", ".h", ".cpp", ".hpp", ".cs", ".java", ".kt", ".go", ".rs", ".rb",
    ".php", ".sql", ".env", ".gitignore", ".srt", ".vtt", ".tex", ".lua",
}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff"}
OFFICE = {".docx": "docx", ".xlsx": "xlsx", ".pptx": "pptx", ".pdf": "pdf"}
MAX_PREVIEW = 20000


def _home() -> Path:
    return Path.home()


def _expand(p: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(str(p))))


def _denied(path: Path) -> str | None:
    low = str(path).lower().replace("\\", "/")
    for part in (config.get("security.denied_path_parts", []) or []):
        needle = part.lower().replace("\\", "/").strip("/")
        if needle and needle in low:
            return f"доступ к пути запрещён настройками безопасности: {part}"
    return None


def _check_read(path: Path) -> str | None:
    if not path.exists():
        return f"файл не найден: {path}"
    if path.is_dir():
        return f"это папка, используй list_dir: {path}"
    size = path.stat().st_size
    limit = int(config.get("security.max_file_read_bytes", 8_000_000))
    if size > limit:
        return f"файл слишком большой ({size} байт > лимит {limit})"
    return _denied(path)


# ------------------------------------------------------------------- readers
def _read_text(path: Path) -> tuple[str, str]:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace"), "utf-8(replace)"


def _read_pdf(path: Path) -> str:
    from pypdf import PdfReader  # type: ignore

    reader = PdfReader(str(path))
    pages = []
    for i, page in enumerate(reader.pages[:60], 1):
        try:
            pages.append(f"--- страница {i} ---\n{page.extract_text() or ''}")
        except Exception:
            pages.append(f"--- страница {i} --- [не читается]")
    return f"PDF, страниц: {len(reader.pages)}\n" + "\n".join(pages)


def _read_docx(path: Path) -> str:
    import docx  # type: ignore

    d = docx.Document(str(path))
    parts = [p.text for p in d.paragraphs if p.text.strip()]
    for t in d.tables[:20]:
        for row in t.rows[:200]:
            parts.append(" | ".join(c.text.strip() for c in row.cells))
    return "\n".join(parts)


def _read_xlsx(path: Path) -> str:
    from openpyxl import load_workbook  # type: ignore

    wb = load_workbook(str(path), read_only=True, data_only=True)
    out = []
    for ws in wb.worksheets[:10]:
        out.append(f"=== лист: {ws.title} ===")
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i >= 300:
                out.append("... (ещё строки опущены)")
                break
            cells = ["" if v is None else str(v) for v in row]
            if any(c.strip() for c in cells):
                out.append(" | ".join(cells))
    wb.close()
    return "\n".join(out)


def _read_pptx(path: Path) -> str:
    from pptx import Presentation  # type: ignore

    prs = Presentation(str(path))
    out = []
    for i, slide in enumerate(prs.slides, 1):
        out.append(f"--- слайд {i} ---")
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    txt = "".join(r.text for r in para.runs).strip()
                    if txt:
                        out.append(txt)
    return "\n".join(out)


def _read_csv(path: Path, text: str) -> str:
    lines = text.splitlines()[:500]
    return "\n".join(lines) + (f"\n... (всего строк: {len(text.splitlines())})"
                               if len(text.splitlines()) > 500 else "")


def read_any(path: Path) -> tuple[str, str, list[str]]:
    """(текст для модели, тип, пути изображений для vision)."""
    ext = path.suffix.lower()
    if ext in IMAGE_EXTS:
        try:
            from PIL import Image  # type: ignore
            with Image.open(path) as im:
                info = (f"Изображение {im.format} {im.size[0]}x{im.size[1]}, "
                        f"режим {im.mode}")
        except Exception:
            info = f"Изображение, размер {path.stat().st_size} байт"
        return (f"{info}. Файл приложен для визуального анализа.", "image", [str(path)])
    if ext in OFFICE:
        kind = OFFICE[ext]
        try:
            fn = {"pdf": _read_pdf, "docx": _read_docx,
                  "xlsx": _read_xlsx, "pptx": _read_pptx}[kind]
            return fn(path), kind, []
        except Exception as e:
            return (f"[не удалось разобрать {kind}: {e}; размер "
                    f"{path.stat().st_size} байт]"), kind, []
    if ext in TEXT_EXTS or ext == "":
        text, enc = _read_text(path)
        head = f"[текст, кодировка {enc}, {len(text)} символов]\n"
        if len(text) > MAX_PREVIEW:
            return head + text[:MAX_PREVIEW] + "\n...[обрезано]", "text", []
        if ext in (".csv", ".tsv"):
            return head + _read_csv(path, text), "csv", []
        if ext == ".json":
            try:
                obj = json.loads(text)
                return head + json.dumps(obj, ensure_ascii=False, indent=2), "json", []
            except Exception:
                return head + text, "json(broken)", []
        return head + text, "text", []
    # бинарные
    raw = path.read_bytes()[:2048]
    hexdump = "\n".join(
        f"{i:08x}  " + " ".join(f"{b:02x}" for b in raw[i:i + 16])
        for i in range(0, min(len(raw), 512), 16))
    printable = re.sub(rb"[^\x20-\x7e\n]", b".", raw[:512]).decode("ascii", "replace")
    return (f"[бинарный файл, {path.stat().st_size} байт]\nHEX:\n{hexdump}\n"
            f"PRINTABLE:\n{printable}"), "binary", []


# --------------------------------------------------------------------- tools
@tool("read_file",
      "Читает ЛЮБОЙ файл: текст, код, JSON, CSV, PDF, DOCX, XLSX, PPTX, "
      "изображения (прикладываются для визуального анализа), бинарные (hex). "
      "Возвращает содержимое с ограничением размера.",
      {"type": "object",
       "properties": {"path": {"type": "string",
                               "description": "путь к файлу (абсолютный или ~)"},
                      "max_chars": {"type": "integer",
                                    "description": "лимит символов вывода"}},
       "required": ["path"]},
      category="files")
def t_read_file(ctx=None, path: str = "", max_chars: int = 20000) -> ToolResult:
    p = _expand(path)
    err = _check_read(p)
    if err:
        return ToolResult(False, err)
    try:
        text, kind, images = read_any(p)
    except Exception as e:
        return ToolResult(False, f"ошибка чтения {p}: {e}")
    limit = int(max_chars or MAX_PREVIEW)
    if len(text) > limit:
        text = text[:limit] + f"\n...[обрезано, всего {len(text)} символов]"
    res = ToolResult(True, f"ФАЙЛ: {p}\nТИП: {kind}\n\n{text}",
                     data={"kind": kind, "size": p.stat().st_size})
    res.attach_images = images
    return res


@tool("write_file",
      "Создаёт или перезаписывает файл текстом. append=True дописывает в конец. "
      "Папки создаются автоматически. Перезапись выполняется сразу, без "
      "подтверждения (системные папки закрыты denied_path_parts).",
      {"type": "object",
       "properties": {
           "path": {"type": "string", "description": "путь к файлу"},
           "content": {"type": "string", "description": "текстовое содержимое"},
           "append": {"type": "boolean", "description": "дописать вместо перезаписи"},
           "encoding": {"type": "string", "description": "кодировка (utf-8 по умолч.)"},
       },
       "required": ["path", "content"]},
      dangerous=True, category="write")
def t_write_file(ctx=None, path: str = "", content: str = "", append: bool = False,
                 encoding: str = "utf-8") -> ToolResult:
    p = _expand(path)
    err = _denied(p)
    if err:
        return ToolResult(False, err)
    limit = int(config.get("security.max_file_write_bytes", 40_000_000))
    if len(content.encode(encoding, errors="replace")) > limit:
        return ToolResult(False, f"содержимое больше лимита {limit} байт")
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        existed = p.exists()
        mode = "a" if append else "w"
        with open(p, mode, encoding=encoding, newline="") as f:
            f.write(content)
        verb = "дописано" if append else ("перезаписан" if existed else "создан")
        return ToolResult(True, f"файл {verb}: {p} ({p.stat().st_size} байт)")
    except Exception as e:
        return ToolResult(False, f"ошибка записи {p}: {e}")


@tool("edit_file",
      "Точечная правка файла: заменяет фрагмент old_text на new_text "
      "(поиск с точностью до пробелов/переносов). replace_all=True меняет все "
      "вхождения.",
      {"type": "object",
       "properties": {
           "path": {"type": "string"},
           "old_text": {"type": "string", "description": "что заменить"},
           "new_text": {"type": "string", "description": "на что заменить"},
           "replace_all": {"type": "boolean"},
       },
       "required": ["path", "old_text", "new_text"]},
      dangerous=True, category="write")
def t_edit_file(ctx=None, path: str = "", old_text: str = "", new_text: str = "",
                replace_all: bool = False) -> ToolResult:
    p = _expand(path)
    err = _check_read(p)
    if err:
        return ToolResult(False, err)
    text, enc = _read_text(p)
    norm_old = old_text.replace("\r\n", "\n")
    norm_text = text.replace("\r\n", "\n")
    count = norm_text.count(norm_old)
    if count == 0:
        return ToolResult(False, f"фрагмент не найден в {p}")
    replaced = norm_text.replace(norm_old, new_text.replace("\r\n", "\n")) \
        if replace_all else norm_text.replace(norm_old, new_text.replace("\r\n", "\n"), 1)
    try:
        p.write_text(replaced, encoding=enc if enc != "utf-8(replace)" else "utf-8")
    except Exception as e:
        return ToolResult(False, f"ошибка записи: {e}")
    return ToolResult(True, f"заменено вхождений: {count if replace_all else 1} в {p}")


@tool("list_dir",
      "Показывает содержимое папки: имена, тип (файл/папка), размер, дату. "
      "recursive=True обходит вложенные папки (с лимитом).",
      {"type": "object",
       "properties": {
           "path": {"type": "string", "description": "путь к папке"},
           "recursive": {"type": "boolean"},
           "max_items": {"type": "integer"},
       },
       "required": ["path"]},
      category="files")
def t_list_dir(ctx=None, path: str = "", recursive: bool = False,
               max_items: int = 200) -> ToolResult:
    p = _expand(path)
    if not p.exists():
        return ToolResult(False, f"папка не найдена: {p}")
    if not p.is_dir():
        return ToolResult(False, f"это не папка: {p}")
    lines = [f"ПАПКА: {p}"]
    count = 0
    try:
        walker = p.rglob("*") if recursive else p.iterdir()
        for item in sorted(walker, key=lambda x: (x.is_file(), x.name.lower())):
            if count >= max_items:
                lines.append(f"... (показано {max_items}, всего больше)")
                break
            try:
                st = item.stat()
                kind = "ПАПКА" if item.is_dir() else f"{st.st_size} Б"
                mtime = time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime))
                lines.append(f"{'[D]' if item.is_dir() else '[F]'} {item.name}  "
                             f"{kind}  {mtime}")
                count += 1
            except OSError:
                continue
    except PermissionError:
        return ToolResult(False, f"нет прав на чтение папки {p}")
    return ToolResult(True, "\n".join(lines), data={"items": count})


@tool("find_files",
      "Ищет файлы по маске имени (glob) от указанной папки: *.pdf, отчёт*.docx, "
      "**/*.py. Возвращает полные пути.",
      {"type": "object",
       "properties": {
           "pattern": {"type": "string", "description": "glob-маска"},
           "root": {"type": "string", "description": "где искать (по умолчанию дом)"},
           "max_results": {"type": "integer"},
       },
       "required": ["pattern"]},
      category="files")
def t_find_files(ctx=None, pattern: str = "", root: str = "",
                 max_results: int = 100) -> ToolResult:
    base = _expand(root) if root else _home()
    if not base.exists():
        return ToolResult(False, f"корень поиска не найден: {base}")
    found = []
    try:
        for item in base.rglob(pattern):
            if item.is_file():
                found.append(str(item))
                if len(found) >= max_results:
                    break
    except (PermissionError, OSError) as e:
        if not found:
            return ToolResult(False, f"поиск прерван: {e}")
    if not found:
        return ToolResult(True, f"ничего не найдено по маске {pattern} в {base}")
    return ToolResult(True, f"Найдено {len(found)}:\n" + "\n".join(found),
                      data={"files": found})


@tool("grep_files",
      "Ищет текст (регулярное выражение или подстрока) в файлах папки. "
      "Возвращает путь, номер строки и саму строку.",
      {"type": "object",
       "properties": {
           "pattern": {"type": "string", "description": "что искать"},
           "root": {"type": "string", "description": "где искать"},
           "file_glob": {"type": "string", "description": "маска файлов (*.py)"},
           "case_sensitive": {"type": "boolean"},
           "max_results": {"type": "integer"},
       },
       "required": ["pattern", "root"]},
      category="files")
def t_grep_files(ctx=None, pattern: str = "", root: str = "", file_glob: str = "*",
                 case_sensitive: bool = False, max_results: int = 100) -> ToolResult:
    base = _expand(root)
    if not base.exists():
        return ToolResult(False, f"папка не найдена: {base}")
    flags = 0 if case_sensitive else re.IGNORECASE
    try:
        rx = re.compile(pattern, flags)
    except re.error as e:
        return ToolResult(False, f"некорректный шаблон: {e}")
    hits = []
    for path in base.rglob(file_glob):
        if not path.is_file() or path.suffix.lower() not in TEXT_EXTS:
            continue
        try:
            text, _ = _read_text(path)
        except OSError:
            continue
        for i, line in enumerate(text.splitlines(), 1):
            if rx.search(line):
                hits.append(f"{path}:{i}: {line.strip()[:200]}")
                if len(hits) >= max_results:
                    break
        if len(hits) >= max_results:
            break
    if not hits:
        return ToolResult(True, f"совпадений с {pattern!r} в {base} не найдено")
    return ToolResult(True, f"Совпадений: {len(hits)}\n" + "\n".join(hits))


@tool("file_info",
      "Сведения о файле/папке: размер, даты создания/изменения, права, тип.",
      {"type": "object", "properties": {"path": {"type": "string"}},
       "required": ["path"]},
      category="files")
def t_file_info(ctx=None, path: str = "") -> ToolResult:
    p = _expand(path)
    if not p.exists():
        return ToolResult(False, f"не найдено: {p}")
    st = p.stat()
    kind = "папка" if p.is_dir() else "файл"
    info = (f"{kind}: {p}\nразмер: {st.st_size} байт\n"
            f"изменён: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(st.st_mtime))}\n"
            f"создан: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(st.st_ctime))}\n"
            f"права: {stat.filemode(st.st_mode)}\n"
            f"расширение: {p.suffix or '(нет)'}")
    if p.is_file():
        try:
            text, kind2, _ = read_any(p)
            info += f"\nчитается как: {kind2}"
        except Exception:
            pass
    return ToolResult(True, info)


@tool("copy_file", "Копирует файл или папку в новое место.",
      {"type": "object",
       "properties": {"src": {"type": "string"}, "dst": {"type": "string"}},
       "required": ["src", "dst"]},
      category="files")
def t_copy_file(ctx=None, src: str = "", dst: str = "") -> ToolResult:
    s, d = _expand(src), _expand(dst)
    # БАГ: copy_file и move_file не проверяли security.denied_path_parts,
    # хотя write_file/delete_file/make_dir проверяют. Модель могла утащить
    # или подменить файл из защищённой системной папки.
    err = _denied(s) or _denied(d)
    if err:
        return ToolResult(False, err)
    if not s.exists():
        return ToolResult(False, f"источник не найден: {s}")
    try:
        if s.is_dir():
            shutil.copytree(s, d, dirs_exist_ok=True)
        else:
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(s, d)
        return ToolResult(True, f"скопировано: {s} -> {d}")
    except Exception as e:
        return ToolResult(False, f"ошибка копирования: {e}")


@tool("move_file", "Перемещает/переименовывает файл или папку.",
      {"type": "object",
       "properties": {"src": {"type": "string"}, "dst": {"type": "string"}},
       "required": ["src", "dst"]},
      dangerous=True, category="files")
def t_move_file(ctx=None, src: str = "", dst: str = "") -> ToolResult:
    s, d = _expand(src), _expand(dst)
    err = _denied(s) or _denied(d)      # см. t_copy_file: защита от system32
    if err:
        return ToolResult(False, err)
    if not s.exists():
        return ToolResult(False, f"источник не найден: {s}")
    try:
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s), str(d))
        return ToolResult(True, f"перемещено: {s} -> {d}")
    except Exception as e:
        return ToolResult(False, f"ошибка перемещения: {e}")


@tool("delete_file",
      "Удаляет файл или папку (безвозвратно, НЕ в корзину!). Выполняй сразу "
      "по просьбе пользователя — отдельного подтверждения система не спрашивает.",
      {"type": "object", "properties": {"path": {"type": "string"}},
       "required": ["path"]},
      dangerous=True, category="files")
def t_delete_file(ctx=None, path: str = "") -> ToolResult:
    p = _expand(path)
    err = _denied(p)
    if err:
        return ToolResult(False, err)
    if not p.exists():
        return ToolResult(False, f"не найдено: {p}")
    try:
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()
        return ToolResult(True, f"удалено: {p}")
    except Exception as e:
        return ToolResult(False, f"ошибка удаления: {e}")


@tool("make_dir", "Создаёт папку (и вложенные).",
      {"type": "object", "properties": {"path": {"type": "string"}},
       "required": ["path"]},
      category="files")
def t_make_dir(ctx=None, path: str = "") -> ToolResult:
    p = _expand(path)
    err = _denied(p)
    if err:
        return ToolResult(False, err)
    try:
        p.mkdir(parents=True, exist_ok=True)
        return ToolResult(True, f"папка создана: {p}")
    except Exception as e:
        return ToolResult(False, f"ошибка создания папки: {e}")
