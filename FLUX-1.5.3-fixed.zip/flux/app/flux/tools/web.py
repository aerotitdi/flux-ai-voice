"""Веб-инструменты: поиск через SearXNG (localhost:8888, Docker) + запасной
DuckDuckGo, и чтение страниц. Паритет с web search из Open WebUI."""
from __future__ import annotations

import html
import re
import urllib.parse

import requests

from .. import config, logger
from .registry import ToolResult, tool

log = logger.get_logger("flux.tools.web")

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
_TAG_RE = re.compile(r"<[^>]+>")


def _searxng_url() -> str:
    return str(config.get("search.searxng_url", "http://localhost:8888")).rstrip("/")


def searxng_search(query: str, max_results: int | None = None,
                   language: str | None = None) -> list[dict]:
    """Прямой запрос к SearXNG в формате JSON (formats: json включён в compose)."""
    url = _searxng_url() + "/search"
    params = {
        "q": query,
        "format": "json",
        "language": language or str(config.get("search.language", "ru-RU")),
        "safesearch": int(config.get("search.safesearch", 1)),
    }
    r = requests.get(url, params=params, timeout=float(config.get("search.timeout_sec", 12)),
                     headers={"User-Agent": "FLUX-assistant/1.0"})
    r.raise_for_status()
    data = r.json()
    out = []
    for item in (data.get("results") or [])[:int(max_results or config.get("search.max_results", 6))]:
        out.append({
            "title": html.unescape(str(item.get("title", "")).strip()),
            "url": str(item.get("url", "")),
            "snippet": html.unescape(_TAG_RE.sub("", str(item.get("content", ""))).strip()),
            "engine": item.get("engine", ""),
        })
    return out


def duckduckgo_search(query: str, max_results: int | None = None) -> list[dict]:
    """Запасной поиск без SearXNG (HTML-эндпоинт DuckDuckGo)."""
    limit = int(max_results or config.get("search.max_results", 6))
    r = requests.post("https://html.duckduckgo.com/html/",
                      data={"q": query, "kl": "ru-ru"},
                      headers={"User-Agent": _UA},
                      timeout=float(config.get("search.timeout_sec", 12)))
    r.raise_for_status()
    text = r.text
    out = []
    blocks = re.findall(
        r'<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>.*?'
        r'(?:<a[^>]*class="result__snippet"[^>]*>(.*?)</a>)?',
        text, re.DOTALL)
    for href, title, snippet in blocks[:limit]:
        url = href
        if "//duckduckgo.com/l/" in url:
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("uddg", [""])
            url = urllib.parse.unquote(q[0]) if q else url
        out.append({
            "title": html.unescape(_TAG_RE.sub("", title)).strip(),
            "url": url,
            "snippet": html.unescape(_TAG_RE.sub("", snippet or "")).strip(),
            "engine": "duckduckgo",
        })
    return out


def search(query: str, max_results: int | None = None) -> tuple[list[dict], str]:
    """Возвращает (результаты, источник). SearXNG -> DuckDuckGo при сбое."""
    if config.get("search.enabled", True):
        try:
            res = searxng_search(query, max_results)
            if res:
                return res, "searxng"
        except Exception as e:
            log.warning("SearXNG search failed: %s", e)
    if config.get("search.fallback_ddg", True):
        try:
            res = duckduckgo_search(query, max_results)
            if res:
                return res, "duckduckgo"
        except Exception as e:
            log.warning("DuckDuckGo search failed: %s", e)
    return [], "none"


def extract_text(html_text: str, max_chars: int | None = None) -> str:
    """HTML -> читаемый текст без скриптов/стилей/разметки."""
    s = re.sub(r"(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\1>", " ", html_text)
    s = re.sub(r"(?is)<!--.*?-->", " ", s)
    s = re.sub(r"(?is)<br\s*/?>|</p>|</div>|</li>|</h[1-6]>|</tr>", "\n", s)
    s = _TAG_RE.sub(" ", s)
    s = html.unescape(s)
    s = re.sub(r"[ \t\xa0]+", " ", s)
    s = re.sub(r"\n\s*\n\s*", "\n\n", s)
    s = s.strip()
    limit = int(max_chars or config.get("search.fetch_max_chars", 12000))
    return s[:limit]


def fetch(url: str, max_chars: int | None = None) -> tuple[str, str, str]:
    """(текст, content_type, заголовок)."""
    r = requests.get(url, timeout=float(config.get("search.fetch_timeout_sec", 20)),
                     headers={"User-Agent": _UA}, allow_redirects=True)
    r.raise_for_status()
    ctype = r.headers.get("Content-Type", "")
    title_m = re.search(r"(?is)<title[^>]*>(.*?)</title>", r.text[:20000])
    title = html.unescape(title_m.group(1)).strip() if title_m else url
    if "html" in ctype or r.text.lstrip()[:15].lower().startswith(("<!doctype", "<html")):
        return extract_text(r.text, max_chars), ctype, title
    return r.text[:int(max_chars or config.get("search.fetch_max_chars", 12000))], ctype, title


# --------------------------------------------------------------------- tools
SEARCH_PER_CALL_MAX = 50      # столько результатов можно посмотреть ЗА РАЗ
SEARCH_SESSION_CAP = 250      # столько результатов суммарно за один запрос-сессию


@tool("web_search",
      "Ищет в интернете через локальный SearXNG (Docker, localhost:8888). "
      "Возвращает заголовки, ссылки и сниппеты. Используй для актуальных фактов, "
      "новостей, погоды, курсов и т.п. За один вызов можно посмотреть до 50 "
      "результатов, суммарно за запрос - до 250. НЕ повторяй один и тот же "
      "запрос подряд: результаты уже в контексте.",
      {"type": "object",
       "properties": {
           "query": {"type": "string", "description": "поисковый запрос"},
           "max_results": {"type": "integer",
                           "description": "сколько результатов (1-50, по умолчанию 6)"},
       },
       "required": ["query"]},
      category="web")
def t_web_search(ctx=None, query: str = "", max_results: int = 6) -> ToolResult:
    limit = max(1, min(SEARCH_PER_CALL_MAX, int(max_results or 6)))
    shown = int(getattr(ctx, "search_shown", 0) or 0) if ctx is not None else 0
    cap = int(config.get("search.session_cap", SEARCH_SESSION_CAP))
    if shown >= cap:
        return ToolResult(False, f"достигнут лимит показа результатов поиска "
                                 f"за запрос ({cap}). Отвечай по уже полученным "
                                 f"данным или уточни запрос другими словами")
    results, source = search(query, limit)
    if ctx is not None:
        ctx.search_shown = shown + len(results)
    if not results:
        return ToolResult(False, "поиск не дал результатов (SearXNG и запасной "
                                 "поиск недоступны). Проверь Docker-контейнер "
                                 "SearXNG на localhost:8888")
    lines = [f"Поиск «{query}» ({source}), результатов: {len(results)}"]
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r['title']}\n   {r['url']}\n   {r['snippet'][:300]}")
    return ToolResult(True, "\n".join(lines), data={"results": results, "source": source})


@tool("fetch_webpage",
      "Скачивает веб-страницу по URL и возвращает её текст (без разметки). "
      "Используй после web_search, чтобы прочитать статью целиком.",
      {"type": "object",
       "properties": {
           "url": {"type": "string", "description": "полный URL страницы"},
           "max_chars": {"type": "integer", "description": "лимит символов текста"},
       },
       "required": ["url"]},
      category="web")
def t_fetch_webpage(ctx=None, url: str = "", max_chars: int = 12000) -> ToolResult:
    if not url.lower().startswith(("http://", "https://")):
        return ToolResult(False, "URL должен начинаться с http:// или https://")
    try:
        text, ctype, title = fetch(url, max_chars)
    except Exception as e:
        return ToolResult(False, f"не удалось загрузить {url}: {e}")
    if not text.strip():
        return ToolResult(False, f"страница {url} пустая (тип {ctype})")
    return ToolResult(True, f"Страница: {title}\nURL: {url}\n\n{text}",
                      data={"title": title, "chars": len(text)})
