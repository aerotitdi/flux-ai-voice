"""Инструменты FLUX (паритет с Open WebUI + computer use + устройства)."""
from __future__ import annotations


def import_all() -> list[str]:
    """Импортирует все модули инструментов (регистрирует их в реестре)."""
    from . import (apps, computer, devices, files, memory_tools, registry,
                   scheduler, shell, system, web)
    _ = (apps, computer, devices, files, memory_tools, scheduler, shell, system, web)
    return sorted(registry.REGISTRY)
