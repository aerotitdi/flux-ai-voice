"""Computer use: скриншоты (с передачей в мультимодальную gemma4), мышь,
клавиатура, окна. Аналог компьютер-инструментов Open WebUI + agent-практик."""
from __future__ import annotations

import os
import time
from pathlib import Path

from .. import logger, paths
from .registry import ToolResult, tool

log = logger.get_logger("flux.tools.computer")


def screen_size_text() -> str:
    """Разрешение рабочего стола - чтобы модель считала координаты метки
    в том же пиксельном пространстве, что и скриншот (практика GUI-агентов)."""
    try:
        import mss  # type: ignore
        with mss.mss() as sct:
            mon = sct.monitors[0]
            return f"{mon['width']}x{mon['height']}"
    except Exception:
        try:
            pg = _pyautogui()
            w, h = pg.size()
            return f"{w}x{h}"
        except Exception:
            return "неизвестно"


def _screenshot_path() -> Path:
    d = paths.SCREENSHOTS_DIR
    d.mkdir(parents=True, exist_ok=True)
    return d / time.strftime("screen_%Y%m%d_%H%M%S.png")


@tool("screenshot",
      "Делает скриншот экрана (или области) и прикладывает его для визуального "
      "анализа моделью. Возвращает путь к файлу и описание.",
      {"type": "object",
       "properties": {
           "region": {"type": "array",
                      "description": "[x, y, width, height] области или пусто = весь экран",
                      "items": {"type": "integer"}},
           "monitor": {"type": "integer", "description": "номер монитора (1 по умолч.)"},
       }},
      category="computer")
def t_screenshot(ctx=None, region: list | None = None, monitor: int = 1) -> ToolResult:
    try:
        import mss  # type: ignore
    except Exception as e:
        return ToolResult(False, f"mss не установлен: {e}")
    path = _screenshot_path()
    try:
        with mss.mss() as sct:
            if region and len(region) == 4:
                mon = {"left": int(region[0]), "top": int(region[1]),
                       "width": int(region[2]), "height": int(region[3])}
            else:
                idx = max(1, min(monitor, len(sct.monitors) - 1))
                mon = sct.monitors[idx]
            img = sct.grab(mon)
            import mss.tools
            mss.tools.to_png(img.rgb, img.size, output=str(path))
    except Exception as e:
        return ToolResult(False, f"не удалось сделать скриншот: {e}")
    res = ToolResult(True, f"Скриншот сохранён: {path} ({img.width}x{img.height}). "
                           f"Изображение приложено - опиши, что видишь, если нужно.",
                     data={"path": str(path)})
    res.attach_images = [str(path)]
    return res


def _pyautogui():
    import pyautogui  # type: ignore
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.05
    return pyautogui


@tool("mouse_click", "Клик мышью в координатах (или по центру экрана).",
      {"type": "object",
       "properties": {
           "x": {"type": "integer"}, "y": {"type": "integer"},
           "button": {"type": "string", "enum": ["left", "right", "middle"]},
           "clicks": {"type": "integer", "description": "1 = клик, 2 = двойной"},
      }},
      category="computer")
def t_mouse_click(ctx=None, x: int | None = None, y: int | None = None,
                  button: str = "left", clicks: int = 1) -> ToolResult:
    try:
        pg = _pyautogui()
        if x is None or y is None:
            w, h = pg.size()
            x, y = w // 2, h // 2
        pg.moveTo(int(x), int(y), duration=0.15)
        pg.click(int(x), int(y), button=button, clicks=int(clicks or 1))
        return ToolResult(True, f"клик {button} x{clicks} в ({x},{y})")
    except Exception as e:
        return ToolResult(False, f"клик не удался: {e}")


@tool("mouse_move", "Перемещает курсор мыши.",
      {"type": "object",
       "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}},
       "required": ["x", "y"]},
      category="computer")
def t_mouse_move(ctx=None, x: int = 0, y: int = 0) -> ToolResult:
    try:
        _pyautogui().moveTo(int(x), int(y), duration=0.15)
        return ToolResult(True, f"курсор в ({x},{y})")
    except Exception as e:
        return ToolResult(False, f"не удалось: {e}")


@tool("mouse_scroll", "Прокрутка колесом (положительное - вверх).",
      {"type": "object",
       "properties": {"amount": {"type": "integer", "description": "число щелчков колеса"}},
       "required": ["amount"]},
      category="computer")
def t_mouse_scroll(ctx=None, amount: int = 3) -> ToolResult:
    try:
        _pyautogui().scroll(int(amount))
        return ToolResult(True, f"прокрутка {amount}")
    except Exception as e:
        return ToolResult(False, f"не удалось: {e}")


@tool("mouse_drag", "Перетаскивание из точки A в точку B.",
      {"type": "object",
       "properties": {"x1": {"type": "integer"}, "y1": {"type": "integer"},
                      "x2": {"type": "integer"}, "y2": {"type": "integer"}},
       "required": ["x1", "y1", "x2", "y2"]},
      category="computer")
def t_mouse_drag(ctx=None, x1: int = 0, y1: int = 0, x2: int = 0, y2: int = 0) -> ToolResult:
    try:
        pg = _pyautogui()
        pg.moveTo(x1, y1)
        pg.drag(x2 - x1, y2 - y1, duration=0.4, button="left")
        return ToolResult(True, f"перетащено ({x1},{y1}) -> ({x2},{y2})")
    except Exception as e:
        return ToolResult(False, f"не удалось: {e}")


@tool("type_text", "Печатает текст в активное окно (как с клавиатуры).",
      {"type": "object",
       "properties": {"text": {"type": "string"},
                      "interval": {"type": "number", "description": "пауза между символами"}},
       "required": ["text"]},
      category="computer")
def t_type_text(ctx=None, text: str = "", interval: float = 0.02) -> ToolResult:
    try:
        pg = _pyautogui()
        pg.typewrite(text, interval=float(interval or 0.02)) if text.isascii() \
            else pg.write(text, interval=float(interval or 0.02))
        return ToolResult(True, f"напечатано {len(text)} символов")
    except Exception as e:
        return ToolResult(False, f"печать не удалась: {e}")


@tool("press_keys", "Нажимает сочетание клавиш: 'ctrl+c', 'win+d', 'enter', "
      "'alt+tab', 'numpad9' и т.п.",
      {"type": "object",
       "properties": {"keys": {"type": "string", "description": "сочетание через +"},
                      "repeat": {"type": "integer"}},
       "required": ["keys"]},
      category="computer")
def t_press_keys(ctx=None, keys: str = "", repeat: int = 1) -> ToolResult:
    try:
        pg = _pyautogui()
        combo = [k.strip() for k in keys.lower().replace(" ", "").split("+")]
        for _ in range(max(1, int(repeat or 1))):
            pg.hotkey(*combo) if len(combo) > 1 else pg.press(combo[0])
        return ToolResult(True, f"нажато: {keys}")
    except Exception as e:
        return ToolResult(False, f"нажатие не удалось: {e}")


@tool("list_windows", "Список открытых окон (заголовок + процесс).",
      {"type": "object", "properties": {}},
      category="computer")
def t_list_windows(ctx=None) -> ToolResult:
    wins = _windows_native()
    if wins is None:
        return ToolResult(False, "не удалось получить список окон на этой ОС")
    if not wins:
        return ToolResult(True, "видимых окон не найдено")
    lines = [f"{i+1}. {t}  [{p}]" for i, (t, p) in enumerate(wins[:80])]
    return ToolResult(True, f"Окон: {len(wins)}\n" + "\n".join(lines),
                      data={"windows": [{"title": t, "process": p} for t, p in wins]})


def _windows_native():
    if os.name != "nt":
        return None
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    out: list[tuple[str, str]] = []
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND,
                                         wintypes.LPARAM)

    def cb(hwnd, lparam):
        if user32.IsWindowVisible(hwnd):
            length = user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buf = ctypes.create_unicode_buffer(length + 1)
                user32.GetWindowTextW(hwnd, buf, length + 1)
                pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                out.append((buf.value, str(pid.value)))
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    return out


@tool("focus_window", "Активирует окно по части заголовка.",
      {"type": "object",
       "properties": {"title": {"type": "string", "description": "часть заголовка окна"}},
       "required": ["title"]},
      category="computer")
def t_focus_window(ctx=None, title: str = "") -> ToolResult:
    if os.name != "nt":
        return ToolResult(False, "focus_window поддерживается только на Windows")
    import ctypes
    user32 = ctypes.windll.user32
    wins = _windows_native() or []
    needle = title.lower()
    target = next((w for w in wins if needle in w[0].lower()), None)
    if not target:
        return ToolResult(False, f"окно с заголовком, содержащим {title!r}, не найдено")
    hwnd = _hwnd_by_title(target[0])
    if hwnd is None:
        return ToolResult(False, "окно найдено, но дескриптор недоступен")
    user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.SetForegroundWindow(hwnd)
    return ToolResult(True, f"окно активировано: {target[0]}")


def _hwnd_by_title(title: str):
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, lparam):
        length = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        if buf.value == title:
            found.append(hwnd)
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    return found[0] if found else None


@tool("screen_info", "Информация об экранах: размеры, количество мониторов, "
      "позиция курсора.",
      {"type": "object", "properties": {}},
      category="computer")
def t_screen_info(ctx=None) -> ToolResult:
    try:
        pg = _pyautogui()
        w, h = pg.size()
        x, y = pg.position()
        extra = ""
        try:
            import mss
            with mss.mss() as sct:
                extra = f", мониторов: {len(sct.monitors) - 1}"
        except Exception:
            pass
        return ToolResult(True, f"экран {w}x{h}, курсор ({x},{y}){extra}")
    except Exception as e:
        return ToolResult(False, f"не удалось: {e}")


@tool("look_at_screen",
      "СМОТРИТ на экран: делает скриншот и прикладывает его к диалогу для "
      "визуального анализа. Используй, когда пользователь спрашивает про то, "
      "что у него на экране (игра, окно, ошибка, куда поставить башню и т.п.).",
      {"type": "object",
       "properties": {
           "monitor": {"type": "integer", "description": "номер монитора (1)"},
           "question": {"type": "string",
                        "description": "на что обратить внимание на экране"},
       }},
      category="computer")
def t_look_at_screen(ctx=None, monitor: int = 1, question: str = "") -> ToolResult:
    res = t_screenshot(ctx=ctx, region=None, monitor=monitor)
    if not res.ok:
        return res
    extra = f" Вопрос к изображению: {question}" if question else ""
    size = screen_size_text()
    res.text = (f"ЭКРАН ПРИЛОЖЕН для визуального анализа. Разрешение экрана: "
                f"{size} - координаты для point_at_screen указывай в этих же "
                f"пикселях." + extra + " Опиши, что видишь, и дай рекомендацию. "
                + res.text)
    res.data["screen_size"] = size
    return res


@tool("point_at_screen",
      "Ставит МЕТКУ на экране поверх всех окон (крест + круг + подпись) в "
      "указанных координатах на несколько секунд. Используй ПОСЛЕ look_at_screen, "
      "чтобы показать пользователю КУДА ставить башню/куда кликнуть/где объект. "
      "В эксклюзивном полноэкранном режиме игры оверлей может быть не виден - "
      "тогда скажи координаты словами и попроси оконный/бордерлес режим.",
      {"type": "object",
       "properties": {
           "x": {"type": "integer", "description": "координата X на экране"},
           "y": {"type": "integer", "description": "координата Y на экране"},
           "label": {"type": "string", "description": "подпись у метки"},
           "seconds": {"type": "number", "description": "сколько держать (1-60)"},
       },
       "required": ["x", "y"]},
      category="computer")
def t_point_at_screen(ctx=None, x: int = 0, y: int = 0, label: str = "",
                      seconds: float = 6.0) -> ToolResult:
    seconds = max(1.0, min(60.0, float(seconds or 6)))
    try:
        import tkinter as tk
    except Exception as e:
        return ToolResult(False, f"tkinter недоступен: {e}")

    def _overlay() -> None:
        try:
            root = tk.Tk()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            try:
                root.attributes("-transparentcolor", "magenta")
                bg = "magenta"
            except Exception:
                bg = "black"
            size = 220
            root.geometry(f"{size}x{size}+{int(x) - size // 2}+{int(y) - size // 2}")
            cv = tk.Canvas(root, width=size, height=size, bg=bg,
                           highlightthickness=0)
            cv.pack()
            c = size // 2
            cv.create_oval(c - 46, c - 46, c + 46, c + 46, outline="#00ff88",
                           width=4)
            cv.create_line(c - 70, c, c + 70, c, fill="#00ff88", width=3)
            cv.create_line(c, c - 70, c, c + 70, fill="#00ff88", width=3)
            if label:
                cv.create_text(c, c + 66, text=label, fill="#ffffff",
                               font=("Segoe UI", 12, "bold"))
            root.after(int(seconds * 1000), root.destroy)
            root.mainloop()
        except Exception:
            pass

    import threading
    threading.Thread(target=_overlay, name="flux-marker", daemon=True).start()
    return ToolResult(True, f"метка показана в ({x},{y}) на {seconds} c"
                            + (f": {label}" if label else ""))


@tool("wait_seconds", "Пауза перед следующим действием (секунды).",
      {"type": "object",
       "properties": {"seconds": {"type": "number"}},
       "required": ["seconds"]},
      category="computer")
def t_wait_seconds(ctx=None, seconds: float = 1.0) -> ToolResult:
    time.sleep(max(0.0, min(30.0, float(seconds or 1))))
    return ToolResult(True, f"пауза {seconds} c завершена")
