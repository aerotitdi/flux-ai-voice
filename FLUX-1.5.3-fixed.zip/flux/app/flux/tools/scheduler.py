"""Таймеры и напоминания: срабатывают голосом через фоновый поток main."""
from __future__ import annotations

import time
from datetime import datetime, timedelta

from .. import logger
from .registry import ToolResult, tool

log = logger.get_logger("flux.tools.scheduler")


def _store(ctx):
    return getattr(ctx, "store", None)


@tool("set_timer",
      "Ставит таймер на N секунд/минут/часов; когда время придёт, FLUX скажет "
      "сообщение голосом.",
      {"type": "object",
       "properties": {
           "value": {"type": "number", "description": "сколько"},
           "unit": {"type": "string", "enum": ["seconds", "minutes", "hours"]},
           "message": {"type": "string", "description": "что сказать по окончании"},
       },
       "required": ["value", "unit", "message"]},
      category="scheduler")
def t_set_timer(ctx=None, value: float = 0, unit: str = "minutes",
                message: str = "") -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "планировщик недоступен")
    mult = {"seconds": 1, "minutes": 60, "hours": 3600}.get(unit, 60)
    secs = float(value) * mult
    if secs <= 0:
        return ToolResult(False, "время должно быть положительным")
    fire = time.time() + secs
    tid = store.timer_add("timer", fire, message or "время вышло")
    when = datetime.fromtimestamp(fire).strftime("%H:%M:%S")
    return ToolResult(True, f"таймер на {value} {unit} установлен (id={tid}), "
                            f"сработает в {when}: «{message}»")


@tool("set_reminder",
      "Напоминание на конкретное время (HH:MM сегодня или завтра, если время "
      "уже прошло). FLUX озвучит его голосом.",
      {"type": "object",
       "properties": {"time_hhmm": {"type": "string", "description": "напр. 18:30"},
                      "message": {"type": "string"}},
       "required": ["time_hhmm", "message"]},
      category="scheduler")
def t_set_reminder(ctx=None, time_hhmm: str = "", message: str = "") -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "планировщик недоступен")
    m = __import__("re").match(r"^(\d{1,2}):(\d{2})$", time_hhmm.strip())
    if not m:
        return ToolResult(False, f"время должно быть в формате HH:MM, получено {time_hhmm!r}")
    hh, mm = int(m.group(1)), int(m.group(2))
    if hh > 23 or mm > 59:
        return ToolResult(False, "некорректное время")
    now = datetime.now()
    target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if target <= now:
        target += timedelta(days=1)
    tid = store.timer_add("reminder", target.timestamp(), message)
    return ToolResult(True, f"напоминание на {target:%d.%m %H:%M} (id={tid}): «{message}»")


@tool("list_timers", "Показывает активные таймеры и напоминания.",
      {"type": "object", "properties": {}},
      category="scheduler")
def t_list_timers(ctx=None) -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "планировщик недоступен")
    items = store.timer_list()
    if not items:
        return ToolResult(True, "активных таймеров нет")
    lines = []
    for t in items:
        when = datetime.fromtimestamp(t["fire_at"]).strftime("%d.%m %H:%M:%S")
        lines.append(f"- [{t['id']}] {t['kind']} на {when}: {t['message']}")
    return ToolResult(True, "\n".join(lines))


@tool("cancel_timer", "Отменяет таймер/напоминание по id.",
      {"type": "object",
       "properties": {"timer_id": {"type": "integer"}},
       "required": ["timer_id"]},
      category="scheduler")
def t_cancel_timer(ctx=None, timer_id: int = 0) -> ToolResult:
    store = _store(ctx)
    if store is None:
        return ToolResult(False, "планировщик недоступен")
    ok = store.timer_cancel(int(timer_id))
    return ToolResult(ok, f"таймер {timer_id} отменен" if ok
                      else f"таймер {timer_id} не найден или уже сработал")
