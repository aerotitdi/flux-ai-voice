"""Shell / интерпретатор кода (аналог Code Interpreter из Open WebUI).

Всё выполняется в ОТДЕЛЬНОМ процессе с таймаутом и ограничением вывода.
Подтверждения операций отключены: агент ПК действует сразу по просьбе
пользователя (единственный оставшийся барьер — security.denied_path_parts
и security.allow_shell).
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile

from .. import logger, paths
from .registry import ToolResult, tool

log = logger.get_logger("flux.tools.shell")

MAX_OUTPUT = 6000


def _truncate(s: str) -> str:
    if len(s) <= MAX_OUTPUT:
        return s
    half = MAX_OUTPUT // 2
    return s[:half] + f"\n...[обрезано {len(s) - MAX_OUTPUT} символов]...\n" + s[-half:]


def _run(cmd: list[str], cwd: str | None, timeout: int, stdin_data: str | None = None):
    kwargs: dict = dict(cwd=cwd or str(paths.HOME), timeout=timeout,
                        capture_output=True, text=True, errors="replace")
    if stdin_data is not None:
        kwargs["input"] = stdin_data
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.run(cmd, **kwargs)
    return proc.returncode, proc.stdout or "", proc.stderr or ""


@tool("run_command",
      "Выполняет команду в оболочке системы (Windows: PowerShell, иначе bash). "
      "Возвращает код возврата, stdout и stderr. Выполняй сразу, ничего не "
      "переспрашивая: подтверждения действий в Флюксе отключены.",
      {"type": "object",
       "properties": {
           "command": {"type": "string", "description": "команда целиком"},
           "cwd": {"type": "string", "description": "рабочая папка (необязательно)"},
           "timeout": {"type": "integer", "description": "таймаут секунд (1-300)"},
       },
       "required": ["command"]},
      dangerous=True, category="shell")
def t_run_command(ctx=None, command: str = "", cwd: str = "", timeout: int = 60) -> ToolResult:
    if not command.strip():
        return ToolResult(False, "пустая команда")
    timeout = max(1, min(300, int(timeout or 60)))
    if os.name == "nt":
        cmd = ["powershell", "-NoProfile", "-Command", command]
    else:
        cmd = ["bash", "-c", command]
    try:
        code, out, err = _run(cmd, cwd or None, timeout)
    except subprocess.TimeoutExpired:
        return ToolResult(False, f"команда не уложилась в {timeout} c и убита")
    except Exception as e:
        return ToolResult(False, f"не удалось выполнить: {e}")
    body = f"exit={code}\nSTDOUT:\n{_truncate(out)}\n"
    if err.strip():
        body += f"STDERR:\n{_truncate(err)}"
    return ToolResult(code == 0, body.strip(), data={"exit": code})


@tool("run_python",
      "Выполняет Python-код в изолированном процессе (code interpreter) и "
      "возвращает вывод. Код получает доступ к файлам пользователя.",
      {"type": "object",
       "properties": {
           "code": {"type": "string", "description": "python-код"},
           "timeout": {"type": "integer", "description": "таймаут секунд (1-300)"},
       },
       "required": ["code"]},
      dangerous=True, category="shell")
def t_run_python(ctx=None, code: str = "", timeout: int = 60) -> ToolResult:
    if not code.strip():
        return ToolResult(False, "пустой код")
    timeout = max(1, min(300, int(timeout or 60)))
    fd, path = tempfile.mkstemp(suffix=".py", prefix="flux_code_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(code)
        code_, out, err = _run([sys.executable, path], str(paths.HOME), timeout)
    except subprocess.TimeoutExpired:
        return ToolResult(False, f"код не уложился в {timeout} c и убит")
    except Exception as e:
        return ToolResult(False, f"не удалось запустить python: {e}")
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    body = f"exit={code_}\n{_truncate(out)}"
    if err.strip():
        body += f"\nSTDERR:\n{_truncate(err)}"
    return ToolResult(code_ == 0, body.strip(), data={"exit": code_})
