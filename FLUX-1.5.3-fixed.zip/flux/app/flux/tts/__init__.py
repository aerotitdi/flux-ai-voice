"""Озвучка FLUX: Edge TTS (как в спейсе innoai/Edge-TTS-Text-to-Speech),
офлайн-запас SAPI5, опционально HF-space. Озвучивается ТОЛЬКО текст в *-...-*-"""
