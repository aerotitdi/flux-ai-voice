"""Движки озвучки.

Основной - Edge TTS (тот же движок, что использует публичный спейс
innoai/Edge-TTS-Text-to-Speech): голос ru-RU-DmitryNeural по умолчанию,
регулировки в тех же диапазонах, что и там:
    Speech Rate Adjustment: -50..+50 %   (строка "+N%")
    Pitch Adjustment:       -20..+20 Hz  (строка "+NHz")

Из практики: Microsoft периодически отвечает NoAudioReceived, поэтому
синтез идёт с ретраями, проверкой результата и запасным движком SAPI5
(голоса Windows, работает офлайн).
"""
from __future__ import annotations

import asyncio
import os
import tempfile
import threading
import time
from dataclasses import dataclass
from typing import Optional

from .. import config, logger

log = logger.get_logger("flux.tts")

RATE_MIN, RATE_MAX = -50, 50
PITCH_MIN, PITCH_MAX = -20, 20


@dataclass
class VoiceInfo:
    short_name: str
    locale: str
    gender: str
    friendly: str = ""

    @property
    def label(self) -> str:
        return f"{self.short_name} - {self.locale} ({self.gender})"


def _run_async(coro):
    """asyncio.run с SelectorEventLoop на Windows.

    aiohttp (edge-tts) на ProactorEventLoop периодически даёт
    SSL: DECRYPTION_FAILED_OR_BAD_RECORD_MAC при подключении к
    speech.platform.bing.com - известная несовместимость; Selector-политика
    её убирает.
    """
    if os.name == "nt":
        try:
            if isinstance(asyncio.get_event_loop_policy(),
                          asyncio.WindowsProactorEventLoopPolicy):
                asyncio.set_event_loop_policy(
                    asyncio.WindowsSelectorEventLoopPolicy())
        except Exception:
            pass
    return asyncio.run(coro)


def clamp_rate(v) -> int:
    return max(RATE_MIN, min(RATE_MAX, int(round(float(v)))))


def clamp_pitch(v) -> int:
    return max(PITCH_MIN, min(PITCH_MAX, int(round(float(v)))))


def rate_str(v) -> str:
    """Формат ровно как в спейсе: f\"{rate:+d}%\""""
    return f"{clamp_rate(v):+d}%"


def pitch_str(v) -> str:
    return f"{clamp_pitch(v):+d}Hz"


_VOICE_CACHE: dict[str, tuple[float, list[VoiceInfo]]] = {}


def list_voices(refresh: bool = False, timeout: float = 15.0) -> list[VoiceInfo]:
    """Список голосов Edge TTS (кэш 1 час). Русские - первыми."""
    key = "voices"
    cached = _VOICE_CACHE.get(key)
    if cached and not refresh and time.time() - cached[0] < 3600:
        return cached[1]
    import edge_tts  # type: ignore

    async def _run():
        raw = await edge_tts.list_voices()
        out = [VoiceInfo(v["ShortName"], v["Locale"], v["Gender"]) for v in raw]
        out.sort(key=lambda v: (not v.locale.startswith("ru-RU"),
                                v.gender != "Male", v.short_name))
        return out

    voices = _run_async(_run())
    _VOICE_CACHE[key] = (time.time(), voices)
    return voices


def russian_voices() -> list[VoiceInfo]:
    try:
        return [v for v in list_voices() if v.locale.startswith("ru")]
    except Exception:
        return []


class EdgeTTSEngine:
    """Синтез через edge-tts с ретраями и запасным голосом."""

    name = "edge"

    def __init__(self, voice: str = "ru-RU-DmitryNeural", rate: int = 0,
                 pitch: int = 0, volume: int = 0, retries: int = 3,
                 fallback_voice: str = "ru-RU-SvetlanaNeural",
                 timeout: float = 20.0) -> None:
        self.voice = voice
        self.fallback_voice = fallback_voice
        self.rate = clamp_rate(rate)
        self.pitch = clamp_pitch(pitch)
        self.volume = int(volume)
        self.retries = max(1, int(retries))
        self.timeout = timeout
        self.failures = 0
        self.synth_count = 0

    # ------------------------------------------------------------------ public
    def available(self) -> bool:
        try:
            import edge_tts  # noqa: F401
            return True
        except Exception:
            return False

    def synthesize(self, text: str, out_path: Optional[str] = None) -> Optional[str]:
        """Синтезирует текст в mp3. Возвращает путь или None при неудаче."""
        if not text or not text.strip():
            return None
        import edge_tts  # type: ignore

        tmp = out_path
        own_tmp = tmp is None
        if own_tmp:
            fd, tmp = tempfile.mkstemp(suffix=".mp3", prefix="flux_tts_")
            os.close(fd)

        voices_to_try = [self.voice]
        if self.fallback_voice and self.fallback_voice != self.voice:
            voices_to_try.append(self.fallback_voice)

        last_err: Exception | None = None
        for voice in voices_to_try:
            for attempt in range(self.retries):
                try:
                    comm = edge_tts.Communicate(
                        text, voice,
                        rate=rate_str(self.rate),
                        pitch=pitch_str(self.pitch),
                        volume=f"{self.volume:+d}%" if self.volume else "+0%",
                    )
                    _run_async(self._save_with_timeout(comm, tmp,
                                                       self.timeout))
                    if self._valid_mp3(tmp):
                        self.synth_count += 1
                        self.failures = 0
                        return tmp
                    last_err = RuntimeError("пустой/битый ответ edge-tts")
                except Exception as e:  # NoAudioReceived и сетевые сбои
                    last_err = e
                log.debug("edge-tts attempt %s (%s) failed: %s",
                          attempt + 1, voice, last_err)
                # backoff ТОЛЬКО если будет ещё одна попытка: раньше мы спали
                # 0.6·N c и после последней, добавляя задержку перед фолбэком
                if attempt < self.retries - 1:
                    time.sleep(0.6 * (attempt + 1))
            log.warning("edge-tts: голос %s недоступен, пробую запасной", voice)
        self.failures += 1
        if own_tmp and tmp and os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        if last_err:
            log.warning("edge-tts synthesis failed: %s", last_err)
        return None

    # ---------------------------------------------------------------- internals
    @staticmethod
    async def _save_with_timeout(comm, path: str, timeout: float = 30.0) -> None:
        # БАГ: таймаут был зашит как 30.0, а self.timeout (20 c из конструктора)
        # не использовался вовсе — мёртвый параметр, который к тому же делал
        # ожидание дольше обещанного.
        await asyncio.wait_for(comm.save(path), timeout=float(timeout or 30.0))

    @staticmethod
    def _valid_mp3(path: str) -> bool:
        try:
            if not os.path.exists(path) or os.path.getsize(path) < 400:
                return False
            with open(path, "rb") as f:
                head = f.read(4)
            return head[:3] == b"ID3" or head[0] == 0xFF
        except OSError:
            return False


class SAPI5Engine:
    """Офлайн-запас: голоса Windows (SAPI5) через pyttsx3 или PowerShell."""

    name = "sapi5"

    def __init__(self, voice: str = "", rate: int = 0, volume: int = 100) -> None:
        self.voice = voice
        self.rate = max(-10, min(10, int(round(rate / 5))))  # -50..50% -> -10..10
        self.volume = max(0, min(100, int(volume)))

    def available(self) -> bool:
        if os.name != "nt":
            return False
        try:
            import pyttsx3  # noqa: F401
            return True
        except Exception:
            return self._powershell_available()

    @staticmethod
    def _has_ru_voice() -> bool | None:
        """True/False если удалось перечислить голоса, None если движка нет."""
        if os.name != "nt":
            return False
        try:
            import pyttsx3  # type: ignore
            eng = pyttsx3.init()
            try:
                voices = eng.getProperty("voices") or []
            finally:
                try:
                    eng.stop()
                except Exception:
                    pass
            return any("ru" in (v.id or "").lower() or "russian" in (v.name or "").lower()
                       or "рус" in (v.name or "").lower() for v in voices)
        except Exception:
            try:
                import subprocess
                r = subprocess.run(
                    ["powershell", "-NoProfile", "-Command",
                     "(New-Object System.Speech.Synthesis.SpeechSynthesizer)"
                     ".GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Culture }"],
                    capture_output=True, text=True, timeout=20,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                if r.returncode == 0:
                    return any(l.strip().lower().startswith("ru")
                               for l in r.stdout.splitlines())
            except Exception:
                return None
        return None

    def synthesize(self, text: str, out_path: Optional[str] = None) -> Optional[str]:
        """SAPI5 пишет WAV (offline). Возвращает путь или None."""
        if not text or not text.strip():
            return None
        if any("а" <= ch <= "я" or "А" <= ch <= "Я" for ch in text):
            ru = self._has_ru_voice()
            if ru is False:
                # английский голос на русском тексте = «Ф ПФФС»: не озвучиваем,
                # пусть маршрутизатор возьмёт следующий движок
                log.warning("SAPI5: нет русского голоса - пропускаю, "
                            "чтобы не говорить по-русски английским голосом")
                return None
        tmp = out_path
        if tmp is None:
            fd, tmp = tempfile.mkstemp(suffix=".wav", prefix="flux_tts_")
            os.close(fd)
        try:
            return self._via_pyttsx3(text, tmp)
        except Exception as e:
            log.debug("pyttsx3 failed: %s", e)
        try:
            return self._via_powershell(text, tmp)
        except Exception as e:
            log.debug("powershell TTS failed: %s", e)
            return None

    def _via_pyttsx3(self, text: str, path: str) -> str:
        import pyttsx3  # type: ignore

        engine = pyttsx3.init()
        try:
            engine.setProperty("rate", 180 + self.rate * 15)
            engine.setProperty("volume", self.volume / 100.0)
            if self.voice:
                for v in engine.getProperty("voices"):
                    if self.voice.lower() in v.name.lower() or self.voice in v.id:
                        engine.setProperty("voice", v.id)
                        break
            engine.save_to_file(text, path)
            engine.runAndWait()
        finally:
            try:
                engine.stop()
            except Exception:
                pass
        if os.path.exists(path) and os.path.getsize(path) > 400:
            return path
        raise RuntimeError("pyttsx3 не записал файл")

    def _via_powershell(self, text: str, path: str) -> str:
        import subprocess

        script = (
            # ВАЖНО: stdin приходит в UTF-8, а консоль по умолчанию CP866/CP1251 -
            # без этой строки SAPI5 произносит моложаву, а whisper слышит мусор
            "[Console]::InputEncoding = [System.Text.Encoding]::UTF8; "
            "Add-Type -AssemblyName System.Speech; "
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            f"$s.Rate = {self.rate}; $s.Volume = {self.volume}; "
            f"$s.SetOutputToWaveFile('{path}'); $s.Speak([Console]::In.ReadToEnd()); "
            "$s.Dispose()"
        )
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            input=text.encode("utf-8"), timeout=60,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if proc.returncode == 0 and os.path.exists(path) and os.path.getsize(path) > 400:
            return path
        raise RuntimeError("powershell TTS error")

    @staticmethod
    def _powershell_available() -> bool:
        import shutil
        return shutil.which("powershell") is not None


class HFSpaceEngine:
    """Опциональный движок: публичный спейс innoai/Edge-TTS-Text-to-Speech.

    Используется только если edge-tts локально сломан, а интернет есть.
    Gradio REST API: POST /gradio_api/call/tts_interface, затем GET результата.
    """

    name = "hf_space"
    SPACE = "https://innoai-edge-tts-text-to-speech.hf.space"

    def __init__(self, voice_label: str = "ru-RU-DmitryNeural - ru-RU (Male)",
                 rate: int = 0, pitch: int = 0, timeout: float = 45.0) -> None:
        self.voice_label = voice_label
        self.rate = clamp_rate(rate)
        self.pitch = clamp_pitch(pitch)
        self.timeout = timeout

    def available(self) -> bool:
        try:
            import requests  # noqa: F401
            return True
        except Exception:
            return False

    def synthesize(self, text: str, out_path: Optional[str] = None) -> Optional[str]:
        import requests

        if not text or not text.strip():
            return None
        tmp = out_path
        if tmp is None:
            fd, tmp = tempfile.mkstemp(suffix=".mp3", prefix="flux_tts_")
            os.close(fd)
        url = f"{self.SPACE}/gradio_api/call/tts_interface"
        try:
            r = requests.post(url, json={"data": [text, self.voice_label,
                                                  self.rate, self.pitch]},
                              timeout=self.timeout)
            r.raise_for_status()
            event_id = r.json().get("event_id")
            if not event_id:
                return None
            deadline = time.time() + self.timeout
            result = None
            while time.time() < deadline:
                g = requests.get(f"{url}/{event_id}", timeout=self.timeout)
                if g.status_code == 200:
                    payload = g.json()
                    if payload.get("status") in ("complete", "generating"):
                        if payload.get("status") == "complete":
                            result = payload
                            break
                time.sleep(0.5)
            if not result:
                return None
            file_url = result["data"][0]["url"] if isinstance(result["data"][0], dict) \
                else result["data"][0]
            audio = requests.get(file_url, timeout=self.timeout)
            audio.raise_for_status()
            with open(tmp, "wb") as f:
                f.write(audio.content)
            if os.path.getsize(tmp) > 400:
                return tmp
        except Exception as e:
            log.debug("hf_space tts failed: %s", e)
        return None


class OpenAITTSEngine:
    """OpenAI-совместимый POST {base}/audio/speech (mp3). Работает с ключом
    OpenAI ($5 стартовых кредитов) и любыми совместимыми прокси/Azure."""

    name = "openai"

    def __init__(self, api_key: str = "", base_url: str = "", model: str = "",
                 voice: str = "", timeout: float = 30.0) -> None:
        from .. import config as _c
        o = _c.get("tts.openai", {}) or {}
        self.api_key = api_key or str(_c.get("keys.openai", "") or "")
        self.base_url = (base_url or str(o.get("base_url",
                                               "https://api.openai.com/v1"))).rstrip("/")
        self.model = model or str(o.get("model", "gpt-4o-mini-tts"))
        self.voice = voice or str(o.get("voice", "onyx"))
        self.timeout = timeout

    def available(self) -> bool:
        return bool(self.api_key)

    def synthesize(self, text: str, out_path: Optional[str] = None) -> Optional[str]:
        import requests

        if not text.strip() or not self.api_key:
            return None
        tmp = out_path
        if tmp is None:
            fd, tmp = tempfile.mkstemp(suffix=".mp3", prefix="flux_tts_")
            os.close(fd)
        try:
            r = requests.post(
                f"{self.base_url}/audio/speech",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"model": self.model, "voice": self.voice,
                      "input": text, "response_format": "mp3"},
                timeout=self.timeout)
            r.raise_for_status()
            if len(r.content) < 400:
                return None
            with open(tmp, "wb") as f:
                f.write(r.content)
            return tmp
        except Exception as e:
            log.debug("openai tts failed: %s", e)
            return None


class ElevenLabsEngine:
    """ElevenLabs v1 text-to-speech: свободный лимит ~10k символов/мес,
    multilingual v2 - один из лучших русских голосов."""

    name = "elevenlabs"

    def __init__(self, api_key: str = "", base_url: str = "", model_id: str = "",
                 voice_id: str = "", timeout: float = 30.0) -> None:
        from .. import config as _c
        o = _c.get("tts.elevenlabs", {}) or {}
        self.api_key = api_key or str(_c.get("keys.elevenlabs", "") or "")
        self.base_url = (base_url or str(o.get("base_url",
                                               "https://api.elevenlabs.io"))).rstrip("/")
        self.model_id = model_id or str(o.get("model_id", "eleven_multilingual_v2"))
        self.voice_id = voice_id or str(o.get("voice_id", "21m00Tcm4TlvDq8ikWAM"))
        self.timeout = timeout

    def available(self) -> bool:
        return bool(self.api_key)

    def synthesize(self, text: str, out_path: Optional[str] = None) -> Optional[str]:
        import requests

        if not text.strip() or not self.api_key:
            return None
        tmp = out_path
        if tmp is None:
            fd, tmp = tempfile.mkstemp(suffix=".mp3", prefix="flux_tts_")
            os.close(fd)
        try:
            r = requests.post(
                f"{self.base_url}/v1/text-to-speech/{self.voice_id}",
                headers={"xi-api-key": self.api_key,
                         "Content-Type": "application/json"},
                params={"model_id": self.model_id},
                json={"text": text,
                      "voice_settings": {"stability": 0.5,
                                         "similarity_boost": 0.75}},
                timeout=self.timeout)
            r.raise_for_status()
            if len(r.content) < 400:
                return None
            with open(tmp, "wb") as f:
                f.write(r.content)
            return tmp
        except Exception as e:
            log.debug("elevenlabs tts failed: %s", e)
            return None


class TTSRouter:
    """Выбор движка: auto -> edge -> hf_space -> sapi5 (офлайн)."""

    def __init__(self, cfg=None) -> None:
        self.cfg = cfg or config
        self._lock = threading.Lock()
        self._engines: dict[str, object] = {}
        self.last_engine = ""
        self.reload()

    def reload(self) -> None:
        t = self.cfg.get("tts", {}) or {}
        edge_cfg = t.get("edge", {}) or {}
        self.edge = EdgeTTSEngine(
            voice=edge_cfg.get("voice", "ru-RU-DmitryNeural"),
            rate=int(str(edge_cfg.get("rate", "+0%")).strip().rstrip("%") or 0)
            if isinstance(edge_cfg.get("rate"), str) else int(edge_cfg.get("rate", 0)),
            pitch=int(str(edge_cfg.get("pitch", "+0Hz")).strip().rstrip("Hz") or 0)
            if isinstance(edge_cfg.get("pitch"), str) else int(edge_cfg.get("pitch", 0)),
            volume=int(str(edge_cfg.get("volume", "+0%")).strip().rstrip("%") or 0)
            if isinstance(edge_cfg.get("volume"), str) else int(edge_cfg.get("volume", 0)),
            retries=int(edge_cfg.get("retries", 3)),
            fallback_voice=edge_cfg.get("fallback_voice", "ru-RU-SvetlanaNeural"),
        )
        sapi_cfg = t.get("sapi5", {}) or {}
        self.sapi5 = SAPI5Engine(voice=sapi_cfg.get("voice", ""),
                                 rate=int(sapi_cfg.get("rate", 0)) * 5,
                                 volume=int(sapi_cfg.get("volume", 100)))
        self.hf = HFSpaceEngine(
            voice_label=f"{self.edge.voice} - ru-RU (Male)",
            rate=self.edge.rate, pitch=self.edge.pitch)
        self.openai_tts = OpenAITTSEngine()
        self.elevenlabs = ElevenLabsEngine()
        self.preferred = str(t.get("engine", "auto"))
        self.enabled = bool(t.get("enabled", True))
        self.volume = float(t.get("volume", 1.0))

    def _order(self) -> list:
        engines = {n: getattr(self, a, None) for n, a in
                   (("edge", "edge"), ("sapi5", "sapi5"), ("hf_space", "hf"),
                    ("openai", "openai_tts"), ("elevenlabs", "elevenlabs"))}
        engines = {k: v for k, v in engines.items() if v is not None}
        keyed = [e for e in (getattr(self, "openai_tts", None),
                             getattr(self, "elevenlabs", None)) if e is not None]
        base = [e for e in (self.edge, self.sapi5, self.hf) if e is not None]
        with_key = [e for e in keyed if e.available()]
        without_key = [e for e in keyed if not e.available()]
        chain = with_key + base + without_key
        if self.preferred in engines:
            return [engines[self.preferred]] + [e for e in chain
                                                if e is not engines[self.preferred]]
        # ключевые движки первыми (пользователь осознанно вставил ключ),
        # затем бесплатный edge, офлайн sapi5, hf-space
        return chain

    def synthesize(self, text: str, out_path: Optional[str] = None) -> tuple[Optional[str], str]:
        """(путь_к_аудио, имя_движка). Пробует движки по порядку."""
        if not self.enabled or not text or not text.strip():
            return None, "disabled"
        with self._lock:
            for eng in self._order():
                try:
                    if not eng.available():
                        continue
                    path = eng.synthesize(text, out_path)
                    if path:
                        self.last_engine = eng.name
                        return path, eng.name
                except Exception as e:
                    log.debug("tts engine %s error: %s", eng.name, e)
        return None, "none"
