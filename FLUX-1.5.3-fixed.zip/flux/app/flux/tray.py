"""Иконка в трее: состояние, быстрые действия, открытие консоли."""
from __future__ import annotations

import threading
import webbrowser
from typing import Callable, Optional

from . import config, logger

log = logger.get_logger("flux.tray")


class TrayIcon:
    def __init__(self, on_open_console: Callable[[], None],
                 on_listen_now: Callable[[], None],
                 on_stop_speaking: Callable[[], None],
                 on_exit: Callable[[], None],
                 icon_path: Optional[str] = None) -> None:
        self.on_open_console = on_open_console
        self.on_listen_now = on_listen_now
        self.on_stop_speaking = on_stop_speaking
        self.on_exit = on_exit
        self.icon_path = icon_path
        self._icon = None
        self._thread: Optional[threading.Thread] = None
        self.state_text = "ожидание"

    def start(self) -> bool:
        try:
            import pystray  # type: ignore
            from PIL import Image, ImageDraw  # type: ignore
        except Exception as e:
            log.warning("трей недоступен (%s); работаем без иконки", e)
            return False

        def make_image():
            if self.icon_path:
                try:
                    return Image.open(self.icon_path)
                except Exception:
                    pass
            img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            d.ellipse([8, 8, 56, 56], fill=(60, 140, 255, 255))
            d.ellipse([24, 24, 40, 40], fill=(255, 255, 255, 255))
            return img

        menu = pystray.Menu(
            pystray.MenuItem("Открыть консоль", lambda: self.on_open_console()),
            pystray.MenuItem("Слушать сейчас", lambda: self.on_listen_now()),
            pystray.MenuItem("Остановить речь", lambda: self.on_stop_speaking()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Выход", lambda: self.on_exit()),
        )
        self._icon = pystray.Icon("flux", make_image(), "FLUX — ожидание", menu)
        self._thread = threading.Thread(target=self._icon.run, name="flux-tray",
                                        daemon=True)
        self._thread.start()
        return True

    def set_state(self, text: str) -> None:
        self.state_text = text
        if self._icon is not None:
            try:
                self._icon.title = f"FLUX — {text}"
            except Exception:
                pass

    def stop(self) -> None:
        if self._icon is not None:
            try:
                self._icon.stop()
            except Exception:
                pass


def open_console() -> None:
    host = config.get("ui.host", "127.0.0.1")
    port = config.get("ui.port", 8790)
    webbrowser.open(f"http://{host}:{port}/")
