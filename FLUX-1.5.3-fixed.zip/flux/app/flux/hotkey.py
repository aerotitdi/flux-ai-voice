"""Горячая клавиша: ЗАЖАТИЕ Numpad 9 = голосовой ввод (push-to-talk).

Второй способ активации помимо слова «флюкс». Отслеживается именно ЗАЖАТИЕ:
нажал - запись идёт (таймаут тишины отключён), отпустил - включается правило
«5 секунд, чтобы продолжить».

Скан-код Numpad 9 = 0x49 (73) - не зависит от NumLock. Дополнительно принимаем
VK_NUMPAD9 (105) для бэкендов, которые сообщают виртуальный код.
Бэкенды по порядку: keyboard -> pynput -> нативный LL-hook (ctypes, без зависимостей).
"""
from __future__ import annotations

import threading
from typing import Callable, Optional

from . import config, logger

log = logger.get_logger("flux.hotkey")

NUMPAD9_SCAN = 73      # 0x49
NUMPAD9_VK = 105       # 0x69
CANCEL_VK = 27         # Esc


class HotkeyListener:
    def __init__(self, on_hold_start: Callable[[], None],
                 on_hold_release: Callable[[], None],
                 on_cancel: Optional[Callable[[], None]] = None,
                 backend: str = "auto") -> None:
        self.on_hold_start = on_hold_start
        self.on_hold_release = on_hold_release
        self.on_cancel = on_cancel or (lambda: None)
        self.backend_pref = backend
        self.backend = "none"
        self._stop = threading.Event()
        self._holder: Optional[object] = None
        self.holding = False

    # ------------------------------------------------------------------ public
    def start(self) -> str:
        if not config.get("hotkey.enabled", True):
            self.backend = "disabled"
            return self.backend
        order = ["keyboard", "pynput", "ctypes"] if self.backend_pref == "auto" \
            else [self.backend_pref]
        for name in order:
            try:
                if name == "keyboard":
                    self._start_keyboard()
                elif name == "pynput":
                    self._start_pynput()
                elif name == "ctypes":
                    self._start_ctypes()
                else:
                    continue
                self.backend = name
                log.info("hotkey backend: %s (Numpad 9 = push-to-talk)", name)
                return name
            except Exception as e:
                log.debug("hotkey backend %s unavailable: %s", name, e)
        self.backend = "none"
        log.warning("ни один бэкенд горячей клавиши не доступен; "
                    "остаётся активация словом")
        return self.backend

    def stop(self) -> None:
        self._stop.set()
        try:
            if self.backend == "keyboard":
                import keyboard  # type: ignore
                keyboard.unhook_all()
            elif self.backend == "pynput" and self._holder is not None:
                self._holder.stop()  # type: ignore[attr-defined]
            elif self.backend == "ctypes" and self._holder is not None:
                self._holder()  # type: ignore[misc]
        except Exception:
            pass

    # ----------------------------------------------------------------- events
    def _press(self) -> None:
        if self.holding:
            return
        self.holding = True
        try:
            self.on_hold_start()
        except Exception:
            log.exception("on_hold_start failed")

    def _release(self) -> None:
        if not self.holding:
            return
        self.holding = False
        try:
            self.on_hold_release()
        except Exception:
            log.exception("on_hold_release failed")

    # ---------------------------------------------------------------- backends
    def _start_keyboard(self) -> None:
        import keyboard  # type: ignore

        def on_down(e):
            self._press()

        def on_up(e):
            self._release()

        keyboard.on_press_key(NUMPAD9_SCAN, on_down)
        keyboard.on_release_key(NUMPAD9_SCAN, on_up)
        # дублируем по VK на случай иных раскладок/эмуляций
        keyboard.on_press_key("num 9", on_down, suppress=False)
        keyboard.on_release_key("num 9", on_up, suppress=False)
        keyboard.on_press_key("esc", lambda e: self.on_cancel())

    def _start_pynput(self) -> None:
        from pynput import keyboard as pk  # type: ignore

        def is_np9(key):
            try:
                if key.vk in (NUMPAD9_VK,):
                    return True
            except Exception:
                pass
            try:
                if key.scan_code == NUMPAD9_SCAN:
                    return True
            except Exception:
                pass
            return False

        def on_down(key):
            if is_np9(key):
                self._press()
            elif key == pk.Key.esc:
                self.on_cancel()

        def on_up(key):
            if is_np9(key):
                self._release()

        listener = pk.Listener(on_press=on_down, on_release=on_up)
        listener.start()
        self._holder = listener

    def _start_ctypes(self) -> None:
        """Нативный low-level keyboard hook (только Windows, без зависимостей)."""
        import ctypes
        import ctypes.wintypes as wt

        if not hasattr(ctypes, "windll"):
            raise RuntimeError("ctypes-hook доступен только на Windows")
        WH_KEYBOARD_LL = 13
        WM_KEYDOWN, WM_KEYUP = 0x0100, 0x0101
        WM_SYSKEYDOWN, WM_SYSKEYUP = 0x0104, 0x0105

        HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_int,
                                      ctypes.c_int, ctypes.c_void_p)

        class KBDLLHOOKSTRUCT(ctypes.Structure):
            _fields_ = [("vkCode", wt.DWORD), ("scanCode", wt.DWORD),
                        ("flags", wt.DWORD), ("time", wt.DWORD),
                        ("dwExtraInfo", ctypes.c_void_p)]

        def low_level_handler(code, wparam, lparam):
            if code >= 0:
                info = ctypes.cast(lparam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                is_np9 = info.scanCode == NUMPAD9_SCAN or info.vkCode == NUMPAD9_VK
                if is_np9 and wparam in (WM_KEYDOWN, WM_SYSKEYDOWN):
                    self._press()
                elif is_np9 and wparam in (WM_KEYUP, WM_SYSKEYUP):
                    self._release()
                elif info.vkCode == CANCEL_VK and wparam in (WM_KEYDOWN, WM_SYSKEYDOWN):
                    self.on_cancel()
            return ctypes.windll.user32.CallNextHookEx(None, code, wparam, lparam)

        proc = HOOKPROC(low_level_handler)
        hook = ctypes.windll.user32.SetWindowsHookExW(
            WH_KEYBOARD_LL, proc, ctypes.windll.kernel32.GetModuleHandleW(None), 0)
        if not hook:
            raise RuntimeError("SetWindowsHookEx failed")
        self._hook_proc = proc  # держим ссылку от сборщика мусора

        def run_loop():
            msg = wt.MSG()
            while not self._stop.is_set():
                r = ctypes.windll.user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if r <= 0:
                    break
                ctypes.windll.user32.TranslateMessage(ctypes.byref(msg))
                ctypes.windll.user32.DispatchMessageW(ctypes.byref(msg))
            ctypes.windll.user32.UnhookWindowsHookEx(hook)

        t = threading.Thread(target=run_loop, name="flux-hotkey-hook", daemon=True)
        t.start()
        self._holder = lambda: None
