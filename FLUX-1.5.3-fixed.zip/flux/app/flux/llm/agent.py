"""Агентный цикл FLUX: история + память + инструменты + озвучка по разметке.

Озвучка стримится в TTS по мере генерации, но с гейтом: первые ~60 символов
накапливаются, и если модель в этом круге решила вызвать инструмент, речь не
начинается (очередь TTS сбрасывается). Это убирает обрывки фраз перед
вызовом инструмента.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

from .. import config, logger, prompts
from ..memory.store import MemoryStore
from ..tools import import_all as import_all_tools
from ..tools import registry
from ..tts_markup import Chunk, MarkupStreamParser
from .ollama_client import OllamaClient, OllamaError

log = logger.get_logger("flux.agent")

SPEAK_GATE_CHARS = 60


@dataclass
class ToolLogEntry:
    name: str
    args: dict
    ok: bool
    preview: str
    elapsed: float = 0.0


@dataclass
class AgentResult:
    text: str = ""
    spoken: str = ""
    spoken_chunks: list[str] = field(default_factory=list)
    tool_log: list[ToolLogEntry] = field(default_factory=list)
    model: str = ""
    rounds: int = 0
    elapsed: float = 0.0
    error: str = ""
    confirmed: list[str] = field(default_factory=list)
    cancelled: list[str] = field(default_factory=list)
    thinking: str = ""
    web_source: str = ""


@dataclass
class AgentContext:
    store: Optional[MemoryStore] = None
    confirm: Optional[Callable[[str, dict], bool]] = None
    emit: Optional[Callable[..., None]] = None
    images: list[str] = field(default_factory=list)


def _b64_image(path: str) -> Optional[str]:
    """Картинка -> base64 для Ollama/OpenAI vision (лимит 8 МБ)."""
    import base64 as _b64
    try:
        size = os.path.getsize(path)
        if size <= 0 or size > 8_000_000:
            return None
        with open(path, "rb") as f:
            return _b64.b64encode(f.read()).decode("ascii")
    except OSError:
        return None


class Agent:
    def __init__(self, client: Optional[OllamaClient] = None,
                 store: Optional[MemoryStore] = None) -> None:
        import_all_tools()
        self.client = client or OllamaClient()
        self.store = store
        self.ctx = AgentContext(store=store)

    # ---------------------------------------------------------------- messages
    def build_messages(self, user_text: str, conv_id: Optional[int] = None,
                       images: Optional[list[str]] = None,
                       recall: bool = True) -> list[dict]:
        msgs: list[dict] = [{"role": "system", "content": prompts.system_prompt()}]
        if recall and self.store is not None and config.get("memory.auto_recall", True):
            items = self.store.recall(user_text,
                                      int(config.get("memory.max_recall_items", 6)))
            block = prompts.recall_block(items)
            if block:
                msgs.append({"role": "system", "content": block})
        if conv_id is not None and self.store is not None:
            limit = int(config.get("memory.history_messages", 24))
            for m in self.store.history(conv_id, limit):
                msgs.append({"role": m["role"], "content": m["content"]})
        user_msg: dict = {"role": "user", "content": user_text}
        if images:
            user_msg["images"] = images
        msgs.append(user_msg)
        return msgs

    # --------------------------------------------------------------------- run
    def run(self, user_text: str, conv_id: Optional[int] = None,
            on_token: Optional[Callable[[str], None]] = None,
            on_speak_chunk: Optional[Callable[[Chunk], None]] = None,
            images: Optional[list[str]] = None,
            think: bool = False, web: bool = False,
            on_thinking: Optional[Callable[[str], None]] = None,
            ) -> AgentResult:
        """Один запрос пользователя.

        think — пилюля «Глубокое мышление» (DeepThink): модель рассуждает,
        токены рассуждения уходят в on_thinking (консоль рисует блок
        «Размышление», как DeepSeek).
        web — пилюля «Умный поиск» (DeepSearch): ДО ответа выполняется
        интернет-поиск (SearXNG), результаты подаются системным блоком,
        а в журнал инструментов падает запись web_search.
        """
        t0 = time.time()
        result = AgentResult()
        # Счётчик показанных результатов поиска ОБНУЛЯЕТСЯ на каждом запросе.
        # Раньше он жил в ctx и копился вечно: после 250 результатов за всё
        # время работы web_search начинал отвечать «достигнут лимит» на ЛЮБОЙ
        # запрос — до самого перезапуска Флюкса.
        self.ctx.search_shown = 0
        self.ctx.pending_images = []
        messages = self.build_messages(user_text, conv_id, images)
        if web:
            from ..tools import web as webtools
            tw = time.time()
            try:
                hits, source = webtools.search(user_text)
            except Exception as e:  # noqa: BLE001 - поиск не должен ронять чат
                log.warning("умный поиск сломался: %s", e)
                hits, source = [], f"ошибка: {e.__class__.__name__}"
            result.web_source = source
            preview = "; ".join(h.get("title", "") for h in hits[:3]) or                 f"результатов нет (источник: {source})"
            result.tool_log.append(ToolLogEntry(
                "web_search", {"query": user_text, "source": source},
                bool(hits), preview, round(time.time() - tw, 2)))
            # вставляем системным сообщением ПЕРЕД пользовательским
            messages.insert(len(messages) - 1,
                            {"role": "system",
                             "content": prompts.web_block(user_text, hits, source)})
        parser = MarkupStreamParser(
            open_marker=str(config.get("tts.marker_open", "*-")),
            close_marker=str(config.get("tts.marker_close", "-*")),
            sentence_streaming=bool(config.get("tts.sentence_streaming", True)),
            min_chunk_chars=int(config.get("tts.min_chunk_chars", 30)),
            max_chunk_chars=int(config.get("tts.max_chunk_chars", 400)),
        )
        gate: dict = {"chars": 0, "open": False, "alive": True, "pending": []}

        def _emit(chunk: Chunk) -> None:
            if not gate["alive"]:
                return
            result.spoken_chunks.append(chunk.text)
            if on_speak_chunk:
                on_speak_chunk(chunk)

        def _gate_chunk(chunk: Chunk) -> None:
            """Речь копится до гейта, затем отдаётся по порядку (ничего не теряем)."""
            gate["chars"] += len(chunk.text)
            if not gate["open"] and gate["chars"] >= SPEAK_GATE_CHARS:
                gate["open"] = True
                for pending in gate["pending"]:
                    _emit(pending)
                gate["pending"].clear()
            if gate["open"]:
                _emit(chunk)
            else:
                gate["pending"].append(chunk)

        def _feed(piece: str) -> None:
            if on_token:
                on_token(piece)
            for chunk in parser.feed(piece):
                if chunk.text:
                    _gate_chunk(chunk)

        max_rounds = int(config.get("llm.max_tool_rounds", 8))
        max_calls = int(config.get("llm.max_tool_calls", 12))
        call_counts: dict[tuple[str, str], int] = {}
        total_calls = 0
        prev_signature: tuple | None = None
        loop_stop = ""
        for round_no in range(1, max_rounds + 1):
            result.rounds = round_no
            try:
                resp = self.client.chat(messages, tools=registry.schemas(),
                                        on_token=_feed, think=bool(think),
                                        on_thinking=on_thinking)
            except OllamaError as e:
                result.error = str(e)
                log.error("LLM error: %s", e)
                break
            except Exception as e:  # noqa: BLE001
                result.error = f"сбой запроса к модели: {e}"
                log.exception("chat crash")
                break

            if resp.thinking:
                result.thinking = resp.thinking

            if resp.tool_calls:
                signature = tuple(
                    (tc.name, json.dumps(tc.arguments or {}, sort_keys=True,
                                         ensure_ascii=False))
                    for tc in resp.tool_calls)
                if signature == prev_signature:
                    loop_stop = ("модель повторила один и тот же набор вызовов "
                                 "подростряду")
                    break
                prev_signature = signature

                # модель ушла в инструменты: речь этого круга не озвучиваем
                gate["alive"] = False
                gate["open"] = False
                parser = MarkupStreamParser(
                    open_marker=str(config.get("tts.marker_open", "*-")),
                    close_marker=str(config.get("tts.marker_close", "-*")),
                    sentence_streaming=bool(config.get("tts.sentence_streaming", True)),
                    min_chunk_chars=int(config.get("tts.min_chunk_chars", 30)),
                    max_chunk_chars=int(config.get("tts.max_chunk_chars", 400)),
                )
                result.spoken_chunks.clear()
                gate["chars"] = 0
                gate["pending"].clear()
                gate["alive"] = True     # следующий круг может говорить снова

                # ВАЖНО: возвращаем модели её собственные tool_calls, иначе она
                # не видит вызовов и повторяет их по кругу (баг remember x8)
                native_calls = []
                openai_calls = []
                for i, tc in enumerate(resp.tool_calls):
                    tc.id = tc.id or f"call_{round_no}_{i}"
                    native_calls.append({"function": {"name": tc.name,
                                                      "arguments": tc.arguments or {}}})
                    openai_calls.append(tc)
                messages.append({"role": "assistant",
                                 "content": resp.content or "",
                                 "tool_calls": native_calls,
                                 "_openai_tool_calls": openai_calls})
                for tc in resp.tool_calls:
                    args = tc.arguments or {}
                    key = (tc.name, json.dumps(args, sort_keys=True,
                                               ensure_ascii=False))
                    call_counts[key] = call_counts.get(key, 0) + 1
                    total_calls += 1
                    if call_counts[key] > 1:
                        entry = ToolLogEntry(
                            tc.name, args, False,
                            "ЭТОТ ВЫЗОВ УЖЕ выполнялся в этом запросе с теми же "
                            "аргументами - результат выше, не повторяй его")
                        result.tool_log.append(entry)
                    elif total_calls > max_calls:
                        entry = ToolLogEntry(
                            tc.name, args, False,
                            f"достигнут лимит вызовов инструментов за запрос "
                            f"({max_calls}) - отвечай по уже полученным данным")
                        result.tool_log.append(entry)
                    else:
                        entry = self._execute(tc.name, args, result)
                    messages.append({
                        "role": "tool",
                        "content": entry.preview,
                        "name": tc.name,
                        "tool_call_id": tc.id,
                    })
                    images_out = getattr(self.ctx, "pending_images", None)
                    if images_out:
                        b64 = [b for b in (_b64_image(x) for x in images_out) if b]
                        self.ctx.pending_images = []
                        if b64:
                            # vision: отдельное user-сообщение с картинками
                            messages.append({
                                "role": "user",
                                "content": "Изображение(я) к результату "
                                           "инструмента - проанализируй их:",
                                "images": b64,
                            })
                if total_calls >= max_calls:
                    loop_stop = f"достигнут лимит вызовов инструментов ({max_calls})"
                    break
                continue

            # финальный ответ
            for chunk in parser.flush():
                if chunk.text:
                    _gate_chunk(chunk)
            # конец ответа: отдаём всё, что гейт придерживал (ничего не теряем)
            for pending in gate["pending"]:
                _emit(pending)
            gate["pending"].clear()
            result.text = resp.content
            result.spoken = parser.spoken_text
            result.model = resp.model
            break
        else:
            loop_stop = loop_stop or "превышено число кругов инструментов"
        if loop_stop and not result.text:
            last_info = ""
            if result.tool_log:
                last_info = result.tool_log[-1].preview[:300]
            result.text = (f"*-Прости, я зациклился на инструментах и остановился "
                           f"({loop_stop}). Вот что успел узнать: {last_info or 'ничего'}-* "
                           f"(служебное: остановлено защитой от цикла)")
            result.spoken = (f"Прости, я зациклился на инструментах и остановился. "
                             f"Вот что успел узнать: {last_info[:200] or 'ничего'}")
            result.error = loop_stop

        result.elapsed = round(time.time() - t0, 2)
        if conv_id is not None and self.store is not None:
            self.store.add_message(conv_id, "user", user_text)
            self.store.add_message(conv_id, "assistant", result.text or result.error)
        return result

    # ------------------------------------------------------------------ tools
    def _execute(self, name: str, args: dict, result: AgentResult) -> ToolLogEntry:
        spec = registry.get(name)
        # Подтверждения действий ВЫРЕЗАНЫ из продуктивного пути: по умолчанию
        # Флюкс выполняет инструмент сразу. Механизм оставлен только как
        # необязательный крючок — он срабатывает, ЛИШЬ если пользователь сам
        # включил security.confirm_destructive=true, и вызывается РОВНО ОДИН
        # раз (раньше второй раз спрашивал registry.dispatch — баг).
        if (spec is not None and spec.dangerous
                and bool(config.get("security.confirm_destructive", False))
                and self.ctx.confirm is not None):
            try:
                ok = bool(self.ctx.confirm(name, args))
            except Exception as e:
                log.warning("confirm failed: %s", e)
                ok = True      # сбой крючка не должен блокировать действие
            if not ok:
                result.cancelled.append(name)
                return ToolLogEntry(name, args, False,
                                    "операция отменена пользователем")
            result.confirmed.append(name)
        res = registry.dispatch(name, args, self.ctx)
        preview = (res.text or "")[:3500]
        entry = ToolLogEntry(name, args, res.ok, preview, res.elapsed)
        result.tool_log.append(entry)
        if res.attach_images:
            pending = getattr(self.ctx, "pending_images", None)
            if pending is None:
                pending = []
                self.ctx.pending_images = pending
            pending.extend(res.attach_images)
        return entry
