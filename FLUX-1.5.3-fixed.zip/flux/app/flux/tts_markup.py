"""Парсер разметки озвучки.

Соглашение FLUX: модель отвечает обычным текстом, а всё, что нужно ПРОИЗНЕСТИ
ВСЛУХ, оборачивает в маркеры:

    *-текст, который будет озвучен-*

Всё, что вне маркеров, показывается в консоли, но НЕ озвучивается (служебные
пояснения, код, таблицы, логи инструментов).

Парсер потоковый: его можно кормить токенами стриминга LLM по одному символу,
он сам собирает маркеры и выдаёт готовые к озвучке куски (по предложениям),
чтобы речь начиналась ещё до конца генерации ответа.

Реализация учитывает типовые подходы low-latency voice-агентов: агрегация
стрима в предложения + параллельный синтез, а не ожидание полного ответа.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterator

DEFAULT_OPEN = "*-"
DEFAULT_CLOSE = "-*"

# Сокращения, после которых точка НЕ заканчивает предложение.
ABBREV = {
    "т.д", "т.п", "т.к", "см", "др", "г", "гг", "ул", "пр", "п", "ст", "рис",
    "eq", "vs", "approx", "No", "№", "им", "проф", "доц", "к.т.н", "м", "см.",
    "мин", "ч", "обл", "р-н", "тыс", "млн", "млрд", "руб", "у.е", "и.о",
}

_SENT_END = ".!?…"
_SOFT_SPLIT = ",;:—"

_CODE_FENCE = re.compile(r"```.*?(?:```|$)", re.DOTALL)
_INLINE_CODE = re.compile(r"`([^`]*)`")
_MD_LINK = re.compile(r"\[([^\]]*)\]\(([^)]*)\)")
_MD_BOLD_ITALIC = re.compile(r"(\*\*|__|\*|_)")
_MD_HEADING = re.compile(r"^\s{0,3}#{1,6}\s*", re.MULTILINE)
_MD_BULLET = re.compile(r"^\s*[-*+•]\s+", re.MULTILINE)
_MD_TABLE_LINE = re.compile(r"^\s*\|.*\|\s*$", re.MULTILINE)
_HTML_TAGS = re.compile(r"<[^>]{1,80}>")
_URL = re.compile(r"https?://\S+")
_EMOJI = re.compile(
    "[\U0001F000-\U0001FAFF\U00002600-\U000027BF\U0001F1E6-\U0001F1FF\u2190-\u21FF\u2B00-\u2BFF\uFE0F]"
)
_MULTI_SPACE = re.compile(r"[ \t]{2,}")
_WS_AROUND_NL = re.compile(r"[ \t]*\n[ \t]*")


@dataclass
class Chunk:
    """Кусок текста, который нужно озвучить."""

    text: str
    index: int = 0
    final: bool = True
    chars: int = 0

    def __post_init__(self) -> None:
        self.chars = len(self.text)


@dataclass
class ParseResult:
    spoken: list[str] = field(default_factory=list)
    display: str = ""
    raw: str = ""

    @property
    def has_speech(self) -> bool:
        return bool(self.spoken)

    @property
    def spoken_text(self) -> str:
        return " ".join(self.spoken).strip()


def clean_for_speech(text: str, cleanup_markdown: bool = True) -> str:
    """Превращает размеченный текст в гладкую речь."""
    if not text:
        return ""
    s = text.replace("\r\n", "\n").replace("\r", "\n")
    if cleanup_markdown:
        s = _CODE_FENCE.sub(" ", s)
        s = _MD_LINK.sub(lambda m: m.group(1) or m.group(2), s)
        s = _URL.sub(" ", s)
        s = _INLINE_CODE.sub(lambda m: m.group(1), s)
        s = _MD_HEADING.sub("", s)
        s = _MD_TABLE_LINE.sub(" ", s)
        s = _MD_BULLET.sub("", s)
        s = _MD_BOLD_ITALIC.sub("", s)
        s = _HTML_TAGS.sub(" ", s)
        s = _EMOJI.sub(" ", s)
        s = s.replace("|", " ").replace("#", " ").replace(">", " ")
        s = s.replace("**", " ").replace("__", " ")
    s = _WS_AROUND_NL.sub(" ", s)
    s = s.replace("\n", " ")
    s = _MULTI_SPACE.sub(" ", s)
    s = re.sub(r"\s+([,.!?;:])", r"\1", s)
    s = s.replace(" - ", ", ").replace("—", ",")
    s = re.sub(r",+", ",", s)
    return s.strip(" \t\n-–—*")


def _is_abbrev_end(buf: str) -> bool:
    """Точка принадлежит сокращению (т.д., см., ул.)?

    Важно: сокращение должно быть ОТДЕЛЬНЫМ токеном, иначе «в дом.»
    ошибочно склеится со следующим предложением.
    """
    tail = buf.rstrip()
    if not tail.endswith("."):
        return False
    body = tail[:-1]
    last_token = body.split(" ")[-1].strip(".")
    for a in ABBREV:
        a_clean = a.strip(".")
        if last_token == a_clean or body == a_clean:
            return True
        if "." in a and (body.endswith(a) or body.endswith(a + ".")):
            return True
    if re.search(r"(^|\s)\d$", tail[:-1]):
        return True
    return False


def split_sentences(text: str, soft_limit: int = 150) -> tuple[list[str], str]:
    """Режет текст на предложения. Возвращает (готовые, остаток)."""
    sentences: list[str] = []
    buf = ""
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        buf += ch
        if ch in _SENT_END:
            # многоточие
            if text[i:i + 3] == "...":
                buf += text[i + 1:i + 3]
                i += 3
                sentences.append(buf.strip())
                buf = ""
                continue
            nxt = text[i + 1] if i + 1 < n else " "
            if ch == "." and _is_abbrev_end(buf):
                i += 1
                continue
            if nxt in (" ", "\n", "\t", "") or i + 1 >= n:
                if buf.strip():
                    sentences.append(buf.strip())
                buf = ""
        elif ch in _SOFT_SPLIT and len(buf) >= soft_limit:
            sentences.append(buf.strip())
            buf = ""
        i += 1
    return sentences, buf


class MarkupStreamParser:
    """Потоковый конечный автомат по маркерам *- ... -*"""

    def __init__(
        self,
        open_marker: str = DEFAULT_OPEN,
        close_marker: str = DEFAULT_CLOSE,
        sentence_streaming: bool = True,
        min_chunk_chars: int = 30,
        max_chunk_chars: int = 400,
        cleanup_markdown: bool = True,
    ) -> None:
        self.open_marker = open_marker or DEFAULT_OPEN
        self.close_marker = close_marker or DEFAULT_CLOSE
        self.sentence_streaming = sentence_streaming
        self.min_chunk_chars = max(1, int(min_chunk_chars))
        self.max_chunk_chars = max(self.min_chunk_chars + 1, int(max_chunk_chars))
        self.cleanup_markdown = cleanup_markdown

        self._raw: list[str] = []
        self._display: list[str] = []
        self._speech: list[str] = []
        self._pending = ""       # неразобранный хвост входящего потока
        self._inside = False     # внутри *- ... -*
        self._speech_buf = ""    # накопленная, ещё не выданная речь
        self._chunk_index = 0

    # ------------------------------------------------------------------ props
    @property
    def raw(self) -> str:
        return "".join(self._raw)

    @property
    def display_text(self) -> str:
        """Текст для консоли: маркеры убраны, речь помечена значком."""
        return "".join(self._display)

    @property
    def spoken_text(self) -> str:
        return " ".join(self._speech).strip()

    @property
    def inside_marker(self) -> bool:
        return self._inside

    # ------------------------------------------------------------------- feed
    def feed(self, text: str) -> Iterator[Chunk]:
        """Скормить очередной фрагмент стрима. Отдаёт готовые куски для TTS."""
        if not text:
            return
        self._raw.append(text)
        self._pending += text
        yield from self._drain(final=False)

    def flush(self) -> Iterator[Chunk]:
        """Конец потока: выдать всё, что осталось (в т.ч. незакрытый маркер)."""
        yield from self._drain(final=True)
        if self._inside:
            # незакрытый *- ... : озвучиваем накопленное, чтобы ничего не потерять
            self._inside = False
        if self._speech_buf.strip():
            tail_text, self._speech_buf = self._speech_buf, ""
            yield self._emit(tail_text, final=True)
        elif not self._speech and self._pending.strip():
            # маркеров не было вообще -> ничего не озвучиваем (по ТЗ),
            # но в display уже всё записано.
            pass
        self._pending = ""

    # ---------------------------------------------------------------- internals
    def _drain(self, final: bool) -> Iterator[Chunk]:
        p = self._pending
        while True:
            if not self._inside:
                idx = p.find(self.open_marker)
                if idx == -1:
                    keep = 0 if final else self._partial_len(p, self.open_marker)
                    safe = p[:len(p) - keep] if keep else p
                    if safe:
                        self._display.append(safe)
                    self._pending = p[len(p) - keep:] if keep else ""
                    break
                if idx > 0:
                    self._display.append(p[:idx])
                p = p[idx + len(self.open_marker):]
                self._inside = True
                self._add_separator()
                self._display.append("")  # маркер не показываем
                continue

            # внутри маркера: ищем закрытие
            idx = p.find(self.close_marker)
            if idx == -1:
                keep = 0 if final else self._partial_len(p, self.close_marker)
                # защита от очень длинного куска без закрытия
                take = p[:len(p) - keep] if keep else p
                if take:
                    self._push_speech(take)
                    self._display.append(take)
                self._pending = p[len(p) - keep:] if keep else ""
                break
            if idx > 0:
                self._push_speech(p[:idx])
                self._display.append(p[:idx])
            p = p[idx + len(self.close_marker):]
            self._inside = False
            self._add_separator()
            continue

        yield from self._yield_chunks(final=final)

    def _push_speech(self, text: str) -> None:
        self._speech_buf += text

    def _add_separator(self) -> None:
        """Пробел между соседними озвученными блоками, чтобы не слипались слова."""
        if self._speech_buf and not self._speech_buf.endswith((" ", "\n")):
            self._speech_buf += " "

    @staticmethod
    def _partial_len(buf: str, marker: str) -> int:
        """Сколько символов в хвосте могут оказаться началом маркера."""
        if not marker:
            return 0
        maxk = min(len(marker) - 1, len(buf))
        for k in range(maxk, 0, -1):
            if buf.endswith(marker[:k]):
                return k
        return 0

    def _yield_chunks(self, final: bool) -> Iterator[Chunk]:
        if not self._speech_buf:
            return

        if not self.sentence_streaming:
            if final or len(self._speech_buf) >= self.max_chunk_chars:
                text, self._speech_buf = self._speech_buf, ""
                if text.strip():
                    yield self._emit(text, final=True)
            return

        sentences, rest = split_sentences(
            self._speech_buf, soft_limit=max(80, self.max_chunk_chars // 2))
        acc = ""
        for sent in sentences:
            acc = (acc + " " + sent).strip() if acc else sent
            if len(clean_for_speech(acc, self.cleanup_markdown)) >= self.min_chunk_chars:
                yield self._emit(acc, final=True)
                acc = ""
        # ВАЖНО: остаток НЕ strip()-им - иначе теряется пробел между
        # предложениями при посимвольном стриминге ("Альфа." + " Бета!").
        self._speech_buf = acc + rest

        # длинные куски без знаков препинания режем жёстко, хвост сохраняем
        while True:
            cleaned = clean_for_speech(self._speech_buf, self.cleanup_markdown)
            if len(cleaned) <= self.max_chunk_chars:
                break
            cut_at = self._cut_point(self._speech_buf, self.max_chunk_chars)
            head, self._speech_buf = self._speech_buf[:cut_at], self._speech_buf[cut_at:]
            if head.strip():
                yield self._emit(head, final=True)
            if not self._speech_buf.strip():
                break

        if final and self._speech_buf.strip():
            tail_text, self._speech_buf = self._speech_buf, ""
            yield self._emit(tail_text, final=True)

    def _cut_point(self, buf: str, limit: int) -> int:
        """Точка разреза длинного куска: по пробелу рядом с лимитом."""
        if len(buf) <= limit:
            return len(buf)
        window = buf[:limit + 40]
        cut = max(window.rfind(" "), window.rfind(","))
        if cut < limit // 2:
            cut = limit
        return min(cut + 1, len(buf))

    def _emit(self, text: str, final: bool) -> Chunk:
        cleaned = clean_for_speech(text, self.cleanup_markdown)
        cleaned = re.sub(r"\s+", " ", cleaned).strip()
        self._chunk_index += 1
        if cleaned:
            self._speech.append(cleaned)
        return Chunk(text=cleaned, index=self._chunk_index, final=final,
                     chars=len(cleaned))


# --------------------------------------------------------------------- one-shot
def parse(text: str, open_marker: str = DEFAULT_OPEN, close_marker: str = DEFAULT_CLOSE,
          cleanup_markdown: bool = True) -> ParseResult:
    """Разовый разбор полного текста (без стриминга)."""
    p = MarkupStreamParser(open_marker=open_marker, close_marker=close_marker,
                           sentence_streaming=False, cleanup_markdown=cleanup_markdown,
                           min_chunk_chars=1, max_chunk_chars=100000)
    for _ in p.feed(text):
        pass
    for _ in p.flush():
        pass
    spoken = [s for s in p.spoken_text.split("\n") if s.strip()]
    joined = " ".join(spoken).strip()
    return ParseResult(
        spoken=[joined] if joined else [],
        display=p.display_text,
        raw=p.raw,
    )


def extract_spoken(text: str, open_marker: str = DEFAULT_OPEN,
                  close_marker: str = DEFAULT_CLOSE) -> list[str]:
    """Список озвучиваемых блоков из готового текста."""
    if not text:
        return []
    out: list[str] = []
    rest = text
    while True:
        i = rest.find(open_marker)
        if i == -1:
            break
        j = rest.find(close_marker, i + len(open_marker))
        if j == -1:
            chunk = rest[i + len(open_marker):]
            cleaned = clean_for_speech(chunk)
            if cleaned:
                out.append(cleaned)
            break
        chunk = rest[i + len(open_marker):j]
        cleaned = clean_for_speech(chunk)
        if cleaned:
            out.append(cleaned)
        rest = rest[j + len(close_marker):]
    return out


def strip_markers(text: str, open_marker: str = DEFAULT_OPEN,
                  close_marker: str = DEFAULT_CLOSE) -> str:
    """Текст для показа в консоли: без маркеров, озвученное помечено 🔊."""
    if not text:
        return ""
    out: list[str] = []
    rest = text
    while True:
        i = rest.find(open_marker)
        if i == -1:
            out.append(rest)
            break
        out.append(rest[:i])
        j = rest.find(close_marker, i + len(open_marker))
        if j == -1:
            out.append("🔊 " + rest[i + len(open_marker):])
            break
        out.append("🔊 " + rest[i + len(open_marker):j])
        rest = rest[j + len(close_marker):]
    return re.sub(r"[ \t]{2,}", " ", "".join(out)).strip()


def has_speech(text: str, open_marker: str = DEFAULT_OPEN,
               close_marker: str = DEFAULT_CLOSE) -> bool:
    return bool(extract_spoken(text, open_marker, close_marker))


def wrap(text: str, open_marker: str = DEFAULT_OPEN,
         close_marker: str = DEFAULT_CLOSE) -> str:
    """Обернуть текст в маркеры озвучки (используется в тестах/промптах)."""
    return f"{open_marker}{text}{close_marker}"
