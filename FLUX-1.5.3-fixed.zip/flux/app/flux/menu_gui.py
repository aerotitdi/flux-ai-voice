"""Меню FLUX (Tkinter) — ярлык на рабочем столе открывает именно его.

Полностью переработано по просьбе пользователя («улучши менюшку»):

  * окно ПРОКРУЧИВАЕТСЯ, поэтому «Сохранить» больше никогда не уходит за край
    (старая болезнь меню — см. АУДИТ A9 — вернулась бы при любом добавлении ручек);
  * настройки разбиты на смысловые секции: Голосовой ввод (whisper) / Мозг /
    Озвучка / Поведение — вместо одной длинной формы;
  * списки микрофонов и моделей whisper берутся ЖИВЬЁМ (из запущенного Флюкса
    по HTTP, а если он не запущен — из системы и из кэша моделей на диске);
  * добавлены ручки, которых не хватало: режим «Глубокое мышление»,
    «Умный поиск» (интернет), тон и громкость озвучки, чувствительность
    слова-активации, перебивание (barge-in), адрес SearXNG, порт whisper-сервера;
  * «Сохранить» не только пишет config.json, но и дёргает /api/reload у уже
    запущенного Флюкса — настройки применяются БЕЗ перезапуска
    (раньше меню молча сохраняло файл, а работающий процесс продолжал
    жить со старыми значениями, и пользователь думал, что меню сломано);
  * «Диагностика» больше не теряет вывод: самотест пишется в лог и открывается
    в блокноте (под pythonw.exe консоли нет вовсе — раньше окно просто мигало);
  * живой статус в шапке: работает/остановлен, состояние, модель, микрофон.

Подтверждений действий в Флюксе больше нет, поэтому в меню нет и такой ручки —
вместо неё секция «Поведение» показывает, какие категории инструментов включены.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path
from typing import Any, Callable, Optional

from . import __version__, config, logger, paths

log = logger.get_logger("flux.menu")

RU_VOICES = ["ru-RU-DmitryNeural", "ru-RU-SvetlanaNeural", "ru-RU-DariyaNeural"]
TTS_ENGINES = [("auto", "авто (edge → SAPI5)"), ("edge", "Edge TTS (интернет)"),
               ("sapi5", "SAPI5 (офлайн, голоса Windows)"),
               ("openai", "OpenAI TTS (нужен ключ)"),
               ("elevenlabs", "ElevenLabs (нужен ключ)")]
STT_ENGINES = [("local", "локальный faster-whisper (офлайн)"),
               ("auto", "авто (локальный → сервер → облако)"),
               ("ollama", "внешний whisper-сервер (OpenAI-эндпоинт)"),
               ("api", "облачный whisper (Groq/OpenAI, нужен ключ)")]

# палитра (тёмная тема читается лучше и не спорит с консолью Флюкса)
BG = "#15181d"
PANEL = "#1d222a"
FG = "#e6e9ef"
DIM = "#8b93a3"
ACC = "#4f8cff"
OK = "#3ddc84"
WARN = "#ffb020"
BAD = "#ff5c5c"


# --------------------------------------------------------------------- utils
def _pythonw() -> str:
    base = Path(sys.executable)
    cand = base.with_name("pythonw.exe")
    return str(cand if cand.exists() else base)


def _run_hidden(args: list[str]) -> None:
    kwargs: dict = {}
    if os.name == "nt":
        kwargs["creationflags"] = (getattr(subprocess, "CREATE_NO_WINDOW", 0)
                                   | getattr(subprocess, "DETACHED_PROCESS", 0))
    subprocess.Popen(args, cwd=str(paths.APP_DIR), **kwargs)


def read_pid() -> int:
    try:
        return int((paths.DATA_DIR / "flux.pid").read_text().strip() or 0)
    except Exception:
        return 0


def is_running() -> bool:
    """Жив ли процесс Флюкса.

    Проверяем НЕ только pid-файл: pid мог остаться от прошлой жизни и даже
    совпасть с чужим процессом (тогда меню врало «работает»). Дополнительно
    спрашиваем консоль по HTTP — если она отвечает, Флюкс точно жив.
    """
    if _http_json("/api/state") is not None:
        return True
    pid = read_pid()
    if not pid:
        return False
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:
        return False


def _base_url() -> str:
    return (f"http://{config.get('ui.host', '127.0.0.1')}:"
            f"{config.get('ui.port', 8790)}")


def _http_json(path: str, body: Optional[dict] = None,
               timeout: float = 2.0) -> Optional[Any]:
    """Маленький HTTP-клиент меню (stdlib, без зависимостей)."""
    url = _base_url() + path
    try:
        data = None
        headers = {"Accept": "application/json"}
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers,
                                     method="POST" if body is not None else "GET")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except (urllib.error.URLError, OSError, ValueError, TimeoutError):
        return None


def _num(v) -> float:
    try:
        if isinstance(v, str):
            return float(v.strip().rstrip("%").rstrip("Hz"))
        return float(v)
    except Exception:
        return 0.0


# ----------------------------------------------------------------- scrollframe
class ScrollFrame:
    """Вертикально прокручиваемая область на чистом ttk (колесо мыши работает)."""

    def __init__(self, parent, style) -> None:
        import tkinter as tk
        from tkinter import ttk
        self.tk = tk
        self.outer = ttk.Frame(parent)
        self.canvas = tk.Canvas(self.outer, highlightthickness=0, borderwidth=0,
                                background=BG)
        self.scroll = ttk.Scrollbar(self.outer, orient="vertical",
                                    command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scroll.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scroll.pack(side="right", fill="y")
        self.inner = ttk.Frame(self.canvas)
        self._win = self.canvas.create_window((0, 0), window=self.inner,
                                              anchor="nw")
        self.inner.bind("<Configure>", self._on_inner)
        self.canvas.bind("<Configure>", self._on_canvas)
        self.canvas.bind_all("<MouseWheel>", self._wheel)
        self.canvas.bind_all("<Button-4>", self._wheel)
        self.canvas.bind_all("<Button-5>", self._wheel)

    def _on_inner(self, _ev=None) -> None:
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas(self, ev) -> None:
        self.canvas.itemconfigure(self._win, width=ev.width)

    def _wheel(self, ev) -> None:
        # прокручиваем только когда курсор над меню (иначе воруем колесо у консоли)
        try:
            w = self.tk.Widget.winfo_containing(self.canvas, ev.x_root, ev.y_root)
        except Exception:
            w = None
        if w is None:
            return
        top = w
        while top is not None and top is not self.outer:
            top = getattr(top, "master", None)
        if top is None:
            return
        step = -1 if getattr(ev, "num", 0) == 4 else (
            1 if getattr(ev, "num", 0) == 5 else 0)
        if not step:
            step = -1 if getattr(ev, "delta", 0) > 0 else 1
        self.canvas.yview_scroll(step, "units")


# ------------------------------------------------------------------ основное
class MenuApp:
    WIDTH, HEIGHT = 600, 720

    def __init__(self) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self._destroyed = False
        self.root = tk.Tk()
        self.root.title(f"FLUX {__version__} — голосовой ИИ-ассистент")
        self.root.geometry(f"{self.WIDTH}x{self.HEIGHT}")
        self.root.minsize(480, 520)
        self.root.configure(background=BG)
        try:
            self.root.iconbitmap(str(paths.APP_DIR / "flux" / "ui" / "flux.ico"))
        except Exception:
            pass

        self.style = ttk.Style(self.root)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass
        self._theme()

        self._build_header()
        self._build_buttons()
        self._build_form()
        self._build_footer()

        # ВСЯ тяжёлая работа (PortAudio, HTTP к Ollama, edge-tts list_voices,
        # скан папки моделей, опрос состояния) уходит в фоновые нити: раньше
        # она выполнялась ПРЯМО В ГЛАВНОМ ЦИКЛЕ Tk, из-за чего окноmenu
        # подвисало на секунды при открытии и дёргалось каждые 3 c на опросе.
        self._choices_loaded = False
        self._pid_alive = False
        self._load_choices_async()
        self._poll_status()
        self.root.protocol("WM_DELETE_WINDOW", self.quit)

    # ------------------------------------------------------------------ тема
    def _theme(self) -> None:
        from tkinter import ttk
        s = self.style
        s.configure(".", background=BG, foreground=FG, fieldbackground=PANEL,
                    font=("Segoe UI", 10), borderwidth=0)
        s.configure("TFrame", background=BG)
        s.configure("Panel.TFrame", background=PANEL)
        s.configure("TLabel", background=BG, foreground=FG)
        s.configure("Panel.TLabel", background=PANEL, foreground=FG)
        s.configure("Dim.TLabel", background=PANEL, foreground=DIM,
                    font=("Segoe UI", 8))
        s.configure("Title.TLabel", background=BG, foreground=FG,
                    font=("Segoe UI", 15, "bold"))
        s.configure("Status.TLabel", background=BG, foreground=DIM,
                    font=("Segoe UI", 9))
        s.configure("Section.TLabel", background=PANEL, foreground=ACC,
                    font=("Segoe UI", 10, "bold"))
        s.configure("TButton", background="#252c37", foreground=FG,
                    padding=(10, 6), font=("Segoe UI", 10))
        s.map("TButton", background=[("active", "#2f3846"), ("pressed", "#1b2129")])
        s.configure("Accent.TButton", background=ACC, foreground="#ffffff",
                    font=("Segoe UI", 10, "bold"), padding=(10, 8))
        s.map("Accent.TButton", background=[("active", "#3d7bf0")])
        s.configure("Danger.TButton", background="#33242a", foreground=BAD)
        s.map("Danger.TButton", background=[("active", "#432c33")])
        s.configure("TEntry", fieldbackground=PANEL, foreground=FG,
                    insertcolor=FG, padding=4)
        s.configure("TCombobox", fieldbackground=PANEL, background="#252c37",
                    foreground=FG, arrowcolor=FG, padding=3)
        s.map("TCombobox", fieldbackground=[("readonly", PANEL)],
              foreground=[("readonly", FG)], selectbackground=[("readonly", PANEL)],
              selectforeground=[("readonly", FG)])
        self.root.option_add("*TCombobox*Listbox.background", PANEL)
        self.root.option_add("*TCombobox*Listbox.foreground", FG)
        self.root.option_add("*TCombobox*Listbox.selectBackground", ACC)
        s.configure("TCheckbutton", background=PANEL, foreground=FG)
        s.map("TCheckbutton", background=[("active", PANEL)],
              indicatorcolor=[("selected", ACC), ("!selected", "#39414f")])
        s.configure("Horizontal.TScale", background=PANEL, troughcolor="#2b323d")
        s.configure("TSpinbox", fieldbackground=PANEL, foreground=FG,
                    arrowcolor=FG, padding=3)
        s.configure("Vertical.TScrollbar", background="#2b323d",
                    troughcolor=BG, arrowcolor=DIM)
        s.configure("TSeparator", background="#2b323d")
        ttk.Label  # noqa: B018 - прогретый импорт, чтобы option_add сработал

    # ------------------------------------------------------------------ шапка
    def _build_header(self) -> None:
        from tkinter import ttk
        head = ttk.Frame(self.root)
        head.pack(fill="x", padx=16, pady=(14, 4))
        ttk.Label(head, text="⚡ FLUX", style="Title.TLabel").pack(side="left")
        self.dot = tk_dot = ttk.Label(head, text="●", foreground=DIM,
                                      style="Status.TLabel")
        tk_dot.pack(side="left", padx=(10, 2))
        self.status = ttk.Label(head, text="определяю состояние…",
                                style="Status.TLabel")
        self.status.pack(side="left")
        self.dot_var = tk_dot

    # ----------------------------------------------------------------- кнопки
    def _build_buttons(self) -> None:
        from tkinter import ttk
        bar = ttk.Frame(self.root)
        bar.pack(fill="x", padx=16, pady=(4, 8))
        self.btn_launch = ttk.Button(bar, text="▶  Запустить ИИ",
                                     style="Accent.TButton", command=self.launch)
        self.btn_launch.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.btn_stop = ttk.Button(bar, text="⏹  Остановить",
                                   command=self.stop)
        self.btn_stop.pack(side="left", padx=(0, 4))
        ttk.Button(bar, text="🌐  Консоль", command=self.open_console).pack(
            side="left", padx=(0, 4))
        ttk.Button(bar, text="🩺  Диагностика", command=self.diagnose).pack(
            side="left")

        bar2 = ttk.Frame(self.root)
        bar2.pack(fill="x", padx=16, pady=(0, 10))
        ttk.Button(bar2, text="🪽  Проверить whisper",
                   command=self.whisper_test).pack(side="left", padx=(0, 4))
        ttk.Button(bar2, text="🔊  Проверить голос",
                   command=self.voice_test).pack(side="left", padx=(0, 4))
        ttk.Button(bar2, text="📁  Папка", command=self.open_folder).pack(
            side="left", padx=(0, 4))
        ttk.Button(bar2, text="✕  Выход", style="Danger.TButton",
                   command=self.quit).pack(side="right")

    # ------------------------------------------------------------------ форма
    def _build_form(self) -> None:
        self.scroll = ScrollFrame(self.root, self.style)
        self.scroll.outer.pack(fill="both", expand=True, padx=10, pady=(0, 4))
        self._build_stt_section()
        self._build_brain_section()
        self._build_voice_section()
        self._build_behaviour_section()

    # ------------------------------------------------- секция: голосовой ввод
    def _make_section(self, body, title: str):
        from tkinter import ttk
        box = ttk.Frame(body, style="Panel.TFrame", padding=12)
        box.pack(fill="x", padx=6, pady=6)
        ttk.Label(box, text=title, style="Section.TLabel").pack(
            anchor="w", pady=(0, 8))
        grid = ttk.Frame(box, style="Panel.TFrame")
        grid.pack(fill="x")
        grid.columnconfigure(1, weight=1)
        state = {"n": 0}

        def row(label: str, factory, hint: str = ""):
            r = state["n"]
            state["n"] += 1
            ttk.Label(grid, text=label, style="Panel.TLabel").grid(
                row=r, column=0, sticky="nw", pady=5)
            w = factory(grid)
            w.grid(row=r, column=1, sticky="we", pady=5, padx=(12, 0))
            if hint:
                hr = state["n"]
                state["n"] += 1
                ttk.Label(grid, text=hint, style="Dim.TLabel", wraplength=400,
                          justify="left").grid(row=hr, column=0, columnspan=2,
                                               sticky="w", pady=(0, 6))
            return w

        def check(label: str, var, hint: str = ""):
            r = state["n"]
            state["n"] += 1
            ttk.Checkbutton(grid, text=label, variable=var).grid(
                row=r, column=0, columnspan=2, sticky="w", pady=4)
            if hint:
                hr = state["n"]
                state["n"] += 1
                ttk.Label(grid, text=hint, style="Dim.TLabel", wraplength=400,
                          justify="left").grid(row=hr, column=0, columnspan=2,
                                               sticky="w", pady=(0, 6))
            return var

        def slider(label: str, lo: float, hi: float, initial: float,
                   fmt: str, hint: str = ""):
            """Шкала с ЖИВОЙ подписью справа (подпись видно всегда)."""
            import tkinter as tk

            r = state["n"]
            state["n"] += 1
            ttk.Label(grid, text=label, style="Panel.TLabel").grid(
                row=r, column=0, sticky="nw", pady=5)
            host = ttk.Frame(grid, style="Panel.TFrame")
            host.grid(row=r, column=1, sticky="we", pady=5, padx=(12, 0))
            host.columnconfigure(0, weight=1)
            val = tk.StringVar(value=fmt(initial))
            lbl = ttk.Label(host, textvariable=val, style="Panel.TLabel",
                            width=9, anchor="e")
            sc = ttk.Scale(host, from_=lo, to=hi, orient="horizontal",
                           command=lambda v: val.set(fmt(float(v))))
            sc.set(initial)
            sc.grid(row=0, column=0, sticky="we")
            lbl.grid(row=0, column=1, sticky="e", padx=(8, 0))
            sc._flux_fmt = fmt          # noqa: SLF001 - для reload_form
            if hint:
                hr = state["n"]
                state["n"] += 1
                ttk.Label(grid, text=hint, style="Dim.TLabel", wraplength=400,
                          justify="left").grid(row=hr, column=0, columnspan=2,
                                               sticky="w", pady=(0, 6))
            return sc

        def note(text: str):
            r = state["n"]
            state["n"] += 1
            ttk.Label(grid, text=text, style="Dim.TLabel", wraplength=430,
                      justify="left").grid(row=r, column=0, columnspan=2,
                                           sticky="w", pady=(2, 4))

        self._section_helpers = (box, row, check, note, slider)
        return box, row, check, note, slider

    def _build_stt_section(self) -> None:
        from tkinter import ttk
        body = self.scroll.inner
        _, row, check, note, _sl = self._make_section(
            body, "🎙  Голосовой ввод:  микрофон → whisper → Флюкс")

        self.stt_model = row(
            "Модель whisper",
            lambda g: ttk.Combobox(g, values=[], width=26),
            "large-v3-turbo — та же large, но в 4–8 раз быстрее (нужна GPU). "
            "small/base — для слабого CPU и 8 ГБ памяти.")
        self.stt_model.set(config.get("stt.local.model", "large-v3-turbo"))

        self.stt_engine = row(
            "Движок распознавания",
            lambda g: ttk.Combobox(g, values=[k for k, _ in STT_ENGINES],
                                   width=26, state="readonly"),
            " · ".join(f"{k} = {v}" for k, v in STT_ENGINES))
        self.stt_engine.set(config.get("stt.engine", "local"))

        self.mic = row(
            "Микрофон",
            lambda g: ttk.Combobox(g, values=[], width=26),
            "Пусто = микрофон по умолчанию в Windows. Индексы PortAudio "
            "съезжают при подключении гарнитур, поэтому выбираем ПО ИМЕНИ.")
        self.mic.set(config.get("audio.input_device_name", "") or "")

        self.idle = row(
            "Тишина до отправки, сек",
            lambda g: ttk.Spinbox(g, from_=1.0, to=30.0, increment=0.5, width=8),
            "Сколько whisper должен молчать после последнего слова, чтобы "
            "сообщение ушло ИИ ЦЕЛИКОМ. 5 c — надёжно, 2–3 c — быстрее отклик.")
        self.idle.set(float(config.get("stream.word_idle_sec", 5.0)))

        self.models_dir = row(
            "Папка моделей",
            lambda g: ttk.Entry(g),
            "Кэш моделей whisper (по умолчанию — models внутри папки FLUX).")
        self.models_dir.insert(0, str(config.get("stt.local.download_root", "") or ""))

        self.browser_src = check(
            "🎙 Источник речи — микрофон браузера (вместо локального whisper)",
            tk_bool(config.get("stt.browser_source", False)),
            "Распознавание вкладки консоли кормит тот же словесный конвейер; "
            "локальный микрофон ставится на паузу, чтобы фраза не задваивалась. "
            "Точнее в шуме, но нужны открытая вкладка и интернет. Локальный "
            "whisper офлайн и приватен — по умолчанию источник он.")

        self.wsrv = check("whisper-сервер FLUX (принимает звук от внешнего whisper)",
                          tk_bool(config.get("whisper_server.enabled", True)),
                          "POST http://127.0.0.1:<порт>/v1/audio/transcriptions — "
                          "сюда может отправить результат любой whisper "
                          "(whisper.cpp, faster-whisper-server, свой скрипт).")
        self.wsrv_port = row(
            "Порт whisper-сервера",
            lambda g: ttk.Spinbox(g, from_=1024, to=65535, increment=1, width=8))
        self.wsrv_port.set(int(config.get("whisper_server.port", 8793)))
        note("Третий способ ввода — положить .txt в data\\inbox: Флюкс прочитает "
             "его и отправит ИИ целиком (data\\inbox\\done — обработанные).")

    # ------------------------------------------------------- секция: мозг ИИ
    def _build_brain_section(self) -> None:
        from tkinter import ttk
        body = self.scroll.inner
        _, row, check, note, _sl = self._make_section(body, "🧠  Мозг: модель ИИ, "
                                                       "размышления и интернет")

        self.model = row(
            "Модель ИИ",
            lambda g: ttk.Combobox(g, values=[], width=26),
            "Список — живые модели твоего Ollama (/api/tags) + облачные. "
            "Если Ollama не запущен, список пуст: впиши имя руками.")
        self.model.set(config.get("llm.model", "gemma4:31b-cloud"))

        self.endpoint = row("Адрес Ollama", lambda g: ttk.Entry(g))
        self.endpoint.insert(0, str(config.get("llm.endpoint",
                                            "http://localhost:11434")))

        self.think = check(
            "🧠 Глубокое мышление (thinking) — для КАЖДОГО запроса",
            tk_bool(config.get("agent.think_by_default", False)),
            "Модель сначала рассуждает пошагово, потом отвечает. Блок "
            "«Размышление» виден в консоли. Медленнее, но заметно умнее на "
            "сложных задачах. Действует и на ГОЛОСОВЫЕ команды.")
        self.web = check(
            "🌐 Умный поиск в интернете — перед КАЖДЫМ ответом",
            tk_bool(config.get("agent.web_by_default", False)),
            "До ответа выполняется поиск (SearXNG, запасной — DuckDuckGo), "
            "свежие источники подаются модели системным блоком.")
        self.searx = row(
            "Адрес SearXNG",
            lambda g: ttk.Entry(g),
            "Docker-контейнер: docker compose -f installer\\docker\\searxng\\"
            "docker-compose.yml up -d  (в settings.yml должен быть formats: json).")
        self.searx.insert(0, str(config.get("search.searxng_url",
                                         "http://localhost:8888")))
        self.web_enabled = check("Интернет-инструменты (web_search / fetch_webpage)",
                                 tk_bool(config.get("search.enabled", True)))
        note("Подтверждений действий больше НЕТ: Флюкс выполняет файлы, оболочку, "
             "питание и устройства сразу. Ниже — какие категории ему разрешены.")

    # ---------------------------------------------------- секция: озвучка
    def _build_voice_section(self) -> None:
        from tkinter import ttk
        body = self.scroll.inner
        _, row, check, note, _sl = self._make_section(body, "🔊  Озвучка ответа")

        self.tts_engine = row(
            "Движок",
            lambda g: ttk.Combobox(g, values=[k for k, _ in TTS_ENGINES],
                                   width=26, state="readonly"),
            " · ".join(f"{k} = {v}" for k, v in TTS_ENGINES))
        self.tts_engine.set(config.get("tts.engine", "auto"))

        self.voice = row(
            "Голос",
            lambda g: ttk.Combobox(g, values=list(RU_VOICES), width=26))
        self.voice.set(config.get("tts.edge.voice", "ru-RU-DmitryNeural"))

        slider = self._section_helpers[4]
        self.rate = slider("Скорость речи", -50, 50,
                           _num(config.get("tts.edge.rate", 0)),
                           lambda v: f"{int(v):+d}%",
                           "−50…+50 %, как в Edge TTS. Действует и на SAPI5.")
        self.pitch = slider("Тон", -20, 20,
                            _num(config.get("tts.edge.pitch", 0)),
                            lambda v: f"{int(v):+d} Гц")
        self.volume = slider("Громкость", 0, 100,
                             float(config.get("tts.volume", 1.0)) * 100.0,
                             lambda v: f"{int(v)}%")
        note("Скорость/тон действуют и на запасной SAPI5 (офлайн), а не только "
             "на Edge TTS — раньше ползунок скорости до SAPI5 не доезжал.")

    # --------------------------------------------------- секция: поведение
    def _build_behaviour_section(self) -> None:
        from tkinter import ttk
        body = self.scroll.inner
        _, row, check, note, _sl = self._make_section(body, "⚙  Поведение и доступы")

        self.wake = row(
            "Слово активации",
            lambda g: ttk.Entry(g),
            "Через запятую: «флюкс, flux». Второй способ — зажать Numpad 9 "
            "(push-to-talk), третий — кнопка «Слушать» в консоли.")
        self.wake.insert(0, ", ".join(config.get("wake.words", ["флюкс"])))

        self.wake_enabled = check("Активация словом включена",
                                  tk_bool(config.get("wake.enabled", True)))
        self.sens = row(
            "Чувствительность слова",
            lambda g: ttk.Combobox(g, values=["0", "1", "2"], width=6,
                                   state="readonly"),
            "0 = строго точное слово (меньше ложных срабатываний), "
            "2 = мягче (лучше слышит в шуме, но чаще реагирует на похожие слова).")
        self.sens.set(str(int(config.get("wake.sensitivity", 0))))

        self.barge = check("Перебивание: моя речь останавливает озвучку Флюкса",
                           tk_bool(config.get("audio.barge_in", False)))

        sec = config.get("security", {}) or {}
        self.allow_shell = check("Разрешить оболочку (run_command / run_python)",
                                 tk_bool(sec.get("allow_shell", True)))
        self.allow_write = check("Разрешить запись и удаление файлов",
                                 tk_bool(sec.get("allow_file_write", True)))
        self.allow_computer = check("Разрешить управление компьютером "
                                    "(мышь/клавиатура/скриншоты)",
                                    tk_bool(sec.get("allow_computer_use", True)))
        self.allow_devices = check("Разрешить управление устройствами и сетью",
                                   tk_bool(sec.get("allow_device_control", True)))
        self.allow_power = check("Разрешить питание (сон/блокировка/выключение)",
                                 tk_bool(sec.get("allow_power_actions", True)))

        self.autostart = check("Запускать вместе с Windows",
                               tk_bool(config.get("autostart.enabled", False)))
        note("Автозагрузка прописывается одним модулем (autostart.py) через "
             "pythonw.exe -m flux.main --autostart — раньше меню и ядро писали "
             "в реестр разные команды, и одна из них вела на несуществующий "
             "Flux.exe.")

    # ---------------------------------------------------------------- подвал
    def _build_footer(self) -> None:
        from tkinter import ttk
        foot = ttk.Frame(self.root)
        foot.pack(fill="x", padx=16, pady=(4, 12))
        self.save_btn = ttk.Button(foot, text="💾  Сохранить и применить",
                                   style="Accent.TButton",
                                   command=self.save_settings)
        self.save_btn.pack(side="left", fill="x", expand=True, padx=(0, 6))
        ttk.Button(foot, text="↺  Отменить", command=self.reload_form).pack(
            side="left", padx=(0, 6))
        ttk.Button(foot, text="Сброс по умолчанию",
                   command=self.reset_defaults).pack(side="left")
        self.hint = ttk.Label(self.root, text="", foreground=DIM,
                              font=("Segoe UI", 8), justify="left")
        self.hint.pack(fill="x", padx=18, pady=(0, 10))

    # ------------------------------------------------------- фоновые задачи
    def _async(self, worker, then) -> None:
        """worker() в нити -> then(result) в ГЛАВНОМ потоке Tk.

        tkinter НЕ потокобезопасен: трогать виджеты из нити нельзя. Поэтому
        нить только собирает ДАННЫЕ, а применяет их колбэк через root.after.
        Это и лечит «менюшка логает»: ни один сетевой/звуковой вызов больше
        не блокирует главный цикл.
        """
        def run() -> None:
            try:
                res = worker()
            except Exception as e:          # noqa: BLE001 - меню не должно падать
                log.debug("фоновая задача меню не удалась: %s", e)
                res = None
            if self._destroyed:
                return
            self._after(0, lambda: then(res))
        threading.Thread(target=run, daemon=True,
                         name="flux-menu-io").start()

    def _load_choices_async(self) -> None:
        def worker() -> dict:
            return {"stt": self._stt_choices(), "mic": self._mic_choices(),
                    "llm": self._llm_choices(), "voice": self._voice_choices()}

        def then(data: Optional[dict]) -> None:
            if not data or self._destroyed:
                return
            # ТОЛЬКО config.get(): у вложенного dict точечных ключей нет
            # (ровно этот баг меню уже чинили в v1.5.0, см. A3)
            for combo, key, cur in ((self.stt_model, "stt",
                                     config.get("stt.local.model",
                                                "large-v3-turbo")),
                                    (self.mic, "mic",
                                     config.get("audio.input_device_name",
                                                "") or ""),
                                    (self.model, "llm",
                                     config.get("llm.model",
                                                "gemma4:31b-cloud")),
                                    (self.voice, "voice",
                                     config.get("tts.edge.voice",
                                                "ru-RU-DmitryNeural"))):
                values = list(data.get(key) or [])
                if cur and cur not in values:
                    values.insert(0, cur)      # текущее значение не «пропадает»
                try:
                    combo.configure(values=values)
                    if cur:
                        combo.set(cur)
                except Exception:
                    pass
            self._choices_loaded = True
        self._async(worker, then)

    # ---------------------------------------------------------------- списки
    @staticmethod
    def _stt_choices() -> list:
        """Модели распознавания: уже скачанные первыми, потом известные."""
        try:
            from .stt import local as local_stt
            cached = local_stt.cached_models()
            known = list(local_stt.FALLBACK_CHAIN)
        except Exception:
            cached, known = [], ["large-v3-turbo", "medium", "small", "base",
                                 "tiny"]
        out: list[str] = []
        for m in cached + known:
            if m and m not in out:
                out.append(m)
        return out or ["base"]

    @staticmethod
    def _mic_choices() -> list:
        """Микрофоны: из запущенного Флюкса (HTTP), иначе напрямую из системы."""
        names: list[str] = [""]
        d = _http_json("/api/devices")
        if isinstance(d, dict) and d.get("devices"):
            for dev in d["devices"]:
                if dev.get("loopback"):
                    continue          # петли захвата из динамиков не берём вовсе
                n = str(dev.get("name") or "")
                if n and n not in names:
                    names.append(n)
        else:
            try:
                from .audio import devices as devmod
                for dev in devmod.list_input_devices():
                    if getattr(dev, "is_loopback", False):
                        continue
                    n = str(getattr(dev, "name", "") or "")
                    if n and n not in names:
                        names.append(n)
            except Exception:
                pass
        return names

    @staticmethod
    def _llm_choices() -> list:
        out: list[str] = []
        try:
            from . import models as models_mod
            cat = models_mod.catalog()
            for m in (cat.get("llm", {}) or {}).get("models", []) or []:
                n = str(m.get("value") or m.get("id") or "")
                if n and n not in out:
                    out.append(n)
        except Exception:
            pass
        if not out:
            try:
                from .llm.ollama_client import OllamaClient
                for n in OllamaClient().models():
                    if n and n not in out:
                        out.append(n)
            except Exception:
                pass
        for extra in ("gemma4:31b-cloud", "llama3.1:8b", "qwen3:14b"):
            if extra not in out:
                out.append(extra)
        return out

    @staticmethod
    def _voice_choices() -> list:
        out = list(RU_VOICES)
        try:
            from .tts.engine import list_voices
            for v in list_voices():
                if v.locale.lower().startswith("ru") and v.short_name not in out:
                    out.append(v.short_name)
        except Exception:
            pass
        return out

    # ---------------------------------------------------------------- статус
    def _set_status(self, text: str, color: str = DIM) -> None:
        if self._destroyed:
            return
        try:
            self.status.configure(text=text, foreground=color)
            self.dot_var.configure(foreground=color)
        except Exception:
            pass

    def _paint_status(self, st) -> None:
        """Рисует шапку ПО ГОТОВЫМ данным (вызывается только из main-потока)."""
        if isinstance(st, dict) and st.get("state"):
            label = {"idle": "слушаю микрофон", "awake": "слушаю команду",
                     "thinking": "думаю", "speaking": "говорю",
                     "ptt": "зажата клавиша"}.get(str(st.get("state")),
                                                  str(st.get("state")))
            bits = [f"РАБОТАЕТ · {label}"]
            if st.get("mic"):
                bits.append(f"микрофон: {st['mic']}")
            if st.get("stt_model"):
                bits.append(f"whisper: {st['stt_model']}")
            if st.get("model"):
                bits.append(f"ИИ: {st['model']}")
            self._set_status(" · ".join(bits), OK)
            self.btn_launch.configure(text="▶  Уже запущен")
        else:
            pid = read_pid()
            if pid and self._pid_alive:
                self._set_status(f"v{__version__} · процесс жив (pid {pid}), "
                                 f"консоль не отвечает", WARN)
            else:
                self._set_status(f"v{__version__} · остановлен", DIM)
            self.btn_launch.configure(text="▶  Запустить ИИ")

    def _refresh_status(self) -> None:
        """Запрос состояния в НИТИ: HTTP больше не морозит главное окно.

        Раньше _http_json("/api/state", timeout=2.0) выполнялся прямо в
        главном цикле Tk каждые 3 c: пока Флюкс не отвечал (старт, фаервол,
        занятый порт), окно намертво замирало на время таймаута.
        """
        if self._destroyed:
            return

        def worker():
            st = _http_json("/api/state")
            alive = bool(st) or is_running()   # HTTP уже мог ответить
            return st, alive

        def then(pair) -> None:
            st, alive = pair or (None, False)
            self._pid_alive = alive
            self._paint_status(st)
        self._pid_alive = getattr(self, "_pid_alive", False)
        self._async(worker, then)

    def _poll_status(self) -> None:
        """Живой статус раз в 3 c (меню не должно выглядеть мёртвым)."""
        if self._destroyed:
            return
        self._refresh_status()
        try:
            self.root.after(3000, self._poll_status)
        except Exception:
            pass

    def _after(self, ms: int, fn: Callable) -> None:
        if self._destroyed:
            return
        try:
            self.root.after(ms, fn)
        except Exception:
            pass

    # --------------------------------------------------------------- действия
    def launch(self) -> None:
        """Запуск Флюкса: проверка и spawn В НИТИ.

        is_running() делает HTTP-запрос к консоли; на старте/фаерволе он
        держит окно до таймаута — а клик по кнопке не должен морозить меню.
        """
        self._set_status("проверяю, запущен ли Флюкс…", WARN)

        def worker():
            running = is_running()
            if not running:
                _run_hidden([_pythonw(), "-m", "flux.main"])
            return running

        def then(running) -> None:
            if running:
                self._set_status("уже работает — открываю консоль", OK)
                self.open_console()
            else:
                self._set_status("запускаю Флюкс…", WARN)
            self._after(1800, self._refresh_status)
        self._async(worker, then)

    def stop(self) -> None:
        """Остановка: terminate/wait(6 c)/taskkill(15 c) — ТОЛЬКО в нити.

        Раньше всё это выполнялось в главном цикле Tk: клик по «Остановить»
        замораживал окно на срок ожидания процесса (до 6 c, а с фолбэком
        taskkill — до 21 c). Это и выглядело как «менюшка лагает».
        """
        self._set_status("останавливаю…", WARN)

        def worker() -> str:
            pid = read_pid()
            if not pid:
                return "no-pid"
            stopped = False
            try:
                import psutil
                pr = psutil.Process(pid)
                pr.terminate()
                try:
                    pr.wait(timeout=6)
                except Exception:
                    pr.kill()
                stopped = True
            except Exception as e:
                log.warning("не удалось остановить процесс %s: %s", pid, e)
            if not stopped and os.name == "nt":
                try:
                    subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                                   capture_output=True, timeout=15, check=False,
                                   creationflags=getattr(
                                       subprocess, "CREATE_NO_WINDOW", 0))
                    stopped = True
                except Exception:
                    pass
            return "ok" if stopped else "fail"

        def then(res: str) -> None:
            if res == "no-pid":
                self._set_status("не нашёл запущенный процесс", BAD)
            elif res == "ok":
                self._set_status("остановлено", OK)
            else:
                self._set_status("процесс жив, но остановить не удалось — "
                                 "закрой его в Диспетчере задач", BAD)
            self._after(900, self._refresh_status)
        self._async(worker, then)

    def open_console(self) -> None:
        webbrowser.open(_base_url() + "/")

    def open_folder(self) -> None:
        try:
            if os.name == "nt":
                os.startfile(str(paths.HOME))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(paths.HOME)])
            else:
                subprocess.Popen(["xdg-open", str(paths.HOME)])
        except Exception as e:
            self._set_status(f"не смог открыть папку: {e}", BAD)

    def _long_task(self, label: str, fn: Callable[[], str]) -> None:
        """Долгая операция в нити + результат в модальном окошке."""
        from tkinter import messagebox
        self._set_status(label, WARN)

        def run() -> None:
            try:
                text = fn()
            except Exception as e:
                text = f"{label} не удался: {type(e).__name__}: {e}"

            def show() -> None:
                if self._destroyed:
                    return
                self._set_status(f"{label}: готово", OK)
                messagebox.showinfo("FLUX", text)
            self._after(0, show)
        threading.Thread(target=run, daemon=True).start()

    def whisper_test(self) -> None:
        def work() -> str:
            # если Флюкс запущен — просим проверить ЕГО (иначе меню само
            # откроет микрофон и два процесса будут драться за устройство)
            r = _http_json("/api/action", {"action": "whisper_test", "seconds": 6},
                           timeout=90.0)
            if isinstance(r, dict) and isinstance(r.get("result"), dict):
                from .stt import whisper_check
                return whisper_check.report(r["result"])
            from .stt import whisper_check
            return whisper_check.report(whisper_check.check(seconds=6.0))
        self._long_task("whisper-тест (6 c записи)", work)

    def voice_test(self) -> None:
        def work() -> str:
            text = "Проверка озвучки. Флюкс на связи."
            r = _http_json("/api/action", {"action": "test_tts", "text": text},
                           timeout=60.0)
            if isinstance(r, dict) and r.get("result", {}).get("played"):
                return "Озвучка проиграна через Edge TTS."
            try:
                from .tts.engine import TTSRouter
                path, engine = TTSRouter().synthesize(text)
                if path:
                    from .audio.player import Player
                    p = Player(volume=float(config.get("tts.volume", 1.0)))
                    p.start()
                    p.enqueue_file(path)
                    p.wait_idle(timeout=20)
                    p.stop()
                    try:
                        os.remove(path)
                    except OSError:
                        pass
                    return f"Озвучка проиграна (движок: {engine})."
                return f"Озвучить не удалось (движок: {engine}). Проверь интернет " \
                       f"или выбери движок sapi5."
            except Exception as e:
                return f"Проверка озвучки не удалась: {type(e).__name__}: {e}"
        self._long_task("проверка озвучки", work)

    def diagnose(self) -> None:
        """Самотест: вывод СОХРАНЯЕМ в файл и показываем.

        БАГ: раньше самоотчёт запускался как ``subprocess.Popen([sys.executable,
        '-m', 'flux.selftest'])`` — а меню живёт под pythonw.exe, то есть
        консоли у дочернего процесса НЕТ и весь отчёт улетал в никуда
        (пользователь видел только мигнувшее окно).
        """
        out_path = paths.LOG_DIR / "selftest_menu.txt"

        def work() -> str:
            paths.LOG_DIR.mkdir(parents=True, exist_ok=True)
            try:
                from .selftest import run_selftest
                rep = run_selftest(quick=False)
                text = rep.as_text()
            except Exception as e:
                text = f"самотест не запустился: {type(e).__name__}: {e}"
            try:
                out_path.write_text(text, encoding="utf-8")
            except OSError:
                pass
            return text
        self._long_task("диагностика", work)

        def opener() -> None:
            try:
                if out_path.exists():
                    if os.name == "nt":
                        os.startfile(str(out_path))  # type: ignore[attr-defined]
                    elif sys.platform == "darwin":
                        subprocess.Popen(["open", str(out_path)])
                    else:
                        subprocess.Popen(["xdg-open", str(out_path)])
            except Exception:
                pass
        self._after(1200, opener)

    # ------------------------------------------------------------- настройки
    def _collect(self) -> dict:
        words = [w.strip() for w in self.wake.get().split(",") if w.strip()]
        rate = int(self.rate.get())
        pitch = int(self.pitch.get())
        vol = max(0, min(100, int(self.volume.get())))
        stt_choice = str(self.stt_model.get().strip() or "")
        out: dict[str, Any] = {
            "wake.words": words or ["флюкс"],
            "wake.enabled": bool(self.wake_enabled.get()),
            "wake.sensitivity": int(self.sens.get() or 0),
            "audio.barge_in": bool(self.barge.get()),
            "audio.input_device_name": str(self.mic.get().strip() or ""),
            "audio.input_device": None,
            "tts.engine": str(self.tts_engine.get() or "auto"),
            "tts.edge.voice": str(self.voice.get() or "ru-RU-DmitryNeural"),
            "tts.edge.rate": f"{rate:+d}%",
            "tts.edge.pitch": f"{pitch:+d}Hz",
            "tts.volume": round(vol / 100.0, 3),
            # скорость/тон доезжают и до офлайн-SAPI5 (см. tts/engine.py)
            "tts.sapi5.rate": max(-10, min(10, int(round(rate / 5)))),
            "tts.sapi5.volume": vol,
            "llm.model": str(self.model.get().strip()
                             or "gemma4:31b-cloud"),
            "llm.endpoint": str(self.endpoint.get().strip()
                                or "http://localhost:11434"),
            "agent.think_by_default": bool(self.think.get()),
            "agent.web_by_default": bool(self.web.get()),
            "search.enabled": bool(self.web_enabled.get()),
            "search.searxng_url": str(self.searx.get().strip()
                                      or "http://localhost:8888"),
            "stream.word_idle_sec": float(self.idle.get() or 5.0),
            "stt.local.download_root": str(self.models_dir.get().strip() or ""),
            "stt.browser_source": bool(self.browser_src.get()),
            "whisper_server.enabled": bool(self.wsrv.get()),
            "whisper_server.port": int(self.wsrv_port.get() or 8793),
            "security.allow_shell": bool(self.allow_shell.get()),
            "security.allow_file_write": bool(self.allow_write.get()),
            "security.allow_computer_use": bool(self.allow_computer.get()),
            "security.allow_device_control": bool(self.allow_devices.get()),
            "security.allow_power_actions": bool(self.allow_power.get()),
            "autostart.enabled": bool(self.autostart.get()),
        }
        if stt_choice:
            out["stt.local.model"] = stt_choice
            out["stt.engine"] = str(self.stt_engine.get() or "local")
        else:
            out["stt.engine"] = str(self.stt_engine.get() or "local")
        return out

    def _write_config(self, values: dict) -> None:
        for dotted, value in values.items():
            config.set_value(dotted, value, save=False)
        config.save_config()

    def _apply_to_running(self, values: dict) -> str:
        """Применить настройки к УЖЕ ЗАПУЩЕННОМУ Флюксу (без перезапуска)."""
        r = _http_json("/api/config", {"set": values}, timeout=8.0)
        if isinstance(r, dict) and r.get("ok"):
            return "применено к работающему Флюксу"
        if _http_json("/api/state", timeout=1.5) is None:
            return "Флюкс не запущен — подхватит при старте"
        _http_json("/api/reload", {}, timeout=8.0)
        return "сохранено (работающий Флюкс перечитает конфиг)"

    def save_settings(self) -> None:
        from tkinter import messagebox
        try:
            values = self._collect()
        except Exception as e:
            messagebox.showerror("FLUX", f"Проверь поля: {e}")
            return
        try:
            self._write_config(values)          # локальная запись — быстрая
        except Exception as e:
            messagebox.showerror("FLUX", f"Не смог записать config.json: {e}")
            return
        self._set_status("сохраняю…", WARN)

        def worker() -> str:
            # автозагрузка — отдельным модулем: он пишет реестр Windows
            try:
                from .autostart import set_autostart
                set_autostart(bool(values.get("autostart.enabled")))
            except Exception as e:
                log.warning("autostart: %s", e)
            # применение к живому Флюксу = HTTP до 8 c: только в нити
            return self._apply_to_running(values)

        def then(note: str) -> None:
            note = note or "сохранено"
            self._set_status(f"настройки сохранены · {note}", OK)
            self.hint.configure(text=f"✔ {note}. Файл: {paths.CONFIG_FILE}")
            self._refresh_status()
        self._async(worker, then)

    def reload_form(self) -> None:
        """Перечитать поля из config.json (кнопка «Отменить»)."""
        config.load(force=True)
        self.wake.delete(0, "end")
        self.wake.insert(0, ", ".join(config.get("wake.words", ["флюкс"])))
        self.voice.set(config.get("tts.edge.voice", "ru-RU-DmitryNeural"))
        self.rate.set(_num(config.get("tts.edge.rate", 0)))
        self.pitch.set(_num(config.get("tts.edge.pitch", 0)))
        self.volume.set(float(config.get("tts.volume", 1.0)) * 100.0)
        self.model.delete(0, "end")
        self.model.insert(0, config.get("llm.model", "gemma4:31b-cloud"))
        self.endpoint.delete(0, "end")
        self.endpoint.insert(0, config.get("llm.endpoint", "http://localhost:11434"))
        self.searx.delete(0, "end")
        self.searx.insert(0, config.get("search.searxng_url", "http://localhost:8888"))
        self.stt_model.set(config.get("stt.local.model", "large-v3-turbo"))
        self.stt_engine.set(config.get("stt.engine", "local"))
        self.tts_engine.set(config.get("tts.engine", "auto"))
        self.mic.set(config.get("audio.input_device_name", "") or "")
        self.idle.delete(0, "end")
        self.idle.insert(0, str(float(config.get("stream.word_idle_sec", 5.0))))
        self.models_dir.delete(0, "end")
        self.models_dir.insert(0, str(config.get("stt.local.download_root", "") or ""))
        self.wsrv_port.delete(0, "end")
        self.wsrv_port.insert(0, str(int(config.get("whisper_server.port", 8793))))
        self.sens.set(str(int(config.get("wake.sensitivity", 0))))
        for var, key in ((self.browser_src, "stt.browser_source"),
                         (self.wsrv, "whisper_server.enabled"),
                         (self.wake_enabled, "wake.enabled"),
                         (self.think, "agent.think_by_default"),
                         (self.web, "agent.web_by_default"),
                         (self.web_enabled, "search.enabled"),
                         (self.barge, "audio.barge_in"),
                         (self.allow_shell, "security.allow_shell"),
                         (self.allow_write, "security.allow_file_write"),
                         (self.allow_computer, "security.allow_computer_use"),
                         (self.allow_devices, "security.allow_device_control"),
                         (self.allow_power, "security.allow_power_actions"),
                         (self.autostart, "autostart.enabled")):
            var.set(bool(config.get(key, False)))
        self.hint.configure(text="значения перечитаны из config.json")

    def reset_defaults(self) -> None:
        from tkinter import messagebox
        if not messagebox.askyesno(
                "FLUX", "Вернуть ВСЕ настройки к значениям по умолчанию?\n"
                        "Текущий config.json будет перезаписан."):
            return
        config.reset_to_defaults()
        self.reload_form()
        self._set_status("настройки сброшены к стандартным", WARN)

    # ------------------------------------------------------------------ цикл
    def quit(self) -> None:
        self._destroyed = True
        try:
            self.scroll.canvas.unbind_all("<MouseWheel>")
            self.scroll.canvas.unbind_all("<Button-4>")
            self.scroll.canvas.unbind_all("<Button-5>")
        except Exception:
            pass
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def tk_bool(value: Any):
    """BooleanVar, созданный ПОСЛЕ Tk() (иначе tkinter ругается на корни)."""
    import tkinter as tk
    return tk.BooleanVar(value=bool(value))


def main() -> int:
    MenuApp().run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
