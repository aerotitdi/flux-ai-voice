"""Проверка API-ключей с ЧЕЛОВЕЧЕСКОЙ расшифровкой ошибки.

Один и тот же код используют:
  * самотест (`python -m flux.selftest` -> строка «ключ groq»);
  * веб-консоль (⚙ -> «🔑 Проверить ключи»);
  * меню/лог старта.

Повод: на машине пользователя самотест напечатал «ключ groq — HTTP 403» без
причины, а на дашборде Groq при этом «0 API Calls». 403 != 401: ключ
синтаксически принят, но запрос отклонён. Причина найдена: Groq отдаёт 403
ПО РЕГИОНУ из России (замер с московского IP 01.10.2026, Хабр: «Groq и
Together тоже 403»); дополнительно запрос может резать антивирус с
TLS-инспекцией (у того же пользователя АВ ломает speech.platform.bing.com).

Проверка идёт в ДВА шага:
  1) GET  {base}/models           — дёшево, но иногда закрыто для ключа;
  2) POST {base}/chat/completions — минимальный реальный запрос (max_tokens=1).
Если 1-й шаг дал 403, а 2-й 200 — ключ РАБОЧИЙ, помечаем ok с предупреждением.
Ключ в отчёт попадает только маской: `gsk_ABC…wxyz`.
"""
from __future__ import annotations


PROBES = {
    "groq": {
        "base": "https://api.groq.com/openai/v1",
        "models": "/models",
        "chat_model": "llama-3.1-8b-instant",
        "header": "bearer",
    },
    "openai": {
        "base": "https://api.openai.com/v1",
        "models": "/models",
        "chat_model": "gpt-4o-mini",
        "header": "bearer",
    },
    "elevenlabs": {
        "base": "https://api.elevenlabs.io/v1",
        "models": "/user/subscription",
        "chat_model": "",
        "header": "xi",
    },
}

HTTP_HINTS = {
    400: "неверный формат запроса/ключа",
    401: "ключ неверный, отозван или скопирован не полностью — вставь заново",
    402: "нет оплаченного баланса",
    404: "нет такого ресурса или модели для этого ключа",
    413: "запрос слишком большой",
    429: "лимит запросов исчерпан (бесплатный тариф) — подожди окно лимита",
    500: "ошибка на стороне провайдера, повтори позже",
    503: "провайдер недоступен (перегрузка/техработы)",
}


def mask_key(key: str) -> str:
    """Маска ключа для логов: никогда не печатаем ключ целиком."""
    key = (key or "").strip()
    if not key:
        return "(пусто)"
    if len(key) <= 12:
        return key[:2] + "…" + str(len(key)) + " симв."
    return f"{key[:7]}…{key[-4:]} ({len(key)} симв.)"


def _headers(spec: dict, key: str) -> dict:
    if spec.get("header") == "xi":
        return {"xi-api-key": key}
    return {"Authorization": f"Bearer {key}"}


def hint(name: str, code: int) -> str:
    """Что означает код и что делать (коротко, по-русски)."""
    if code == 403:
        base = ("доступ запрещён: ключ принят, но запрос отклонён. Причины: "
                "организация не активирована/не подтверждена, у ключа нет прав "
                "на этот ресурс, либо запрос режет антивирус/прокси с "
                "TLS-инспекцией (он же у тебя ломает speech.platform.bing.com)")
        if name == "groq":
            return ("Groq из РОССИИ не работает: 403 по региону (замер с "
                    "московского IP 01.10.2026, Хабр: «Groq и Together тоже "
                    "403»). Ключ ни при чём — его принимает авторизация, но "
                    "запрос отклоняет гео-фильтр; то же самое делает твой "
                    "антивирус с TLS-инспекцией (speech.platform.bing.com). "
                    "Лечится прокси/VPN вне РФ; если ты не в РФ и всё равно "
                    "403 — добавь api.groq.com в исключения антивируса с "
                    "TLS-инспекцией. Проверить, что ключ "
                    "ни при чём: console.groq.com → API Keys (статус Active) "
                    "и Usage (0 вызовов = запросы даже не доходили). FLUX это "
                    "учитывает: основной распознаватель — ЛОКАЛЬНЫЙ "
                    "faster-whisper (large-v3-turbo на твоей GPU), Groq даже "
                    "не нужен")
        return base
    return HTTP_HINTS.get(code, "проверь ключ в консоли ⚙ → «Проверить ключи»")


def check(name: str, key: str, requests_mod=None, timeout: int = 10) -> dict:
    """Проверяет один ключ. Возвращает:
    {ok, code, detail, warn, engine}
    """
    if requests_mod is None:
        import requests as requests_mod  # type: ignore
    spec = PROBES.get(name)
    if spec is None:
        return {"ok": False, "code": 0, "warn": True,
                "detail": f"неизвестный провайдер {name}"}
    key = (key or "").strip()
    if not key:
        return {"ok": False, "code": 0, "warn": True, "detail": "нет ключа",
                "masked": mask_key(key)}
    hdr = _headers(spec, key)
    masked = mask_key(key)
    base = spec["base"]

    first = None
    try:
        first = requests_mod.get(base + spec["models"], headers=hdr,
                                 timeout=timeout)
    except Exception as e:
        return {"ok": False, "code": 0, "warn": True, "masked": masked,
                "detail": f"сеть недоступна: {type(e).__name__}: {str(e)[:110]}"}

    if first.status_code == 200:
        return {"ok": True, "code": 200, "warn": False, "masked": masked,
                "detail": "валиден"}

    second = None
    net = ""
    if spec.get("chat_model"):
        try:
            second = requests_mod.post(
                base + "/chat/completions",
                headers={**hdr, "Content-Type": "application/json"},
                json={"model": spec["chat_model"], "max_tokens": 1,
                      "messages": [{"role": "user", "content": "ping"}]},
                timeout=timeout)
        except Exception as e:
            net = f"{type(e).__name__}: {str(e)[:80]}"
        if second is not None and second.status_code == 200:
            return {"ok": True, "code": 200, "warn": True, "masked": masked,
                    "detail": "валиден (список моделей для ключа закрыт, "
                              "но чат отвечает)"}

    resp = second if second is not None else first
    code = int(getattr(resp, "status_code", 0) or 0)
    body = ""
    try:
        body = " ".join(str(resp.text or "").split())[:160]
    except Exception:
        body = ""
    detail = f"HTTP {code}: {hint(name, code)} (ключ: {masked})"
    if body:
        detail += f" | ответ: {body}"
    if net:
        detail += f" | чат-проверка не прошла: {net}"
    return {"ok": False, "code": code, "warn": False, "masked": masked,
            "detail": detail}


def check_all(get_key, requests_mod=None) -> dict:
    """Все ключи из конфига. `get_key(name) -> str`."""
    out: dict[str, dict] = {}
    for name in PROBES:
        try:
            key = str(get_key(name) or "")
        except Exception:
            key = ""
        if not key:
            continue
        out[name] = check(name, key, requests_mod=requests_mod)
    return out


def short(result: dict) -> str:
    """Однострочный статус для консоли («OK», «HTTP 403: …»)."""
    if result.get("ok"):
        return "OK" + (" (модел. список закрыт)" if result.get("warn") else "")
    return str(result.get("detail") or "ошибка")


def summary(results: dict) -> str:
    lines = []
    for name, r in results.items():
        mark = "OK " if r.get("ok") else "ОШИБКА"
        lines.append(f"[{mark}] {name}: {short(r)}")
    return "\n".join(lines) if lines else "ключи не заданы"
