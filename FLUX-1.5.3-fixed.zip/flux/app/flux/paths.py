"""Определение корня установки FLUX и всех рабочих путей.

Порядок поиска корня:
  1) переменная окружения FLUX_HOME
  2) D:\\flux  (целевое место установки по ТЗ)
  3) родительская папка пакета (портативный запуск / разработка)
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def _candidate_roots() -> list[Path]:
    out: list[Path] = []
    env = os.environ.get("FLUX_HOME")
    if env:
        out.append(Path(env))
    if os.name == "nt":
        out.append(Path("D:/flux"))
    # .../flux/app/flux/paths.py -> .../flux
    here = Path(__file__).resolve()
    for parent in here.parents:
        if parent.name in {"app", "flux"} and parent.parent.exists():
            out.append(parent.parent if parent.name == "app" else parent)
            break
    out.append(here.parents[2])
    return out


def flux_home() -> Path:
    for cand in _candidate_roots():
        try:
            if (cand / "config").is_dir() or (cand / "app").is_dir():
                return cand
        except OSError:
            continue
    # фолбэк: создаём рядом с приложением
    fallback = Path(__file__).resolve().parents[2]
    return fallback


HOME: Path = flux_home()
APP_DIR: Path = Path(__file__).resolve().parents[1]
CONFIG_DIR: Path = HOME / "config"
DATA_DIR: Path = HOME / "data"
LOG_DIR: Path = HOME / "logs"
MODELS_DIR: Path = HOME / "models"
CACHE_DIR: Path = DATA_DIR / "cache"
TMP_DIR: Path = DATA_DIR / "tmp"
SCREENSHOTS_DIR: Path = DATA_DIR / "screenshots"
AUDIO_DIR: Path = DATA_DIR / "audio"
CONFIG_FILE: Path = CONFIG_DIR / "config.json"
DB_FILE: Path = DATA_DIR / "flux.db"
DESKTOP_CANDIDATES = [
    Path(os.path.expanduser("~/Desktop")),
    Path("C:/Users/User/Desktop"),
]


def ensure_dirs() -> None:
    for p in (CONFIG_DIR, DATA_DIR, LOG_DIR, MODELS_DIR, CACHE_DIR, TMP_DIR,
              SCREENSHOTS_DIR, AUDIO_DIR):
        try:
            p.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass


def desktop_dir() -> Path:
    """Реальный рабочий стол текущего пользователя (OneDesktop учитывается)."""
    if os.name == "nt":
        try:
            import winreg  # type: ignore

            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders",
            )
            val, _ = winreg.QueryValueEx(key, "Desktop")
            winreg.CloseKey(key)
            expanded = os.path.expandvars(val)
            if expanded:
                p = Path(expanded)
                if p.exists():
                    return p
        except Exception:
            pass
    for cand in DESKTOP_CANDIDATES:
        if cand.exists():
            return cand
    return Path(os.path.expanduser("~"))


def is_frozen() -> bool:
    return getattr(sys, "frozen", False)
