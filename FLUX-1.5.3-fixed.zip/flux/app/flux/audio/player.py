"""Воспроизведение озвучки. Декодирует MP3 (edge-tts) через PyAV и играет PCM.

Уведомляет внешний колбэк о начале/конце речи - main использует это для
анти-эха (пауза микрофона на время озвучки).
"""
from __future__ import annotations

import threading
import time
from typing import Callable, Optional

import numpy as np

try:
    import av  # type: ignore  (ставится вместе с faster-whisper)
except Exception:  # pragma: no cover
    av = None  # type: ignore

try:
    import sounddevice as sd  # type: ignore
except Exception:  # pragma: no cover
    sd = None  # type: ignore

CHUNK_SECONDS = 0.12


def decode_audio_file(path: str, target_sr: int | None = None) -> tuple[np.ndarray, int]:
    """MP3/WAV/OGG -> (float32 mono -1..1, sample_rate)."""
    if av is None:  # pragma: no cover
        raise RuntimeError("PyAV не установлен: pip install av")
    container = av.open(str(path))
    stream = None
    try:
        stream = next((s for s in container.streams if s.type == "audio"), None)
        if stream is None:
            raise RuntimeError(f"в файле {path} нет аудиопотока")
        if target_sr:
            resampler = av.AudioResampler(format="s16", layout="mono", rate=target_sr)
        else:
            resampler = av.AudioResampler(format="s16", layout="mono",
                                          rate=int(stream.rate))
        pcm: list[np.ndarray] = []
        for packet in container.demux(stream):
            for frame in packet.decode():
                for rf in resampler.resample(frame):
                    arr = rf.to_ndarray()
                    pcm.append(arr.reshape(-1))
        for rf in resampler.resample(None):  # type: ignore[arg-type]
            arr = rf.to_ndarray()
            pcm.append(arr.reshape(-1))
    finally:
        container.close()
    if not pcm:
        return np.zeros(0, dtype=np.int16), target_sr or 16000
    data = np.concatenate(pcm).astype(np.float32) / 32768.0
    sr = target_sr or int(getattr(stream, "rate", 0) or 16000)
    return data, sr


def decode_audio_file_bytes(data: bytes, target_sr: int | None = 16000
                            ) -> tuple[np.ndarray, int]:
    """Байты звука (WAV/MP3/OGG) -> (int16 mono, sample_rate).

    WAV читаем стандартной библиотекой (быстро и без зависимостей), всё
    остальное — через PyAV. Используется whisper-сервером FLUX: туда любой
    внешний whisper может прислать звук, который надо распознать.
    """
    import io
    import wave

    if data[:4] == b"RIFF" and data[8:12] == b"WAVE":
        try:
            with wave.open(io.BytesIO(data), "rb") as w:
                ch, sw, sr = w.getnchannels(), w.getsampwidth(), w.getframerate()
                raw = w.readframes(w.getnframes())
            if sw == 2 and ch >= 1 and raw:
                arr = np.frombuffer(raw, dtype=np.int16)
                if ch > 1:
                    arr = arr.reshape(-1, ch).mean(axis=1).astype(np.int16)
                if target_sr and sr != target_sr:
                    n = int(len(arr) * float(target_sr) / float(sr))
                    idx = np.linspace(0, len(arr) - 1, num=max(1, n)).astype(int)
                    arr = arr[idx]
                    sr = int(target_sr)
                return arr.astype(np.int16), int(sr)
        except Exception:
            pass                                  # не наш WAV -> через PyAV
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".audio", delete=False) as f:
        f.write(data)
        tmp = f.name
    try:
        audio, sr = decode_audio_file(tmp, target_sr=target_sr or 16000)
    finally:
        import os

        try:
            os.remove(tmp)
        except OSError:
            pass
    arr = np.asarray(audio)
    if arr.dtype != np.int16:
        arr = (arr.astype(np.float32) * 32767.0).astype(np.int16)
    return arr.astype(np.int16), int(sr or target_sr or 16000)


class Player:
    """Очередь озвучки в отдельном потоке."""

    def __init__(self, volume: float = 1.0,
                 on_speech_start: Optional[Callable[[], None]] = None,
                 on_speech_end: Optional[Callable[[], None]] = None) -> None:
        self.volume = float(volume)
        self.on_speech_start = on_speech_start
        self.on_speech_end = on_speech_end
        self._queue: list[tuple[np.ndarray, int]] = []
        self._lock = threading.Lock()
        self._cv = threading.Condition(self._lock)
        self._thread: Optional[threading.Thread] = None
        self._stop = False
        self.speaking = False
        self.played_items = 0
        self._current_stream = None
        self._interrupted = False

    # ------------------------------------------------------------------ public
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop = False
        self._thread = threading.Thread(target=self._worker, name="flux-player",
                                        daemon=True)
        self._thread.start()

    def stop(self, drain: bool = False) -> None:
        if not drain:
            with self._cv:
                self._queue.clear()
        self._stop = True
        with self._cv:
            self._cv.notify_all()
        self.interrupt()

    def interrupt(self) -> None:
        """Немедленно оборвать текущую речь (для barge-in / отмены).

        БАГ: флаг сбрасывал только очередь и дёргал stream.stop() из чужого
        потока, но цикл записи проверял лишь self._stop (он ставится только
        при выходе). Из-за этого Esc и barge-in обрывали речь с задержкой
        до целого файла, а stop() из соседнего потока мог подвиснуть.
        """
        with self._cv:
            self._queue.clear()
        self._interrupted = True
        stream = self._current_stream
        if stream is not None:
            try:
                stream.abort()          # abort, а не stop: не ждёт хвост буфера
            except Exception:
                try:
                    stream.stop()
                except Exception:
                    pass

    def enqueue_file(self, path: str, target_sr: int = 24000) -> None:
        data, sr = decode_audio_file(path, target_sr=target_sr)
        if data.size:
            self.enqueue_pcm(data, sr)

    def enqueue_pcm(self, data: np.ndarray, sr: int) -> None:
        with self._cv:
            self._queue.append((np.asarray(data, dtype=np.float32), int(sr)))
            self._cv.notify_all()

    def queue_size(self) -> int:
        with self._lock:
            return len(self._queue)

    def wait_idle(self, timeout: float | None = None) -> bool:
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            with self._lock:
                if not self._queue and not self.speaking:
                    return True
            if deadline is not None and time.monotonic() > deadline:
                return False
            time.sleep(0.02)

    # ------------------------------------------------------------------ worker
    def _worker(self) -> None:
        while not self._stop:
            with self._cv:
                while not self._queue and not self._stop:
                    self._cv.wait(0.1)
                if self._stop:
                    break
                data, sr = self._queue.pop(0)
            self._play_pcm(data, sr)
        self.speaking = False

    def _play_pcm(self, data: np.ndarray, sr: int) -> None:
        if sd is None or data.size == 0:  # pragma: no cover
            return
        self.speaking = True
        self._interrupted = False
        if self.on_speech_start:
            try:
                self.on_speech_start()
            except Exception:
                pass
        chunk = max(256, int(sr * CHUNK_SECONDS))
        try:
            stream = sd.OutputStream(samplerate=sr, channels=1, dtype="float32",
                                     blocksize=chunk)
            self._current_stream = stream
            with stream:
                for i in range(0, data.size, chunk):
                    if self._interrupted or (self._stop and not self._queue):
                        break
                    piece = data[i:i + chunk] * self.volume
                    if piece.size < chunk:
                        piece = np.pad(piece, (0, chunk - piece.size))
                    stream.write(piece.reshape(-1, 1))
        except Exception:
            pass
        finally:
            self._current_stream = None
            self.speaking = False
            self.played_items += 1
            if self.on_speech_end:
                try:
                    self.on_speech_end()
                except Exception:
                    pass
