"""Устройства ввода: ТОЛЬКО микрофоны. Никакого захвата звука из динамиков.

Требование ТЗ: «ВВОД ДОЛЖЕН БЫТЬ ИМЕННО С МИКРО, А НЕ СО ЗВУКА ВЕЗДЕ».
Поэтому:
  * перечисляются только устройства с max_input_channels > 0;
  * петлевые/виртуальные «захват из динамиков» (Stereo Mix, Loopback,
    What U Hear, Voicemeeter Output...) отсеиваются и помечаются;
  * выбор устройства явно проверяется: попытка выбрать выходное или
    петлевое устройство отклоняется с понятной ошибкой.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

import numpy as np

LOOPBACK_PATTERNS = (
    "loopback", "stereo mix", "стерео микшер", "стереомикшер", "what u hear",
    "what you hear", "wave out mix", "waveout mix", "mono mix", "mixed output",
    "virtual audio cable output", "voicemeeter output", "voicemeeter aux",
    "ndi audio", "cable output", "системные звуки", "system sounds",
    "primary sound capture driver", "sum of all",
)


@dataclass
class DeviceInfo:
    index: int
    name: str
    channels: int
    host_api: str = ""
    default_samplerate: int = 0
    is_default_input: bool = False
    is_loopback: bool = False
    extra: dict = field(default_factory=dict)

    @property
    def label(self) -> str:
        tag = " [ПЕТЛЯ!]" if self.is_loopback else ""
        star = " *" if self.is_default_input else ""
        return f"{self.name} ({self.channels}ch, {self.host_api}){star}{tag}"


def is_loopback_name(name: str) -> bool:
    low = (name or "").lower()
    return any(p in low for p in LOOPBACK_PATTERNS)


# ---------------------------------------------------------------------------
# «14 микрофонов» на самом деле НЕ 14 физических микрофонов.
#
# PortAudio (sounddevice) перечисляет устройства ПО КАЖДОМУ звуковому API
# Windows отдельно: один и тот же микрофон попадает в список как
#   MME, DirectSound, Windows WASAPI (+ иногда Windows WDM-KS)
# то есть физический микрофон даёт 3-4 записи. Плюс Windows создаёт
# виртуальные записывающие устройства: Bluetooth-гарнитура в профиле
# Hands-Free, «Стерео микшер», микрофоны веб-камеры/монитора, устройства
# Discord/OBS/NVIDIA Broadcast/Virtual Audio Cable.
# Ниже - схлопывание одноимённых записей и человекочитаемая инвентаризация,
# чтобы в самотесте было видно, ЧТО именно за 14 (или сколько их) устройств.
HOST_API_PREFERENCE = ("wasapi", "directsound", "mme", "wdm", "asio")


def sort_key(d: "DeviceInfo") -> tuple:
    """Петлевые - в конец, затем устройство по умолчанию, затем имя."""
    return (d.is_loopback, not d.is_default_input, d.name.lower())


def _api_rank(host_api: str) -> int:
    low = (host_api or "").lower()
    for i, name in enumerate(HOST_API_PREFERENCE):
        if name in low:
            return i
    return len(HOST_API_PREFERENCE)


def dedupe_devices(devs: list["DeviceInfo"]) -> list["DeviceInfo"]:
    """Одно физическое устройство = одна запись.

    Один и тот же микрофон перечислен по несколько раз (MME / DirectSound /
    WASAPI / WDM-KS). Оставляем лучшую запись: устройство по умолчанию,
    затем наиболее современный API, затем меньший индекс PortAudio.
    """
    best: dict[tuple, DeviceInfo] = {}
    for d in devs:
        k = (" ".join((d.name or "").lower().split()), d.is_loopback)
        cur = best.get(k)
        if cur is None:
            best[k] = d
            continue
        new_rank = (not d.is_default_input, _api_rank(d.host_api), d.index)
        old_rank = (not cur.is_default_input, _api_rank(cur.host_api), cur.index)
        if new_rank < old_rank:
            best[k] = d
    return sorted(best.values(), key=sort_key)


def inventory(devs: list["DeviceInfo"]) -> str:
    """Инвентаризация устройств записи для лога/самотеста.

    Одноимённые записи разных API группируются в одну строку:
      [12] * Mic (MCHOSE V9 PRO) -> 1ch: MME(1), DirectSound(5), WASAPI(12)
    """
    groups: dict[tuple, list[DeviceInfo]] = {}
    order: list[tuple] = []
    for d in sorted(devs, key=sort_key):
        k = (" ".join((d.name or "").lower().split()), d.is_loopback)
        if k not in groups:
            groups[k] = []
            order.append(k)
        groups[k].append(d)
    lines = []
    for k in order:
        g = groups[k]
        head = g[0]
        star = "*" if any(x.is_default_input for x in g) else " "
        loop = " [ПЕТЛЯ]" if head.is_loopback else ""
        idx = ", ".join(f"{x.host_api or 'api'}({x.index})" for x in g)
        lines.append(f"  [{head.index:>2}] {star} {head.name} -> "
                     f"{head.channels}ch: {idx}{loop}")
    return "\n".join(lines)


def _load_sounddevice():
    try:
        import sounddevice as sd  # type: ignore
        return sd
    except Exception as e:  # pragma: no cover - зависит от системы
        raise RuntimeError(
            "Не удалось загрузить sounddevice (PortAudio). "
            "Переустановите зависимости: pip install sounddevice"
        ) from e


def configured_spec() -> Any:
    """Что открывать как микрофон: сначала ИМЯ, затем устаревший индекс.

    Индекс PortAudio НЕ стабилен: воткнул/выключил Bluetooth-гарнитуру,
    сменился API-слой — и сохранённый номер указывает на другое устройство
    или в пустоту (PaErrorCode -9996 «Invalid device»). Имя устройства
    переживает перезапуски, поэтому config audio.input_device_name главнее
    старого audio.input_device.
    """
    try:
        from .. import config as _cfg
    except Exception:  # pragma: no cover - devices могут импортировать рано
        return None
    name = str(_cfg.get("audio.input_device_name", "") or "").strip()
    if name:
        return name
    return _cfg.get("audio.input_device", None)


def attempt_specs(device_spec: Any = None) -> list:
    """Цепочка попыток открытия микрофона: запрошенный -> из конфига -> умолчание.

    Дедупликация по сути (имя/индекс/«по умолчанию»), чтобы не открывать одно
    и то же устройство дважды.
    """
    specs: list = [device_spec]
    try:
        specs.append(configured_spec())
    except Exception:  # pragma: no cover
        pass
    specs.append(None)
    out: list = []
    seen: set = set()
    for s in specs:
        if isinstance(s, str):
            key = ("name", " ".join(s.lower().split()))
        elif isinstance(s, int):
            key = ("index", s)
        else:
            key = ("default",)
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out


def build_device_list(rows, hostapis, default_in: int = -1) -> list[DeviceInfo]:
    """Чистая сборка DeviceInfo из сырых записей PortAudio (тестируемо)."""
    out: list[DeviceInfo] = []
    for i, d in enumerate(rows):
        ch = int(d.get("max_input_channels", 0) or 0)
        if ch <= 0:
            continue  # устройство воспроизведения - не трогаем ВООБЩЕ
        api_idx = int(d.get("hostapi", 0) or 0)
        host = ""
        if 0 <= api_idx < len(hostapis):
            host = str(hostapis[api_idx].get("name", ""))
        name = str(d.get("name", f"device {i}"))
        out.append(DeviceInfo(
            index=i, name=name, channels=ch, host_api=host,
            default_samplerate=int(d.get("default_samplerate", 0) or 0),
            is_default_input=(i == default_in),
            is_loopback=is_loopback_name(name),
        ))
    return out


def _collapse_enabled() -> bool:
    try:
        from .. import config as _cfg  # лениво: devices может импортироваться рано
        return bool(_cfg.get("audio.collapse_duplicates", True))
    except Exception:  # pragma: no cover
        return True


def list_input_devices(include_loopback: bool = False) -> list[DeviceInfo]:
    """Все устройства ЗАПИСИ (микрофоны), петлевые помечены/отсеяны.

    Одно физическое устройство отдаётся ОДНОЙ записей: PortAudio перечисляет
    каждый микрофон по каждому API (MME/DirectSound/WASAPI/WDM-KS), из-за чего
    в Windows «14 микрофонов» при одном реальном. Дубли схлопываются, остаётся
    лучшая запись (по умолчанию -> WASAPI -> DirectSound -> MME).
    """
    sd = _load_sounddevice()
    try:
        # sd.default - кортеж (input_index, output_index), а не объект
        default_in = int(sd.default[0])
    except Exception:
        default_in = -1
    try:
        hostapis = list(sd.query_hostapis())
    except Exception:  # pragma: no cover
        hostapis = []
    out = build_device_list(list(sd.query_devices()), hostapis, default_in)
    if not include_loopback:
        out = [d for d in out if not d.is_loopback]
    out.sort(key=sort_key)
    if _collapse_enabled():
        # дубли разных API помним как alias-индексы: по любому из них
        # resolve_input_device() найдёт устройство
        aliases: dict[tuple, list[int]] = {}
        for d in out:
            aliases.setdefault((" ".join(d.name.lower().split()), d.is_loopback),
                               []).append(d.index)
        collapsed = dedupe_devices(out)
        for d in collapsed:
            k = (" ".join(d.name.lower().split()), d.is_loopback)
            d.extra["alias_indices"] = [i for i in aliases.get(k, []) if i != d.index]
        out = collapsed
    return out


def list_output_names() -> list[str]:
    """Имена устройств воспроизведения (для справки в настройках)."""
    sd = _load_sounddevice()
    return [str(d.get("name")) for d in sd.query_devices()
            if int(d.get("max_output_channels", 0) or 0) > 0]


def _by_index(devs: list[DeviceInfo], idx: int) -> DeviceInfo | None:
    """Поиск по индексу PortAudio, включая «схлопнутые» дубли API."""
    for d in devs:
        if d.index == idx:
            return d
    for d in devs:
        if idx in (d.extra.get("alias_indices") or []):
            return d
    return None


def resolve_input_device(spec: Any = None, include_loopback: bool = False) -> DeviceInfo | None:
    """Находит микрофон по индексу, имени (подстрока) или None = по умолчанию."""
    devs = list_input_devices(include_loopback=include_loopback)
    if not devs:
        return None
    if spec is None or spec == "":
        for d in devs:
            if d.is_default_input:
                return d
        return devs[0]
    if isinstance(spec, int):
        return _by_index(devs, spec)
    needle = str(spec).strip().lower()
    if needle.isdigit():
        found = _by_index(devs, int(needle))
        if found is not None:
            return found
    for d in devs:
        if needle and needle in d.name.lower():
            return d
    return None


def assert_is_microphone(dev: DeviceInfo) -> None:
    if dev.is_loopback:
        raise ValueError(
            f"Устройство {dev.name!r} похоже на петлю захвата звука из динамиков. "
            "FLUX слушает ТОЛЬКО микрофон - выберите микрофон в настройках.")


def describe(devs: Iterable[DeviceInfo]) -> str:
    lines = [f"  [{d.index}] {d.label}" for d in devs]
    return "\n".join(lines) if lines else "  (микрофоны не найдены)"


def buffer_to_int16(indata) -> "np.ndarray":
    """Копия кадра из sounddevice.RawInputStream.

    RawInputStream отдаёт cffi-буфер (без .copy()), поэтому копируем строго
    через np.frombuffer - иначе AttributeError в колбэке и «нет данных».
    """
    return np.frombuffer(indata, dtype=np.int16).copy()


def _probe_peak(sd, dev: "DeviceInfo", seconds: float = 0.4,
                sample_rate: int = 16000) -> float:
    """Короткий ПРОБНЫЙ замер пика устройства (0 = молчит, -1 = не открылось).

    Это ИЗМЕРЕНИЕ, а не обработка звука: отсчёты только читаются и сразу
    выбрасываются, в тракт распознавания они не попадают. Нужно, чтобы
    цепочка фолбэка не хватала первый открывшийся микрофон (им нередко
    оказывается молчаливый «Microsoft Sound Mapper - Input»), а выбирала
    устройство, которое реально даёт сигнал.
    """
    chunks: list[np.ndarray] = []

    def cb(indata, frames, t, status):
        try:
            chunks.append(buffer_to_int16(indata))
        except Exception:
            pass

    try:
        with sd.RawInputStream(device=dev.index, channels=1, dtype="int16",
                               samplerate=sample_rate,
                               blocksize=int(sample_rate * 0.05), callback=cb):
            import time as _t
            _t.sleep(seconds)
    except Exception:
        return -1.0
    if not chunks:
        return 0.0
    data = np.concatenate(chunks).astype(np.float32) / 32768.0
    return float(np.max(np.abs(data)))


def rank_by_signal(devs: list["DeviceInfo"], probe_sec: float = 0.4,
                   threshold: float = 0.002) -> list["DeviceInfo"]:
    """Упорядочить кандидатов по живости: сначала дающие сигнал (по убыванию
    пика), затем молчаливые/неоткрываемые в исходном порядке.

    Порог 0.002 (-54 dBFS) — тот же, что в stt/whisper_check.py: ниже него
    сигнала нет. Порядок внутри «живых» — по убыванию пика.
    """
    try:
        sd = _load_sounddevice()
    except Exception:  # pragma: no cover - нет PortAudio вовсе
        return list(devs)
    probed: list[tuple[float, int, "DeviceInfo"]] = []
    for i, d in enumerate(devs):
        probed.append((_probe_peak(sd, d, probe_sec), i, d))
    live = sorted([p for p in probed if p[0] >= threshold],
                  key=lambda t: (-t[0], t[1]))
    dead = [p for p in probed if p[0] < threshold]
    return [d for _, _, d in live] + [d for _, _, d in dead]


def _candidate_devices(device_spec: Any = None) -> list["DeviceInfo"]:
    """Устройства для попытки записи, по приоритету: запрошенное -> настройка
    (имя главнее индекса) -> по умолчанию -> остальные микрофоны по списку.

    Список устройств PortAudio живёт своей жизнью: индексы смещаются при
    подключении гарнитур/вебкамер, поэтому «запрошенное» устройство может
    оказаться дыркой (-9996). Цепочка гарантирует: если в системе есть ХОТЬ
    ОДИН живой микрофон — запись состоится, а в отчёте будет видно, каким
    именно и вместо какого запрошенного.
    """
    out: list[DeviceInfo] = []
    seen: set[int] = set()
    for spec in attempt_specs(device_spec):
        d = resolve_input_device(spec)
        if d is not None and d.index not in seen:
            seen.add(d.index)
            out.append(d)
    try:
        for d in list_input_devices():
            if d.index not in seen:
                seen.add(d.index)
                out.append(d)
    except Exception:  # pragma: no cover - перечисление умерло целиком
        pass
    return out


def _requested_name(device_spec: Any) -> str:
    try:
        d = resolve_input_device(device_spec)
        return d.name if d is not None else ""
    except Exception:  # pragma: no cover
        return ""


def record_seconds(seconds: float = 4.0,
                   sample_rate: int = 16000,
                   device_spec: Any = None) -> tuple["np.ndarray", dict]:
    """Пишет N секунд с микрофона. Возвращает (int16 mono, инфо об устройстве).

    device_spec: индекс/имя микрофона или None = устройство по умолчанию.

    Устойчивость (баг -9996): сохранённый индекс мог устареть (список
    устройств PortAudio сместился) — тогда RawInputStream бросает
    PaError «Invalid device». Вместо падения идём по цепочке
    attempt_specs(): запрошенное устройство -> настройка из конфига
    (имя главнее индекса) -> устройство по умолчанию. В info попадает
    fallback_from, чтобы в отчёте было видно, чем писали на самом деле.
    """
    import time

    from .. import logger as _lg
    log = _lg.get_logger("flux.audio.devices")

    sd = _load_sounddevice()
    wanted = _requested_name(device_spec)
    last_error = "микрофон не найден"
    order = _candidate_devices(device_spec)
    ranked = False
    i = 0
    while i < len(order):
        dev = order[i]
        chunks: list[np.ndarray] = []

        def cb(indata, frames, t, status):
            try:
                chunks.append(buffer_to_int16(indata))
            except Exception:
                pass

        try:
            with sd.RawInputStream(device=dev.index, channels=1, dtype="int16",
                                   samplerate=sample_rate,
                                   blocksize=int(sample_rate * 0.05), callback=cb):
                time.sleep(seconds)
        except Exception as e:
            last_error = f"{dev.name}: {e.__class__.__name__}: {e}"
            log.warning("микрофон %s не открылся (%s) — пробую следующий "
                        "по цепочке", dev.name, e)
            if i == 0 and len(order) > 1:
                # Запрошенное/настроечное устройство недоступно. Дальше по
                # цепочке шёл «первый открывшийся» — им оказывался молчаливый
                # «Microsoft Sound Mapper - Input», и whisper галлюцинировал
                # на тишине. Теперь остальные кандидаты ранжируются ПРОБНЫМ
                # замером сигнала: живой микрофон важнее порядка в списке.
                order = rank_by_signal(order[1:])
                ranked = True
                i = 0
                continue
            i += 1
            continue
        if not chunks:
            return np.zeros(0, dtype=np.int16), {
                "ok": False, "error": "нет данных с микрофона",
                "device": dev.name, "index": dev.index}
        info = {"ok": True, "device": dev.name, "index": dev.index}
        if ranked:
            info["signal_ranked"] = True
        if wanted and wanted != dev.name:
            info["fallback_from"] = wanted
            log.info("пишу микрофоном %s вместо %s (запрошенное устройство "
                     "недоступно)%s", dev.name, wanted,
                     ", выбран по пробному замеру сигнала" if ranked else "")
        return np.concatenate(chunks), info
    return np.zeros(0, dtype=np.int16), {"ok": False, "error": last_error}


def mic_self_test(seconds: float = 1.2) -> dict:
    """Короткая запись: проверяет, что микрофон реально даёт сигнал.

    Возвращает dict с rms/peak и verdict. Не используется в боевом цикле.
    """
    import time

    import numpy as np

    sd = _load_sounddevice()
    dev = None
    chunks: list[np.ndarray] = []
    last_error = "микрофон не найден"

    def cb(indata, frames, t, status):
        # RawInputStream отдаёт cffi-буфер, а не numpy; любой сбой внутри
        # колбэка не должен ронять поток и показывать попапы
        try:
            chunks.append(buffer_to_int16(indata))
        except Exception:
            pass

    # та же цепочка устойчивости, что и в record_seconds: настроечный
    # микрофон мог «съехать» по индексу (-9996) — тогда пишем следующим
    # живым микрофоном из списка; а если настроечный недоступен, остальные
    # ранжируются пробным замером сигнала (молчаливый Sound Mapper не берём)
    order = _candidate_devices(configured_spec())
    ranked = False
    dev = None
    i = 0
    while i < len(order):
        cand = order[i]
        chunks.clear()
        try:
            with sd.RawInputStream(device=cand.index, channels=1, dtype="int16",
                                   samplerate=16000, blocksize=int(16000 * 0.05),
                                   callback=cb):
                time.sleep(seconds)
        except Exception as e:
            last_error = f"{cand.name}: {e.__class__.__name__}: {e}"
            if i == 0 and len(order) > 1:
                order = rank_by_signal(order[1:])
                ranked = True
                i = 0
                continue
            i += 1
            continue
        dev = cand
        break
    if dev is None:
        return {"ok": False, "error": last_error}
    if not chunks:
        return {"ok": False, "error": "нет данных с микрофона", "device": dev.name}
    from . import meter
    data = np.concatenate(chunks).astype(np.float32) / 32768.0
    rms = float(np.sqrt(np.mean(np.square(data))))
    peak = float(np.max(np.abs(data)))
    silent = peak < meter.SILENCE_PEAK
    out = {
        "ok": True, "device": dev.name, "index": dev.index,
        "rms": round(rms, 5), "peak": round(peak, 5),
        "peak_dbfs": meter.dbfs(peak), "rms_dbfs": meter.dbfs(rms),
        "silent": silent,
        # тишина НЕ означает поломку: поток открылся и пишет отсчёты -
        # устройство работает, просто никто не говорил
        "verdict": ("микрофон работает (сейчас тишина - скажи что-нибудь "
                    "для проверки уровня)" if silent else
                    f"микрофон работает, уровень {peak:.3f} "
                    f"({meter.dbfs(peak)} dBFS)"),
    }
    if ranked:
        out["signal_ranked"] = True
    return out
