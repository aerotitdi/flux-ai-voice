"""Детектор речи (VAD) по кадрам PCM 16 кГц mono int16.

Два движка:
  * webrtcvad  - качественный, если установлен (опциональная зависимость);
  * energy     - адаптивный порог по RMS + шумовой пол (работает везде).

Режим "auto" использует webrtcvad, если он доступен, и всегда добавляет
энергетический гейт, чтобы вентилятор/клавиатура не считались речью.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

try:  # numpy есть в зависимостях, но импорт защищаем для тестов
    import numpy as np
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    import webrtcvad
except Exception:  # pragma: no cover - опциональная зависимость
    webrtcvad = None  # type: ignore

FRAME_MS_ALLOWED = (10, 20, 30)


@dataclass
class VadConfig:
    engine: str = "auto"          # auto|webrtcvad|energy
    aggressiveness: int = 2       # 0..3 (webrtcvad)
    sample_rate: int = 16000
    energy_threshold: float = 0.012
    noise_floor_auto: bool = True
    noise_floor_mult: float = 3.0
    speech_pad_ms: int = 200
    frame_ms: int = 30


def to_int16_bytes(samples) -> bytes:
    """numpy int16 / float / bytes -> bytes int16."""
    if isinstance(samples, bytes):
        return samples
    if np is None:  # pragma: no cover
        return bytes(samples)
    arr = np.asarray(samples)
    if arr.dtype == np.int16:
        return arr.tobytes()
    if arr.dtype in (np.float32, np.float64):
        return np.clip(arr * 32767.0, -32768, 32767).astype(np.int16).tobytes()
    return arr.astype(np.int16).tobytes()


def to_float_array(samples):
    """Любой вход (bytes int16 / numpy int16 / numpy float) -> float32 -1..1."""
    if np is None:  # pragma: no cover
        return samples
    if isinstance(samples, (bytes, bytearray, memoryview)):
        raw = bytes(samples)
        if len(raw) % 2:
            raw = raw[:-1]
        return np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    arr = np.asarray(samples)
    if arr.dtype in (np.float32, np.float64):
        return arr.astype(np.float32)
    if arr.dtype == np.int16:
        return arr.astype(np.float32) / 32768.0
    if arr.dtype == np.uint8:      # редкий случай 8-bit PCM
        return (arr.astype(np.float32) - 128.0) / 128.0
    return arr.astype(np.float32) / 32768.0


def rms_float(samples) -> float:
    """RMS в диапазоне 0..1 для PCM (int16, float или bytes)."""
    arr = to_float_array(samples)
    if np is None or arr is None or getattr(arr, "size", 0) == 0:  # pragma: no cover
        return 0.0
    return float(math.sqrt(float(np.mean(np.square(arr.astype(np.float64))))))


def rms_from_dbfs(db: float) -> float:
    """rms для порога в дБ (FS): -50 дБ -> ~0.00316."""
    return 10.0 ** (float(db) / 20.0)


def dbfs(rms: float) -> float:
    if rms <= 0:
        return -120.0
    return 20.0 * math.log10(rms)


class VAD:
    """Определяет, есть ли в кадре речь."""

    def __init__(self, cfg: VadConfig | None = None, **kw) -> None:
        self.cfg = cfg or VadConfig(**kw)
        self._web = None
        self.noise_floor = self.cfg.energy_threshold
        self._frames_seen = 0
        if self.cfg.engine in ("auto", "webrtcvad") and webrtcvad is not None:
            try:
                self._web = webrtcvad.Vad(min(3, max(0, self.cfg.aggressiveness)))
            except Exception:  # pragma: no cover
                self._web = None
        self.engine = "webrtcvad" if self._web is not None else "energy"

    # ------------------------------------------------------------------ public
    @property
    def available_engines(self) -> list[str]:
        out = ["energy"]
        if webrtcvad is not None:
            out.insert(0, "webrtcvad")
        return out

    def is_speech(self, samples, frame_ms: int | None = None) -> bool:
        frame_ms = frame_ms or self.cfg.frame_ms
        data = to_int16_bytes(samples)
        rms = rms_float(data)
        self._update_noise_floor(rms)

        gate_ok = rms >= max(self.cfg.energy_threshold,
                             self.noise_floor * self.cfg.noise_floor_mult
                             if self.cfg.noise_floor_auto else 0.0)
        if self._web is None:
            return bool(gate_ok and rms >= self.cfg.energy_threshold * 0.6)

        # webrtcvad требует кадр 10/20/30 мс
        sr = self.cfg.sample_rate
        need = int(sr * frame_ms / 1000) * 2
        if len(data) != need:
            # подрезаем/добиваем нулями до нужной длины
            data = data[:need] if len(data) > need else data + b"\x00" * (need - len(data))
        try:
            web_ok = bool(self._web.is_speech(data, sr))
        except Exception:
            web_ok = False
        self._frames_seen += 1
        return bool(web_ok and gate_ok)

    def _update_noise_floor(self, rms: float) -> None:
        if not self.cfg.noise_floor_auto:
            return
        # медленная адаптация к фону, быстрая - вниз при тишине
        alpha = 0.02 if rms > self.noise_floor else 0.005
        self.noise_floor = (1 - alpha) * self.noise_floor + alpha * rms

    def reset(self) -> None:
        self.noise_floor = self.cfg.energy_threshold
        self._frames_seen = 0
