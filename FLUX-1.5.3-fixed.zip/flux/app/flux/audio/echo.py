"""Анти-эхо и защита от ложных активаций.

Три слоя (все тестируемые как чистые функции):
  1. временное окно: сегменты, пойманные ВО ВРЕМЯ озвучки или сразу после неё
     (хвост из динамиков/комнатное эхо), отбрасываются;
  2. текстовый: распознанный текст, похожий на то, что Флюкс сам только что
     сказал, - это он слышит себя, отбрасываем;
  3. состояние: «Слушаю» (AWAKE) не может жить вечно - шумной сегмент возвращает
     в IDLE, чтобы любой звук не уходил модели как команда.
"""
from __future__ import annotations

from difflib import SequenceMatcher

DEFAULT_TAIL_GUARD_SEC = 0.9


def in_speech_window(speaking: bool, seconds_since_tts_end: float,
                     tail_guard_sec: float = DEFAULT_TAIL_GUARD_SEC) -> bool:
    """True, если сегмент пойман во время озвучки или в хвостовом окне."""
    if speaking:
        return True
    return seconds_since_tts_end < tail_guard_sec


def text_similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.strip().lower(), b.strip().lower()).ratio()


def _norm(s: str) -> str:
    return " ".join((s or "").lower().split())


def looks_like_echo(text: str, last_spoken: str,
                    threshold: float = 0.55) -> bool:
    """Распознанный текст совпадает с собственной речью ассистента?"""
    if not text or not last_spoken:
        return False
    nt, nl = _norm(text), _norm(last_spoken)
    # хвост собственной речи часто попадает в сегмент целиком:
    # «Открыть их?» является концом «…стола. Открыть их?»
    if nt and (nt in nl or nl in nt):
        return True
    if text_similarity(nt, nl) >= threshold:
        return True
    tail = " ".join(nl.split()[-6:])
    return bool(tail) and text_similarity(nt, tail) >= threshold


def should_accept_wake_segment(speech_seconds: float, min_speech_sec: float,
                               last_activation_ago: float,
                               min_activation_interval: float) -> tuple[bool, str]:
    """Принимаем ли сегмент как кандидат на слово-активацию."""
    if speech_seconds < min_speech_sec:
        return False, f"речь короче {min_speech_sec} c"
    if last_activation_ago < min_activation_interval:
        return False, "слишком частые активации"
    return True, ""
