"""Поток захвата с микрофона (16 кГц mono int16) БЕЗ какой-либо обработки.

Правило пользователя (2026-10-08): «до whisper должен доходить чистый,
нетронутый звук». Никакого AGC, шумодава, гейтов и нормализации на пути
микрофон -> whisper: кадры int16 кладутся в кольцо и отдаются дальше
байт-в-байт. Так же делает Buzz (github.com/chidiwilliams/buzz): сырой
запись -> faster-whisper, а «извлечение речи» (VAD) живёт ВНУТРИ whisper,
а не в микрофоне. Тяжёлая нейронная обработка до whisper только ухудшает
распознавание (arXiv 2603.04710), а громкость whisper не нужна — он
работает с log-mel спектрограммами.

Единственное управление потоком (не изменение звука!): анти-эхо пауза —
пока FLUX сам говорит (TTS), кадры не отдаются наверх, чтобы ассистент
не слушал собственный голос. Обходной режим (barge_in) — в настройках.
"""
from __future__ import annotations

import threading
import time
from collections import deque
from typing import Callable, Optional

import numpy as np

from .vad import rms_float

FrameCallback = Callable[[np.ndarray, float], None]


class MicCapture:
    """Непрерывный захват с выбранного микрофона: сырые кадры, без обработки."""

    def __init__(self, device_index: Optional[int], sample_rate: int = 16000,
                 block_ms: int = 30, on_frame: Optional[FrameCallback] = None,
                 name: str = "") -> None:
        self.device_index = device_index
        self.sample_rate = int(sample_rate)
        self.block_ms = int(block_ms)
        self.on_frame = on_frame
        self.name = name
        self._stream = None
        self._thread_lock = threading.Lock()
        self.paused = False
        self.running = False
        self.last_rms = 0.0
        self.level = 0.0            # сглаженный СЫРОЙ уровень для индикатора в UI
        self.frames = 0
        self.started_at = 0.0
        self.ring: deque = deque()          # (ts, frame int16) за ~70 секунд
        self._ring_span = 70.0

    # ------------------------------------------------------------------ stream
    def start(self) -> None:
        import sounddevice as sd  # type: ignore

        with self._thread_lock:
            if self.running:
                return
            block = max(64, int(self.sample_rate * self.block_ms / 1000))
            kwargs = {"samplerate": self.sample_rate, "channels": 1,
                      "dtype": "int16", "blocksize": block,
                      "callback": self._callback}
            if self.device_index is not None:
                kwargs["device"] = self.device_index
            try:
                self._stream = sd.RawInputStream(**kwargs)
            except Exception as e:
                # сохранённый индекс микрофона мог устареть (PaErrorCode
                # -9996 «Invalid device»): боевой цикл НЕ должен глохнуть —
                # переходим на устройство по умолчанию и честно пишем в лог
                if self.device_index is None:
                    raise
                from .. import logger as _lg
                _lg.get_logger("flux.audio.capture").warning(
                    "микрофон %s не открылся (%s) — захват переходит на "
                    "устройство по умолчанию", self.name or self.device_index, e)
                self.device_index = None
                self.name = (self.name or "") + " (недоступен, взято по умолчанию)"
                kwargs.pop("device", None)
                self._stream = sd.RawInputStream(**kwargs)
            self._stream.start()
            self.running = True
            self.started_at = time.monotonic()

    def stop(self) -> None:
        with self._thread_lock:
            if self._stream is not None:
                try:
                    self._stream.stop()
                    self._stream.close()
                except Exception:
                    pass
                self._stream = None
            self.running = False

    def get_window(self, seconds: float) -> np.ndarray:
        """Последние N секунд СЫРОГО звука (без порогов) - прямиком в whisper."""
        now = time.monotonic()
        frames = [f for ts, f in list(self.ring) if ts >= now - seconds]
        if not frames:
            return np.zeros(0, dtype=np.int16)
        return np.concatenate(frames)

    def get_window_since(self, since: float) -> np.ndarray:
        frames = [f for ts, f in list(self.ring) if ts >= since]
        if not frames:
            return np.zeros(0, dtype=np.int16)
        return np.concatenate(frames)

    def clear_ring(self) -> None:
        self.ring.clear()

    def pause(self) -> None:
        self.paused = True

    def resume(self) -> None:
        self.paused = False

    # ---------------------------------------------------------------- callback
    def _callback(self, indata, frames, t, status) -> None:
        # БАЙТ-В-БАЙТ: что дал микрофон, то и уходит в кольцо и в whisper.
        data = np.frombuffer(indata, dtype=np.int16).reshape(-1)
        rms = rms_float(data)
        self.last_rms = rms
        self.level = 0.8 * self.level + 0.2 * rms
        self.frames += 1
        ts = time.monotonic()
        self.ring.append((ts, data))
        while self.ring and ts - self.ring[0][0] > self._ring_span:
            self.ring.popleft()
        if self.paused:
            return                      # анти-эхо: не слушаем себя
        if self.on_frame is not None:
            try:
                self.on_frame(data.copy(), rms)
            except Exception:
                pass

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()
        return False


class WavCapture:
    """Захват из WAV-файла/массива - для самотеста и unit-тестов."""

    def __init__(self, audio: np.ndarray, sample_rate: int = 16000,
                 frame_ms: int = 30, on_frame: Optional[FrameCallback] = None,
                 realtime: bool = False) -> None:
        self.audio = np.asarray(audio, dtype=np.int16)
        self.sample_rate = sample_rate
        self.frame_ms = frame_ms
        self.on_frame = on_frame
        self.realtime = realtime
        self.paused = False
        self.running = False
        self.level = 0.0
        self.last_rms = 0.0
        self.ring: deque = deque()
        self._ring_span = 70.0
        self._t0 = time.monotonic()

    def start(self) -> None:
        self.running = True
        self._t0 = time.monotonic()

    def run(self) -> None:
        """Прогнать файл кадрами (как живой микрофон); сырые кадры, без обработки."""
        step = max(1, int(self.sample_rate * self.frame_ms / 1000))
        for i in range(0, len(self.audio), step):
            if not self.running:
                break
            frame = self.audio[i:i + step]
            ts = self._t0 + i / float(self.sample_rate)
            self.ring.append((ts, frame))
            rms = rms_float(frame)
            self.last_rms = rms
            self.level = rms
            if self.paused:
                continue
            if self.on_frame is not None:
                try:
                    self.on_frame(frame.copy(), rms)
                except Exception:
                    pass
                if self.realtime:
                    time.sleep(self.frame_ms / 1000.0)

    def stop(self) -> None:
        self.running = False

    def get_window(self, seconds: float) -> np.ndarray:
        if not len(self.audio):
            return np.zeros(0, dtype=np.int16)
        n = int(seconds * self.sample_rate)
        return self.audio[max(0, len(self.audio) - n):]

    def get_window_since(self, since: float) -> np.ndarray:
        return self.audio

    def clear_ring(self) -> None:
        self.ring.clear()

    def pause(self) -> None:
        self.paused = True

    def resume(self) -> None:
        self.paused = False
