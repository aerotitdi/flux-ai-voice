"""Измеритель громкости микрофона в дБ (просил пользователь: «штука теста
громкости микро по дб для тестов»).

Считаем ТОЛЬКО цифры по сырым отсчётам — звук при этом никак НЕ изменяется
(ни усиления, ни шумодава): измерение не входит в тракт распознавания.

Шкала dBFS (decibels relative to full scale): 0 dBFS = максимум тракта
int16, всё остальное отрицательно. Ориентиры живой записи:

  -74 dBFS  тишина / микрофон отключён (как в логове пользователя: пик 0.00018)
  -54 dBFS  порог «микрофон молчит» (SILENCE_PEAK)
  -40 dBFS  тихий шёпот в метре
  -30 dBFS  обычная речь в метре от микрофона
  -18 dBFS  громкая речь вплотную
   -6 dBFS  почти клиппинг

Вердикты подобраны по этим ориентирам и проверяются тестами на синусоиде
заданной амплитуды (амплитуда -> dBFS известна аналитически).
"""
from __future__ import annotations

import math

import numpy as np

# Ниже этого пика (-54 dBFS) сигнала нет вообще: устройство молчит или
# пишет «цифровую тишину». Совпадает с порогом в stt/whisper_check.py.
SILENCE_PEAK = 0.002


def to_float(audio: "np.ndarray") -> "np.ndarray":
    """int16 -> float32 в диапазоне [-1, 1]. Вход НЕ изменяется."""
    a = np.asarray(audio)
    if a.size == 0:
        return a.astype(np.float32)
    if a.dtype == np.int16:
        return a.astype(np.float32) / 32768.0
    return a.astype(np.float32)


def dbfs(value: float) -> float:
    """Амплитуда (0..1) -> dBFS, округлённо до 0.1. Ноль -> -120 dBFS."""
    return round(20.0 * math.log10(abs(value) + 1e-9), 1)


def peak_of(audio: "np.ndarray") -> float:
    f = to_float(audio)
    return float(np.max(np.abs(f))) if f.size else 0.0


def rms_of(audio: "np.ndarray") -> float:
    f = to_float(audio)
    return float(np.sqrt(np.mean(np.square(f)))) if f.size else 0.0


def verdict_ru(peak: float, rms: float) -> str:
    """Человеческий вердикт по пику и RMS (пороги — ориентиры выше)."""
    if peak < SILENCE_PEAK:
        return ("тишина: микрофон молчит (сигнала нет). Проверь устройство "
                "и его уровень в Windows")
    if rms < 0.003:          # < -50 dBFS
        return "очень тихо: шёпот не разобрать, подними уровень микрофона"
    if rms < 0.018:          # < -35 dBFS
        return "тихая речь / шёпот: whisper разберёт впритык"
    if rms < 0.125:          # < -18 dBFS
        return "нормальная речь: хороший уровень для распознавания"
    return "громко: близко к клиппингу, отодвинься от микрофона"


def bar_ru(db: float, width: int = 24) -> str:
    """Текстовая шкала █▅▃▁ для дБFS (-60..0) — наглядно в консоли/чате."""
    if db <= -60.0:
        filled = 0
    else:
        filled = int(round((db + 60.0) / 60.0 * width))
    filled = max(0, min(width, filled))
    return "█" * filled + "░" * (width - filled)


def db_stats(audio: "np.ndarray", sample_rate: int = 16000) -> dict:
    """Полный замер: пик/RMS в дБFS + посекундная разбивка + вердикт.

    Возвращает словарь для консоли/самотеста:
      peak, peak_dbfs, rms, rms_dbfs, silent, verdict, bar,
      per_sec: [{sec, peak_dbfs, rms_dbfs, bar}, ...]
    """
    f = to_float(audio)
    peak = peak_of(audio)
    rms = rms_of(audio)
    per_sec = []
    step = int(sample_rate)
    for i in range(0, f.size, step):
        piece = f[i:i + step]
        if piece.size < step // 2:
            break
        p = float(np.max(np.abs(piece)))
        r = float(np.sqrt(np.mean(np.square(piece))))
        pdb = dbfs(p)
        per_sec.append({
            "sec": len(per_sec) + 1,
            "peak_dbfs": pdb,
            "rms_dbfs": dbfs(r),
            "bar": bar_ru(pdb),
        })
    return {
        "peak": round(peak, 5),
        "peak_dbfs": dbfs(peak),
        "rms": round(rms, 5),
        "rms_dbfs": dbfs(rms),
        "silent": peak < SILENCE_PEAK,
        "verdict": verdict_ru(peak, rms),
        "bar": bar_ru(dbfs(peak)),
        "per_sec": per_sec,
        "seconds": round(f.size / float(sample_rate), 2) if sample_rate else 0.0,
    }
