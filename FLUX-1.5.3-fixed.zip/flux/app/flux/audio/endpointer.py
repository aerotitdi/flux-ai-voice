"""Выделение речевого сегмента + правило «5 секунд, чтобы продолжить фразу».

Требование ТЗ: пользователь сказал одно слово - и у него есть ровно 5 секунд
тишины, чтобы сказать следующее. Только после 5 секунд тишины сегмент
закрывается и уходит в распознавание/модель. Ничего не обрывается на полуслове.

Режимы:
  * wake  - обычная работа: сегмент закрывается после silence_timeout тишины;
  * hold  - зажата горячая клавиша (Numpad 9): тишина НЕ закрывает сегмент,
            но после отпускания клавиши те же 5 секунд продолжают действовать.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, Optional

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None  # type: ignore

from .vad import VAD, VadConfig, rms_float, to_int16_bytes

IDLE = "idle"
LISTENING = "listening"


@dataclass
class Segment:
    """Готовый речевой сегмент (всё, что сказал пользователь)."""

    audio: "np.ndarray"                 # int16 mono
    sample_rate: int
    started_at: float
    ended_at: float
    speech_seconds: float
    total_seconds: float
    held: bool = False                  # завершён по отпусканию горячей клавиши
    forced: bool = False                # обрезан по max_segment_sec
    frames: int = 0
    speech_frames_count: int = 0
    peak_rms: float = 0.0

    @property
    def is_too_short(self) -> bool:
        return self.speech_seconds < 0.25


@dataclass
class Event:
    kind: str                            # speech_start|segment|discard|tick
    segment: Optional[Segment] = None
    data: dict = field(default_factory=dict)


class Endpointer:
    """Конечный автомат: кадры PCM -> речевые сегменты."""

    def __init__(
        self,
        sample_rate: int = 16000,
        frame_ms: int = 30,
        silence_timeout: float = 5.0,
        min_speech_sec: float = 0.30,
        max_segment_sec: float = 60.0,
        pre_roll_sec: float = 0.45,
        vad: VAD | None = None,
        vad_cfg: VadConfig | None = None,
        clock: Callable[[], float] = time.monotonic,
        open_on_any_sound: bool = True,
    ) -> None:
        self.sample_rate = int(sample_rate)
        self.frame_ms = int(frame_ms)
        self.silence_timeout = float(silence_timeout)
        self.min_speech_sec = float(min_speech_sec)
        self.max_segment_sec = float(max_segment_sec)
        self.pre_roll_sec = float(pre_roll_sec)
        self.vad = vad or VAD(vad_cfg or VadConfig(sample_rate=sample_rate,
                                                   frame_ms=frame_ms))
        self.open_on_any_sound = open_on_any_sound
        self._clock = clock

        self.state = IDLE
        self.hold_active = False        # зажата горячая клавиша
        self._buf: list[bytes] = []
        self._pre: list[bytes] = []
        self._pre_max = max(1, int(pre_roll_sec * 1000 / frame_ms))
        self._started_at = 0.0
        self._last_speech_at = 0.0
        self._speech_frames = 0
        self._consec_speech = 0
        self._peak = 0.0
        self._held_started = False
        self.min_start_frames = 2      # ~60 мс речи подряд, чтобы открыть окно
        self.min_speech_frames = 4     # ~120 мс речи в сегменте, иначе это шум
        self.stats = {"segments": 0, "discarded_short": 0, "forced": 0,
                      "discarded_noise": 0}

    # ------------------------------------------------------------------- state
    @property
    def silence_left(self) -> float:
        """Сколько секунд осталось, чтобы продолжить фразу (для UI)."""
        if self.state != LISTENING:
            return 0.0
        elapsed = self._clock() - self._last_speech_at
        return max(0.0, self.silence_timeout - elapsed)

    @property
    def seconds_recorded(self) -> float:
        if self.state != LISTENING:
            return 0.0
        return len(self._buf) * self.frame_ms / 1000.0

    def hold_start(self) -> Event:
        """Горячая клавиша зажата: начинаем/продолжаем запись без таймаута."""
        self.hold_active = True
        if self.state != LISTENING:
            self._begin(forced_hold=True)
            return Event(kind="speech_start", data={"reason": "hold"})
        self._held_started = True
        return Event(kind="tick", data={"hold": True})

    def hold_release(self) -> Optional[Event]:
        """Клавиша отпущена: включается обычное правило 5 секунд тишины."""
        self.hold_active = False
        if self.state != LISTENING:
            return None
        # отсчёт тишины продолжается от последней речи (не сбрасываем!)
        return None

    def cancel(self) -> None:
        self.state = IDLE
        self._buf.clear()
        self.hold_active = False

    # -------------------------------------------------------------------- push
    def push(self, samples, frame_ms: int | None = None) -> list[Event]:
        """Скормить кадр PCM. Возвращает список событий (обычно 0 или 1)."""
        frame_ms = frame_ms or self.frame_ms
        data = to_int16_bytes(samples)
        rms = rms_float(data)
        self._peak = max(self._peak, rms) if self.state == LISTENING else rms
        speech = self.vad.is_speech(data, frame_ms=frame_ms)
        now = self._clock()
        events: list[Event] = []

        # «любой звук открывает окно, а whisper решает, речь ли это»:
        # старт - по любому не-цифровому-нулю звуку, тишина для закрытия -
        # относительная (rms ниже шумового пола * mult)
        opened_by = speech
        if self.open_on_any_sound:
            opened_by = rms > 1e-4
            speech = speech or rms > max(1e-4, self.vad.noise_floor * 3.0)
        if self.state == IDLE:
            if opened_by:
                self._consec_speech += 1
                if self._consec_speech < self.min_start_frames:
                    self._pre.append(data)
                    if len(self._pre) > self._pre_max:
                        self._pre.pop(0)
                    return events          # одиночный «щелчок» окно не открывает
                self._begin()
                events.append(Event(kind="speech_start", data={"rms": rms}))
                self._buf.append(data)
                self._last_speech_at = now
                self._speech_frames += 1
            else:
                self._consec_speech = 0
                self._pre.append(data)
                if len(self._pre) > self._pre_max:
                    self._pre.pop(0)
            return events

        # LISTENING
        self._buf.append(data)
        if speech:
            self._speech_frames += 1
            self._consec_speech += 1
            self._last_speech_at = now
        else:
            self._consec_speech = 0

        total_sec = len(self._buf) * frame_ms / 1000.0
        silence_sec = now - self._last_speech_at

        if total_sec >= self.max_segment_sec:
            self.stats["forced"] += 1
            events.append(self._finish(forced=True))
        elif not self.hold_active and silence_sec >= self.silence_timeout:
            events.append(self._finish(forced=False))
        else:
            events.append(Event(kind="tick", data={
                "silence_left": max(0.0, self.silence_timeout - silence_sec)
                if not self.hold_active else -1.0,
                "seconds": total_sec,
                "rms": rms,
                "speech": speech,
            }))
        return events

    # ---------------------------------------------------------------- internals
    def _begin(self, forced_hold: bool = False) -> None:
        self.state = LISTENING
        self._buf = list(self._pre)          # pre-roll: не теряем начало слова
        self._pre.clear()
        self._started_at = self._clock()
        self._last_speech_at = self._started_at
        self._speech_frames = 1 if not forced_hold else 0
        self._peak = 0.0
        self._held_started = forced_hold

    def _finish(self, forced: bool) -> Event:
        frame_ms = self.frame_ms
        raw = b"".join(self._buf)
        self._buf.clear()
        self._pre.clear()
        self.state = IDLE
        ended = self._clock()
        speech_sec = self._speech_frames * frame_ms / 1000.0
        total_sec = len(raw) / 2.0 / self.sample_rate
        if np is not None:
            audio = np.frombuffer(raw, dtype=np.int16).copy()
        else:  # pragma: no cover
            audio = raw  # type: ignore
        seg = Segment(
            audio=audio, sample_rate=self.sample_rate,
            started_at=self._started_at, ended_at=ended,
            speech_seconds=speech_sec, total_seconds=total_sec,
            held=self._held_started, forced=forced,
            frames=len(raw) // 2, speech_frames_count=self._speech_frames,
            peak_rms=self._peak,
        )
        self._held_started = False
        self._speech_frames = 0
        if seg.speech_seconds < self.min_speech_sec and not forced:
            self.stats["discarded_short"] += 1
            return Event(kind="discard", segment=seg,
                         data={"reason": "слишком короткий сегмент (шум)"})
        if (not self.open_on_any_sound
                and seg.frames
                and seg.speech_seconds / max(seg.total_seconds, 1e-6) < 0.15
                and seg.speech_frames_count < self.min_speech_frames
                and not forced):
            self.stats["discarded_noise"] += 1
            return Event(kind="discard", segment=seg,
                         data={"reason": "в сегменте почти нет речи (шум/фон)"})
        self.stats["segments"] += 1
        return Event(kind="segment", segment=seg)


def segment_to_wav_bytes(segment: Segment) -> bytes:
    """Сегмент -> WAV (для STT API / отладки)."""
    import io
    import wave

    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(segment.sample_rate)
        data = segment.audio
        w.writeframes(data.tobytes() if hasattr(data, "tobytes") else data)
    return buf.getvalue()
