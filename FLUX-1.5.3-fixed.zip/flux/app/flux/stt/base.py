"""Общие типы распознавания."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Transcript:
    text: str
    language: str = "ru"
    confidence: float = 0.0
    duration: float = 0.0
    engine: str = ""
    model: str = ""
    segments: list = field(default_factory=list)
    # СЛОВА С МЕТКАМИ ВРЕМЕНИ whisper (word_timestamps): именно по ним
    # определяется конец фразы — тишину решает whisper, а не громкость.
    words: list = field(default_factory=list)
    window_sec: float = 0.0      # сколько секунд звука было в этом куске
    raw: dict = field(default_factory=dict)

    @property
    def empty(self) -> bool:
        return not self.text.strip()


NOMATCH_TRANSCRIPT = Transcript(text="", engine="none")


def audio_to_wav_bytes(audio, sample_rate: int = 16000) -> bytes:
    """numpy int16 / bytes -> WAV для отправки в API."""
    import io
    import wave

    import numpy as np

    if isinstance(audio, (bytes, bytearray)):
        data = bytes(audio)
    else:
        data = np.asarray(audio).astype(np.int16).tobytes()
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(data)
    return buf.getvalue()
