"""Фильтр мусора: не отправлять в модель шум и галлюцинации Whisper.

Whisper на тишине/шуме выдаёт характерные «галлюцинации» («Субтитры сделал…»,
«Спасибо за просмотр», повторы одного слова). Такие сегменты отбрасываются,
как и чисто «слово-паразит» сегменты и слишком короткие.
"""
from __future__ import annotations

import re

BRACKET_RE = __import__("re").compile(r"[\[\]()]")

# Галлюцинации whisper делим на два класса:
#  1) PHRASES — узнаваемые МНОГОСЛОВНЫЕ хвосты («спасибо за просмотр»,
#     «субтитры сделал…», «думаю, что это не было»): ищем подстрокой,
#     потому что команда человека такой хвост не содержит;
#  2) EXACT — сегмент-бирка ЦЕЛИКОМ («(музыка)», «Звук.», «Смех»): сравниваем
#     ПОСЛЕ нормировки целиком, чтобы НЕ отстреливать живые команды вида
#     «сделай звук громче» или «включи музыку» (раньше «звук»/«музыка»
#     ловились подстрокой — это была ошибка фильтра).
HALLUCINATION_PHRASES = (
    "субтитры", "сделал dima", "dima torzok", "торжок", "спасибо за просмотр",
    "подпишись", "подписывайтесь", "подпишитесь", "ставьте лайк",
    "в следующей серии", "продолжение следует", "редактор субтитров",
    "автор субтитров", "the following content", "thank you for watching",
    "subtitle", "captions by", "думаю, что это не было", "думаю что это не было",
    "что это не было", "я не знаю, что сказать", "не знаю что сказать",
)

HALLUCINATION_EXACT = {
    "музыка", "звук", "звуки", "смех", "аплодисменты", "шипение", "помехи",
    "лайк", "эфир", "ведущий", "титры", "субтитры", "пока", "до встречи",
    "увидимся", "спокойной ночи", "доброй ночи", "музыка играет",
    "звучит музыка", "тишина", "спокойная музыка", "тихая музыка",
    "фоновая музыка", "играет музыка", "медленная музыка",
    "громкая музыка", "весёлая музыка", "легкая музыка", "лёгкая музыка",
}


def _is_upper_tag(text: str) -> bool:
    """Caps-бирка whisper («СПОКОЙНАЯ МУЗЫКА», «ТИХИЙ ГОЛОС»): короткий
    сегмент КАПСОМ без единой строчной буквы — это стиль-тег, не речь."""
    t = " ".join((text or "").split())
    words = [w for w in t.strip("()[]{}«»'\" ").split() if w]
    if not words or len(words) > 5:
        return False
    letters = [c for c in t if c.isalpha()]
    if not letters:
        return False
    return all(c.isupper() for c in letters)


def _norm(text: str) -> str:
    """«Звук.» / «(звук) уже без скобок» -> сравнимая основа: регистр и
    пунктуация не должны решать, галлюцинация это или команда."""
    t = re.sub(r"[^\w\s]", " ", (text or "").strip().lower(), flags=re.UNICODE)
    return " ".join(t.split())


FILLER_ONLY = {
    "", "э", "ээ", "эээ", "м", "мм", "ну", "а", "ага", "угу", "да", "нет",
    "ок", "окей", "хм", "хмм", "ой", "ух", "ах", "нуу", "так", "вот",
    "э-э", "э-э-э", "м-м", "ммм", "аа", "ааа", "о", "оо", "ооо", "и", "ы",
}

_REPEAT_WORD = re.compile(r"^(\w+)(?:\s+\1){3,}$", re.IGNORECASE | re.UNICODE)

# 3) CREDIT_TAILS — короткий «субтитровый» хвост, который whisper дописывает
#    ПОСЛЕДОНИМ предложением к чистой речи. Доказательство из живого прогона
#    (edge-tts ru-RU-DmitryNeural -> faster-whisper base, 2026-10-09):
#    «Флюкс, включи, свет на кухне. Повторяю.» — в озвученном тексте слова
#    «Повторяю» не было; в том же прогоне вместо него прилетал Caps-тег
#    «СПОКОЙНАЯ МУЗЫКА» (его ловит _is_upper_tag). Подстрокой такие слова в
#    HALLUCINATION_PHRASES класть НЕЛЬЗЯ: убьёт живую команду «повтори ещё
#    раз» / «переведи на английский», поэтому режем только хвост и только
#    когда перед ним есть substantialная команда.
CREDIT_TAILS = frozenset({
    "повторяю", "продолжаю", "перевожу", "читаю", "повтор", "перевод",
    "титры", "субтитр", "конец", "финал",
})

# Слова, по которым Caps-хвост («СПОКОЙНАЯ МУЗЫКА») отличаем от обычной
# КАПС-речи пользователя («ВКЛЮЧИ СВЕТ»): без такого слова хвост НЕ режем.
CAPS_TAG_WORDS = frozenset({
    "музыка", "звук", "звуки", "аплодисменты", "смех", "тишина", "шум",
    "помехи", "эфир", "титры", "субтитры", "голос", "фон", "ветер",
})

_CREDIT_TAIL_RE = re.compile(
    r"(?<=[.!?…])\s*((?:[\w-]+)(?:\s+[\w-]+)?)\s*[.!?…]?\s*$", re.UNICODE)


def strip_credit_tail(text: str) -> str:
    """«Флюкс, включи свет на кухне. Повторяю.» -> «Флюкс, включи свет на кухне».

    Хвост снимается только если: (а) он отделён концом предложения,
    (б) состоит из 1–2 слов, (в) это либо ВСЕ слова из CREDIT_TAILS, либо
    Caps-бирка whisper со словом-маркером («СПОКОЙНАЯ МУЗЫКА»), (г) перед ним
    осталась речь минимум из двух слов. Обычная КАПС-речь («ВКЛЮЧИ СВЕТ») не
    трогается: без маркера из CAPS_TAG_WORDS хвост не режем. Ограничение
    осознанное: настоящее повторное предложение в конце фразы, состоящее
    ровно из одного слова «повторяю/перевод/титры…», будет отрезано.
    """
    t = (text or "").strip()
    if not t:
        return t
    m = _CREDIT_TAIL_RE.search(t)
    if not m:
        return t
    tail = m.group(1)
    words = tail.lower().split()
    credit = words and all(w.strip(".!?…") in CREDIT_TAILS for w in words)
    caps_tag = _is_upper_tag(tail) and any(
        w.strip(".!?…") in CAPS_TAG_WORDS for w in words)
    if not credit and not caps_tag:
        return t                      # хвост — обычная речь, не трогаем
    head = t[:m.start()].strip(" ,.;:!?—-")
    if len([w for w in head.split() if w.strip(".,!?;:")]) < 2:
        return t                      # «Повторяю.» отдельно — не трогаем
    return head


def is_hallucination(text: str) -> bool:
    low = (text or "").strip().lower()
    if not low:
        return False
    norm = _norm(text)
    if norm in HALLUCINATION_EXACT:
        return True          # сегмент-бирка целиком: «Звук.», «Музыка»
    if _is_upper_tag(text):
        return True          # «СПОКОЙНАЯ МУЗЫКА»:Caps-бирки whisper
    if any(m in low for m in HALLUCINATION_PHRASES):
        return True
    if _REPEAT_WORD.match(low):
        return True
    if BRACKET_RE.search(text or ""):
        return True          # «(музыка)», «[аплодисменты]» - служебные теги whisper
    return False


def strip_hallucination_tail(text: str) -> str:
    """«команда + хвост-галлюцинация» в ОДНОМ сегменте -> оставить команду.

    Whisper иногда приклеивает галлюцинацию к концу нормальной фразы
    («Флюкс, включи свет. Думаю, что это не было.»). Выбросить сегмент
    целиком — значит потерять команду: отрезаем хвост по началу
    фразы-галлюцинации и возвращаем голову.
    """
    t = (text or "").strip()
    if not t:
        return t
    t = strip_credit_tail(t) or t
    if not is_hallucination(t):
        return t
    low = t.lower()
    pos = -1
    for ph in HALLUCINATION_PHRASES:
        i = low.find(ph)
        if i >= 0 and (pos < 0 or i < pos):
            pos = i
    if pos <= 0:
        return ""                      # сегмент целиком бирка/галлюцинация
    head = t[:pos].strip(" ,.;:!?—-")
    if not head or is_hallucination(head) or is_filler_only(head):
        return ""
    return head


def is_filler_only(text: str) -> bool:
    words = [w.strip(".,!?;: ") for w in (text or "").lower().split()]
    if not words:
        return True
    return all(w in FILLER_ONLY for w in words)


class NoiseFilter:
    def __init__(self, enabled: bool = True, drop_filler_only: bool = True,
                 min_chars: int = 2, min_confidence: float = 0.0) -> None:
        self.enabled = enabled
        self.drop_filler_only = drop_filler_only
        self.min_chars = int(min_chars)
        self.min_confidence = float(min_confidence)

    @classmethod
    def from_config(cls, cfg=None) -> "NoiseFilter":
        from .. import config as _c
        cfg = cfg or _c
        nf = cfg.get("stt.noise_filter", {}) or {}
        return cls(enabled=bool(nf.get("enabled", True)),
                   drop_filler_only=bool(nf.get("drop_filler_only", True)),
                   min_chars=int(nf.get("min_chars", 2)))

    def should_drop(self, text: str, confidence: float = 1.0,
                    speech_seconds: float | None = None) -> tuple[bool, str]:
        """(отбросить?, причина)"""
        t = (text or "").strip()
        if not t:
            return True, "пусто"
        if not self.enabled:
            return False, ""
        if len(t) < self.min_chars:
            return True, "слишком коротко"
        if is_hallucination(t):
            return True, "галлюцинация whisper"
        if speech_seconds is not None and speech_seconds < 0.25:
            return True, "речь короче 0.25 c"
        if self.drop_filler_only and is_filler_only(t):
            return True, "только слова-паразиты"
        if self.min_confidence and confidence and confidence < self.min_confidence:
            return True, "низкая уверенность распознавания"
        return False, ""


def clean_transcript(text: str) -> str:
    """Убирает артефакты: двойные пробелы, мусор по краям."""
    t = re.sub(r"\s+", " ", (text or "").strip())
    return t.strip(" \t-–—*").strip()
