"""Маршрутизатор STT: local / api / auto с фолбэком."""
from __future__ import annotations

from .. import config, logger
from .base import Transcript, audio_to_wav_bytes
from .api import WhisperAPISTT, transcribe_with_connections
from .local import LocalWhisperSTT
from .ollama_asr import OllamaWhisperSTT

log = logger.get_logger("flux.stt.router")


class STTRouter:
    """Порядок по умолчанию (auto): локальный faster-whisper -> ollama -> облако.

    Локальный whisper — основной движок (цепочка пользователя: микрофон ->
    whisper -> FLUX): из России облачный Groq всё равно отвечает 403 по
    региону (замер Хабр 01.10.2026), а локальный large-v3-turbo на GPU
    быстрее и приватнее. Звук передаётся СЫРЫМ: никакой нормализации/AGC
    до движков (как в Buzz). Если движок ОТРАБОТАЛ без исключения — его
    вердикт окончательный, даже пустой текст («whisper промолчал»):
    тишину решает whisper, а не фолбэк на другой движок.
    """

    name = "router"

    def __init__(self) -> None:
        self.local = LocalWhisperSTT()
        self.api = WhisperAPISTT()
        self.ollama = OllamaWhisperSTT()

    def reload(self) -> None:
        self.local = LocalWhisperSTT()
        self.api = WhisperAPISTT()
        self.ollama = OllamaWhisperSTT()

    def wake_engine(self):
        """Движок для поиска слова-активации.

        По умолчанию - локальная лёгкая faster-whisper (быстро, офлайн, без
        лишних hop'ов на каждый короткий сегмент). Если в настройках включено
        stt.ollama.use_for_wake и эндпоинт жив - используется whisper из Ollama
        (точнее на сложных фразах).
        """
        if (config.get("stt.ollama.use_for_wake", False)
                and self.ollama.available()):
            return self.ollama
        if config.get("stt.router_for_wake", True) and (
                self.local.available() or self.api.enabled()
                or self.ollama.available()):
            # слово-активация проверяется тем же точным whisper (локальным)
            return self
        return LocalWhisperSTT(size=str(config.get("stt.local.wake_model", "base")))

    def _order(self, mode: str) -> list[str]:
        if mode == "ollama":
            return ["ollama", "local"]
        if mode == "local":
            return ["local"]
        if mode == "api":
            return ["api", "conn", "local"]
        # auto: ЛОКАЛЬНЫЙ faster-whisper первый (цепочка пользователя и Buzz),
        # ollama-whisper и облако — только если локально не смогло (исключение)
        return ["local", "ollama", "api", "conn"]

    def transcribe(self, audio, sample_rate: int = 16000,
                   prefer: str | None = None) -> Transcript:
        # Звук передаётся СЫРЫМ (байт-в-байт из кольца захвата): никакой
        # нормализации/AGC до движков — whisper сам разбирается с уровнем
        # (log-mel), а «извлечение речи» делает Silero VAD внутри транскрипции.
        import numpy as _np
        arr = _np.asarray(audio)
        if arr.dtype != _np.int16:
            arr = (arr.astype(_np.float32) * 32767.0).astype(_np.int16)
        audio = arr
        mode = prefer or str(config.get("stt.engine", "auto"))
        errors: list[str] = []
        for name in self._order(mode):
            try:
                if name == "local":
                    if not self.local.available():
                        continue
                    res = self.local.transcribe_audio(audio, sample_rate)
                elif name == "ollama":
                    if not self.ollama.available():
                        continue
                    res = self.ollama.transcribe_audio(audio, sample_rate)
                elif name == "conn":
                    res = transcribe_with_connections(
                        audio_to_wav_bytes(audio, sample_rate),
                        language=str(config.get("stt.language", "ru")))
                else:
                    if not self.api.enabled():
                        continue
                    res = self.api.transcribe_audio(audio, sample_rate)
                # движок ОТРАБОТАЛ — его вердикт окончательный (даже «пусто»:
                # тишину решает whisper, фолбэк только по исключению)
                return res
            except Exception as e:
                errors.append(f"{name}: {e}")
                log.warning("STT %s failed: %s", name, e)
        return Transcript(text="", engine="none", raw={"errors": errors})
