"""Распознавание через OpenAI-совместимый Whisper API (только бесплатные
эндпоинты, напр. Groq whisper-large-v3-turbo free tier). Включается опцией.

Запрос: POST {base_url}/audio/transcriptions, multipart file=wav, model=...
Ответ: {"text": "..."} или {"text":..., "segments":[...]}
"""
from __future__ import annotations

import time
from typing import Optional

import requests

from .. import config, logger
from .base import Transcript, audio_to_wav_bytes

log = logger.get_logger("flux.stt.api")


def transcribe_wav_openai_compat(
    base_url: str,
    model: str,
    wav: bytes,
    language: str = "ru",
    timeout: float = 30.0,
    api_key: str = "",
    filename: str = "speech.wav",
) -> Transcript:
    """OpenAI-совместимый POST {base}/audio/transcriptions (multipart).

    Этим же эндпоинтом отвечают: локальный whisper в Ollama/xOllama
    (mannix/whisper:large-v3-turbo), Groq, OpenAI и любые vLLM-совместимые
    серверы. Без ключа заголовок Authorization не отправляется.
    """
    t0 = time.time()
    headers = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    files = {"file": (filename, wav, "audio/wav")}
    data = {"model": model}
    if language:
        data["language"] = language
    url = base_url.rstrip("/") + "/audio/transcriptions"
    resp = requests.post(url, headers=headers, files=files, data=data,
                         timeout=timeout)
    resp.raise_for_status()
    payload = resp.json()
    text = str(payload.get("text", "")).strip()
    return Transcript(text=text, language=language,
                      confidence=float(payload.get("confidence", 0.0) or 0.0),
                      duration=time.time() - t0, engine="openai-compat",
                      model=model, segments=payload.get("segments", []) or [],
                      raw=payload)


def transcribe_with_connections(wav: bytes, language: str = "ru",
                                timeout: float = 25.0) -> Transcript:
    """Пробует /audio/transcriptions на каждом OpenAI-подключении
    (вкладка «Подключения» в стиле Open WebUI): openrouter/xkiro и т.п.,
    если провайдер вообще отдаёт whisper. 404/400 молча пропускаются."""
    conns = config.get("llm.connections", []) or []
    errors: list[str] = []
    for c in conns:
        base = str(c.get("base_url", "")).rstrip("/")
        if not base:
            continue
        model = str(c.get("stt_model") or "") or "whisper-1"
        try:
            tr = transcribe_wav_openai_compat(
                base, model, wav, language=language, timeout=timeout,
                api_key=str(c.get("api_key") or ""))
            if tr.text:
                tr.engine = "openai-conn"
                return tr
            errors.append(f"{base}: пусто")
        except Exception as e:
            errors.append(f"{base}: {e}")
    return Transcript(text="", engine="none", raw={"errors": errors})


class WhisperAPISTT:
    name = "api"

    PRESETS = {
        "groq": ("https://api.groq.com/openai/v1", "whisper-large-v3-turbo"),
        "openai": ("https://api.openai.com/v1", "whisper-1"),
    }

    def __init__(self, base_url: Optional[str] = None, model: Optional[str] = None,
                 api_key: Optional[str] = None, language: Optional[str] = None,
                 timeout: Optional[float] = None) -> None:
        # пресет выбирается по вставленному ключу: groq (бесплатный) -> openai
        preset = str(config.get("stt.api.preset", "") or "")
        key = api_key if api_key is not None else str(config.get("stt.api.api_key", ""))
        if not key:
            if not preset and str(config.get("keys.groq", "") or ""):
                preset, key = "groq", str(config.get("keys.groq", ""))
            elif not preset and str(config.get("keys.openai", "") or ""):
                preset, key = "openai", str(config.get("keys.openai", ""))
        if preset in self.PRESETS and not base_url:
            base_url, def_model = self.PRESETS[preset]
            model = model or str(config.get("stt.api.model", "") or def_model)
        self.preset = preset
        self._explicit_base = bool(base_url)
        self._explicit_model = bool(model)
        self._explicit_key = api_key is not None and api_key != ""
        self.base_url = (base_url or str(config.get("stt.api.base_url",
                                                    "https://api.groq.com/openai/v1"))).rstrip("/")
        self.model = model or str(config.get("stt.api.model", "whisper-large-v3-turbo"))
        self.api_key = key
        self.language = language or str(config.get("stt.language", "ru"))
        self.timeout = float(timeout or config.get("stt.timeout_sec", 25))

    def _refresh(self) -> None:
        """Ключ/пресет читаются из конфига на каждый вызов: вставил ключ в
        консоли - уже запущенный FLUX сразу начинает слать в Groq."""
        key = str(config.get("stt.api.api_key", "") or "")
        preset = str(config.get("stt.api.preset", "") or "")
        if not key:
            if str(config.get("keys.groq", "") or ""):
                preset, key = "groq", str(config.get("keys.groq", ""))
            elif str(config.get("keys.openai", "") or ""):
                preset, key = "openai", str(config.get("keys.openai", ""))
        if preset in self.PRESETS:
            base, def_model = self.PRESETS[preset]
            if not self._explicit_base:
                self.base_url = str(config.get("stt.api.base_url", "") or base).rstrip("/")
            if not self._explicit_model:
                self.model = str(config.get("stt.api.model", "") or def_model)
        self.preset = preset
        if not self._explicit_key:
            self.api_key = key

    def enabled(self) -> bool:
        self._refresh()
        return bool(self.api_key)

    def available(self) -> bool:
        return self.enabled()

    def transcribe_audio(self, audio, sample_rate: int = 16000) -> Transcript:
        self._refresh()
        wav = audio_to_wav_bytes(audio, sample_rate)
        return self.transcribe_wav(wav)

    def transcribe_wav(self, wav: bytes) -> Transcript:
        tr = transcribe_wav_openai_compat(
            self.base_url, self.model, wav, language=self.language,
            timeout=self.timeout, api_key=self.api_key)
        tr.engine = self.name
        return tr
