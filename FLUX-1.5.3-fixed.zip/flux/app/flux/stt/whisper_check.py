"""ШТУКА ДЛЯ ПРОВЕРКИ ЛОКАЛЬНОГО WHISPER (просил пользователь).

Цепочка ровно боевая: микрофон (сырой звук, без обработки) -> faster-whisper
-> текст. Показывает всё, что нужно для доверия:

  * какое устройство писали и сырой уровень сигнала (peak, dBFS);
  * какая модель, на каком устройстве (cuda/cpu) и с каким compute_type;
  * сколько модель грузилась и сколько считала, RTF (<=1 быстрее реального);
  * сам текст, который услышал whisper (или «промолчал»).

Запуск из консоли: кнопка «whisper-тест». Из меню: «Проверить whisper».
Из командной строки:  python -m flux.stt.whisper_check [секунды] [модель]
"""
from __future__ import annotations

import math
import time
from typing import Optional

import numpy as np

from .. import config, logger
from . import local

log = logger.get_logger("flux.stt.check")

# Ниже этого пика (-54 dBFS) сигнала нет: это тишина, а не «тихая речь».
# Нормальная речь у микрофона даёт пик примерно -24...-6 dBFS.
SILENCE_PEAK = 0.002


def check(seconds: float = 6.0, model_size: Optional[str] = None) -> dict:
    """Записать seconds секунд с микрофона и распознать локальным whisper."""
    from ..audio.devices import configured_spec, record_seconds

    size = str(model_size or config.get("stt.local.model", "large-v3-turbo"))
    device_pref = str(config.get("stt.local.device", "auto"))
    device = local._resolve_device(device_pref)
    compute = local._resolve_compute(
        str(config.get("stt.local.compute_type", "auto")), device)

    # 1) модель (кэш живой: повторная загрузка = 0.0 c).
    #    Ошибку загрузки модели НЕ путаем с ошибкой микрофона: это разные
    #    поломки с разными кодами возврата (1 и 2) и разными советами.
    t0 = time.time()
    try:
        _, eff_size = local.get_model(size, compute_type=compute)
    except Exception as e:
        return {"ok": False, "stage": "model", "model": size,
                "device_compute": device, "compute_type": compute,
                "error": f"{e.__class__.__name__}: {e}"}
    load_sec = round(time.time() - t0, 2)
    # ЧЕСТНОЕ устройство: запрошено может быть «cuda», а по факту (нет
    # cublas64_12.dll) модель живёт на cpu — показываем проверенное.
    fact = local.last_load()
    if fact.get("device"):
        device, compute = fact["device"], fact["compute"]

    # 2) сырая запись с микрофона (тот же путь, что и боевой захват).
    #    record_seconds сам идёт по цепочке устройств (настроечное ->
    #    по умолчанию), поэтому сюда падает только действительно мёртвый
    #    микрофон: устройство занято, отключено или PortAudio его не видит.
    try:
        audio, info = record_seconds(seconds, device_spec=configured_spec())
    except Exception as e:
        return {"ok": False, "stage": "mic", "model": eff_size or size,
                "device_compute": device, "compute_type": compute,
                "load_sec": load_sec,
                "error": f"микрофон недоступен ({e.__class__.__name__}: {e})"}
    if not info.get("ok") or audio.size == 0:
        return {"ok": False, "stage": "mic", "model": eff_size or size,
                "device_compute": device, "compute_type": compute,
                "load_sec": load_sec,
                "error": info.get("error", "микрофон не дал данных"),
                "mic_device": info.get("device", "")}
    peak = float(np.max(np.abs(audio.astype(np.float32)))) / 32768.0

    # 3) распознавание: сырой звук -> модель, без всякой обработки
    stt = local.LocalWhisperSTT(size=size)
    t1 = time.time()
    tr = stt.transcribe_audio(audio, 16000)
    tr_sec = round(time.time() - t1, 2)
    rec_sec = round(len(audio) / 16000.0, 2)
    text = (tr.text or "").strip()
    dbfs = round(20 * math.log10(peak + 1e-9), 1)

    # 4) ТИШИНА НЕ БЫВАЕТ УСПЕХОМ. Живой лог пользователя: пик -74.7 dBFS
    #    (микрофон молчит), whisper на тишине галлюцинировал («Субтитры
    #    создавал DimaTorzok»), а тест рапортовал «модель проверена на
    #    микрофоне». Теперь тишина = провал стадии mic (код возврата 2),
    #    а текст на тишине помечается галлюцинацией и не считается успехом.
    if peak < SILENCE_PEAK:
        err = (f"микрофон молчит: сырой пик {round(peak, 5)} ({dbfs} dBFS) — "
               f"сигнал не доходит до whisper")
        if text:
            err += (f"; текст «{text}» — галлюцинация whisper на тишине, "
                    f"это НЕ распознанная речь")
        return {"ok": False, "stage": "mic", "silent": True,
                "hallucination": bool(text),
                "model": eff_size or size,
                "requested_model": size,
                "device_compute": device, "compute_type": compute,
                "load_sec": load_sec,
                "mic": info.get("device"),
                "mic_fallback": info.get("fallback_from", ""),
                "rec_sec": rec_sec, "tr_sec": tr_sec,
                "rtf": round(tr_sec / rec_sec, 3) if rec_sec else 0.0,
                "peak": round(peak, 5), "dbfs": dbfs,
                "engine": tr.engine, "text": text, "error": err}

    return {
        "ok": True,
        "stage": "ok",
        "silent": False,
        "model": eff_size or size,
        "requested_model": size,
        "model_fallback": (eff_size or size) != size,
        "words": len(getattr(tr, "words", None) or []),
        "device_compute": device,
        "compute_type": compute,
        "load_sec": load_sec,
        "mic": info.get("device"),
        "mic_fallback": info.get("fallback_from", ""),
        "rec_sec": rec_sec,
        "tr_sec": tr_sec,
        "rtf": round(tr_sec / rec_sec, 3) if rec_sec else 0.0,
        "peak": round(peak, 5),
        "dbfs": dbfs,
        "engine": tr.engine,
        "text": text,
    }


def report(d: dict) -> str:
    """Человеческий отчёт в несколько строк (консоль/меню/CLI)."""
    if not d.get("ok"):
        stage = d.get("stage", "")
        if stage == "mic":
            # модель ЖИВАЯ: нагружена и ждала звука — сломался именно микрофон.
            # Раньше тут писалось «модель не загрузилась» — это была ложь.
            lines = [
                f"whisper-тест НЕ прошёл: МИКРОФОН недоступен "
                f"({d.get('error', '?')})",
                f"модель {d.get('model')} при этом ЗАГРУЗИЛАСЬ "
                f"({d.get('device_compute')}/{d.get('compute_type')}, "
                f"{d.get('load_sec', '?')} c) — whisper работает, не даёт "
                f"звуку дойти до него устройство",
            ]
            if d.get("silent"):
                lines.append(
                    "микрофон МОЛЧИТ (тишина), а не «плохо слышно»: проверь, "
                    "какое устройство выбрано (консоль -> ⚙ -> Микрофон, имя "
                    "устройства), и его уровень в Windows (Звук -> Свойства "
                    "микрофона). Кнопка «🔊 дБ» в чате покажет громкость в "
                    "дБFS по секундам")
            if d.get("hallucination"):
                lines.append(
                    f"текст «{d.get('text', '')}» whisper ПРИДУМАЛ на тишине "
                    f"(галлюцинация) — он не считается распознанной речью")
            lines.append(
                "что сделать: консоль -> Настройки -> Микрофон (выбрать имя "
                "устройства), или освободить микрофон (занят Discord/Skype), "
                "или выбрать устройство по умолчанию в Windows")
            return "\n".join(lines)
        if stage == "model":
            return (f"whisper-тест НЕ прошёл: МОДЕЛЬ {d.get('model')} не "
                    f"загрузилась ({d.get('error', '?')})\n"
                    f"FLUX сам попробует более лёгкую модель "
                    f"(large-v3-turbo -> large-v3 -> medium -> small -> base "
                    f"-> tiny), выбрать модель: консоль -> Настройки -> "
                    f"Понимание речи")
        return (f"whisper-тест НЕ прошёл: {d.get('error', '?')}\n"
                f"модель: {d.get('model')} ({d.get('device_compute')})")
    lines = [
        f"модель: {d['model']} на {d['device_compute']} ({d['compute_type']})"
        + (f" — ВНИМАНИЕ: {d.get('requested_model')} не завелась, взял запасную"
           if d.get("model_fallback") else ""),
        f"загрузка модели: {d['load_sec']} c"
        + (" (уже была в памяти)" if d["load_sec"] < 0.05 else ""),
        f"микрофон: {d['mic']}, сырой пик {d['peak']} ({d['dbfs']} dBFS)"
        + (f" — ВНИМАНИЕ: запрошенное «{d['mic_fallback']}» не открылось, "
           f"писал этим (цепочка устройств)" if d.get("mic_fallback") else ""),
        f"запись {d['rec_sec']} c -> распознавание {d['tr_sec']} c "
        f"(RTF {d['rtf']}, {'быстрее реального времени' if d['rtf'] < 1 else 'МЕДЛЕННЕЕ реального времени'})",
        f"whisper услышал: «{d['text']}» (слов с метками времени: {d.get('words', 0)})"
        if d["text"]
        else "whisper ПРОМОЛЧАЛ: за эти секунды слов не было (это вердикт "
             "whisper, а не ошибка — скажи что-нибудь и повтори тест)",
    ]
    if d["peak"] < 0.004:
        lines.append("ВНИМАНИЕ: сырой микрофон очень тихий — подними уровень "
                     "микрофона в Windows (Звук -> Свойства микрофона). "
                     "FLUX звук НЕ усиливает: в whisper идёт сырой сигнал.")
    return "\n".join(lines)


def main(argv: Optional[list[str]] = None) -> int:
    """CLI/установщик: 0 = whisper работает, 1 = модель не завелась,
    2 = модель работает, но микрофон не дал звука."""
    import sys
    args = list(sys.argv[1:] if argv is None else argv)
    seconds = float(args[0]) if args else 6.0
    model = args[1] if len(args) > 1 else None
    try:
        d = check(seconds=seconds, model_size=model)
    except Exception as e:
        # исключение НА ЭТОМ уровне — тоже про модель (микрофон свои ошибки
        # возвращает словарём, а не бросает): код 1
        print(report({"ok": False, "stage": "model", "model": model or "?",
                      "error": f"{e.__class__.__name__}: {e}"}))
        return 1
    print(report(d))
    if not d.get("ok"):
        return 1 if d.get("stage") == "model" else 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
