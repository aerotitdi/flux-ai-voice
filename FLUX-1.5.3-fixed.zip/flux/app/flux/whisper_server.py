"""WHISPER-СЕРВЕР FLUX: вот КАК whisper «отправляет» текст Флюксу.

Whisper — библиотека: сам он никуда ничего не шлёт, он только возвращает
слова тому, кто его вызвал. Поэтому в FLUX два способа, и оба уже работают:

1) ВНУТРИ FLUX (основной): поток microфон -> сырое кольцо -> кусок в whisper
   -> слова с метками времени -> voice/utterance.py собирает ОДНО целое
   сообщение и отдаёт его модели. Ничего «отправлять» не нужно: FLUX сам
   забирает результат каждого вызова (main._consume_chunk).

2) СНАРУЖИ (этот модуль): FLUX поднимает локальный HTTP-эндпоинт
   OpenAI-совместимого вида, и ЛЮБОЙ whisper (whisper.cpp, faster-whisper
   сервер, Ollama-обвязка, свой скрипт) может ОТПРАВИТЬ ему звук:

       POST http://127.0.0.1:8793/v1/audio/transcriptions
            -F file=@speech.wav -F model=large-v3-turbo -F language=ru
       ->  {"text": "флюкс включи свет",
            "words": [{"word": "флюкс", "start": 0.2, "end": 0.9}, ...]}

   Текст с этого эндпоинта попадает в тот же словесный поток FLUX, то есть
   становится частью сообщения и уходит модели ЦЕЛИКОМ по правилу
   «whisper замолчал на 5 секунд».

Проверка руками (PowerShell):
    curl.exe -F "file=@test.wav" http://127.0.0.1:8793/v1/audio/transcriptions

Почему не Ollama: в официальном API Ollama НЕТ эндпоинта транскрипции
(docs.ollama.com/api: generate/chat/embed/tags/... — audio/transcriptions
отсутствует), поэтому скачанная mannix/whisper:large-v3-turbo в сток-Ollama
не запускается (ollama/ollama#1168 — «We'd love to support this at some
point», OllamaSharp#381 от 26.03.2026 — «you can load whisper models ...
but you can't use them»). Отсюда и этот эндпоинт + локальный faster-whisper.
"""
from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Optional

from . import config, logger

log = logger.get_logger("flux.whisper_server")

TRANSCRIBE_PATH = "/v1/audio/transcriptions"
MODELS_PATH = "/v1/models"
TEXT_PATH = "/text"          # упрощённый путь: {"text": "..."} -> в поток слов
HEALTH_PATH = "/health"


# --------------------------------------------------------------- multipart
def parse_multipart(body: bytes, content_type: str) -> tuple[Optional[bytes], dict]:
    """Разбор multipart/form-data без внешних зависимостей.

    Возвращает (байты файла, поля формы). Поле ``file`` (или первое бинарное)
    считается звуком.

    ИСПРАВЛЕННЫЙ РАЗБОР ГРАНИЦ. Прежняя версия делила тело по ``--boundary``
    и затем делала ``part.strip(b"\r\n")``. ``strip`` срезает \r и \n
    с ОБОИХ концов, поэтому он мог откусить НАСТОЯЩИЕ байты звука в конце
    WAV-файла (последний отсчёт int16 вполне может быть 0x0D или 0x0A) —
    тихое искажение хвоста записи, которое не видно ни в логе, ни в ответе.
    Теперь разделитель включает предшествующий CRLF (``\r\n--boundary``),
    а содержимое части не обрабатывается strip'ом вовсе: байты звука
    проходят насквозь неизменёнными.
    """
    fields: dict[str, str] = {}
    if "boundary=" not in (content_type or ""):
        return None, fields
    boundary = content_type.split("boundary=", 1)[1].strip().strip('"')
    boundary = boundary.split(";", 1)[0].strip()
    if not boundary:
        return None, fields
    sep = b"\r\n--" + boundary.encode()
    # тело multipart обычно начинается прямо с "--boundary" (без ведущего CRLF):
    # добавляем его, чтобы ПЕРВАЯ граница разбиралась тем же правилом
    normalized = body if body.startswith(b"\r\n") else b"\r\n" + body
    file_bytes: Optional[bytes] = None
    for part in normalized.split(sep):
        if not part or part.startswith(b"--"):
            continue                      # пусто или закрывающая "--boundary--"
        if b"\r\n\r\n" not in part:
            continue
        head, _, content = part.partition(b"\r\n\r\n")
        head_txt = head.decode("utf-8", "replace")
        name = ""
        if 'name="' in head_txt:
            name = head_txt.split('name="', 1)[1].split('"', 1)[0]
        is_file = "filename=" in head_txt
        if is_file and file_bytes is None:
            file_bytes = content            # байты звука — КАК ЕСТЬ, без strip
        elif name:
            # у текстового поля служебный CRLF принадлежит разделителю и уже
            # съеден sep'ом; здесь убираем только явно лишний хвост
            if content.endswith(b"\r\n"):
                content = content[:-2]
            fields[name] = content.decode("utf-8", "replace").strip()
    if file_bytes is None:
        # вдруг звук положили полем audio/data/file в base64
        for key in ("audio", "data", "file"):
            if key in fields:
                import base64
                try:
                    file_bytes = base64.b64decode(fields.pop(key))
                    break
                except Exception:
                    continue
    return file_bytes, fields


def wav_to_pcm(data: bytes, target_sr: int = 16000):
    """Любой аудио-формат, который умеет наш декодер -> int16 mono 16 кГц."""
    import numpy as np

    from .audio.player import decode_audio_file_bytes

    audio, sr = decode_audio_file_bytes(data, target_sr=target_sr)
    arr = np.asarray(audio)
    if arr.dtype != np.int16:
        arr = (arr.astype(np.float32) * 32767.0).astype(np.int16)
    return arr, int(sr or target_sr)


# ------------------------------------------------------------------ server
class WhisperServer:
    """Локальный HTTP-приёмник звука/текста от внешнего whisper."""

    def __init__(self, transcribe: Callable[[Any, int], Any],
                 on_words: Optional[Callable[[str], None]] = None,
                 models_provider: Optional[Callable[[], list]] = None) -> None:
        self.transcribe = transcribe          # (audio int16, sr) -> Transcript
        self.on_words = on_words              # текст -> словесный поток FLUX
        self.models_provider = models_provider or (lambda: [])
        self._srv: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()         # модель одна: транскрипции в очередь
        self.requests = 0
        self.last_text = ""
        self.last_error = ""

    # ------------------------------------------------------------------ start
    def start(self) -> bool:
        if not bool(config.get("whisper_server.enabled", True)):
            log.info("whisper-сервер выключен в настройках")
            return False
        host = str(config.get("whisper_server.host", "127.0.0.1"))
        port = int(config.get("whisper_server.port", 8793))
        handler = _make_handler(self)
        try:
            self._srv = ThreadingHTTPServer((host, port), handler)
        except OSError as e:
            self.last_error = f"{host}:{port}: {e}"
            log.error("whisper-сервер не стартовал на %s:%s (%s) — "
                      "возможно, порт занят; поменяй whisper_server.port",
                      host, port, e)
            return False
        self._srv.daemon_threads = True
        self._thread = threading.Thread(target=self._srv.serve_forever,
                                        name="flux-whisper-server", daemon=True)
        self._thread.start()
        log.info("whisper-сервер FLUX: POST http://%s:%s%s "
                 "(сюда любой whisper может отправить звук)",
                 host, port, TRANSCRIBE_PATH)
        return True

    def stop(self) -> None:
        if self._srv is not None:
            try:
                self._srv.shutdown()
                self._srv.server_close()
            except Exception:
                pass
            self._srv = None

    # ------------------------------------------------------------------ info
    def info(self) -> dict:
        host = str(config.get("whisper_server.host", "127.0.0.1"))
        port = int(config.get("whisper_server.port", 8793))
        running = self._srv is not None
        return {
            "enabled": bool(config.get("whisper_server.enabled", True)),
            "running": running,
            "url": f"http://{host}:{port}{TRANSCRIBE_PATH}" if running else "",
            "host": host, "port": port,
            "requests": self.requests,
            "last_text": self.last_text,
            "last_error": self.last_error,
            "howto": (f'curl.exe -F "file=@speech.wav" '
                      f'http://{host}:{port}{TRANSCRIBE_PATH}'),
        }

    # ----------------------------------------------------------------- work
    def handle_audio(self, data: bytes, fields: dict) -> dict:
        """Распознать присланный звук и (опционально) внести в поток слов."""
        import numpy as np

        with self._lock:
            self.requests += 1
            audio, sr = wav_to_pcm(data)
            if audio is None or np.asarray(audio).size == 0:
                raise ValueError("пустой/нечитаемый звук")
            tr = self.transcribe(audio, sr)
        text = str(getattr(tr, "text", "") or "").strip()
        self.last_text = text
        words = [{"word": w.get("word"), "start": w.get("start"),
                  "end": w.get("end")}
                 for w in (getattr(tr, "words", None) or [])
                 if isinstance(w, dict)]
        if text and self.on_words is not None and str(
                fields.get("inject", "1")) not in ("0", "false", "no"):
            try:
                self.on_words(text)
            except Exception as e:               # pragma: no cover
                log.warning("не удалось передать текст в поток FLUX: %s", e)
        return {"text": text,
                "language": str(getattr(tr, "language", "") or ""),
                "engine": str(getattr(tr, "engine", "") or ""),
                "model": str(getattr(tr, "model", "") or ""),
                "duration": round(float(getattr(tr, "duration", 0.0) or 0.0), 3),
                "words": words}

    def handle_text(self, text: str) -> dict:
        """Готовый текст от внешнего whisper -> сразу в поток слов FLUX."""
        text = (text or "").strip()
        with self._lock:
            self.requests += 1
        self.last_text = text
        if text and self.on_words is not None:
            self.on_words(text)
        return {"text": text, "injected": bool(text)}


def _make_handler(srv: WhisperServer):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "FluxWhisper/1.0"

        def _json(self, obj: Any, code: int = 200) -> None:
            data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(data)

        def _body(self) -> bytes:
            length = int(self.headers.get("Content-Length", 0) or 0)
            return self.rfile.read(length) if length else b""

        def log_message(self, fmt, *args):    # не спамим
            pass

        def do_OPTIONS(self):                  # noqa: N802
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
            self.send_header("Content-Length", "0")
            self.end_headers()

        def do_GET(self):                      # noqa: N802
            path = self.path.split("?", 1)[0].rstrip("/")
            if path in ("", "/", HEALTH_PATH):
                return self._json({"ok": True, "service": "flux-whisper",
                                   **srv.info()})
            if path == MODELS_PATH:
                return self._json({"object": "list",
                                   "data": [{"id": m, "object": "model"}
                                            for m in srv.models_provider()]})
            return self._json({"error": "not found",
                               "hint": f"POST {TRANSCRIBE_PATH}"}, 404)

        def do_POST(self):                     # noqa: N802
            path = self.path.split("?", 1)[0].rstrip("/")
            ctype = self.headers.get("Content-Type", "")
            body = self._body()
            try:
                if path == TRANSCRIBE_PATH or path.endswith("/transcriptions"):
                    if "multipart/form-data" in ctype:
                        audio, fields = parse_multipart(body, ctype)
                        if audio is None:
                            return self._json({"error": "нет поля file со звуком"},
                                              400)
                    else:
                        # JSON: {"audio": "<base64>"} — удобно из скриптов
                        import base64
                        try:
                            obj = json.loads(body.decode("utf-8") or "{}")
                        except Exception:
                            obj = {}
                        b64 = str(obj.get("audio") or obj.get("data") or "")
                        if not b64:
                            return self._json({"error": "нужен multipart file "
                                                        "или {\"audio\": base64}"},
                                              400)
                        audio = base64.b64decode(b64)
                        fields = {k: str(v) for k, v in obj.items()
                                  if k not in ("audio", "data")}
                    return self._json(srv.handle_audio(audio, fields))
                if path == TEXT_PATH:
                    try:
                        obj = json.loads(body.decode("utf-8") or "{}")
                    except Exception:
                        obj = {}
                    return self._json(srv.handle_text(str(obj.get("text", ""))))
                return self._json({"error": "not found"}, 404)
            except Exception as e:
                srv.last_error = str(e)
                log.warning("whisper-сервер: %s", e)
                return self._json({"error": str(e)}, 500)

    return Handler
