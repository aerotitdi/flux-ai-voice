"""Конфигурация FLUX: единый config.json + значения по умолчанию.

Файл читают и пишут два процесса: меню Flux.exe (C#) и Python-ядро, поэтому
сохранение атомарное (запись во временный файл + os.replace), а чтение
терпимо к повреждённому JSON (создаётся резервная копия .bad).
"""
from __future__ import annotations

import copy
import json
import os
import threading
from typing import Any

from . import paths

_LOCK = threading.RLock()

DEFAULTS: dict[str, Any] = {
    "assistant": {
        "name": "Флюкс",
        "language": "ru",
        "voice_only": True,          # ввод ТОЛЬКО с микрофона
        "greeting": "Да, я на связи. Чем помочь?",
        "followup_window_sec": 5.0,   # после ответа слушаем продолжение без wake word
    },
    "wake": {
        "enabled": True,
        "words": ["флюкс", "flux"],   # слово-активация (настраивается в меню)
        # дубли убраны (было: "флюкс" трижды) — детектор зря гонял лишние формы
        "aliases": ["флюкс", "флукс", "flux", "плюкс"],
        "require_at_start": True,     # слово должно быть В НАЧАЛЕ фразы
        "max_leading_fillers": 1,     # допускаем "эй/ну" перед словом
        "min_speech_sec": 0.15,       # почти не ограничиваем: активация по whisper
        "min_activation_interval_sec": 0.8,  # минимальная защита от спама
        "awake_timeout_sec": 15.0,    # «Слушаю» без команды само сбрасывается
        "sensitivity": 0,             # 0=строго (только точное слово), 1/2 мягче
        "min_confidence": 0.0,        # активация чисто по whisper (без порога)
        "min_words_after": 0,         # 0 = можно одним словом "флюкс"
    },
    "hotkey": {
        "enabled": True,
        "push_to_talk": "num 9",      # ЗАЖАТИЕ Numpad 9 = голосовой ввод
        "cancel": "esc",
        "backend": "auto",            # auto|keyboard|pynput
    },
    "audio": {
        "input_device": None,         # None = микрофон по умолчанию
        "input_device_name": "",
        "exclude_loopback": True,     # НИКОГДА не брать звук из динамиков
        "collapse_duplicates": True,  # один микрофон = одна запись (MME/WASAPI/DS
                                      # перечисляют одно устройство 3-4 раза)
        "sample_rate": 16000,
        "channels": 1,
        "block_ms": 30,
        "silence_timeout_sec": 5.0,   # 5 секунд чтобы продолжить фразу
        "wake_silence_sec": 1.2,      # в ожидании слова: быстрая, но не рвущая реакция
        "barge_rms": 0.10,            # порог устойчивой речи для barge-in
        "min_speech_sec": 0.30,
        "max_segment_sec": 60.0,
        "pre_roll_sec": 0.45,
        "open_on_any_sound": True,  # любой звук уходит в whisper - решает whisper
        "quiet_threshold_db": -50.0,  # «меньше 50 дБ» (dBFS) = считаем тишиной
        "quiet_timeout_sec": 5.0,     # тишины подряд -> сессия записи закрыта (гг)
        "vad": {
            "engine": "auto",         # auto|webrtcvad|energy
            "aggressiveness": 2,      # 0..3 для webrtcvad (2 = баланс шум/речь)
            "energy_threshold": 0.002,   # абсолютный МИНИМУМ; основной гейт относительный
            "noise_floor_auto": True,
            "speech_pad_ms": 200,
        },
        "barge_in": False,            # не слушать себя во время озвучки
        "tail_guard_sec": 0.5,        # окно после озвучки: хвост из динамиков игнорим
        "feedback_sounds": True,
        "noise_gate_db": -45.0,
    },
    "stt": {
        "engine": "auto",             # auto|local|api|ollama
        # Источник речи: локальный whisper (по умолчанию) ИЛИ микрофон браузера
        # (Web Speech API в консоли). Браузерный режим точнее в шуме, но требует
        # открытой вкладки и интернета и не даёт меток времени слов — поэтому
        # конец фразы в нём отстукивается heartbeat'ами консоли, а не шкалой
        # whisper. Включается пилюлей «🎙 браузер» в консоли или ручкой в меню.
        "browser_source": False,
        "router_for_wake": True,      # слово-активация через точный роутер (Groq)
        "language": "ru",
        "local": {
            "model": "large-v3-turbo",  # ОСНОВНОЙ локальный whisper (GPU: летает)
            "wake_model": "base",     # лёгкий, если router_for_wake=False
            "compute_type": "auto",   # auto: float16 на GPU, int8 на CPU
            "device": "auto",         # auto|cpu|cuda
            "beam_size": 1,
            "cpu_threads": 0,         # 0 = авто
            "word_timestamps": True,  # МЕТКИ ВРЕМЕНИ СЛОВ: по ним whisper сам
                                      # определяет конец фразы (5 c молчания)
            "model_fallback": True,   # если модель не скачалась — берём легче
            "vad_filter": True,       # Silero VAD внутри транскрипции (как в HA)
            "condition_on_previous_text": False,
            "temperature": 0.0,
            # смещение словаря: whisper чаще слышит «Флюкс» и команды правильно
            "initial_prompt": "Флюкс, флюкс. включи, выключи, открой, закрой, "
                              "найди, погода, таймер, напомни, громкость, экран, "
                              "файлы, браузер, музыка, компьютер.",
            "download_root": "",      # пусто = D:\flux\models
        },
        "ollama": {
            "enabled": True,          # внешний whisper-сервер (OpenAI-эндпоинт)
            "model": "mannix/whisper:large-v3-turbo",
            # сток-Ollama транскрипцию НЕ умеет (docs.ollama.com/api): сюда
            # вписываем отдельный whisper-сервер, если он у тебя поднят
            "base_url": "http://localhost:22434/v1",
            "fallback_base_urls": ["http://localhost:11434/v1"],
            "language": "ru",
            "timeout_sec": 30,
            "use_for_wake": False,    # слово-активация: быстрее и надёжнее локально
        },
        "api": {
            "enabled": False,         # включается автоматически при наличии ключа
            "preset": "",             # "" | groq | openai (или base_url/model вручную)
            "base_url": "https://api.groq.com/openai/v1",
            "model": "whisper-large-v3-turbo",
            "api_key": "",
            "use_for_wake": False,
        },
        "timeout_sec": 25,
        "noise_filter": {
            "enabled": False,         # по умолчанию НЕ отсеиваем: активация чисто по whisper
            "drop_filler_only": True,
            "min_chars": 2,
        },
    },
    "tts": {
        "enabled": True,
        "engine": "auto",             # auto|edge|sapi5|piper
        "marker_open": "*-",          # *-текст-*  -> озвучивается
        "marker_close": "-*",
        "edge": {
            "voice": "ru-RU-DmitryNeural",
            "fallback_voice": "ru-RU-SvetlanaNeural",
            "rate": "+0%",
            "pitch": "+0Hz",
            "volume": "+0%",
            "retries": 2,
        },
        "sapi5": {
            "voice": "",              # пусто = первый русский голос Windows
            "rate": 0,                # -10..10
            "volume": 100,
        },
        "piper": {"voice_path": "", "executable": ""},
        "openai": {
            "base_url": "https://api.openai.com/v1",
            "model": "gpt-4o-mini-tts",      # или tts-1 / tts-1-hd
            "voice": "onyx",                 # alloy/echo/fable/onyx/nova/shimmer
        },
        "elevenlabs": {
            "base_url": "https://api.elevenlabs.io",
            "model_id": "eleven_multilingual_v2",
            "voice_id": "21m00Tcm4TlvDq8ikWAM",   # Rachel (multilingual, ру ок)
        },
        "sentence_streaming": True,   # озвучка по предложениям (низкая задержка)
        "min_chunk_chars": 30,
        "max_chunk_chars": 400,
        "speak_tool_status": False,
        "cleanup_markdown": True,
        "volume": 1.0,
    },
    "llm": {
        "endpoint": "http://localhost:11434",
        "cloud_endpoint": "https://ollama.com",
        "model": "gemma4:31b-cloud",   # по умолчанию как в ТЗ
        "fallback_models": ["gemma4:12b", "gemma4:e4b", "llama3.1:8b"],
        "api_key": "",                 # OLLAMA_API_KEY для облачных моделей
        "prefer_cloud_endpoint": False,
        # Подключения в стиле Open WebUI (Admin → Подключения):
        #   Ollama API  -> endpoint выше (нативный /api/chat)
        #   API OpenAI  -> список base_url + ключей (OpenAI-совместимые /v1)
        # Заполняются автоматически из env, если заданы (как в Open WebUI):
        #   OLLAMA_BASE_URL, OPENAI_API_BASE_URLS, OPENAI_API_KEYS
        "connections": [],             # [{"name","base_url","api_key","model"}]
        "temperature": 0.4,
        "top_p": 0.95,
        "num_ctx": 16384,
        "num_predict": 2048,
        "max_tool_rounds": 8,
        "max_tool_calls": 12,        # защита от циклов (remember x8, search x8)
        "timeout_sec": 240,
        "keep_alive": "15m",
        "stream": True,
        "system_prompt_extra": "",
    },
    "keys": {
        # Вставил ключ - движок включился сам (порядок см. README §8.1):
        "groq": "",          # бесплатный STT whisper-large-v3-turbo (console.groq.com)
        "openai": "",        # STT whisper-1/gpt-4o-transcribe + TTS /audio/speech
        "elevenlabs": "",    # TTS eleven_multilingual_v2 (отличный русский)
    },
    "search": {
        "enabled": True,
        "searxng_url": "http://localhost:8888",
        "fallback_ddg": True,
        "max_results": 6,
        "session_cap": 250,         # максимум показанных результатов за запрос
        "safesearch": 1,
        "language": "ru-RU",
        "timeout_sec": 12,
        "fetch_timeout_sec": 20,
        "fetch_max_chars": 12000,
    },
    "stream": {
        "chunk_sec": 3.0,        # как часто прослушиваем новый кусок звука
        "overlap_sec": 0.4,      # (курсоровая схема: нахлёст не нужен, оставлено
                                 #  для совместимости со старыми конфигами)
        "word_idle_sec": 5.0,    # whisper молчит 5 c ПОСЛЕ ПОСЛЕДНЕГО СЛОВА ->
                                 # сообщение закончено и уходит модели ЦЕЛИКОМ
                                 # (настраивается в меню и в консоли)
        "keep_sec": 8.0,         # сколько секунд слов держать для поиска «флюкс»
        "max_message_sec": 60.0, # предохранитель: длинный монолог режем на 60 c
        "max_window_sec": 30.0,  # максимум звука, который догоняем за один раз
        "max_chunk_sec": 10.0,   # если whisper не успевает — режем кусок до 10 c
    },
    # «Как whisper отправляет Флюксу»: локальный HTTP-приёмник
    # POST http://127.0.0.1:8793/v1/audio/transcriptions (multipart file=звук)
    # или POST /text {"text": "..."} — текст уходит в тот же поток слов.
    "whisper_server": {
        "enabled": True,
        "host": "127.0.0.1",
        "port": 8793,
    },
    # «whisper сохранил .txt»: FLUX смотрит папку и отправляет текст ИИ
    # ЦЕЛИКОМ (без таймера: файл = уже законченное сообщение). Обработанный
    # файл уезжает в done/. Отключается одной ручкой bridge.enabled.
    "bridge": {
        "enabled": True,
        "txt_dir": "",            # "" = data\inbox внутри папки FLUX
        "poll_sec": 1.0,
    },
    "memory": {
        "enabled": True,
        "auto_recall": True,
        "auto_remember": True,
        "history_messages": 24,
        "summarize_after": 60,
        "max_recall_items": 6,
    },
    # Поведение агента по умолчанию (пилюли DeepThink / DeepSearch из консоли
    # теперь действуют и на ГОЛОСОВЫЕ команды, а не только на чат).
    "agent": {
        "think_by_default": False,   # «Глубокое мышление» для каждого запроса
        "web_by_default": False,     # «Умный поиск» перед каждым ответом
        "voice_think": True,         # голосовые команды тоже думают (think)
        "voice_web": True,           # голосовые команды тоже ищут в интернете
        "max_think_chars": 4000,     # предел блока «Размышление» для консоли
    },
    "security": {
        # Подтверждения опасных действий ВЫКЛЮЧЕНЫ: Флюкс — агент ПК и действует
        # сразу. Крючок остаётся для тех, кто хочет вернуть вопросы вручную.
        "confirm_destructive": False,
        "allow_shell": True,
        "allow_file_write": True,
        "allow_computer_use": True,
        "allow_device_control": True,
        "allow_power_actions": True,
        "denied_path_parts": [
            "\\windows\\system32\\config", "\\windows\\syswow64\\config",
            "\\boot\\", "\\efi\\", "bootmgr", "\\windows\\system32\\drivers\\etc\\hosts.bak",
        ],
        "max_file_read_bytes": 8_000_000,
        "max_file_write_bytes": 40_000_000,
    },
    "ui": {
        "enabled": True,
        "host": "127.0.0.1",
        "port": 8790,
        "open_on_start": True,
        "show_tool_log": True,
    },
    "autostart": {"enabled": False, "start_minimized": True},
    "devices": {
        "scan_threads": 64,
        "ping_timeout_sec": 0.6,
        "wol_broadcast": "255.255.255.255",
        "wol_port": 9,
        "include_printers": True,
        "include_bluetooth": True,
    },
    "logging": {
        "level": "INFO",
        "file": "logs/flux.log",
        "max_bytes": 5_242_880,
        "backups": 3,
        "console": True,
    },
}

_CONFIG: dict[str, Any] = {}


def _split_list(value: str) -> list[str]:
    return [x.strip() for x in value.replace(";", ",").split(",") if x.strip()]


def _apply_env_overrides(cfg: dict) -> dict:
    """Поведение как в Open WebUI: env-переменные подключений применяются
    при старте, если пользователь не задал подключения вручную."""
    env_base = os.environ.get("OLLAMA_BASE_URL", "").strip()
    if env_base:
        cfg.setdefault("llm", {})["endpoint"] = env_base.rstrip("/")
    urls = _split_list(os.environ.get("OPENAI_API_BASE_URLS", ""))
    keys = _split_list(os.environ.get("OPENAI_API_KEYS", ""))
    if urls and not cfg.get("llm", {}).get("connections"):
        conns = []
        for i, u in enumerate(urls):
            conns.append({
                "name": f"openai-{i + 1}",
                "base_url": u.rstrip("/"),
                "api_key": keys[i] if i < len(keys) else "",
                "model": "",
            })
        cfg.setdefault("llm", {})["connections"] = conns
    return cfg


def _deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def config_file() -> "os.PathLike[str]":
    return paths.CONFIG_FILE


def load(force: bool = False) -> dict[str, Any]:
    """Загружает config.json, дополняя недостающие ключи значениями по умолчанию."""
    global _CONFIG
    with _LOCK:
        if _CONFIG and not force:
            return _CONFIG
        paths.ensure_dirs()
        user_cfg: dict[str, Any] = {}
        cf = paths.CONFIG_FILE
        if cf.exists():
            try:
                user_cfg = json.loads(cf.read_text(encoding="utf-8"))
                if not isinstance(user_cfg, dict):
                    user_cfg = {}
            except Exception:
                try:
                    cf.replace(cf.with_suffix(".bad"))
                except OSError:
                    pass
                user_cfg = {}
        _CONFIG = _apply_env_overrides(_deep_merge(DEFAULTS, user_cfg))
        # стоп-основы детектора - настраиваемый список (дефолт из wakeword)
        from .wakeword import STOP_STEMS as _WAKE_STOP_STEMS
        _CONFIG.setdefault("wake", {}).setdefault(
            "stop_stems", list(_WAKE_STOP_STEMS))
        return _CONFIG


def get(dotted: str, default: Any = None) -> Any:
    cfg = load()
    node: Any = cfg
    for part in dotted.split("."):
        if isinstance(node, dict) and part in node:
            node = node[part]
        else:
            return default
    return node


def set_value(dotted: str, value: Any, save: bool = True) -> None:
    cfg = load()
    parts = dotted.split(".")
    node = cfg
    for part in parts[:-1]:
        node = node.setdefault(part, {})
        if not isinstance(node, dict):
            raise TypeError(f"не могу записать в {dotted}")
    node[parts[-1]] = value
    if save:
        save_config()


def update(mapping: dict[str, Any], save: bool = True) -> None:
    global _CONFIG
    with _LOCK:
        _CONFIG = _deep_merge(load(), mapping)
        if save:
            save_config()


def save_config() -> None:
    with _LOCK:
        cfg = _CONFIG or DEFAULTS
        paths.ensure_dirs()
        tmp = paths.CONFIG_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, paths.CONFIG_FILE)


def as_dict() -> dict[str, Any]:
    return copy.deepcopy(load())


def reset_to_defaults() -> None:
    global _CONFIG
    with _LOCK:
        _CONFIG = copy.deepcopy(DEFAULTS)
        save_config()


def data_path(relative: str) -> "os.PathLike[str]":
    """Путь внутри HOME (data/, logs/, models/ ...)."""
    p = paths.HOME / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    return p
