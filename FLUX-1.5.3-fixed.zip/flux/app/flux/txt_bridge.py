"""Мост «whisper пишет .txt -> FLUX отправляет ИИ целиком».

Пользователь спросил: «ПО ФАКТУ WHISPER ОТПРАВЛЯЕТ .TXT — ОН СОХРАНЯЕТ В .TXT,
А ФЛЮКС НЕ ЗНАЕТ ЭТОГО». Разбираем по фактам:

  * faster-whisper (наш основной движок) — это БИБЛИОТЕКА: она ничего не
    пишет на диск, а возвращает текст и слова с метками времени прямо в
    память FLUX (voice/utterance.py). Файл .txt не появляется вовсе;
  * а вот ОТДЕЛЬНЫЕ программы-whisper действительно сохраняют .txt:
    whisper.cpp по умолчанию кладёт рядом <файл>.txt, Buzz умеет
    экспортировать транскрипт в txt, скрипты людей пишут txt в папку.

Поэтому у FLUX ТРИ способа принять результат whisper (все отправляют ИИ
ОДНО целое сообщение, см. voice/stream.py):

  1. библиотекой: локальный faster-whisper внутри FLUX (основной путь);
  2. по HTTP: POST http://127.0.0.1:8793/v1/audio/transcriptions или /text
     (whisper_server.py) — для любого внешнего whisper-сервера;
  3. ПАПКОЙ (этот модуль): положи «ответ.txt» в data\\inbox — FLUX заметит
     файл, прочитает, уберёт слово «флюкс» и отправит текст ИИ ЦЕЛИКОМ,
     а обработанный файл перенесёт в data\\inbox\\done (ничего не теряем
     и не читаем дважды).

Пустые файлы и галлюцинации whisper («субтитры», «спасибо за просмотр»)
отбрасываются тем же фильтром stt/filter.py, что и голосовой поток.
"""
from __future__ import annotations

import os
import threading
import time
from typing import Callable, Optional

from . import config, logger

log = logger.get_logger("flux.bridge.txt")


def default_dir() -> str:
    """data/inbox внутри установочной папки FLUX."""
    return str(config.data_path("inbox"))


class TxtBridge:
    """Наблюдатель папки: новый .txt = готовое сообщение пользователя."""

    def __init__(self, on_message: Callable[[str, str], bool],
                 directory: Optional[str] = None,
                 poll_sec: Optional[float] = None) -> None:
        self.on_message = on_message
        self.directory = str(directory
                             or config.get("bridge.txt_dir", "")
                             or default_dir())
        self.poll_sec = float(poll_sec or config.get("bridge.poll_sec", 1.0))
        self.enabled = bool(config.get("bridge.enabled", True))
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.processed_count = 0
        self.last_file = ""
        self.last_error = ""

    # ------------------------------------------------------------------ scan
    def scan_once(self) -> list[str]:
        """Файлы .txt в папке, старые первыми (порядок = порядок сообщений)."""
        try:
            names = os.listdir(self.directory)
        except OSError:
            return []
        out = []
        for fn in names:
            if not fn.lower().endswith(".txt"):
                continue
            path = os.path.join(self.directory, fn)
            if os.path.isfile(path):
                out.append(path)
        return sorted(out, key=lambda p: os.path.getmtime(p))

    def process_file(self, path: str) -> bool:
        """Прочитать .txt, отдать как целое сообщение, убрать файл в done/."""
        try:
            with open(path, encoding="utf-8-sig", errors="replace") as f:
                text = f.read()
        except OSError as e:
            self.last_error = f"{os.path.basename(path)}: {e}"
            log.warning("не смог прочитать %s: %s", path, e)
            return False
        if not text.strip():
            # пустой .txt — не сообщение: архивируем, чтобы не спамить
            self._archive(path)
            return False
        taken = bool(self.on_message(text, "txt-bridge"))
        self._archive(path)
        if taken:
            self.processed_count += 1
            self.last_file = os.path.basename(path)
        return taken

    def _archive(self, path: str) -> None:
        done = os.path.join(self.directory, "done")
        try:
            os.makedirs(done, exist_ok=True)
            dst = os.path.join(done, os.path.basename(path))
            if os.path.exists(dst):
                stem, ext = os.path.splitext(os.path.basename(path))
                dst = os.path.join(done, f"{stem}-{int(time.time() * 1000)}{ext}")
            os.replace(path, dst)
        except OSError as e:  # pragma: no cover - диск/права
            self.last_error = f"archive {os.path.basename(path)}: {e}"
            log.warning("не смог убрать %s в done/: %s", path, e)

    # ----------------------------------------------------------------- thread
    def _loop(self) -> None:
        log.info("txt-мост смотрит в %s (каждые %.1f c)", self.directory,
                 self.poll_sec)
        while not self._stop.wait(self.poll_sec):
            try:
                for path in self.scan_once():
                    if self._stop.is_set():
                        break
                    self.process_file(path)
            except Exception as e:  # pragma: no cover - наблюдатель не падает
                self.last_error = str(e)
                log.warning("txt-мост: сбой цикла: %s", e)

    def start(self) -> bool:
        if not self.enabled or self._thread is not None:
            return False
        try:
            os.makedirs(self.directory, exist_ok=True)
        except OSError as e:  # pragma: no cover
            log.warning("txt-мост: не создал папку %s: %s", self.directory, e)
            return False
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="flux-txt-bridge",
                                        daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

    def reload(self) -> None:
        """Перечитать настройки (включён/папка/период) без перезапуска FLUX."""
        was = self.running
        self.stop()
        self.__init__(self.on_message)  # type: ignore[misc]
        if was or self.enabled:
            self.start()

    @property
    def running(self) -> bool:
        return self._thread is not None

    def info(self) -> dict:
        return {"enabled": self.enabled, "running": self.running,
                "dir": self.directory, "poll_sec": self.poll_sec,
                "processed": self.processed_count,
                "last_file": self.last_file, "last_error": self.last_error}
