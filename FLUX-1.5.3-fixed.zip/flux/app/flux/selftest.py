"""Самотест FLUX: проверяет ВСЁ, что нужно для работы, и пишет отчёт.

Запуск:  python -m flux.selftest [--quick]
Инсталлер вызывает его после установки и показывает результат в меню
(кнопка «Диагностика»). Отчёт дублируется в logs/selftest_<время>.txt.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import sys
import time
import wave
from dataclasses import dataclass, field

from . import config, logger, paths

log = logger.get_logger("flux.selftest")

REQUIRED_MODULES = [
    ("numpy", "numpy"), ("requests", "requests"), ("sounddevice", "sounddevice"),
    ("faster-whisper", "faster_whisper"), ("edge-tts", "edge_tts"),
    ("PyAV", "av"), ("Pillow", "PIL"), ("psutil", "psutil"),
    ("mss", "mss"), ("pypdf", "pypdf"), ("python-docx", "docx"),
    ("openpyxl", "openpyxl"), ("python-pptx", "pptx"),
    ("beautifulsoup4", "bs4"), ("pystray", "pystray"),
]
OPTIONAL_MODULES = [
    ("webrtcvad (VAD)", "webrtcvad"), ("pyttsx3 (офлайн TTS)", "pyttsx3"),
    ("pyautogui (computer use)", "pyautogui"), ("keyboard (hotkey)", "keyboard"),
    ("pynput (hotkey fallback)", "pynput"), ("pycaw (громкость)", "pycaw"),
    ("comtypes (громкость)", "comtypes"),
]


@dataclass
class Check:
    name: str
    ok: bool
    detail: str = ""
    warn: bool = False


@dataclass
class Report:
    checks: list[Check] = field(default_factory=list)
    started: float = field(default_factory=time.time)
    finished: float = 0.0

    def add(self, name: str, ok: bool, detail: str = "", warn: bool = False) -> None:
        self.checks.append(Check(name, ok, detail, warn))
        mark = "OK  " if ok else ("WARN" if warn else "FAIL")
        print(f"[{mark}] {name}" + (f" — {detail}" if detail else ""))

    @property
    def ok(self) -> bool:
        return all(c.ok or c.warn for c in self.checks)

    @property
    def failed(self) -> list[Check]:
        return [c for c in self.checks if not c.ok and not c.warn]

    def as_text(self) -> str:
        lines = [f"FLUX selftest {time.strftime('%Y-%m-%d %H:%M:%S')}",
                 f"python {platform.python_version()} | {platform.platform()}",
                 "-" * 70]
        for c in self.checks:
            mark = "OK  " if c.ok else ("WARN" if c.warn else "FAIL")
            lines.append(f"[{mark}] {c.name}" + (f" — {c.detail}" if c.detail else ""))
        lines.append("-" * 70)
        lines.append("ИТОГ: " + ("ВСЁ ГОТОВО" if self.ok else
                                 f"ПРОБЛЕМЫ: {len(self.failed)}"))
        return "\n".join(lines)

    def save(self) -> str:
        paths.ensure_dirs()
        path = paths.LOG_DIR / time.strftime("selftest_%Y%m%d_%H%M%S.txt")
        path.write_text(self.as_text(), encoding="utf-8")
        (paths.LOG_DIR / "selftest_last.json").write_text(
            json.dumps([c.__dict__ for c in self.checks], ensure_ascii=False, indent=2),
            encoding="utf-8")
        return str(path)


def _check_imports(rep: Report, quick: bool) -> None:
    import importlib
    for label, mod in REQUIRED_MODULES:
        try:
            importlib.import_module(mod)
            rep.add(f"модуль {label}", True)
        except Exception as e:
            rep.add(f"модуль {label}", False, str(e))
    for label, mod in OPTIONAL_MODULES:
        try:
            importlib.import_module(mod)
            rep.add(f"опционально {label}", True)
        except Exception:
            rep.add(f"опционально {label}", True, "не установлен (есть запасной путь)",
                    warn=True)


def _check_config(rep: Report) -> None:
    try:
        cfg = config.load(force=True)
        assert isinstance(cfg, dict) and cfg.get("llm", {}).get("model")
        config.set_value("selftest.probe", time.time(), save=False)
        config.save_config()
        rep.add("конфиг читается/пишется", True, str(paths.CONFIG_FILE))
    except Exception as e:
        rep.add("конфиг читается/пишется", False, str(e))


def _check_markup(rep: Report) -> None:
    from .tts_markup import extract_spoken, parse
    try:
        text = ("служебное *-Привет! Я Флюкс. Готов помочь.-* ещё служебное "
                "*-Второй блок-*")
        spoken = extract_spoken(text)
        assert spoken == ["Привет! Я Флюкс. Готов помочь.", "Второй блок"], spoken
        res = parse(text)
        assert "служебное" not in res.spoken_text
        rep.add("разметка озвучки *-...-*", True, f"{len(spoken)} блока")
    except Exception as e:
        rep.add("разметка озвучки *-...-*", False, str(e))


def _check_wakeword(rep: Report) -> None:
    from .wakeword import WakeDetector
    det = WakeDetector(words=["флюкс", "flux"])
    cases = [("Флюкс, включи свет", True), ("флюкс который час", True),
             ("Флюк с которой час.", True), ("Включи свет", False),
             ("плюс два градуса", False), ("Флокс зацвёл", False)]
    bad = [(t, exp, det.check(t).matched) for t, exp in cases
           if det.check(t).matched != exp]
    if bad:
        rep.add("детектор слова-активации", False, f"ошибки: {bad}")
    else:
        rep.add("детектор слова-активации", True, f"{len(cases)} кейсов")


def _raw_device_count() -> int:
    """Сколько записей устройств ЗАПИСИ отдаёт PortAudio ДО схлопывания дублей."""
    try:
        import sounddevice as sd
        return sum(1 for d in sd.query_devices()
                   if int(d.get("max_input_channels", 0) or 0) > 0)
    except Exception:
        pass
    # sounddevice может быть недоступен напрямую (например, в тестах) —
    # считаем через тот же путь, что и боевой код, с выключенным схлопыванием
    try:
        from .audio import devices as devmod
        real = devmod._collapse_enabled
        devmod._collapse_enabled = lambda: False
        try:
            return len(devmod.list_input_devices(include_loopback=True))
        finally:
            devmod._collapse_enabled = real
    except Exception:
        return -1


def _check_audio_devices(rep: Report) -> None:
    from .audio import devices as devmod
    try:
        devs = devmod.list_input_devices()
        if not devs:
            rep.add("микрофоны", False, "устройств записи не найдено")
            return
        loopbacks = devmod.list_input_devices(include_loopback=True)
        hidden = len(loopbacks) - len(devs)
        raw = _raw_device_count()
        chosen = devmod.resolve_input_device(devmod.configured_spec())
        inv = devmod.inventory(loopbacks)
        # полный список - в лог (report.txt рядом с логом установки)
        log.info("устройства записи (%s записей PortAudio -> %s уникальных):\n%s",
                 raw, len(devs), inv)
        dup = (f" (PortAudio перечисляет {raw} записей: один микрофон "
               f"дублируется по API MME/DirectSound/WASAPI)"
               if raw > len(devs) else "")
        head = (f"{len(devs)} шт.{dup}; петлевых отфильтровано: {hidden}")
        if chosen is not None:
            head += f"; выбран: {chosen.name} [индекс {chosen.index}]"
        rep.add("микрофоны", True, head)
        rep.add("инвентаризация микрофонов", True,
                f"{len(devs)} уникальных устройств записи:\n{inv}")
    except Exception as e:
        rep.add("микрофоны", False, str(e))
        return
    try:
        res = devmod.mic_self_test(2.0)
        if not res.get("ok"):
            rep.add("запись с микрофона", False, res.get("error", ""))
        else:
            # Тракт ДО whisper: сырой сигнал, байт-в-байт. Никакого AGC,
            # шумодава и нормализации (правило пользователя + практика Buzz):
            # «извлечение речи» делает Silero VAD ВНУТРИ faster-whisper.
            import numpy as _np
            raw_peak = res.get("peak", 0.0)
            detail = (f"{res['device']}: сырой пик {raw_peak:.4f} "
                      f"({20 * _np.log10(raw_peak + 1e-9):.0f} dBFS); "
                      f"в whisper уходит БЕЗ изменений (AGC/шумодав удалены)")
            if raw_peak < 0.0005:
                detail += (" | СЫРОЙ МИКРОФОН ОЧЕНЬ ТИХИЙ: подними громкость/"
                           "усиление микрофона в Windows (Параметры -> Система ->"
                           " Звук -> Микрофон -> Уровень/Усиление). FLUX звук"
                           " не усиливает намеренно")
            rep.add("запись с микрофона", True, detail,
                    warn=raw_peak < 0.0002)
    except Exception as e:
        rep.add("запись с микрофона", False, str(e))


def _check_playback(rep: Report) -> None:
    """Устройство воспроизведения: откроется ли поток и пишется ли звук.
    Доказательство, что серверная озвучка может играть (не только браузер)."""
    try:
        import sounddevice as sd
        import numpy as np
        with sd.OutputStream(samplerate=24000, channels=1, dtype="float32",
                             blocksize=1024) as st:
            st.write(np.zeros((2400, 1), dtype=np.float32))
        rep.add("устройство воспроизведения", True,
                "поток 24 кГц открыт, тестовая тишина записана")
    except Exception as e:
        rep.add("устройство воспроизведения", False,
                f"не удалось открыть выходной поток: {e}")


def _check_endpointer(rep: Report) -> None:
    import numpy as np

    from .audio.endpointer import Endpointer

    class Stub:
        engine = "stub"
        noise_floor = 0.0

        def is_speech(self, samples, frame_ms=30):
            from .audio.vad import rms_float
            return rms_float(samples) > 0.02

    clock = {"t": 0.0}
    ep = Endpointer(sample_rate=16000, frame_ms=30, silence_timeout=5.0,
                    vad=Stub(), clock=lambda: clock["t"])
    frame = int(16000 * 0.03)
    speech = (np.sin(np.linspace(0, 40, frame)) * 6000).astype(np.int16)
    silence = np.zeros(frame, dtype=np.int16)
    segs = 0
    for i in range(16):                       # 0.48 c речи
        clock["t"] += 0.03
        for ev in ep.push(speech):
            segs += ev.kind == "segment"
    for i in range(200):                      # 6 c тишины -> закрытие через ~5 c
        clock["t"] += 0.03
        for ev in ep.push(silence):
            if ev.kind == "segment":
                segs += 1
                dur = ev.segment.total_seconds
    if segs == 1 and 5.2 <= dur <= 5.8:
        rep.add("правило «5 секунд на продолжение»", True, f"сегмент {dur:.2f} c")
    else:
        rep.add("правило «5 секунд на продолжение»", False,
                f"сегментов={segs}, dur={dur if segs else '-'}")


def _check_tts(rep: Report, quick: bool) -> str | None:
    """Возвращает путь к синтезированному mp3 для дальнейшей проверки STT."""
    from .audio.player import decode_audio_file
    from .tts.engine import TTSRouter

    router = TTSRouter()
    text = "Флюкс на связи. Проверка озвучки."
    path = paths.AUDIO_DIR / "selftest_tts.mp3"
    got, engine = router.synthesize(text, str(path))
    if not got:
        rep.add("озвучка (edge-tts/запас)", False,
                "ни один движок не синтезировал (нужен интернет или голоса Windows)")
        return None
    try:
        data, sr = decode_audio_file(got, target_sr=16000)
        wav = paths.AUDIO_DIR / "selftest_tts.wav"
        with wave.open(str(wav), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
            w.writeframes((data * 32767).astype("<i2").tobytes())
        rep.add("озвучка (edge-tts/запас)", True,
                f"движок {engine}, {len(data) / 16000:.1f} c")
        return str(wav)
    except Exception as e:
        rep.add("озвучка (edge-tts/запас)", False, f"декодирование: {e}")
        return None


def _check_stt_model(rep: Report, quick: bool) -> None:
    """Главная модель распознавания: реально ли она доступна на этой машине.

    Если выбранная модель не скачалась/не загрузилась, FLUX сам уходит на
    более лёгкую (stt.local.model_fallback) — но пользователь обязан об этом
    знать, поэтому пишем WARN с причиной и советом.
    """
    from .stt import local as local_stt

    size = str(config.get("stt.local.model", "large-v3-turbo"))
    if quick:
        rep.add("модель распознавания (выбор в консоли)", True,
                f"выбрана {size}; быстрая проверка пропущена (--quick)", warn=True)
        return
    t0 = time.time()
    try:
        _, eff = local_stt.get_model(size)
        dt = time.time() - t0
        if eff != size:
            err = local_stt.last_error().get("error", "")[:160]
            rep.add("модель распознавания (выбор в консоли)", True,
                    f"{size} недоступна ({err}) — работаю на {eff}; "
                    f"скачай её или выбери другую в консоли (⚙ → Понимание речи)",
                    warn=True)
        else:
            rep.add("модель распознавания (выбор в консоли)", True,
                    f"{eff} загружена за {dt:.1f} c "
                    f"({local_stt.status()['device']}/"
                    f"{local_stt.status()['compute_type']})")
    except Exception as e:
        rep.add("модель распознавания (выбор в консоли)", False,
                f"ни одна модель не загрузилась: {e}")


def _check_whole_message(rep: Report) -> None:
    """Правило пользователя: whisper сам решает, когда фраза закончена, и
    отдаёт FLUX ОДНО целое сообщение (а не куски и не догадки по громкости)."""
    try:
        from .stt.base import Transcript
        from .voice.stream import WordStream
        from .wakeword import WakeDetector

        st = WordStream(WakeDetector(words=tuple(config.get(
                            "wake.words", ["флюкс"]) or ["флюкс"]),
                            sensitivity=int(config.get("wake.sensitivity", 0))),
                        word_idle_sec=float(config.get("stream.word_idle_sec", 5.0)),
                        wake_idle_sec=float(config.get("audio.wake_silence_sec", 1.2)),
                        max_message_sec=float(config.get("stream.max_message_sec", 60.0)))
        sends: list = []
        pos = 0.0
        for text in ("флюкс", "включи свет", "на кухне"):
            pos += 3.0
            tr = Transcript(text=text, engine="selftest", model="-",
                            duration=3.0, window_sec=3.0)
            for ev in st.feed(text=text, tr=tr, end_sec=pos, sec=3.0):
                if ev.kind == "send":
                    sends.append(ev)
        if sends:
            rep.add("сообщение целиком (одно целое от whisper)", False,
                    "отправили раньше, чем whisper замолчал")
            return
        idle = float(config.get("stream.word_idle_sec", 5.0))
        for _ in range(3):
            pos += 3.0
            tr = Transcript(text="", engine="selftest", model="-",
                            duration=3.0, window_sec=3.0)
            for ev in st.feed(text="", tr=tr, end_sec=pos, sec=3.0):
                if ev.kind == "send":
                    sends.append(ev)
        if len(sends) != 1:
            rep.add("сообщение целиком (одно целое от whisper)", False,
                    f"отправок {len(sends)} вместо одной")
            return
        utt = sends[0].utterance
        rep.add("сообщение целиком (одно целое от whisper)", True,
                f"«{utt.text}» — {utt.word_count} записей, тишина "
                f"{utt.silence_sec:.1f} c (порог {idle:.1f} c), одна отправка")
    except Exception as e:
        rep.add("сообщение целиком (одно целое от whisper)", False, str(e))


def _check_whisper_server(rep: Report) -> None:
    """«Как whisper отправляет Флюксу»: локальный HTTP-приёмник звука/текста."""
    import io
    import json
    import urllib.request
    import wave

    import numpy as np

    from .stt.base import Transcript
    from .whisper_server import WhisperServer

    if not bool(config.get("whisper_server.enabled", True)):
        rep.add("whisper-сервер (приём звука от внешнего whisper)", True,
                "выключен в настройках", warn=True)
        return
    port = int(config.get("whisper_server.port", 8793)) + 7
    got: list = []
    srv = WhisperServer(
        transcribe=lambda audio, sr: Transcript(text="флюкс включи свет",
                                                engine="selftest", model="-"),
        on_words=got.append)
    old_port = int(config.get("whisper_server.port", 8793))
    config.set_value("whisper_server.port", port, save=False)
    started = False
    try:
        started = srv.start()
        if not started:
            rep.add("whisper-сервер (приём звука от внешнего whisper)", False,
                    srv.last_error or f"не стартовал на порту {port}")
            return
        pcm = (np.sin(np.linspace(0, 90, 16000)) * 6000).astype(np.int16)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(16000)
            w.writeframes(pcm.tobytes())
        body = (b"--FLUXSELF\r\nContent-Disposition: form-data; name=\"file\"; "
                b"filename=\"s.wav\"\r\nContent-Type: audio/wav\r\n\r\n"
                + buf.getvalue() + b"\r\n--FLUXSELF--\r\n")
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}/v1/audio/transcriptions", data=body,
            headers={"Content-Type": "multipart/form-data; boundary=FLUXSELF"},
            method="POST")
        with urllib.request.urlopen(req, timeout=20) as r:
            ans = json.loads(r.read().decode("utf-8"))
        ok = bool(ans.get("text")) and got == ["флюкс включи свет"]
        rep.add("whisper-сервер (приём звука от внешнего whisper)", ok,
                f"POST /v1/audio/transcriptions -> {ans.get('text')!r}; "
                f"текст попал в поток слов FLUX: {got!r}"
                if ok else f"ответ {ans!r}, в поток попало {got!r}")
    except Exception as e:
        rep.add("whisper-сервер (приём звука от внешнего whisper)", False, str(e))
    finally:
        srv.stop()
        try:
            config.set_value("whisper_server.port", old_port, save=False)
        except Exception:
            pass


def _check_stt(rep: Report, wav_path: str | None, quick: bool) -> None:
    from .stt.local import LocalWhisperSTT
    from .wakeword import WakeDetector

    stt = LocalWhisperSTT(size=str(config.get("stt.local.wake_model", "base")))
    if wav_path is None:
        # без интернета: синтезируем речь сами (синус-имитация не подойдёт),
        # поэтому проверяем только загрузку модели на тишине
        try:
            import numpy as np
            tr = stt.transcribe_audio(np.zeros(16000, dtype=np.int16), 16000)
            rep.add("whisper (загрузка модели)", True,
                    f"модель {stt.size}, тишина -> {tr.text!r}")
        except Exception as e:
            rep.add("whisper (загрузка модели)", False, str(e))
        return
    words = tuple(config.get("wake.words", ["флюкс"]) or ["флюкс"])
    sens = int(config.get("wake.sensitivity", 0))
    rep.add("слово активации", True,
            f"«{', '.join(words)}», чувствительность {sens} "
            f"(0=строгое совпадение)")
    try:
        from .audio.player import decode_audio_file
        from .stt.router import STTRouter
        data, sr = decode_audio_file(wav_path, target_sr=16000)
        audio = (data * 32767.0).astype("<i2")
        t0 = time.time()
        # проверяем ТОТ же путь, что в бою: роутер (Groq/OpenAI -> local)
        tr = STTRouter().transcribe(audio, 16000)
        dt = time.time() - t0
        det = WakeDetector(words=words, sensitivity=sens)
        m = det.check(tr.text)
        if m.matched:
            rep.add("whisper + детектор на живой речи", True,
                    f"[{tr.engine}] {tr.text!r} за {dt:.1f} c -> команда {m.command!r}")
        else:
            rep.add("whisper + детектор на живой речи", False,
                    f"[{tr.engine}] распознано {tr.text!r}, слово не найдено "
                    f"(слово активации: {', '.join(words)})")
    except Exception as e:
        rep.add("whisper + детектор на живой речи", False, str(e))


def _check_stt_ollama(rep: Report, wav_path: str | None) -> None:
    """Локальный whisper в Ollama (mannix/whisper:large-v3-turbo)."""
    from .stt.ollama_asr import OllamaWhisperSTT
    from .wakeword import WakeDetector

    stt = OllamaWhisperSTT()
    if not stt.enabled():
        rep.add("whisper в Ollama", True, "выключен в настройках (stt.ollama.enabled)",
                warn=True)
        return
    base = stt.probe(ttl=0)
    if base is None:
        # ЗАПАСНОЙ путь: основной движок — локальный faster-whisper, поэтому
        # недоступность whisper-эндпоинта это WARN, а не поломка установки
        rep.add("whisper в Ollama (запасной путь)", True,
                f"эндпоинты {stt.bases()} не отвечают. Оно и не нужно: в API "
                f"сток-Ollama нет /audio/transcriptions (docs.ollama.com/api, "
                f"ollama/ollama#1168), поэтому модель mannix/whisper там "
                f"скачивается, но не запускается. Распознавание работает "
                f"локальным faster-whisper", warn=True)
        return
    if not stt.model_present():
        rep.add("whisper в Ollama (запасной путь)", True,
                f"{base} отвечает, но модели whisper там нет (в API сток-Ollama "
                f"нет транскрипции). Работает локальный faster-whisper",
                warn=True)
        return
    if not wav_path:
        rep.add("whisper в Ollama", True,
                f"эндпоинт {base} жив, модель {stt.model} "
                f"(проверка текста пропущена: нет синтезированной речи)", warn=True)
        return
    try:
        with open(wav_path, "rb") as f:
            tr = stt.transcribe_wav(f.read())
        det = WakeDetector(words=tuple(config.get("wake.words", ["флюкс"])))
        m = det.check(tr.text)
        if tr.text and m.matched:
            rep.add("whisper в Ollama", True,
                    f"{base}: {tr.text!r} за {tr.duration:.1f} c -> команда {m.command!r}")
        elif tr.text:
            rep.add("whisper в Ollama", True,
                    f"{base}: распознано {tr.text!r} (слово-активация не требуется "
                    f"для этого сэмпла)", warn=True)
        else:
            rep.add("whisper в Ollama", False, f"{base}: пустой ответ")
    except Exception as e:
        # сток-Ollama модель перечисляет, но транскрипцию не умеет (404),
        # либо не поднят отдельный whisper-сервер: это НЕ поломка - работает
        # фолбэк на локальный faster-whisper
        rep.add("whisper в Ollama", True,
                f"{base}: эндпоинт транскрипцию не отдаёт ({str(e)[:90]}). "
                f"Распознавание идёт локальным faster-whisper - как в Open WebUI",
                warn=True)


def _check_keys(rep: Report) -> None:
    """Пинг вставленных API-ключей (Groq/OpenAI/ElevenLabs) + расшифровка.

    Логика и тексты причин — в общем модуле flux.keys (его же использует
    кнопка «Проверить ключи» в веб-консоли), чтобы самотест и консоль не
    противоречили друг другу.
    """
    from . import keys as keymod

    results = keymod.check_all(lambda name: config.get(f"keys.{name}", ""))
    if not results:
        rep.add("API-ключи", True,
                "не заданы: работают локальные движки (faster-whisper, SAPI5/edge)",
                warn=True)
        return
    for name, r in results.items():
        rep.add(f"ключ {name}", bool(r.get("ok")), str(r.get("detail", "")),
                warn=bool(r.get("warn")))


def _check_searxng(rep: Report) -> None:
    from .tools.web import search
    url = config.get("search.searxng_url")
    results, source = search("тестовый запрос флюкс", 3)
    if source == "searxng":
        rep.add("SearXNG (поиск)", True, f"{url}, результатов: {len(results)}")
    elif results:
        rep.add("SearXNG (поиск)", True,
                f"SearXNG недоступен, сработал запасной {source}", warn=True)
    else:
        rep.add("SearXNG (поиск)", False,
                f"{url} не отвечает и запасной поиск не сработал")


def _check_ollama(rep: Report) -> None:
    from .llm.ollama_client import OllamaClient
    client = OllamaClient()
    info = client.ping()
    model = config.get("llm.model")
    conns = client.connections()
    if conns:
        alive = []
        for c in conns:
            try:
                import requests as _rq
                h = {"Authorization": f"Bearer {c['api_key']}"} if c["api_key"] else {}
                r = _rq.get(c["base_url"] + "/models", headers=h, timeout=5)
                if r.status_code in (200, 401):
                    alive.append(c["name"])
            except Exception:
                pass
        rep.add("OpenAI-подключения (как в Open WebUI)", bool(alive),
                f"живых: {len(alive)}/{len(conns)} {alive or ''}",
                warn=not alive)
    if info["model_ok"]:
        rep.add("Ollama + модель", True, f"{model} ({info['detail']})")
    elif info["local"]:
        rep.add("Ollama + модель", False,
                f"сервер есть, но модель {model} не ответила: {info['detail']}")
    else:
        rep.add("Ollama + модель", False,
                f"локальный Ollama недоступен: {info['detail']}")


def _check_memory(rep: Report) -> None:
    from .memory.store import MemoryStore
    tmp = paths.TMP_DIR / "selftest_memory.db"
    store = MemoryStore(str(tmp))
    try:
        cid = store.new_conversation("самотест")
        store.add_message(cid, "user", "привет")
        mid = store.remember("самотестный факт")
        assert store.recall("самотестный")[0]["id"] == mid
        store.forget("самотестный")
        rep.add("память (SQLite/FTS)", True, str(tmp))
    except Exception as e:
        rep.add("память (SQLite/FTS)", False, str(e))
    finally:
        store.close()
        try:
            os.remove(tmp)
        except OSError:
            pass


def _check_tools(rep: Report) -> None:
    from .tools import import_all, registry
    names = import_all()
    problems = []
    for name in ("current_time", "system_info"):
        res = registry.dispatch(name, {}, None)
        if not res.ok:
            problems.append(f"{name}: {res.text}")
    schemas = registry.schemas()
    if problems:
        rep.add("инструменты", False, "; ".join(problems))
    else:
        rep.add("инструменты", True, f"{len(names)} шт., схем для LLM: {len(schemas)}")


def _check_hotkey(rep: Report) -> None:
    backends = []
    for mod in ("keyboard", "pynput"):
        try:
            __import__(mod)
            backends.append(mod)
        except Exception:
            pass
    if os.name != "nt":
        rep.add("горячая клавиша Numpad 9", True,
                "проверяется на Windows; бэкенды: " + ",".join(backends) or "-",
                warn=True)
    elif backends:
        rep.add("горячая клавиша Numpad 9", True, "бэкенды: " + ",".join(backends))
    else:
        rep.add("горячая клавиша Numpad 9", False,
                "нет ни keyboard, ни pynput (останется ctypes-hook)")


def _check_ui(rep: Report) -> None:
    import urllib.request

    from .ui.server import UiServer

    class DummyApp:
        def public_state(self):
            return {"state": "selftest"}

        def recent_history(self, limit=40):
            return []

        def console_action(self, action, body):
            return {}

        def resolve_confirmation(self, cid, answer):
            return True

        def on_config_changed(self):
            return None

    port = int(config.get("ui.port", 8790)) + 1
    config.set_value("ui.port", port, save=False)
    srv = UiServer(DummyApp())
    if not srv.start():
        rep.add("веб-консоль", False, f"порт {port} занят")
        return
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=5) as r:
            html = r.read().decode("utf-8", "replace")
        ok = "FLUX" in html and "Настройки" in html
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/state",
                                    timeout=5) as r:
            state = json.loads(r.read())
        rep.add("веб-консоль", ok and state.get("state") == "selftest",
                f"http://127.0.0.1:{port}/ (тестовый порт: +1 к боевому "
                f"{port - 1}, чтобы не мешать запущенному FLUX)")
    except Exception as e:
        rep.add("веб-консоль", False, str(e))
    finally:
        srv.stop()
        config.set_value("ui.port", port - 1, save=False)


def run_selftest(quick: bool = False) -> Report:
    rep = Report()
    print("=" * 70)
    print("FLUX САМОТЕСТ")
    print("=" * 70)
    _check_imports(rep, quick)
    _check_config(rep)
    _check_markup(rep)
    _check_wakeword(rep)
    _check_endpointer(rep)
    _check_audio_devices(rep)
    _check_playback(rep)
    wav = _check_tts(rep, quick)
    _check_stt_ollama(rep, wav)
    _check_stt(rep, wav, quick)
    _check_stt_model(rep, quick)
    _check_whole_message(rep)
    _check_whisper_server(rep)
    _check_keys(rep)
    _check_searxng(rep)
    _check_ollama(rep)
    _check_memory(rep)
    _check_tools(rep)
    _check_hotkey(rep)
    _check_ui(rep)
    rep.finished = time.time()
    path = rep.save()
    print("=" * 70)
    print(rep.as_text())
    print(f"\nотчёт сохранён: {path}")
    return rep


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()
    rep = run_selftest(quick=args.quick)
    return 0 if rep.ok else 1


if __name__ == "__main__":
    sys.exit(main())
