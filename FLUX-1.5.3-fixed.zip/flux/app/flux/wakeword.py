"""Детектор слова-активации («Флюкс») по тексту распознавания речи.

Готовых wake-word моделей под русское слово нет, поэтому используется
надёжный подход: непрерывное распознавание коротких речевых сегментов лёгкой
моделью Whisper + нечёткое фонетическое сравнение первого слова с эталоном.

Учтены РЕАЛЬНЫЕ ошибки распознавания (проверено на faster-whisper, см. отчёт
в tests/test_e2e_voice_real.py):
    «Флюкс, включи свет»  -> "Флюкс включи свет на кухне."     (точно)
    «флюкс который час»   -> "Флюк с которой час."             (слово РАЗБИТО)
    «Флюкс! Найди…»       -> "Флюкс.  Наедивинтер найти…"      (точка, слипание)
    tiny-модель           -> "Флёкс включи сверхно кухне."     (ё/е)

Сравнение идёт в четырёх пространствах: сырая нормализация, компактная форма
(без пробелов - для склеенных токенов), фонетическое свёртывание русских
звуков и латинская транслитерация (для варианта "flux").

Защита от ложных срабатываний (требование ТЗ «чтобы не попадалось лишнее»):
  * слово-активация обязано стоять В НАЧАЛЕ фразы;
  * первый звук обязан совпадать (иначе «люкс»/«плюс» принимались бы за «флюкс»);
  * совпадение с префиксом длинного слова допускается только если покрыта вся
    длина эталона (иначе «флюсовка» -> «флюс» давало бы срабатывание);
  * стоп-основы известных похожих слов («флукту…», «флюоро…», «флокс», «флеш…»).
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Iterable, Sequence

# ---------------------------------------------------------------- normalisation
_PUNCT_RE = re.compile(r"[^\w\s'-]+", re.UNICODE)
_SPACE_RE = re.compile(r"\s+")

FILLERS = {
    "эй", "ей", "ну", "окей", "ок", "okay", "хм", "а", "так", "hey", "well",
    "о", "oh", "ладно", "значит", "слушай",
}

# Основы слов, похожих на «флюкс», но им НЕ являющихся. Настраивается в config.
STOP_STEMS = (
    "флукту", "флюоро", "флюгер", "флюгар", "флеш", "флакс", "флюид", "флокс",
    "флейт", "флор", "флот", "фрукт", "плюск", "минус", "флюорес", "люкс",
    "флюсов", "флюсач", "флексор", "флекси", "плюха", "плюхн",
)

# Русское фонетическое свёртывание: глухие/звонкие + редукция гласных.
_RU_FOLD = {
    "а": "а", "о": "а", "е": "и", "ё": "и", "и": "и", "ы": "и", "у": "у",
    "ю": "у", "я": "а", "э": "и",
    "б": "п", "в": "ф", "г": "к", "д": "т", "ж": "ш", "з": "с", "й": "и",
    "к": "к", "л": "л", "м": "м", "н": "н", "п": "п", "р": "р", "с": "с",
    "т": "т", "ф": "ф", "х": "х", "ц": "ц", "ч": "ч", "ш": "ш", "щ": "ш",
    "ъ": "", "ь": "",
}

# Кириллица/латиница -> единое латинское фонетическое пространство.
_LAT_FOLD = {
    "а": "a", "о": "a", "е": "i", "ё": "i", "и": "i", "ы": "i", "у": "u",
    "ю": "u", "я": "a", "э": "e", "й": "i", "ъ": "", "ь": "",
    "б": "b", "в": "v", "г": "g", "д": "d", "ж": "zh", "з": "z", "к": "k",
    "л": "l", "м": "m", "н": "n", "п": "p", "р": "r", "с": "s", "т": "t",
    "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sh",
    "a": "a", "b": "b", "c": "k", "d": "d", "e": "i", "f": "f", "g": "k",
    "h": "h", "i": "i", "j": "i", "k": "k", "l": "l", "m": "m", "n": "n",
    "o": "a", "p": "p", "q": "k", "r": "r", "s": "s", "t": "t", "u": "u",
    "v": "f", "w": "f", "x": "ks", "y": "i", "z": "s",
}


def normalize(text: str) -> str:
    """Нижний регистр, ё->е, NFKC, пунктуация -> пробел, схлопывание пробелов."""
    if not text:
        return ""
    s = unicodedata.normalize("NFKC", text).lower().replace("ё", "е")
    s = _PUNCT_RE.sub(" ", s)
    return _SPACE_RE.sub(" ", s).strip()


def normalize_mapped(text: str) -> tuple[str, list[int]]:
    """То же, что normalize, но с картой индексов: norm[i] -> text[j].

    Нужна, чтобы вырезать слово-активацию из ИСХОДНОЙ фразы (с регистром и
    знаками препинания) и отдать модели нормальный текст команды.
    """
    if not text:
        return "", []
    s = unicodedata.normalize("NFKC", text)
    out: list[str] = []
    idx: list[int] = []
    for i, ch in enumerate(s):
        low = ch.lower()
        if low == "ё":
            low = "е"
        if low.isalnum() or low in "'- ":
            out.append(low)
            idx.append(i)
        else:
            out.append(" ")
            idx.append(i)
    # пересчитываем карту после схлопывания пробелов
    mapped: list[int] = []
    res: list[str] = []
    for k, ch in enumerate(out):
        if ch == " " and res and res[-1] == " ":
            continue
        res.append(ch)
        mapped.append(idx[k])
    while res and res[-1] == " ":
        res.pop()
        mapped.pop()
    while res and res[0] == " ":
        res.pop(0)
        mapped.pop(0)
    return "".join(res), mapped


def fold_ru(text: str) -> str:
    return "".join(_RU_FOLD.get(ch, ch) for ch in normalize(text) if ch != " ")


def fold_lat(text: str) -> str:
    out: list[str] = []
    for ch in normalize(text):
        if ch == " ":
            continue
        out.append(_LAT_FOLD.get(ch, ch))
    return "".join(out)


def compact(text: str) -> str:
    return normalize(text).replace(" ", "")


def levenshtein(a: str, b: str) -> int:
    """Расстояние Левенштейна (строки короткие - полное ДП дёшево)."""
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[-1]


def distance_forms(a: str, b: str) -> tuple[int, str]:
    """Минимальное расстояние между двумя строками во всех пространствах."""
    forms_a = {
        "raw": normalize(a), "compact": compact(a),
        "ru": fold_ru(a), "lat": fold_lat(a),
    }
    forms_b = {
        "raw": normalize(b), "compact": compact(b),
        "ru": fold_ru(b), "lat": fold_lat(b),
    }
    best, best_form = 99, ""
    for name in ("raw", "compact", "ru", "lat"):
        x, y = forms_a[name], forms_b[name]
        if not x or not y:
            continue
        d = levenshtein(x, y)
        if d < best:
            best, best_form = d, name
    return best, best_form


def _distance(a: str, b: str) -> int:
    return distance_forms(a, b)[0]


@dataclass
class WakeMatch:
    matched: bool
    wake: str = ""             # как услышано слово-активация
    canonical: str = ""        # эталон из настроек
    distance: int = 99
    confidence: float = 0.0
    command: str = ""          # остаток фразы (исходный текст, без слова)
    span: tuple[int, int] = (-1, -1)   # позиции в нормализованной строке
    form: str = ""             # пространство, в котором совпало

    def __bool__(self) -> bool:
        return self.matched


NOMATCH = WakeMatch(matched=False)

_STRIP_EDGES = " \t\r\n,.;:!?-–—*\"'()"


class WakeDetector:
    """Ищет слово-активацию в начале фразы и возвращает остаток как команду."""

    def __init__(
        self,
        words: Sequence[str] = ("флюкс", "flux"),
        aliases: Sequence[str] = (),
        sensitivity: int = 1,
        require_at_start: bool = True,
        max_leading_fillers: int = 1,
        stop_stems: Sequence[str] = STOP_STEMS,
        require_first_char: bool = True,
    ) -> None:
        canon: list[str] = []
        for w in list(words) + list(aliases):
            w = (w or "").strip().lower()
            if w and w not in canon:
                canon.append(w)
        self.canonical = canon or ["флюкс"]
        self.sensitivity = max(0, min(2, int(sensitivity)))
        self.require_at_start = require_at_start
        self.max_leading_fillers = max(0, int(max_leading_fillers))
        self.stop_stems = tuple(s.lower() for s in stop_stems)
        self.require_first_char = require_first_char and self.sensitivity < 2

    # ------------------------------------------------------------------ tuning
    def max_distance(self, word_len: int) -> int:
        """Порог расстояния. 0=строго, 1=обычно (по умолчанию), 2=мягко."""
        if self.sensitivity == 0:
            return 0
        if self.sensitivity == 2:
            return 2 if word_len <= 7 else 3
        return 1 if word_len <= 7 else 2

    def max_distance_prefix(self, word_len: int) -> int:
        """Порог для совпадения с ПРЕФИКСОМ длинного слова (склеенные токены)."""
        if self.sensitivity == 0:
            return 0
        if self.sensitivity == 2:
            return 2
        return 1

    # ------------------------------------------------------------------- check
    def check(self, text: str) -> WakeMatch:
        if not text or not text.strip():
            return NOMATCH
        norm, index_map = normalize_mapped(text)
        if not norm:
            return NOMATCH

        best: WakeMatch | None = None
        for start in self._candidate_starts(norm):
            m = self._match_from(norm, start)
            if m is not None and (best is None or self._better(m, best)):
                best = m
        if best is None:
            return NOMATCH

        # команда - из ИСХОДНОГО текста (регистр и пунктуация сохраняются)
        end_norm = best.span[1]
        if index_map and end_norm < len(index_map):
            orig_pos = index_map[end_norm]
        else:
            orig_pos = len(text)
        command = text[orig_pos:].strip(_STRIP_EDGES)
        best.command = command
        best.wake = text[index_map[best.span[0]]:orig_pos].strip(_STRIP_EDGES) \
            if index_map and best.span[0] < len(index_map) else best.wake
        return best

    # ---------------------------------------------------------------- internals
    def _candidate_starts(self, norm: str) -> list[int]:
        starts = [0]
        if not self.require_at_start:
            starts += [m.start() for m in re.finditer(r"(?<=\s)\S", norm)]
        elif self.max_leading_fillers > 0:
            pos = 0
            skipped = 0
            for tok in norm.split(" "):
                if skipped >= self.max_leading_fillers or tok not in FILLERS:
                    break
                pos += len(tok) + 1
                skipped += 1
                if pos <= len(norm):
                    starts.append(pos)
        return sorted({s for s in starts if 0 <= s < len(norm)})

    def _full_token_at(self, norm: str, start: int) -> str:
        m = re.compile(r"\S+").search(norm[start:])
        return m.group(0) if m else ""

    def _blocked_by_stop_stem(self, token: str, cand_compact: str = "") -> bool:
        """Известная «похожая, но не наша» основа? Работает и для целых слов.

        Стоп-основа игнорируется, если она является частью самого эталона
        (иначе пользовательское слово-активация «флора» блокировалось бы
        основой «флор»).
        """
        token = normalize(token)
        if not token:
            return False
        for c in self.canonical:
            cc = compact(c)
            if cc == compact(token) or cc == cand_compact:
                return False  # точное совпадение с эталоном - всегда разрешено
        for stem in self.stop_stems:
            for c in self.canonical:
                cc = compact(c)
                if cc.startswith(stem) or stem.startswith(cc):
                    break
            else:
                if token.startswith(stem) or cand_compact.startswith(stem):
                    return True
        return False

    def _match_from(self, norm: str, start: int) -> WakeMatch | None:
        best: WakeMatch | None = None
        limit = max(compact(c).__len__() for c in self.canonical)
        for end in range(start + 2, min(start + limit + 6, len(norm)) + 1):
            candidate = norm[start:end]
            cand_compact = candidate.replace(" ", "").strip()
            if len(cand_compact) < 3:
                continue
            if len(cand_compact) > limit + 3:
                break
            token = self._full_token_at(norm, start)
            inside_word = end - start < len(token)   # совпали не со всем словом
            if inside_word and len(cand_compact) < limit:
                continue  # «флюс» внутри «флюсовка» - не активация
            if self._blocked_by_stop_stem(token, cand_compact):
                continue
            for canon in self.canonical:
                canon_compact = compact(canon)
                maxd = self.max_distance_prefix(len(canon_compact)) if inside_word \
                    else self.max_distance(len(canon_compact))
                d, form = distance_forms(cand_compact, canon_compact)
                if d > maxd:
                    continue
                if self.require_first_char and cand_compact and canon_compact:
                    if fold_lat(cand_compact[0]) != fold_lat(canon_compact[0]):
                        continue
                conf = 1.0 - d / max(1, len(canon_compact))
                span = self._trim_span(norm, start, end)
                m = WakeMatch(
                    matched=True,
                    wake=candidate.strip(),
                    canonical=canon,
                    distance=d,
                    confidence=round(max(0.0, conf), 3),
                    command=norm[span[1]:].strip(_STRIP_EDGES),
                    span=span,
                    form=form,
                )
                if best is None or self._better(m, best):
                    best = m
        return best

    @staticmethod
    def _trim_span(norm: str, start: int, end: int) -> tuple[int, int]:
        while start < end and norm[start].isspace():
            start += 1
        while end > start and norm[end - 1].isspace():
            end -= 1
        return start, end

    @staticmethod
    def _better(a: WakeMatch, b: WakeMatch) -> bool:
        if a.distance != b.distance:
            return a.distance < b.distance
        if a.confidence != b.confidence:
            return a.confidence > b.confidence
        return (a.span[1] - a.span[0]) > (b.span[1] - b.span[0])

    # --------------------------------------------------------------- utilities
    def is_wake_only(self, match: WakeMatch, min_words_after: int = 0) -> bool:
        """True, если после слова-активации ничего нет (просто «Флюкс!»)."""
        if not match.matched:
            return False
        return len([w for w in match.command.split(" ") if w]) <= min_words_after

    def quick_contains(self, text: str) -> bool:
        norm = normalize(text)
        return any(
            _distance(tok, c) <= self.max_distance(len(compact(c)))
            for tok in norm.split(" ") for c in self.canonical
        )


def from_config(cfg) -> WakeDetector:
    """Собирает детектор из конфига (flux.config)."""
    return WakeDetector(
        words=tuple(cfg.get("wake.words", ["флюкс"]) or ["флюкс"]),
        aliases=tuple(cfg.get("wake.aliases", []) or []),
        sensitivity=int(cfg.get("wake.sensitivity", 1)),
        require_at_start=bool(cfg.get("wake.require_at_start", True)),
        max_leading_fillers=int(cfg.get("wake.max_leading_fillers", 1)),
        stop_stems=tuple(cfg.get("wake.stop_stems", STOP_STEMS) or STOP_STEMS),
    )


def detect(text: str, words: Iterable[str] = ("флюкс", "flux"), **kw) -> WakeMatch:
    return WakeDetector(words=tuple(words), **kw).check(text)
