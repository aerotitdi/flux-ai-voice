"""Логирование FLUX: файл с ротацией + консоль + события для веб-консоли."""
from __future__ import annotations

import logging
import logging.handlers
import threading
import time
from collections import deque
from typing import Any, Callable

from . import config, paths

_LOG: logging.Logger | None = None
_EVENTS: deque[dict[str, Any]] = deque(maxlen=500)
_SUBSCRIBERS: list[Callable[[dict[str, Any]], None]] = []
_SUB_LOCK = threading.Lock()


class _EventBus(logging.Handler):
    """Кладёт записи в кольцевой буфер и рассылает подписчикам (SSE)."""

    def emit(self, record: logging.LogRecord) -> None:  # pragma: no cover - thin
        try:
            ev = {
                "ts": record.created,
                "level": record.levelname,
                "name": record.name,
                "msg": record.getMessage(),
            }
            _EVENTS.append(ev)
            with _SUB_LOCK:
                subs = list(_SUBSCRIBERS)
            for fn in subs:
                try:
                    fn(ev)
                except Exception:
                    pass
        except Exception:
            pass


def _ensure_root() -> logging.Logger:
    """Один корневой логгер "flux" с ОДНИМ файловым хендлером.

    БАГ: раньше get_logger() вешал RotatingFileHandler на КАЖДЫЙ именованный
    логгер (flux.main, flux.tools, flux.stt, ... — их в проекте ~15), и все они
    писали/ротировали ОДИН файл logs/flux.log. На Windows ротация при этом
    стабильно падала (WinError 32: файл занят другим процессом), лог терялся,
    а часть записей дублировалась. Теперь хендлеры живут только на корне
    "flux", а дочерние логгеры пишут в него через propagate.
    """
    global _LOG
    if _LOG is not None:
        return _LOG
    paths.ensure_dirs()
    log = logging.getLogger("flux")
    log.propagate = False
    if not log.handlers:
        lvl_name = str(config.get("logging.level", "INFO")).upper()
        log.setLevel(getattr(logging, lvl_name, logging.INFO))
        fmt = logging.Formatter(
            "%(asctime)s %(levelname)-7s %(name)s: %(message)s",
            datefmt="%H:%M:%S")
        if config.get("logging.console", True):
            sh = logging.StreamHandler()
            sh.setFormatter(fmt)
            log.addHandler(sh)
        try:
            logfile = paths.HOME / str(config.get("logging.file", "logs/flux.log"))
            logfile.parent.mkdir(parents=True, exist_ok=True)
            fh = logging.handlers.RotatingFileHandler(
                logfile,
                maxBytes=int(config.get("logging.max_bytes", 5_242_880)),
                backupCount=int(config.get("logging.backups", 3)),
                encoding="utf-8",
            )
            fh.setFormatter(logging.Formatter(
                "%(asctime)s %(levelname)-7s %(name)s: %(message)s"))
            fh.setLevel(getattr(logging, lvl_name, logging.INFO))
            log.addHandler(fh)
        except OSError:
            pass
        log.addHandler(_EventBus())
    _LOG = log
    return log


def get_logger(name: str = "flux") -> logging.Logger:
    root = _ensure_root()
    if name in ("flux", "", None):
        return root
    log = logging.getLogger(name)
    # дочерний логгер НЕ имеет своих хендлеров: всё уходит в корень "flux"
    log.handlers.clear()
    log.propagate = True
    log.setLevel(logging.NOTSET)
    return log


def _legacy_get_logger_unused(name: str = "flux") -> logging.Logger:
    paths.ensure_dirs()
    log = logging.getLogger(name)
    if log.handlers:
        return log
    lvl_name = str(config.get("logging.level", "INFO")).upper()
    log.setLevel(getattr(logging, lvl_name, logging.INFO))
    log.propagate = False
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s",
                            datefmt="%H:%M:%S")
    if config.get("logging.console", True):
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        log.addHandler(sh)
    try:
        logfile = paths.HOME / str(config.get("logging.file", "logs/flux.log"))
        logfile.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(
            logfile,
            maxBytes=int(config.get("logging.max_bytes", 5_242_880)),
            backupCount=int(config.get("logging.backups", 3)),
            encoding="utf-8",
        )
        fh.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)-7s %(name)s: %(message)s"))
        log.addHandler(fh)
    except OSError:
        pass
    log.addHandler(_EventBus())
    if name == "flux":
        _LOG = log
    return log


def subscribe(fn: Callable[[dict[str, Any]], None]) -> Callable[[], None]:
    with _SUB_LOCK:
        _SUBSCRIBERS.append(fn)

    def unsubscribe() -> None:
        with _SUB_LOCK:
            if fn in _SUBSCRIBERS:
                _SUBSCRIBERS.remove(fn)

    return unsubscribe


def recent_events(limit: int = 100) -> list[dict[str, Any]]:
    return list(_EVENTS)[-limit:]


def emit(event: str, **data: Any) -> None:
    """Структурированное событие для UI (state, tool, tts, stt...)."""
    payload = {"event": event, **data}
    _EVENTS.append({"ts": time.time(), "level": "EVENT", "name": event,
                    "msg": ""})
    with _SUB_LOCK:
        subs = list(_SUBSCRIBERS)
    for fn in subs:
        try:
            fn({"type": "flux_event", **payload})
        except Exception:
            pass


log = get_logger("flux")
