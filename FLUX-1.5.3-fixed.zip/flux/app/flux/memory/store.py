"""SQLite-хранилище памяти (D:\\flux\\data\\flux.db).

Таблицы: conversations, messages, memories(+FTS5), notes, knowledge(+FTS5),
timers. Поиск по фактам/знанию - полнотекстовый FTS5 (bm25), при отсутствии
FTS5 в сборке sqlite - прозрачный фолбэк на LIKE.
"""
from __future__ import annotations

import os
import sqlite3
import threading
import time
from typing import Iterable, Optional

from .. import logger, paths

log = logger.get_logger("flux.memory")

SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL DEFAULT 'Новый диалог',
    created REAL NOT NULL,
    updated REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS messages(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conv_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    ts REAL NOT NULL,
    meta TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conv_id, id);
CREATE TABLE IF NOT EXISTS memories(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    tags TEXT DEFAULT '',
    importance INTEGER DEFAULT 1,
    created REAL NOT NULL,
    last_used REAL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS notes(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    created REAL NOT NULL,
    updated REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS knowledge(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,
    chunk TEXT NOT NULL,
    created REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS timers(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,             -- timer|reminder
    fire_at REAL NOT NULL,
    message TEXT NOT NULL,
    created REAL NOT NULL,
    done INTEGER DEFAULT 0
);
"""


def _has_fts(conn: sqlite3.Connection) -> bool:
    try:
        conn.execute("CREATE VIRTUAL TABLE IF NOT EXISTS _fts_probe USING fts5(x)")
        conn.execute("DROP TABLE _fts_probe")
        return True
    except sqlite3.Error:
        return False


class MemoryStore:
    def __init__(self, db_path: Optional[str] = None) -> None:
        self.db_path = str(db_path or paths.DB_FILE)
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self.fts = False
        with self._lock:
            self._conn.executescript(SCHEMA)
            self.fts = _has_fts(self._conn)
            if self.fts:
                self._conn.executescript("""
                    CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts
                        USING fts5(text, tags, content='memories', content_rowid='id');
                    CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts
                        USING fts5(chunk, source, content='knowledge', content_rowid='id');
                """)
                # триггеры синхронизации
                self._conn.executescript("""
                    CREATE TRIGGER IF NOT EXISTS mem_ai AFTER INSERT ON memories BEGIN
                        INSERT INTO memories_fts(rowid, text, tags)
                        VALUES (new.id, new.text, new.tags);
                    END;
                    CREATE TRIGGER IF NOT EXISTS mem_ad AFTER DELETE ON memories BEGIN
                        INSERT INTO memories_fts(memories_fts, rowid, text, tags)
                        VALUES ('delete', old.id, old.text, old.tags);
                    END;
                    CREATE TRIGGER IF NOT EXISTS kn_ai AFTER INSERT ON knowledge BEGIN
                        INSERT INTO knowledge_fts(rowid, chunk, source)
                        VALUES (new.id, new.chunk, new.source);
                    END;
                    CREATE TRIGGER IF NOT EXISTS kn_ad AFTER DELETE ON knowledge BEGIN
                        INSERT INTO knowledge_fts(knowledge_fts, rowid, chunk, source)
                        VALUES ('delete', old.id, old.chunk, old.source);
                    END;
                """)
            self._conn.commit()

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except sqlite3.Error:
                pass

    # ------------------------------------------------------------ conversations
    def new_conversation(self, title: str = "Новый диалог") -> int:
        now = time.time()
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO conversations(title, created, updated) VALUES (?,?,?)",
                (title, now, now))
            self._conn.commit()
            return int(cur.lastrowid)

    def add_message(self, conv_id: int, role: str, content: str,
                    meta: str = "") -> int:
        now = time.time()
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO messages(conv_id, role, content, ts, meta) "
                "VALUES (?,?,?,?,?)", (conv_id, role, content, now, meta))
            self._conn.execute(
                "UPDATE conversations SET updated=? WHERE id=?", (now, conv_id))
            self._conn.commit()
            return int(cur.lastrowid)

    def history(self, conv_id: int, limit: int = 24) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT role, content, ts FROM messages WHERE conv_id=? "
                "ORDER BY id DESC LIMIT ?", (conv_id, int(limit))).fetchall()
        return [{"role": r["role"], "content": r["content"], "ts": r["ts"]}
                for r in reversed(rows)]

    def list_conversations(self, limit: int = 30) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, title, created, updated FROM conversations "
                "ORDER BY updated DESC LIMIT ?", (int(limit),)).fetchall()
        return [dict(r) for r in rows]

    def rename_conversation(self, conv_id: int, title: str) -> bool:
        with self._lock:
            cur = self._conn.execute(
                "UPDATE conversations SET title=? WHERE id=?", (title, conv_id))
            self._conn.commit()
            return cur.rowcount > 0

    def delete_conversation(self, conv_id: int) -> bool:
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM conversations WHERE id=?", (conv_id,))
            self._conn.commit()
            return cur.rowcount > 0

    def message_count(self, conv_id: int) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(*) c FROM messages WHERE conv_id=?",
                (conv_id,)).fetchone()
        return int(row["c"])

    # ---------------------------------------------------------------- memories
    def remember(self, text: str, tags: str = "", importance: int = 1) -> int:
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO memories(text, tags, importance, created) "
                "VALUES (?,?,?,?)", (text.strip(), tags, int(importance), time.time()))
            self._conn.commit()
            return int(cur.lastrowid)

    def recall(self, query: str, limit: int = 6) -> list[dict]:
        q = (query or "").strip()
        if not q:
            return []
        with self._lock:
            if self.fts:
                try:
                    rows = self._conn.execute(
                        "SELECT m.id, m.text, m.tags, m.importance, "
                        " bm25(memories_fts) AS score "
                        "FROM memories_fts f JOIN memories m ON m.id=f.rowid "
                        "WHERE memories_fts MATCH ? ORDER BY score LIMIT ?",
                        (self._fts_query(q), int(limit))).fetchall()
                    out = [dict(r) for r in rows]
                    if out:
                        self._touch([r["id"] for r in out])
                        return out
                except sqlite3.Error:
                    pass
            like = "%" + "%".join(q.lower().split()) + "%"
            rows = self._conn.execute(
                "SELECT id, text, tags, importance, 0.0 AS score FROM memories "
                "WHERE lower(text) LIKE ? ORDER BY importance DESC, id DESC LIMIT ?",
                (like, int(limit))).fetchall()
            out = [dict(r) for r in rows]
            self._touch([r["id"] for r in out])
            return out

    def _touch(self, ids: Iterable[int]) -> None:
        try:
            self._conn.executemany(
                "UPDATE memories SET last_used=? WHERE id=?",
                [(time.time(), i) for i in ids])
            self._conn.commit()
        except sqlite3.Error:
            pass

    @staticmethod
    def _fts_query(q: str) -> str:
        """Префиксный запрос с усечением окончания: русская морфология не
        поддерживается FTS5, поэтому «москва» ищем как «москв*» (поймает
        «Москве», «Москвой»), «тверская» как «тверск*» (поймает «Тверской»)."""
        tokens = [t.lower() for t in q.replace('"', " ").split() if len(t) > 2]
        if not tokens:
            return '"' + q.replace('"', "").strip() + '"'
        parts = []
        for t in tokens[:8]:
            stem = t[:max(4, len(t) - 2)]
            parts.append(f'"{stem}"*')
        return " OR ".join(parts)

    def forget(self, match: str) -> int:
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM memories WHERE id=? OR lower(text) LIKE ?",
                (int(match) if str(match).isdigit() else -1,
                 f"%{match.lower()}%"))
            self._conn.commit()
            return cur.rowcount

    def list_memories(self, limit: int = 50) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, text, tags, importance, created FROM memories "
                "ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------- notes
    def note_save(self, title: str, content: str = "", note_id: int | None = None) -> int:
        now = time.time()
        with self._lock:
            if note_id:
                self._conn.execute(
                    "UPDATE notes SET title=?, content=?, updated=? WHERE id=?",
                    (title, content, now, note_id))
                self._conn.commit()
                return int(note_id)
            cur = self._conn.execute(
                "INSERT INTO notes(title, content, created, updated) VALUES (?,?,?,?)",
                (title, content, now, now))
            self._conn.commit()
            return int(cur.lastrowid)

    def note_list(self, limit: int = 50) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, title, length(content) AS chars, updated FROM notes "
                "ORDER BY updated DESC LIMIT ?", (int(limit),)).fetchall()
        return [dict(r) for r in rows]

    def note_get(self, note_id: int) -> dict | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM notes WHERE id=?", (note_id,)).fetchone()
        return dict(row) if row else None

    def note_delete(self, note_id: int) -> bool:
        with self._lock:
            cur = self._conn.execute("DELETE FROM notes WHERE id=?", (note_id,))
            self._conn.commit()
            return cur.rowcount > 0

    # --------------------------------------------------------------- knowledge
    def knowledge_ingest(self, source: str, chunks: Iterable[str]) -> int:
        now = time.time()
        with self._lock:
            self._conn.execute("DELETE FROM knowledge WHERE source=?", (source,))
            cur = self._conn.executemany(
                "INSERT INTO knowledge(source, chunk, created) VALUES (?,?,?)",
                [(source, c, now) for c in chunks])
            self._conn.commit()
            return cur.rowcount

    def knowledge_search(self, query: str, limit: int = 5) -> list[dict]:
        q = (query or "").strip()
        if not q:
            return []
        with self._lock:
            if self.fts:
                try:
                    rows = self._conn.execute(
                        "SELECT k.id, k.source, k.chunk, bm25(knowledge_fts) AS score "
                        "FROM knowledge_fts f JOIN knowledge k ON k.id=f.rowid "
                        "WHERE knowledge_fts MATCH ? ORDER BY score LIMIT ?",
                        (self._fts_query(q), int(limit))).fetchall()
                    if rows:
                        return [dict(r) for r in rows]
                except sqlite3.Error:
                    pass
            like = "%" + "%".join(q.lower().split()) + "%"
            rows = self._conn.execute(
                "SELECT id, source, chunk, 0.0 AS score FROM knowledge "
                "WHERE lower(chunk) LIKE ? LIMIT ?", (like, int(limit))).fetchall()
            return [dict(r) for r in rows]

    def knowledge_sources(self) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT source, COUNT(*) AS chunks FROM knowledge "
                "GROUP BY source ORDER BY source").fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ timers
    def timer_add(self, kind: str, fire_at: float, message: str) -> int:
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO timers(kind, fire_at, message, created) VALUES (?,?,?,?)",
                (kind, float(fire_at), message, time.time()))
            self._conn.commit()
            return int(cur.lastrowid)

    def timers_due(self, now: float | None = None) -> list[dict]:
        now = time.time() if now is None else now
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM timers WHERE done=0 AND fire_at<=? ORDER BY fire_at",
                (now,)).fetchall()
        return [dict(r) for r in rows]

    def timer_done(self, timer_id: int) -> None:
        with self._lock:
            self._conn.execute("UPDATE timers SET done=1 WHERE id=?", (timer_id,))
            self._conn.commit()

    def timer_cancel(self, timer_id: int) -> bool:
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM timers WHERE id=? AND done=0", (timer_id,))
            self._conn.commit()
            return cur.rowcount > 0

    def timer_list(self, include_done: bool = False) -> list[dict]:
        sql = "SELECT * FROM timers" + ("" if include_done else " WHERE done=0")
        with self._lock:
            rows = self._conn.execute(sql + " ORDER BY fire_at").fetchall()
        return [dict(r) for r in rows]
