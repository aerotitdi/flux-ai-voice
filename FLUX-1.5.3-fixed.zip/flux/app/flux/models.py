"""Каталог моделей для выбора в консоли: «Понимание речи» и «ИИ для ответа».

Пользователь просил выбор моделей прямо в настройках консоли, поэтому здесь
собирается ЧЕСТНЫЙ список того, что реально доступно на этой машине:

  * понимание речи (STT): локальные модели faster-whisper (в т.ч. уже
    скачанные), whisper-эндпоинты OpenAI-совместимых серверов (Groq/OpenAI/
    faster-whisper-server/speaches/форки Ollama с ASR) и whisper внутри
    Ollama — с честной пометкой,
    работает он или нет;
  * ИИ для ответа (LLM): модели из локального Ollama (/api/tags), облачные
    модели Ollama (*:cloud), модели из подключений в стиле Open WebUI.

Ничего не выдумываем: если Ollama не отвечает — список пустой, но текущая
модель из конфига в нём остаётся (чтобы настройка не «пропадала»).
"""
from __future__ import annotations


from typing import Any

import requests

from . import config, logger

log = logger.get_logger("flux.models")

# Локальные модели faster-whisper (Systran/faster-whisper-*), размер на диске
LOCAL_STT_MODELS = [
    ("tiny", "~75 МБ", "быстрая, грубая — только для теста"),
    ("base", "~145 МБ", "лёгкая, для слабых CPU"),
    ("small", "~485 МБ", "баланс скорость/качество"),
    ("medium", "~1.5 ГБ", "хорошо на CPU"),
    ("large-v3", "~3 ГБ", "максимум качества, медленно без GPU"),
    ("large-v3-turbo", "~1.6 ГБ", "ТА ЖЕ large, в 4-8 раз быстрее (GPU)"),
]

CLOUD_STT_MODELS = [
    ("groq:whisper-large-v3-turbo", "Groq (облако, из России 403 по региону)"),
    ("openai:whisper-1", "OpenAI whisper-1"),
    ("openai:gpt-4o-transcribe", "OpenAI gpt-4o-transcribe"),
]

# что ещё можно выбрать, даже если Ollama сейчас не отвечает
EXTRA_LLM_MODELS = [
    "gemma4:31b-cloud", "gemma4:12b-cloud", "llama3.1:8b", "qwen3:14b",
]


def fmt_size(num: Any) -> str:
    """Размер как в Open WebUI: 32_700_000_000 -> «32.7B», 1_600_000_000 -> «1.6B»."""
    try:
        n = float(num)
    except (TypeError, ValueError):
        return ""
    if n <= 0:
        return ""
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if n >= div:
            v = n / div
            return f"{v:.1f}".rstrip("0").rstrip(".") + suf
    return str(int(n))


def _ollama_models(timeout: float = 2.0) -> tuple[list[dict], str]:
    """Модели локального Ollama (+размер для бейджа, как в Open WebUI).

    Размер берём из details.parameter_size («31B») — это то самое число,
    которое Open WebUI показывает справа от имени; если его нет — из size
    (байты на диске). Ошибка доступа возвращается строкой, чтобы консоль
    честно показала «Ollama не отвечает», а не пустой список без причин.
    """
    endpoint = str(config.get("llm.endpoint", "http://localhost:11434")).rstrip("/")
    try:
        r = requests.get(endpoint + "/api/tags", timeout=timeout)
        r.raise_for_status()
        data = r.json()
        out = []
        for m in data.get("models", []) or []:
            name = str(m.get("name") or "")
            if not name:
                continue
            det = m.get("details") or {}
            size = str(det.get("parameter_size") or "").strip()
            if not size:
                size = fmt_size(m.get("size"))
            out.append({"name": name, "size": size})
        return out, ""
    except Exception as e:
        return [], f"{endpoint}: {e.__class__.__name__} {e}"


def stt_models() -> dict:
    """Варианты для «Понимание речи» (STT)."""
    from .stt import local as local_stt
    from .stt.ollama_asr import OllamaWhisperSTT

    st = local_stt.status()
    cached = set(st.get("cached_models") or [])
    out: list[dict] = []
    for name, size, note in LOCAL_STT_MODELS:
        out.append({
            "id": f"local:{name}",
            "label": f"Локально: whisper {name} ({size})"
                     + (" — уже скачана" if name in cached else ""),
            "engine": "local",
            "value": name,
            "note": note,
            "cached": name in cached,
            "size": size.replace("~", ""),
            "scope": "local",
            "cloud": False,
        })
    cur_local = str(config.get("stt.local.model", "large-v3-turbo"))
    if cur_local and not any(o["value"] == cur_local and o["engine"] == "local"
                             for o in out):
        out.insert(0, {"id": f"local:{cur_local}", "engine": "local",
                       "value": cur_local,
                       "label": f"Локально: whisper {cur_local} (из конфига)",
                       "note": "", "cached": cur_local in cached,
                       "size": "", "scope": "local", "cloud": False})

    # whisper внутри Ollama: сток-Ollama модель скачивает, но НЕ
    # запускает (в API Ollama нет эндпоинта транскрипции — docs.ollama.com/api)
    oll = OllamaWhisperSTT()
    base = oll.probe()
    can = bool(base) and oll.model_present()
    out.append({
        "id": f"ollama:{oll.model}",
        "label": f"Whisper-сервер (Ollama-эндпоинт): {oll.model}",
        "engine": "ollama",
        "value": oll.model,
        "note": ("работает через " + base) if can else
                "не работает: в API сток-Ollama нет /audio/transcriptions "
                "(docs.ollama.com/api) — нужен отдельный whisper-сервер "
                "или локальный faster-whisper (он и работает)",
        "cached": can,
        "size": "", "scope": "local", "cloud": False,
    })
    for mid, note in CLOUD_STT_MODELS:
        out.append({"id": mid, "label": mid.split(":", 1)[1] + " — " + note,
                    "engine": mid.split(":", 1)[0], "value": mid.split(":", 1)[1],
                    "note": note, "cached": False,
                    "size": "", "scope": "cloud", "cloud": True})
    current = _current_stt()
    return {"models": out, "current": current, "status": st,
            "ollama_ok": can, "ollama_base": base or ""}


def _current_stt() -> str:
    engine = str(config.get("stt.engine", "auto"))
    if engine == "ollama":
        return "ollama:" + str(config.get("stt.ollama.model", ""))
    if engine == "api":
        preset = str(config.get("stt.api.preset", "") or "groq")
        return f"{preset}:{config.get('stt.api.model', '')}"
    return "local:" + str(config.get("stt.local.model", "large-v3-turbo"))


def llm_models() -> dict:
    """Варианты для «ИИ для ответа» (LLM)."""
    models, err = _ollama_models()
    out: list[dict] = []
    for m in models:
        name = m["name"]
        cloud = ":cloud" in name or name.endswith("-cloud")
        out.append({"id": f"ollama:{name}", "value": name,
                    "label": ("Ollama (облако): " if cloud else "Ollama (локально): ")
                             + name,
                    "engine": "ollama-cloud" if cloud else "ollama",
                    "note": "", "size": m.get("size", ""),
                    "scope": "cloud" if cloud else "local", "cloud": cloud})
    for name in EXTRA_LLM_MODELS:
        if not any(o["value"] == name for o in out):
            cloud = ":cloud" in name
            out.append({"id": f"ollama:{name}", "value": name,
                        "label": ("Ollama (облако): " if cloud
                                  else "Ollama: ") + name,
                        "engine": "ollama-cloud" if cloud else "ollama",
                        "note": ("нужен вход в Ollama или OLLAMA_API_KEY"
                                 if cloud else
                                 "скачается при первом запуске (ollama pull)"),
                        "size": "", "scope": "cloud" if cloud else "local",
                        "cloud": cloud})
    for c in (config.get("llm.connections", []) or []):
        base = str(c.get("base_url", "")).rstrip("/")
        model = str(c.get("model", "") or "")
        if base and model:
            local_conn = ("127.0.0.1" in base or "localhost" in base)
            out.append({"id": f"conn:{base}:{model}", "value": model,
                        "label": f"Подключение {c.get('name', base)}: {model}",
                        "engine": "openai-conn", "note": base,
                        "size": "", "scope": "local" if local_conn else "cloud",
                        "cloud": not local_conn})
    current = str(config.get("llm.model", "gemma4:31b-cloud"))
    if not any(o["value"] == current for o in out):
        out.insert(0, {"id": f"ollama:{current}", "value": current,
                       "label": f"Ollama: {current} (из конфига)",
                       "engine": "ollama", "note": "", "size": "",
                       "scope": "cloud" if ":cloud" in current else "local",
                       "cloud": ":cloud" in current})
    return {"models": out, "current": current, "endpoint":
            str(config.get("llm.endpoint", "")), "error": err}


def catalog() -> dict:
    """Оба списка одним запросом (консоль: GET /api/models)."""
    return {"stt": stt_models(), "llm": llm_models()}
