"""Автозагрузка FLUX вместе с Windows (HKCU\\...\\Run)."""
from __future__ import annotations

import os
import sys
from pathlib import Path

from . import config, logger

log = logger.get_logger("flux.autostart")

VALUE_NAME = "FluxAssistant"


def autostart_command() -> str:
    pythonw = Path(sys.executable).with_name(
        "pythonw.exe" if os.name == "nt" else Path(sys.executable).name)
    if not pythonw.exists():
        pythonw = Path(sys.executable)
    return f'"{pythonw}" -m flux.main --autostart'


def set_autostart(enabled: bool) -> bool:
    if os.name != "nt":
        log.info("автозагрузка поддерживается только на Windows")
        return False
    try:
        import winreg  # type: ignore

        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE)
        if enabled:
            winreg.SetValueEx(key, VALUE_NAME, 0, winreg.REG_SZ,
                              autostart_command())
        else:
            try:
                winreg.DeleteValue(key, VALUE_NAME)
            except FileNotFoundError:
                pass
        winreg.CloseKey(key)
        config.set_value("autostart.enabled", bool(enabled), save=False)
        config.save_config()
        log.info("автозагрузка: %s", "включена" if enabled else "выключена")
        return True
    except Exception as e:
        log.warning("не удалось изменить автозагрузку: %s", e)
        return False


def get_autostart() -> bool:
    if os.name != "nt":
        return False
    try:
        import winreg  # type: ignore

        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_READ)
        try:
            winreg.QueryValueEx(key, VALUE_NAME)
            present = True
        except FileNotFoundError:
            present = False
        winreg.CloseKey(key)
        return present
    except Exception:
        return False
