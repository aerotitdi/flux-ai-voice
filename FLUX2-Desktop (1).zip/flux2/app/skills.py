"""Скиллы: локальные (bundled) + каталог NVIDIA/skills (build.nvidia.com/skills).

Авто-работа: на каждый запрос подбирается 1-2 релевантных скилла и их
инструкции впрыскиваются в системный промпт (как у агентов с SKILL.md).
"""
from __future__ import annotations

import json
import os
import re
import time

import aiohttp

from .config import app_dir

GH_API = "https://api.github.com/repos/NVIDIA/skills/contents"
RAW = "https://raw.githubusercontent.com/NVIDIA/skills/main"
CACHE_DIR = lambda: os.path.join(app_dir(), "data", "skills_cache")
BUNDLED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "skills_bundled")
INDEX_TTL = 86400


def _read_md(path: str) -> dict:
    """Парсит frontmatter: name/description + тело."""
    with open(path, "r", encoding="utf-8") as f:
        txt = f.read()
    meta = {"name": os.path.basename(path).replace(".md", ""), "description": ""}
    body = txt
    m = re.match(r"^---\n([\s\S]*?)\n---\n([\s\S]*)$", txt)
    if m:
        for line in m.group(1).split("\n"):
            k, _, v = line.partition(":")
            if k.strip() in ("name", "description"):
                meta[k.strip()] = v.strip().strip('"')
        body = m.group(2)
    meta["body"] = body.strip()
    return meta


def bundled_skills() -> list[dict]:
    out = []
    if os.path.isdir(BUNDLED):
        for fn in sorted(os.listdir(BUNDLED)):
            if fn.endswith(".md"):
                s = _read_md(os.path.join(BUNDLED, fn))
                s["source"] = "bundled"
                out.append(s)
    return out


def index_path() -> str:
    return os.path.join(CACHE_DIR(), "nvidia_index.json")


async def nvidia_index(force: bool = False) -> list[dict]:
    """Список скиллов NVIDIA (имя + описание) с кэшем 24ч."""
    p = index_path()
    if not force and os.path.exists(p) and time.time() - os.path.getmtime(p) < INDEX_TTL:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(GH_API, timeout=aiohttp.ClientTimeout(total=30)) as r:
                if r.status != 200:
                    return []
                items = await r.json()
        names = [i["name"] for i in items if i["type"] == "dir"]
        out = [{"name": n, "description": "", "source": "nvidia"} for n in names]
        os.makedirs(CACHE_DIR(), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False)
        return out
    except Exception:
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        return []


async def fetch_skill(name: str) -> dict | None:
    """Скачать SKILL.md скилла NVIDIA (кэш локально)."""
    p = os.path.join(CACHE_DIR(), f"{name}.md")
    if os.path.exists(p):
        s = _read_md(p)
        s["source"] = "nvidia"
        return s
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"{RAW}/{name}/SKILL.md", timeout=aiohttp.ClientTimeout(total=30)) as r:
                if r.status != 200:
                    return None
                txt = await r.text()
        os.makedirs(CACHE_DIR(), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(txt)
        s = _read_md(p)
        s["source"] = "nvidia"
        return s
    except Exception:
        return None


def _stem(w: str) -> str:
    return w[:5] if len(w) > 5 else w


def _tokens(s: str) -> set:
    return {_stem(w) for w in re.findall(r"[a-zа-яё]{4,}", s.lower())}


async def match_skills(query: str, k: int = 2, max_chars: int = 3500) -> list[dict]:
    """Авто-подбор скиллов под запрос."""
    qt = _tokens(query)
    if not qt:
        return []
    cands = bundled_skills()
    idx = await nvidia_index()
    # описания NVIDIA-скиллов подтягиваем только для совпавших по имени
    scored = []
    for s in cands:
        st = _tokens(s["name"] + " " + s["description"] + " " + s["body"][:400])
        ov = len(qt & st)
        if ov >= 2:
            scored.append((ov, s))
    for s in idx:
        st = _tokens(s["name"].replace("-", " ").replace("_", " "))
        ov = len(qt & st)
        if ov >= 2:
            scored.append((ov, s))
    scored.sort(key=lambda x: -x[0])
    out = []
    for ov, s in scored[:k]:
        if not s.get("body"):
            full = await fetch_skill(s["name"])
            if not full:
                continue
            s = full
        s = dict(s)
        s["body"] = s["body"][:max_chars]
        out.append(s)
    return out


async def all_skills() -> list[dict]:
    out = bundled_skills()
    out += await nvidia_index()
    return out


async def search_skills(query: str, k: int = 10) -> list[dict]:
    qt = _tokens(query)
    res = []
    for s in await all_skills():
        st = _tokens(s["name"] + " " + (s.get("description") or ""))
        ov = len(qt & st)
        if ov > 0:
            res.append((ov, s))
    res.sort(key=lambda x: -x[0])
    return [s for _, s in res[:k]]
