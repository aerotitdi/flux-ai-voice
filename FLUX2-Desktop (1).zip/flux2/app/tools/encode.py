"""Кодировки, хеши, токены (38)."""
from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import secrets
import string
import uuid
import zlib

from .registry import P, REG

C = "encode"
T = REG.tool
B = lambda s: s.encode("utf-8") if isinstance(s, str) else s


@T("enc_base64", "Кодировать в base64", [P("text", desc="текст")], C)
def _(ctx, text): return base64.b64encode(B(text)).decode()


@T("enc_base64_dec", "Декодировать base64", [P("text", desc="base64")], C)
def _(ctx, text): return base64.b64decode(B(text)).decode("utf-8", "replace")


@T("enc_base32", "Кодировать в base32", [P("text", desc="текст")], C)
def _(ctx, text): return base64.b32encode(B(text)).decode()


@T("enc_base32_dec", "Декодировать base32", [P("text", desc="base32")], C)
def _(ctx, text): return base64.b32decode(B(text)).decode("utf-8", "replace")


@T("enc_hex", "Кодировать в hex", [P("text", desc="текст")], C)
def _(ctx, text): return B(text).hex()


@T("enc_hex_dec", "Декодировать hex", [P("text", desc="hex")], C)
def _(ctx, text): return bytes.fromhex(text.replace(" ", "")).decode("utf-8", "replace")


@T("enc_url", "URL-кодировать строку", [P("text", desc="текст")], C)
def _(ctx, text):
    from urllib.parse import quote
    return quote(text)


@T("enc_url_dec", "URL-декодировать строку", [P("text", desc="percent-encoded")], C)
def _(ctx, text):
    from urllib.parse import unquote
    return unquote(text)


@T("enc_html_ent", "Экранировать HTML-сущности", [P("text", desc="текст")], C)
def _(ctx, text):
    import html
    return html.escape(text)


@T("enc_html_ent_dec", "Разэкранировать HTML-сущности", [P("text", desc="html entities")], C)
def _(ctx, text):
    import html
    return html.unescape(text)


@T("enc_rot13", "ROT13", [P("text", desc="текст")], C)
def _(ctx, text):
    import codecs
    return codecs.encode(text, "rot13")


@T("enc_caesar", "Шифр Цезаря со сдвигом", [P("text", desc="текст"), P("shift", "integer", desc="сдвиг")], C)
def _(ctx, text, shift):
    out = []
    for ch in text:
        if ch.isalpha():
            base = ord("A") if ch.isupper() else ord("a")
            out.append(chr((ord(ch) - base + shift) % 26 + base))
        else:
            out.append(ch)
    return "".join(out)


MORSE = {
    "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".", "F": "..-.", "G": "--.", "H": "....",
    "I": "..", "J": ".---", "K": "-.-", "L": ".-..", "M": "--", "N": "-.", "O": "---", "P": ".--.",
    "Q": "--.-", "R": ".-.", "S": "...", "T": "-", "U": "..-", "V": "...-", "W": ".--", "X": "-..-",
    "Y": "-.--", "Z": "--..", "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-",
    "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----.",
}


@T("enc_morse", "Текст в азбуку Морзе", [P("text", desc="текст")], C)
def _(ctx, text): return " / ".join(" ".join(MORSE.get(c.upper(), c) for c in w) for w in text.split())


@T("enc_morse_dec", "Азбука Морзе в текст", [P("text", desc="морзе (/ = пробел слова)")], C)
def _(ctx, text):
    rev = {v: k for k, v in MORSE.items()}
    return " ".join("".join(rev.get(c, c) for c in w.split()) for w in text.split(" / "))


@T("enc_binary", "Текст в двоичный код", [P("text", desc="текст")], C)
def _(ctx, text): return " ".join(f"{b:08b}" for b in B(text))


@T("enc_binary_dec", "Двоичный код в текст", [P("text", desc="байты через пробел")], C)
def _(ctx, text): return bytes(int(x, 2) for x in text.split()).decode("utf-8", "replace")


@T("enc_octal", "Текст в восьмеричный код", [P("text", desc="текст")], C)
def _(ctx, text): return " ".join(f"{b:03o}" for b in B(text))


@T("enc_octal_dec", "Восьмеричный код в текст", [P("text", desc="октеты через пробел")], C)
def _(ctx, text): return bytes(int(x, 8) for x in text.split()).decode("utf-8", "replace")


@T("enc_ascii85", "Кодировать в ascii85", [P("text", desc="текст")], C)
def _(ctx, text): return base64.a85encode(B(text)).decode()


@T("enc_ascii85_dec", "Декодировать ascii85", [P("text", desc="ascii85")], C)
def _(ctx, text): return base64.a85decode(B(text)).decode("utf-8", "replace")


@T("enc_punycode", "Домен/текст в punycode (IDN)", [P("text", desc="домен")], C)
def _(ctx, text): return text.encode("idna").decode() if "." in text else text.encode("punycode").decode()


@T("enc_punycode_dec", "Punycode в юникод", [P("text", desc="xn--...")], C)
def _(ctx, text): return text.encode().decode("idna") if text.startswith("xn--") else text.encode().decode("punycode")


@T("enc_unicode_esc", "Текст в \\uXXXX экранирование", [P("text", desc="текст")], C)
def _(ctx, text): return text.encode("unicode_escape").decode()


@T("enc_unicode_esc_dec", "\\uXXXX экранирование в текст", [P("text", desc="escaped")], C)
def _(ctx, text): return text.encode("utf-8", "ignore").decode("unicode_escape")


@T("enc_jwt_decode", "Раскодировать JWT payload (без проверки подписи)", [P("token", desc="jwt")], C)
def _(ctx, token):
    import json
    part = token.split(".")[1]
    part += "=" * (-len(part) % 4)
    return json.dumps(json.loads(base64.urlsafe_b64decode(part)), ensure_ascii=False, indent=2)


@T("hash_md5", "MD5 хеш строки", [P("text", desc="текст")], C)
def _(ctx, text): return hashlib.md5(B(text)).hexdigest()


@T("hash_sha1", "SHA1 хеш строки", [P("text", desc="текст")], C)
def _(ctx, text): return hashlib.sha1(B(text)).hexdigest()


@T("hash_sha256", "SHA-256 хеш строки", [P("text", desc="текст")], C)
def _(ctx, text): return hashlib.sha256(B(text)).hexdigest()


@T("hash_sha512", "SHA-512 хеш строки", [P("text", desc="текст")], C)
def _(ctx, text): return hashlib.sha512(B(text)).hexdigest()


@T("hash_blake2b", "BLAKE2b хеш строки", [P("text", desc="текст")], C)
def _(ctx, text): return hashlib.blake2b(B(text)).hexdigest()


@T("hash_crc32", "CRC32 контрольная сумма", [P("text", desc="текст")], C)
def _(ctx, text): return format(zlib.crc32(B(text)), "08x")


@T("hash_adler32", "Adler-32 контрольная сумма", [P("text", desc="текст")], C)
def _(ctx, text): return format(zlib.adler32(B(text)), "08x")


@T("hash_hmac", "HMAC-SHA256 подпись сообщения", [P("text", desc="сообщение"), P("key", desc="секрет")], C)
def _(ctx, text, key): return hmac.new(B(key), B(text), hashlib.sha256).hexdigest()


@T("enc_uuid4", "Сгенерировать UUID v4", [], C)
def _(ctx): return str(uuid.uuid4())


@T("enc_uuid7_like", "Сгенерировать сортируемый UUID (time-based)", [], C)
def _(ctx):
    import time
    return f"{int(time.time()*1000):012x}-flux-{secrets.token_hex(2)}-{secrets.token_hex(6)}"


@T("enc_nanoid", "Сгенерировать короткий nano-id", [P("size", "integer", desc="длина", required=False, default=12)], C)
def _(ctx, size):
    abc = string.ascii_letters + string.digits + "_-"
    return "".join(secrets.choice(abc) for _ in range(max(4, min(size, 64))))


@T("enc_password_gen", "Сгенерировать пароль", [P("length", "integer", desc="длина", required=False, default=16), P("symbols", "boolean", desc="с символами", required=False, default=True)], C)
def _(ctx, length, symbols):
    abc = string.ascii_letters + string.digits + ("!@#$%^&*-_" if symbols else "")
    return "".join(secrets.choice(abc) for _ in range(max(6, min(length, 128))))


@T("enc_token_hex", "Сгенерировать hex-токен", [P("bytes", "integer", desc="байт", required=False, default=32)], C)
def _(ctx, bytes): return secrets.token_hex(max(4, min(bytes, 256)))


@T("enc_base64_image_dec_info", "Информация о base64-изображении (размер байт, магия формата)", [P("text", desc="base64 data или чистый base64")], C)
def _(ctx, text):
    if "," in text[:64]:
        text = text.split(",", 1)[1]
    raw = base64.b64decode(text)
    magic = {"\x89PNG": "png", "\xff\xd8": "jpg", "GIF8": "gif", "RIFF": "webp/bmp?", "BM": "bmp"}
    fmt = next((v for k, v in magic.items() if raw.startswith(k.encode("latin1"))), "unknown")
    return f"байт={len(raw)} формат={fmt}"
