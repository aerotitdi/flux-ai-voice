"""Сеть: запросы, DNS, IP (16)."""
from __future__ import annotations

import asyncio
import json
import socket
import ssl
import time
from urllib.parse import urlparse, urlunparse, parse_qs, urlencode

import aiohttp

from .registry import P, REG, ToolResult

C = "net"
T = REG.tool
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FluxDesktop/2.0"}


@T("net_get", "GET-запрос: статус + начало тела", [P("url", desc="URL"), P("max_chars", "integer", desc="лимит символов", required=False, default=3000)], C)
async def _(ctx, url, max_chars):
    async with aiohttp.ClientSession(headers=UA) as s:
        async with s.get(url, timeout=aiohttp.ClientTimeout(total=30)) as r:
            txt = await r.text(errors="replace")
    return ToolResult(True, f"status={r.status}\n{txt[:max_chars]}")


@T("net_get_json", "GET-запрос и распарсенный JSON", [P("url", desc="URL")], C)
async def _(ctx, url):
    async with aiohttp.ClientSession(headers=UA) as s:
        async with s.get(url, timeout=aiohttp.ClientTimeout(total=30)) as r:
            return json.dumps(await r.json(), ensure_ascii=False)[:6000]


@T("net_head_status", "HTTP-статус и заголовки URL", [P("url", desc="URL")], C)
async def _(ctx, url):
    async with aiohttp.ClientSession(headers=UA) as s:
        async with s.head(url, timeout=aiohttp.ClientTimeout(total=20), allow_redirects=True) as r:
            return f"status={r.status}\n" + "\n".join(f"{k}: {v}" for k, v in list(r.headers.items())[:20])


@T("net_check_site_up", "Жив ли сайт (статус + время)", [P("url", desc="URL")], C)
async def _(ctx, url):
    t0 = time.time()
    async with aiohttp.ClientSession(headers=UA) as s:
        async with s.get(url, timeout=aiohttp.ClientTimeout(total=15)) as r:
            return f"status={r.status} за={time.time()-t0:.2f}с"


@T("net_dns", "DNS A-записи домена", [P("domain", desc="домен")], C)
def _(ctx, domain):
    return ", ".join(ai[4][0] for ai in socket.getaddrinfo(domain, None)) or "нет записей"


@T("net_reverse_dns", "Обратный DNS (IP -> имя)", [P("ip", desc="IP")], C)
def _(ctx, ip):
    try:
        return socket.gethostbyaddr(ip)[0]
    except Exception as e:
        return f"нет PTR: {e}"


@T("net_ping", "Ping хоста (TCP-уровень, время подключения)", [P("host", desc="хост"), P("port", "integer", desc="порт", required=False, default=443)], C)
def _(ctx, host, port):
    t0 = time.time()
    try:
        s = socket.create_connection((host, port), timeout=5)
        s.close()
        return f"{host}:{port} доступен, {(time.time()-t0)*1000:.0f} мс"
    except Exception as e:
        return f"недоступен: {e}"


@T("net_latency", "Серия из 4 TCP-замеров задержки до хоста", [P("host", desc="хост"), P("port", "integer", desc="порт", required=False, default=443)], C)
def _(ctx, host, port):
    ms = []
    for _ in range(4):
        t0 = time.time()
        try:
            s = socket.create_connection((host, port), timeout=4)
            s.close()
            ms.append(round((time.time() - t0) * 1000))
        except Exception:
            ms.append(-1)
    return f"задержки={ms} среднее={sum(m for m in ms if m > 0)/max(1,len([m for m in ms if m>0])):.0f} мс"


@T("net_my_ip", "Мой внешний IP и гео", [], C)
async def _(ctx):
    async with aiohttp.ClientSession() as s:
        async with s.get("https://ipwho.is/") as r:
            d = await r.json()
    return f"ip={d.get('ip')} город={d.get('city')} страна={d.get('country')} провайдер={d.get('connection',{}).get('org')}"


@T("net_ip_geo", "Геолокация IP-адреса", [P("ip", desc="IP")], C)
async def _(ctx, ip):
    async with aiohttp.ClientSession() as s:
        async with s.get(f"https://ipwho.is/{ip}") as r:
            d = await r.json()
    return f"ip={d.get('ip')} город={d.get('city')} регион={d.get('region')} страна={d.get('country')} орг={d.get('connection',{}).get('org')}"


@T("net_url_parse", "Разобрать URL на части", [P("url", desc="URL")], C)
def _(ctx, url):
    p = urlparse(url)
    return json.dumps({"scheme": p.scheme, "host": p.netloc, "path": p.path,
                       "query": parse_qs(p.query), "fragment": p.fragment}, ensure_ascii=False)


@T("net_url_build", "Собрать URL из частей + query-параметров JSON", [P("base", desc="базовый url"), P("params_json", desc="JSON объекта параметров", required=False, default="{}")], C)
def _(ctx, base, params_json):
    q = urlencode(json.loads(params_json or "{}"))
    sep = "&" if "?" in base else "?"
    return base + (sep + q if q else "")


@T("net_port_check", "Открыт ли TCP-порт", [P("host", desc="хост"), P("port", "integer", desc="порт")], C)
def _(ctx, host, port):
    try:
        s = socket.create_connection((host, port), timeout=4)
        s.close()
        return "открыт"
    except Exception:
        return "закрыт"


@T("net_download", "Скачать файл в data-каталог и вернуть путь", [P("url", desc="URL файла"), P("name", desc="имя файла", required=False, default="")], C)
async def _(ctx, url, name):
    import os
    from ..config import app_dir
    dest = os.path.join(app_dir(), "data", name or os.path.basename(urlparse(url).path) or "download.bin")
    async with aiohttp.ClientSession(headers=UA) as s:
        async with s.get(url, timeout=aiohttp.ClientTimeout(total=120)) as r:
            with open(dest, "wb") as f:
                async for chunk in r.content.iter_chunked(65536):
                    f.write(chunk)
    return f"сохранено: {dest} ({os.path.getsize(dest)} байт)"


@T("net_ssl_expiry", "Срок действия SSL-сертификата сайта", [P("host", desc="домен"), P("port", "integer", desc="порт", required=False, default=443)], C)
def _(ctx, host, port):
    ctxs = ssl.create_default_context()
    with socket.create_connection((host, port), timeout=8) as sock:
        with ctxs.wrap_socket(sock, server_hostname=host) as s:
            cert = s.getpeercert()
    return f"истекает: {cert.get('notAfter')}, субъект: {cert.get('subject', ((('commonName',''),),))[0][0][1]}"


@T("net_rss_read", "Прочитать RSS-ленту (заголовки + ссылки)", [P("url", desc="RSS url"), P("limit", "integer", desc="сколько", required=False, default=10)], C)
async def _(ctx, url, limit):
    import re as _re
    async with aiohttp.ClientSession(headers=UA) as s:
        async with s.get(url, timeout=aiohttp.ClientTimeout(total=20)) as r:
            xml = await r.text()
    items = _re.findall(r"<item[\s\S]*?</item>|<entry[\s\S]*?</entry>", xml)[:limit]
    out = []
    for it in items:
        t = _re.search(r"<title[^>]*>([\s\S]*?)</title>", it)
        l = _re.search(r"<link[^>]*>([\s\S]*?)</link>|<link[^>]*href=\"([^\"]+)\"", it)
        link = (l.group(1) or l.group(2)) if l else ""
        out.append(f"- {t.group(1).strip() if t else '?'} :: {link.strip()}")
    return "\n".join(out) or "пусто"


@T("net_whois_lite", "WHOIS-лайт: возраст домена через RDAP", [P("domain", desc="домен")], C)
async def _(ctx, domain):
    async with aiohttp.ClientSession() as s:
        async with s.get(f"https://rdap.org/domain/{domain}") as r:
            if r.status != 200:
                return f"RDAP {r.status}: нет данных"
            d = await r.json()
    ev = [e for e in d.get("events", []) if e.get("eventAction") in ("registration", "expiration")]
    return json.dumps(ev, ensure_ascii=False) or "нет событий"
