"""Математика, статистика, случайность (31)."""
from __future__ import annotations

import math
import random
import statistics as st
from math import comb, perm

from .registry import P, REG

C = "math"
T = REG.tool
NUM = lambda s: [float(x) for x in str(s).replace(",", " ").split()]


@T("math_eval", "Безопасно вычислить арифметическое выражение", [P("expr", desc="выражение (2+2*2, sqrt(16), pi)")], C)
def _(ctx, expr):
    import ast
    import operator as op
    ops = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv,
           ast.FloorDiv: op.floordiv, ast.Mod: op.mod, ast.Pow: op.pow, ast.USub: op.neg, ast.UAdd: op.pos}
    funcs = {"sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan, "log": math.log,
             "log10": math.log10, "abs": abs, "round": round, "min": min, "max": max, "exp": math.exp}
    consts = {"pi": math.pi, "e": math.e, "tau": math.tau}

    def ev(node):
        if isinstance(node, ast.Constant):
            return float(node.value)
        if isinstance(node, ast.BinOp):
            return ops[type(node.op)](ev(node.left), ev(node.right))
        if isinstance(node, ast.UnaryOp):
            return ops[type(node.op)](ev(node.operand))
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in funcs:
            return funcs[node.func.id](*[ev(a) for a in node.args])
        if isinstance(node, ast.Name) and node.id in consts:
            return consts[node.id]
        raise ValueError(f"unsupported: {ast.dump(node)}")

    return ev(ast.parse(expr, mode="eval").body)


@T("math_prime_check", "Простое ли число", [P("n", "integer", desc="число")], C)
def _(ctx, n):
    if n < 2:
        return "нет"
    i = 2
    while i * i <= n:
        if n % i == 0:
            return "нет"
        i += 1
    return "да"


@T("math_factorize", "Разложить число на простые множители", [P("n", "integer", desc="число")], C)
def _(ctx, n):
    out, d = [], 2
    while d * d <= n:
        while n % d == 0:
            out.append(d); n //= d
        d += 1
    if n > 1:
        out.append(n)
    return " * ".join(map(str, out)) or "1"


@T("math_gcd", "Наибольший общий делитель", [P("numbers", desc="числа через пробел")], C)
def _(ctx, numbers):
    from math import gcd
    from functools import reduce
    return reduce(gcd, [int(x) for x in numbers.split()])


@T("math_lcm", "Наименьшее общее кратное", [P("numbers", desc="числа через пробел")], C)
def _(ctx, numbers):
    from math import gcd
    from functools import reduce
    return reduce(lambda a, b: a * b // gcd(a, b), [int(x) for x in numbers.split()])


@T("math_fibonacci", "N-е число Фибоначчи (или ряд до N)", [P("n", "integer", desc="номер/длина"), P("series", "boolean", desc="весь ряд", required=False, default=False)], C)
def _(ctx, n, series):
    a, b, out = 0, 1, []
    for _ in range(n):
        out.append(a); a, b = b, a + b
    return out if series else out[-1]


@T("math_factorial", "Факториал числа", [P("n", "integer", desc="число")], C)
def _(ctx, n): return math.factorial(min(n, 5000))


@T("math_mean", "Среднее арифметическое", [P("numbers", desc="числа через пробел")], C)
def _(ctx, numbers): return st.mean(NUM(numbers))


@T("math_median", "Медиана", [P("numbers", desc="числа через пробел")], C)
def _(ctx, numbers): return st.median(NUM(numbers))


@T("math_mode", "Мода (самое частое значение)", [P("numbers", desc="числа через пробел")], C)
def _(ctx, numbers): return st.multimode(NUM(numbers))


@T("math_std", "Стандартное отклонение", [P("numbers", desc="числа через пробел")], C)
def _(ctx, numbers): return st.pstdev(NUM(numbers))


@T("math_variance", "Дисперсия", [P("numbers", desc="числа через пробел")], C)
def _(ctx, numbers): return st.pvariance(NUM(numbers))


@T("math_percentile", "Перцентиль P из списка", [P("numbers", desc="числа через пробел"), P("p", "number", desc="перцентиль 0-100")], C)
def _(ctx, numbers, p): return st.quantiles(NUM(numbers), n=100)[min(99, max(0, int(p) - 1))]


@T("math_min_max", "Мин и макс списка", [P("numbers", desc="числа через пробел")], C)
def _(ctx, numbers):
    v = NUM(numbers); return f"min={min(v)} max={max(v)}"


@T("math_percent", "Процент: часть от целого в %", [P("part", "number", desc="часть"), P("total", "number", desc="целое")], C)
def _(ctx, part, total): return part / total * 100 if total else 0


@T("math_percent_change", "Изменение в % между старым и новым", [P("old", "number", desc="старое"), P("new", "number", desc="новое")], C)
def _(ctx, old, new): return (new - old) / old * 100 if old else 0


@T("math_discount", "Цена со скидкой", [P("price", "number", desc="цена"), P("percent", "number", desc="скидка %")], C)
def _(ctx, price, percent): return price * (100 - percent) / 100


@T("math_tip_split", "Счёт на компанию с чаевыми", [P("bill", "number", desc="сумма"), P("people", "integer", desc="человек"), P("tip_percent", "number", desc="чаевые %", required=False, default=10)], C)
def _(ctx, bill, people, tip_percent): return round(bill * (1 + tip_percent / 100) / max(1, people), 2)


@T("math_bmi", "Индекс массы тела", [P("weight_kg", "number", desc="вес кг"), P("height_cm", "number", desc="рост см")], C)
def _(ctx, weight_kg, height_cm):
    bmi = weight_kg / (height_cm / 100) ** 2
    cat = "недобор" if bmi < 18.5 else "норма" if bmi < 25 else "избыток" if bmi < 30 else "ожирение"
    return f"ИМТ={bmi:.1f} ({cat})"


@T("math_loan_payment", "Ежемесячный платёж по кредиту (аннуитет)", [P("amount", "number", desc="сумма"), P("annual_percent", "number", desc="ставка % годовых"), P("months", "integer", desc="месяцев")], C)
def _(ctx, amount, annual_percent, months):
    r = annual_percent / 100 / 12
    p = amount * (r * (1 + r) ** months) / ((1 + r) ** months - 1) if r else amount / months
    return round(p, 2)


@T("math_compound_interest", "Сложный процент: итоговая сумма", [P("principal", "number", desc="вклад"), P("annual_percent", "number", desc="% годовых"), P("years", "number", desc="лет"), P("compounds_per_year", "integer", desc="капитализаций в год", required=False, default=12)], C)
def _(ctx, principal, annual_percent, years, compounds_per_year):
    n = compounds_per_year
    return round(principal * (1 + annual_percent / 100 / n) ** (n * years), 2)


@T("math_random_int", "Случайное целое в диапазоне", [P("lo", "integer", desc="от"), P("hi", "integer", desc="до")], C)
def _(ctx, lo, hi): return random.randint(lo, hi)


@T("math_random_float", "Случайное вещественное 0..1 (или 0..N)", [P("hi", "number", desc="до", required=False, default=1.0)], C)
def _(ctx, hi): return random.uniform(0, hi)


@T("math_dice", "Бросить кубики NdM", [P("count", "integer", desc="число кубиков", required=False, default=2), P("sides", "integer", desc="граней", required=False, default=6)], C)
def _(ctx, count, sides):
    rolls = [random.randint(1, sides) for _ in range(max(1, count))]
    return f"{rolls} сумма={sum(rolls)}"


@T("math_coin", "Подбросить монетку", [], C)
def _(ctx): return "орёл" if random.random() < 0.5 else "решка"


@T("math_choice", "Выбрать случайный элемент списка", [P("items", desc="варианты через перенос строки")], C)
def _(ctx, items): return random.choice([i for i in items.split("\n") if i.strip()])


@T("math_shuffle_list", "Перемешать список", [P("items", desc="элементы через перенос строки")], C)
def _(ctx, items):
    ls = [i for i in items.split("\n") if i.strip()]
    random.shuffle(ls)
    return "\n".join(ls)


@T("math_combinations", "Число сочетаний C(n,k)", [P("n", "integer", desc="n"), P("k", "integer", desc="k")], C)
def _(ctx, n, k): return comb(n, k)


@T("math_permutations", "Число размещений P(n,k)", [P("n", "integer", desc="n"), P("k", "integer", desc="k")], C)
def _(ctx, n, k): return perm(n, k)


@T("math_base_convert", "Число в другую систему счисления (bin/oct/hex)", [P("n", "integer", desc="число"), P("base", "integer", desc="основание 2/8/16", required=False, default=16)], C)
def _(ctx, n, base):
    digs = "0123456789abcdef"
    neg = n < 0
    n = abs(n)
    out = ""
    while n:
        out = digs[n % base] + out
        n //= base
    return ("-" if neg else "") + (out or "0")


@T("math_round", "Округлить число до знака", [P("value", "number", desc="число"), P("digits", "integer", desc="знаков", required=False, default=2)], C)
def _(ctx, value, digits): return round(value, digits)


@T("math_hypot", "Гипотенуза / длина вектора", [P("a", "number", desc="катет a"), P("b", "number", desc="катет b")], C)
def _(ctx, a, b): return math.hypot(a, b)


@T("math_sum_series", "Сумма и среднее ряда чисел", [P("numbers", desc="числа через пробел")], C)
def _(ctx, numbers):
    v = NUM(numbers)
    return f"sum={sum(v)} mean={sum(v)/len(v)} n={len(v)}"
