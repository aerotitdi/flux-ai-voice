"""Агрегация всех семейств инструментов + единая точка входа."""
from __future__ import annotations

from . import registry  # noqa: F401
from .registry import P, REG, ToolResult, ToolSpec  # noqa: F401
from . import text      # noqa: F401,E402
from . import encode    # noqa: F401,E402
from . import convert   # noqa: F401,E402
from . import dt        # noqa: F401,E402
from . import math_tools  # noqa: F401,E402
from . import net       # noqa: F401,E402
from . import files     # noqa: F401,E402
from . import codrun    # noqa: F401,E402
from . import browser   # noqa: F401,E402
from . import search    # noqa: F401,E402
from . import voice     # noqa: F401,E402
from . import memory    # noqa: F401,E402
from . import formats   # noqa: F401,E402
from . import misc      # noqa: F401,E402
from . import computer  # noqa: F401,E402

REG.build_idf()


def count() -> int:
    return len(REG.tools)
