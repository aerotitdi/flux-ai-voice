"""Прогон кода: выбор движка (python, java, c, cpp, go, rust, ...). Пункт 5 ТЗ."""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile

from .registry import P, REG, ToolResult

C = "code"

ENGINES: dict[str, dict] = {
    "python":     {"label": "Python", "ext": ".py", "bin": ["python3", "python"], "run": ["{bin}", "{file}"]},
    "javascript": {"label": "JavaScript (Node.js)", "ext": ".js", "bin": ["node"], "run": ["{bin}", "{file}"]},
    "typescript": {"label": "TypeScript (tsx/ts-node)", "ext": ".ts", "bin": ["tsx", "ts-node", "deno run"], "run": ["{bin}", "{file}"]},
    "java":       {"label": "Java (single-file, JDK 11+)", "ext": ".java", "bin": ["java"], "run": ["{bin}", "{file}"]},
    "c":          {"label": "C (gcc)", "ext": ".c", "bin": ["gcc", "cc", "clang"], "compile": ["{bin}", "{file}", "-o", "{out}"], "run": ["{out}"]},
    "cpp":        {"label": "C++ (g++)", "ext": ".cpp", "bin": ["g++", "clang++"], "compile": ["{bin}", "-std=c++17", "{file}", "-o", "{out}"], "run": ["{out}"]},
    "go":         {"label": "Go", "ext": ".go", "bin": ["go"], "run": ["{bin}", "run", "{file}"]},
    "rust":       {"label": "Rust (rustc)", "ext": ".rs", "bin": ["rustc"], "compile": ["{bin}", "-O", "{file}", "-o", "{out}"], "run": ["{out}"]},
    "ruby":       {"label": "Ruby", "ext": ".rb", "bin": ["ruby"], "run": ["{bin}", "{file}"]},
    "php":        {"label": "PHP", "ext": ".php", "bin": ["php"], "run": ["{bin}", "{file}"]},
    "bash":       {"label": "Bash", "ext": ".sh", "bin": ["bash"], "run": ["{bin}", "{file}"]},
    "powershell": {"label": "PowerShell", "ext": ".ps1", "bin": ["pwsh", "powershell"], "run": ["{bin}", "-NoProfile", "-File", "{file}"]},
    "sql":        {"label": "SQL (SQLite, in-memory)", "ext": ".sql", "bin": ["sqlite3"], "run": ["{bin}", "-init", "{file}", ":memory:"]},
    "lua":        {"label": "Lua", "ext": ".lua", "bin": ["lua", "lua5.4", "lua5.3"], "run": ["{bin}", "{file}"]},
    "perl":       {"label": "Perl", "ext": ".pl", "bin": ["perl"], "run": ["{bin}", "{file}"]},
    "kotlin":     {"label": "Kotlin (script)", "ext": ".kts", "bin": ["kotlinc", "kotlin"], "run": ["{bin}", "-script", "{file}"]},
}


def engine_available(eid: str) -> bool:
    e = ENGINES.get(eid)
    if not e:
        return False
    return any(shutil.which(b.split()[0]) for b in e["bin"])


def available_engines() -> list[dict]:
    return [{"id": k, "label": v["label"], "installed": engine_available(k)} for k, v in ENGINES.items()]


def _find_bin(e: dict) -> str:
    for b in e["bin"]:
        head = b.split()[0]
        if shutil.which(head):
            return b
    raise RuntimeError(f"движок не установлен: {e['label']} (нужен бинарь: {e['bin'][0]})")


def run_code(engine: str, code: str, stdin: str = "", timeout: int = 20) -> dict:
    e = ENGINES.get(engine)
    if not e:
        return {"ok": False, "error": f"неизвестный движок {engine}. Доступны: {', '.join(ENGINES)}"}
    tmp = tempfile.mkdtemp(prefix="fluxcode_")
    src = os.path.join(tmp, ("Main" if engine == "java" else "main") + e["ext"])
    with open(src, "w", encoding="utf-8") as f:
        f.write(code)
    out_bin = os.path.join(tmp, "a.out" if os.name != "nt" else "a.exe")
    argv_compile = None
    try:
        binv = _find_bin(e)
        if "compile" in e:
            argv_compile = [p.format(bin=binv, file=src, out=out_bin) for p in e["compile"]]
        argv_run = [p.format(bin=binv, file=src, out=out_bin) for p in e["run"]]
    except RuntimeError as ex:
        return {"ok": False, "error": str(ex)}

    proc_log = []
    try:
        if argv_compile:
            r = subprocess.run(argv_compile, capture_output=True, text=True, timeout=timeout, cwd=tmp)
            proc_log.append(f"[compile rc={r.returncode}] {r.stderr.strip()[:2000]}")
            if r.returncode != 0:
                return {"ok": False, "error": "\n".join(proc_log), "stdout": r.stdout[:2000]}
        r = subprocess.run(argv_run, capture_output=True, text=True, timeout=timeout, cwd=tmp,
                           input=stdin or None)
        out = (r.stdout or "")[:6000]
        err = (r.stderr or "")[:3000]
        return {"ok": r.returncode == 0, "engine": engine, "rc": r.returncode,
                "stdout": out, "stderr": err, "log": "\n".join(proc_log)}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"таймаут {timeout}с"}
    except Exception as ex:
        return {"ok": False, "error": f"{type(ex).__name__}: {ex}"}


from .registry import REG as _R

_R.tool("code_engines_list", "Список движков прогона кода и их доступность", [], C, core=True)(
    lambda ctx: "\n".join(f"{e['id']}: {e['label']} {'[установлен]' if e['installed'] else '[НЕТ в системе]'}"
                          for e in available_engines()))

_R.tool("code_test", "Прогнать код на выбранном движке и вернуть stdout/stderr",
        [P("code", desc="исходный код"), P("engine", desc="движок", required=False, default="python",
           enum=list(ENGINES)), P("stdin", desc="входные данные", required=False, default="")], C, core=True)(
    lambda ctx, code, engine, stdin: _fmt(run_code(engine, code, stdin)))


def _fmt(res: dict) -> str:
    if not res.get("ok") and res.get("error"):
        return f"ОШИБКА: {res['error']}\n{res.get('stdout','')}"
    return f"rc={res.get('rc')}\nSTDOUT:\n{res.get('stdout','(пусто)')}\nSTDERR:\n{res.get('stderr','')}"


for _eid, _e in ENGINES.items():
    def _mk(eid):
        def handler(ctx, code, stdin=""):
            return _fmt(run_code(eid, code, stdin))
        return handler
    _R.tool(f"run_{_eid}", f"Выполнить код: {_e['label']}",
            [P("code", desc="исходный код"), P("stdin", desc="входные данные", required=False, default="")], C)(_mk(_eid))
