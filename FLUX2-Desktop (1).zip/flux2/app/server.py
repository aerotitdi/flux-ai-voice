"""HTTP-сервер FLUX 2.0: UI, SSE-чат, STT/TTS, CRUD подключений, CDP-хелперы."""
from __future__ import annotations

import asyncio
import json
import os

from aiohttp import web

from . import agent, bridge, voicelab
from .config import CONFIG, app_dir
from .tools import REG

UI_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ui")

HISTORIES: dict[str, list] = {}


def _mask(conn: dict) -> dict:
    c = dict(conn)
    k = c.get("api_key") or ""
    c["api_key_masked"] = (k[:4] + "…" + k[-4:]) if len(k) > 10 else ("*" * len(k) if k else "")
    c["api_key"] = k  # локально ключ виден только своему UI
    return c


async def index(request):
    return web.FileResponse(os.path.join(UI_DIR, "index.html"))


async def favicon(request):
    return web.FileResponse(os.path.join(UI_DIR, "flux.ico"))


async def api_state(request):
    mics = await asyncio.to_thread(voicelab.list_mics)
    return web.json_response({
        "settings": CONFIG.settings,
        "voice": CONFIG.voice,
        "connections": [_mask(c) for c in CONFIG.connections],
        "mics": mics,
        "tools_count": len(REG.tools),
        "tools_categories": REG.categories(),
    })


async def api_settings(request):
    data = await request.json()
    for k, v in (data.get("settings") or {}).items():
        CONFIG.settings[k] = v
    for k, v in (data.get("voice") or {}).items():
        CONFIG.voice[k] = v
    CONFIG.save()
    return web.json_response({"ok": True})


async def api_conn_save(request):
    conn = await request.json()
    saved = CONFIG.upsert_connection(conn)
    return web.json_response({"ok": True, "id": saved["id"]})


async def api_conn_delete(request):
    cid = (await request.json()).get("id")
    CONFIG.delete_connection(cid)
    return web.json_response({"ok": True})


async def api_conn_models(request):
    conn = await request.json()
    from . import providers
    try:
        models = await providers.fetch_models(conn)
        return web.json_response({"ok": True, "models": models})
    except Exception as e:
        return web.json_response({"ok": False, "error": str(e)})


async def api_conn_test(request):
    conn = await request.json()
    from . import providers
    res = await providers.test_connection(conn)
    return web.json_response(res)


async def api_voices(request):
    vs = await voicelab.voice_list_async()
    return web.json_response({"ok": True, "voices": vs})


async def api_chat(request):
    data = await request.json()
    text = (data.get("text") or "").strip()
    sid = data.get("sid", "default")
    hist = HISTORIES.setdefault(sid, [])
    if data.get("reset"):
        hist.clear()
        return web.json_response({"ok": True})
    if not text:
        return web.json_response({"ok": False, "error": "пусто"})

    resp = web.StreamResponse(headers={"Content-Type": "text/event-stream",
                                       "Cache-Control": "no-cache"})
    await resp.prepare(request)

    async def on_event(ev: dict):
        await resp.write(("data: " + json.dumps(ev, ensure_ascii=False) + "\n\n").encode())

    try:
        await agent.run_turn(text, hist, on_event, cookies=data.get("cookies"))
    except Exception as e:
        await on_event({"type": "error", "text": f"{type(e).__name__}: {e}"})
    await resp.write(b"data: {\"type\": \"stream_end\"}\n\n")
    return resp


async def api_stt(request):
    audio = await request.read()
    txt = await voicelab.transcribe_auto(audio)
    if txt is None:
        return web.json_response({"ok": False, "error": "STT недоступен на бэкенде; используй браузерное распознавание"},
                                 status=501)
    return web.json_response({"ok": True, "text": txt})


async def api_tts(request):
    text = request.query.get("text", "")[:2000]
    voice = request.query.get("voice") or CONFIG.voice.get("voice")
    rate, pitch = CONFIG.voice.get("rate", 0), CONFIG.voice.get("pitch", 0)
    engine = CONFIG.voice.get("tts_engine", "winget")
    if engine in ("winget", "auto"):
        url = await voicelab.winget_url(text, voice, rate, pitch)
        if url:
            asyncio.create_task(voicelab._save_copy(url))
            raise web.HTTPFound(url)   # плеер стримит mp3 напрямую, без перекачки
        if engine == "winget":
            return web.json_response({"ok": False, "error": "wingetgui недоступен"}, status=502)
    path = await voicelab.synth_to_file(text, voice)
    if not path:
        return web.json_response({"ok": False, "error": "edge-tts не установлен"}, status=501)
    return web.FileResponse(path, headers={"Content-Type": "audio/mpeg"})


async def api_shots(request):
    name = os.path.basename(request.match_info["name"])
    return web.FileResponse(os.path.join(app_dir(), "data", "shots", name))


async def api_audio(request):
    name = os.path.basename(request.match_info["name"])
    return web.FileResponse(os.path.join(app_dir(), "data", "audio", name))


async def api_cdp(request):
    """Жив ли браузер-мост: расширение FLUX Bridge, 9222 или DevToolsActivePort."""
    from . import browser_cdp as cdp
    if bridge.online():
        try:
            tabs = await bridge.call({"cmd": "targets"})
            return web.json_response({"ok": True, "browser": "Chrome (расширение FLUX Bridge, живой)", "tabs": len(tabs)})
        except Exception as e:
            return web.json_response({"ok": False, "error": str(e)[:120]})
    if await cdp.discover():
        try:
            v = await cdp.version()
            tabs = await cdp.targets()
            return web.json_response({"ok": True, "browser": v.get("Browser", ""), "tabs": len(tabs)})
        except Exception as e:
            return web.json_response({"ok": False, "error": str(e)[:120]})
    if cdp.chrome_running():
        return web.json_response({"ok": False, "error": cdp.FRIENDLY_HINT})
    return web.json_response({"ok": False, "error": "браузер не запущен; FLUX поднимет его при первом browser-тулзе"})


async def api_browser_launch(request):
    from . import browser_cdp as cdp
    ok = await cdp.ensure_ready()
    return web.json_response({"ok": ok})


async def api_tools(request):
    q = request.query.get("q", "")
    specs = REG.search(q, int(request.query.get("k", 20))) if q else list(REG.tools.values())[:50]
    return web.json_response({"count": len(REG.tools),
                              "tools": [{"name": s.name, "desc": s.description, "cat": s.category} for s in specs]})


async def api_runcode(request):
    """Интерпретатор кода для кнопок «▶ запустить» у код-блоков в чате."""
    from .tools import codrun
    data = await request.json()
    res = await asyncio.to_thread(codrun.run_code, data.get("engine", "python"),
                                  data.get("code", ""), data.get("stdin", ""), 25)
    return web.json_response(res)


def build_app() -> web.Application:
    app = web.Application(client_max_size=40 * 1024 * 1024)
    app.router.add_get("/", index)
    app.router.add_get("/favicon.ico", favicon)
    app.router.add_get("/api/state", api_state)
    app.router.add_post("/api/settings", api_settings)
    app.router.add_post("/api/conn/save", api_conn_save)
    app.router.add_post("/api/conn/delete", api_conn_delete)
    app.router.add_post("/api/conn/models", api_conn_models)
    app.router.add_post("/api/conn/test", api_conn_test)
    app.router.add_get("/api/voices", api_voices)
    app.router.add_post("/api/chat", api_chat)
    app.router.add_post("/api/stt", api_stt)
    app.router.add_get("/api/tts", api_tts)
    app.router.add_get("/api/shots/{name}", api_shots)
    app.router.add_get("/api/audio/{name}", api_audio)
    app.router.add_post("/api/browser/launch", api_browser_launch)
    app.router.add_get("/api/cdp", api_cdp)
    app.router.add_get("/bridge", bridge.ws_bridge)
    app.router.add_get("/api/tools", api_tools)
    app.router.add_post("/api/runcode", api_runcode)
    return app
