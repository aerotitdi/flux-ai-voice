---
name: computer-control
description: Управление компьютером как JARVIS: окна ОС, мышь, клавиатура, скриншоты, OCR, процессы
---
# Computer Control
1. Окна ОС: os_windows_list -> os_window_focus/minimize/maximize/restore/close/move;
   «сверни браузер» = os_window_minimize(title="chrome") или browser-тулзы для вкладок.
   Свернуть всё: os_minimize_all.
2. Ввод: keyboard_type / keyboard_press / keyboard_hotkey ("ctrl+c", "win+d");
   мышь: mouse_click/move/drag/scroll/position.
3. Экран: screen_screenshot (PNG приходит картинкой в чат), ocr_screen для текста с экрана,
   ui_tree для элементов окна (нужен pywinauto).
4. Процессы и shell: proc_list/proc_kill/proc_start, shell_run, app_launch, clipboard_get_set.
5. Перед кликами по координатам сначала screen_screenshot, чтобы увидеть, куда кликать.
